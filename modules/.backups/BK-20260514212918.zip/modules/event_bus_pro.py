# -*- coding: utf-8 -*-
"""
        AUTO-EVO-AI v7.0 - EventBusPro 企业级事件总线
==============================================
分布式事件总线：发布/订阅/事件溯源/CQRS/顺序保证/死信/重放。
支持：同步/异步分发、通配符订阅、事件持久化、因果顺序、
      消费者组、事件回溯、Schema验证、流量整形。

        A级生产标准：EnterpriseModule继承 + 链路追踪 + Prometheus + 审计 + 熔断 + 限流
"""
import time
import asyncio
import json
import logging
import re
import fnmatch
from datetime import datetime
from typing import Any, Dict, List, Optional, Callable, Set, Awaitable
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
from abc import ABC, abstractmethod
import uuid

from modules._base.enterprise_module import EnterpriseModule, ModuleStatus
from modules._base.metrics import prometheus_timer, metrics_collector
from modules._base.circuit_breaker import CircuitBreakerMixin
from modules._base.rate_limiter import RateLimiterMixin

class EventPriority(int, Enum):
    LOW = 0
    NORMAL = 5
    HIGH = 10
    CRITICAL = 15


class ConsumerAck(str, Enum):
    ACK = "ack"
    NACK = "nack"
    REQUEUE = "requeue"


@dataclass
class DomainEvent:
    """领域事件"""
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    event_type: str = ""
    aggregate_id: str = ""      # 聚合根ID
    aggregate_type: str = ""    # 聚合根类型
    payload: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    causation_id: Optional[str] = None  # 因果链
    correlation_id: Optional[str] = None
    source: str = "auto-evo-ai"
    version: int = 1
    priority: EventPriority = EventPriority.NORMAL
    trace_id: Optional[str] = None
    sequence_number: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
    "event_id": self.event_id, "event_type": self.event_type,
    "aggregate_id": self.aggregate_id, "aggregate_type": self.aggregate_type,
    "payload": self.payload, "metadata": self.metadata, "timestamp": self.timestamp,
    "causation_id": self.causation_id, "correlation_id": self.correlation_id,
    "source": self.source, "version": self.version, "priority": self.priority.value,
    "trace_id": self.trace_id, "sequence_number": self.sequence_number
    }


@dataclass
class Subscription:
    """订阅"""
    subscription_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    event_pattern: str = "*"           # 支持通配符如 "task.*" 或 "alert.*.triggered"
    handler: Optional[Callable] = None
    async_handler: Optional[Callable] = None
    consumer_group: str = "default"
    priority: EventPriority = EventPriority.NORMAL
    filter_expr: Optional[str] = None  # 简单过滤表达式
    max_retries: int = 3
    active: bool = True
    subscribed_at: str = field(default_factory=lambda: datetime.now().isoformat())
    delivered_count: int = 0
    error_count: int = 0
    last_delivered: Optional[str] = None

    def matches(self, event_type: str) -> bool:
        """通配符匹配"""
        return fnmatch.fnmatch(event_type, self.event_pattern)


@dataclass
class EventEnvelope:
    """事件信封（含投递状态）"""
    event: DomainEvent
    subscription: Subscription
    delivery_count: int = 0
    max_deliveries: int = 3
    status: str = "pending"
    ack_deadline_seconds: float = 30.0
    scheduled_at: Optional[str] = None
    last_error: Optional[str] = None


# ============================================================================
# EventBusPro 主类
# ============================================================================

class EventDispatchEngine(object):
    """事件分发引擎 - 负责事件路由、匹配、优先级排序和消费者分发"""

    def __init__(self):
        self._dispatch_count: int = 0
        self._dispatch_errors: int = 0
        self._wildcard_cache: Dict[str, List[str]] = {}
        self._priority_queue_size: int = 0
        self._avg_dispatch_latency_ms: float = 0.0

    def match_subscriptions(self, event_type: str, subscriptions: Dict[str, list]) -> List:
        """匹配事件类型到订阅者，支持通配符"""
        matched = []
        for pattern, subs in subscriptions.items():
            if fnmatch.fnmatch(event_type, pattern):
                matched.extend(subs)
        return matched

    def rank_by_priority(self, envelopes: List) -> List:
        """按优先级排序事件"""
        return sorted(envelopes, key=lambda e: e.priority.value, reverse=True)

    def calculate_backpressure(self, queue_depth: int, max_depth: int) -> float:
        """计算背压系数 0.0~1.0"""
        if max_depth <= 0:
            return 1.0
        return min(1.0, queue_depth / max_depth)

    def record_dispatch(self, latency_ms: float, error: bool = False) -> None:
        """记录分发指标"""
        self._dispatch_count += 1
        if error:
            self._dispatch_errors += 1
        alpha = 0.1
        self._avg_dispatch_latency_ms = (alpha * latency_ms +
            (1 - alpha) * self._avg_dispatch_latency_ms)

    def get_metrics(self) -> Dict[str, Any]:
        """获取引擎指标"""
        return {
            "dispatch_count": self._dispatch_count,
            "dispatch_errors": self._dispatch_errors,
            "error_rate": round(self._dispatch_errors / max(self._dispatch_count, 1), 6),
            "avg_latency_ms": round(self._avg_dispatch_latency_ms, 2),
            "wildcard_cache_size": len(self._wildcard_cache),
        }


class EventBusPro(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    企业级事件总线
    
    功能：
      - 同步/异步事件发布
      - 通配符模式订阅 (task.*, alert.**)
      - 消费者组（同一组内负载均衡）
      - 事件溯源（持久化所有事件）
      - 因果链追踪（causation_id / correlation_id）
      - 事件Schema验证
      - 死信处理
      - 事件回溯重放
      - 优先级队列
      - 背压控制
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):

        super().__init__()
        self.metric = type("M", (), {
        "__call__": lambda *a, **k: None,
        "counter": lambda *a, **k: type("_R", (), {"inc": lambda s,*a:None, "labels": lambda s,*a:s})(),
        "histogram": lambda *a, **k: type("_R", (), {"observe": lambda s,*a:None, "labels": lambda s,*a:s})(),
    })()
        self.config = config or {}
        # 订阅表: pattern -> [Subscription]
        self._subscriptions: Dict[str, List[Subscription]] = defaultdict(list)
        # 消费者组: group_name -> {pattern: [Subscription]}
        self._consumer_groups: Dict[str, Dict[str, List[Subscription]]] = defaultdict(lambda: defaultdict(list))
        # 事件存储（溯源）
        self._event_store: List[DomainEvent] = []
        self._event_store_max: int = self.config.get("event_store_max", 100000)
        # 序列号生成器
        self._sequence_counter: int = 0
        # 待投递队列（优先级堆）
        self._pending_envelopes: asyncio.PriorityQueue = asyncio.PriorityQueue(maxsize=100000)
        # 投递工作协程
        self._dispatchers: List[asyncio.Task] = []
        self._dispatcher_count: int = self.config.get("dispatcher_count", 4)
        # 死信队列
        self._dead_letters: List[EventEnvelope] = []
        # Schema注册（简易JSON Schema验证）
        self._schemas: Dict[str, Dict[str, Any]] = {}
        # 统计
        self._bus_stats = {
            "events_published": 0, "events_delivered": 0,
            "events_failed": 0, "events_dead_letter": 0,
            "subscriptions_count": 0, "consumer_groups_count": 0
        }
        # 背压信号
        self._backpressure = False
        self._queue_high_watermark = self.config.get("queue_high_watermark", 80000)
        self._queue_low_watermark = self.config.get("queue_low_watermark", 30000)

    # ----------------------------------------------------------------
    # 生命周期
    # ----------------------------------------------------------------

    def initialize(self) -> Result:
        """初始化：启动调度器 + 加载Schema"""
        try:
            self._update_status(ModuleStatus.INITIALIZING)
            # 启动调度工作协程
            for i in range(self._dispatcher_count):
                task = asyncio.create_task(self._dispatch_worker(f"dispatcher-{i}"))
                self._dispatchers.append(task)
            # 加载预定义Schema
            for event_type, schema in self.config.get("schemas", {}).items():
                self.register_schema(event_type, schema)
            self._update_status(ModuleStatus.RUNNING)
            self.audit("eventbus.initialized", {"dispatchers": self._dispatcher_count, "schemas": len(self._schemas)})
            logger.info(f"[EventBusPro] 初始化完成: {self._dispatcher_count} dispatchers")
            return Result(success=True, data={"dispatchers": self._dispatcher_count})
        except Exception as e:
            self._update_status(ModuleStatus.ERROR)
            logger.error(f"[EventBusPro] 初始化失败: {e}", exc_info=True)
            return Result(success=False, error=str(e))

        """统一执行入口 — 根据action路由到对应业务方法"""
        

        metrics_collector.counter("event_bus_ops_total", labels={"action": action})
        params = params or {}
        actions = {
            "register_schema": self.register_schema,
            "validate_event": self.validate_event,
            "subscribe": self.subscribe,
            "unsubscribe": self.unsubscribe,
            "list_subscriptions": self.list_subscriptions,
            "publish": self.publish,
            "publish_sync": self.publish_sync,
            "replay_events": self.replay_events,
            "get_aggregate_history": self.get_aggregate_history,
            "get_stats": self.get_stats,
            "get_dead_letters": self.get_dead_letters,
            "list_actions": lambda: list(actions.keys()),
            "help": lambda: {"actions": list(actions.keys()), "usage": "execute(action, params)"},
        }

        if action not in actions:
            self.metrics_collector.counter("execute_total", 1, tags={"action": action, "status": "unknown", "module": "event_bus_pro"})
            return {"status": "error", "message": f"Unknown action: {action}", "available": list(actions.keys())}

        handler = actions[action]
        if callable(handler) and not isinstance(handler, list):
            import inspect
            if inspect.iscoroutinefunction(handler):
                try:
                    sig = inspect.signature(handler)
                    if len(sig.parameters) <= 1:
                        result = handler()
                    else:
                        result = handler(**params)
                except Exception as e:
                    self.metrics_collector.counter("execute_error", 1, tags={"action": action, "error_type": type(e).__name__, "module": "event_bus_pro"})
                    return {"status": "error", "message": str(e)}
            else:
                try:
                    sig = inspect.signature(handler)
                    if len(sig.parameters) <= 1:
                        result = handler()
                    else:
                        result = handler(**params)
                except Exception as e:
                    self.metrics_collector.counter("execute_error", 1, tags={"action": action, "error_type": type(e).__name__, "module": "event_bus_pro"})
                    return {"status": "error", "message": str(e)}
            self.metrics_collector.counter("execute_total", 1, tags={"action": action, "status": "success", "module": "event_bus_pro"})
            if isinstance(result, dict):
                return {"status": "success", **result}
            return {"status": "success", "data": result}

    def health_check(self) -> HealthReport:
        """健康检查"""
        workers_ok = all(not w.done() for w in self._dispatchers)
        checks = {
            "dispatchers_alive": workers_ok,
            "pending_queue_size": self._pending_envelopes.qsize(),
            "backpressure_active": self._backpressure,
            "subscriptions_count": len(self._subscriptions),
            "event_store_size": len(self._event_store),
        }
        healthy = workers_ok and not self._backpressure
        return HealthReport(
            status="running" if healthy else "degraded",
            healthy=healthy, last_beat=datetime.now().isoformat(),
            uptime_seconds=self.stats.uptime_seconds, checks_run=5,
            error_rate=self.stats.error_rate, details=checks, version="v7.0"
        )

    def shutdown(self) -> Result:
        """优雅关闭"""
        try:
            self._update_status(ModuleStatus.STOPPING)
            for _ in self._dispatchers:
                self._pending_envelopes.put((999, None, None, None))
            for w in self._dispatchers:
                w.cancel()
            asyncio.gather(*self._dispatchers, return_exceptions=True)
            self._dispatchers.clear()
            self._update_status(ModuleStatus.STOPPED)
            self.audit("eventbus.shutdown", {"event_store": len(self._event_store)})
            logger.info("[EventBusPro] 关闭完成")
            return Result(success=True)
        except Exception as e:
            return Result(success=False, error=str(e))

    # ----------------------------------------------------------------
    # Schema管理
    # ----------------------------------------------------------------

    def register_schema(self, event_type: str, schema: Dict[str, Any]):
        """注册事件Schema"""
        self._schemas[event_type] = schema

    def validate_event(self, event: DomainEvent) -> bool:
        """验证事件是否符合Schema"""
        schema = self._schemas.get(event.event_type)
        if not schema:
            return True  # 无Schema=不验证
        try:
            required = schema.get("required", [])
            for field_name in required:
                if field_name not in event.payload:
                    return False
            payload_types = schema.get("types", {})
            for field_name, expected_type in payload_types.items():
                if field_name in event.payload:
                    actual = type(event.payload[field_name]).__name__
                    if actual != expected_type:
                        return False
            return True
        except Exception:
            return True

    # ----------------------------------------------------------------
    # 订阅管理
    # ----------------------------------------------------------------

    def subscribe(self, event_pattern: str, handler: Callable, *,
                   consumer_group: str = "default", priority: EventPriority = EventPriority.NORMAL,
                   async_handler: bool = False, max_retries: int = 3) -> str:
        """订阅事件"""
        sub = Subscription(
            event_pattern=event_pattern, handler=None if async_handler else handler,
            async_handler=handler if async_handler else None,
            consumer_group=consumer_group, priority=priority, max_retries=max_retries
        )
        self._subscriptions[event_pattern].append(sub)
        self._consumer_groups[consumer_group][event_pattern].append(sub)
        self._bus_stats["subscriptions_count"] = sum(len(v) for v in self._subscriptions.values())
        self._bus_stats["consumer_groups_count"] = len(self._consumer_groups)
        self.audit("subscription.created", {"id": sub.subscription_id, "pattern": event_pattern})
        return sub.subscription_id

    def unsubscribe(self, subscription_id: str) -> Result:
        """取消订阅"""
        for pattern, subs in self._subscriptions.items():
            for i, sub in enumerate(subs):
                if sub.subscription_id == subscription_id:
                    sub.active = False
                    subs.pop(i)
                    self.audit("subscription.removed", {"id": subscription_id})
                    return Result(success=True, data={"subscription_id": subscription_id})
        return Result(success=False, error=f"订阅不存在: {subscription_id}")

    def list_subscriptions(self, consumer_group: Optional[str] = None) -> List[Dict]:
        """列出订阅"""
        result = []
        for pattern, subs in self._subscriptions.items():
            for s in subs:
                if consumer_group and s.consumer_group != consumer_group:
                    continue
                result.append({
                    "id": s.subscription_id, "pattern": s.event_pattern,
                    "group": s.consumer_group, "priority": s.priority.value,
                    "active": s.active, "delivered": s.delivered_count, "errors": s.error_count
                })
        return result

    # ----------------------------------------------------------------
    # 事件发布
    # ----------------------------------------------------------------

    def publish(self, event_type: str, payload: Dict[str, Any], *,
                       aggregate_id: str = "", aggregate_type: str = "",
                       correlation_id: Optional[str] = None,
                       causation_id: Optional[str] = None,
                       source: str = "auto-evo-ai",
                       priority: EventPriority = EventPriority.NORMAL) -> Result:
        """
        发布事件
        
        Args:
            event_type: 事件类型（如 "task.completed"）
            payload: 事件载荷
            aggregate_id: 聚合根ID
            aggregate_type: 聚合根类型
            correlation_id: 关联ID（同一业务链路）
            causation_id: 因果ID（触发当前事件的源事件ID）
            priority: 优先级
        """
        start = time.time()
        try:
            with self.trace("publish"):
                if not self.rate_limit(f"publish:{event_type}", max_per_second=1000):
                    return Result(success=False, error="rate_limited")
                # 构建事件
                self._sequence_counter += 1
                event = DomainEvent(
                    event_type=event_type, payload=payload,
                    aggregate_id=aggregate_id, aggregate_type=aggregate_type,
                    correlation_id=correlation_id, causation_id=causation_id,
                    source=source, priority=priority,
                    sequence_number=self._sequence_counter
                )
                # Schema验证
                if not self.validate_event(event):
                    self.stats.record_request((time.time() - start) * 1000, False, "schema_validation_failed")
                    return Result(success=False, error=f"Schema验证失败: {event_type}")
                # 持久化到事件存储
                self._append_to_store(event)
                # 匹配订阅者
                matched_subs = self._match_subscriptions(event)
                if not matched_subs:
                    self._bus_stats["events_published"] += 1
                    self.stats.record_request((time.time() - start) * 1000, True)
                    return Result(success=True, data={"event_id": event.event_id, "matched": 0})
                # 入队
                for sub in matched_subs:
                    envelope = EventEnvelope(event=event, subscription=sub, max_deliveries=sub.max_retries)
                    self._pending_envelopes.put((-event.priority.value, event.timestamp, event.event_id, envelope))
                # 背压检测
                if self._pending_envelopes.qsize() >= self._queue_high_watermark:
                    self._backpressure = True
                    logger.warning("[EventBusPro] 背压激活")
                self._bus_stats["events_published"] += 1
                latency = (time.time() - start) * 1000
                self.stats.record_request(latency, True)
                return Result(success=True, data={"event_id": event.event_id, "matched": len(matched_subs)})
        except Exception as e:
            latency = (time.time() - start) * 1000
            self.stats.record_request(latency, False, str(e))
            return Result(success=False, error=str(e))

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None):
        """Execute event bus pro actions"""
        params = params or {}
        try:
            if action in ("status", "info"):
                return {"success": True, "data": {"module": "event_bus_pro", "status": "active",
                         "subscriptions": len(self._subscriptions),
                         "events_stored": len(self._event_store)}}
            elif action == "help":
                return {"success": True, "data": {"actions": ["status", "help", "publish", "subscribe", "list_subscriptions", "get_metrics"]}}
            elif action == "publish":
                event_type = params.get("event_type", "")
                payload = params.get("payload", {})
                r = self.publish_sync(event_type, payload)
                return {"success": r.success, "result": r.data, "error": r.error}
            elif action == "subscribe":
                pattern = params.get("pattern", "")
                handler_name = params.get("handler", "default")
                self.subscribe(pattern, handler_name)
                return {"success": True, "data": {"subscribed": pattern}}
            elif action == "list_subscriptions":
                subs = self.list_subscriptions()
                return {"success": True, "data": {"subscriptions": subs}}
            elif action == "get_metrics":
                m = self.get_metrics()
                return {"success": True, "data": m}
            else:
                return {"success": True, "data": {"action": action, "module": "event_bus_pro"}}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def publish_sync(self, event_type: str, payload: Dict[str, Any], **kwargs) -> Result:
        """同步发布（直接调用handler，不入队）"""
        try:
            event = DomainEvent(event_type=event_type, payload=payload, **kwargs)
            self._sequence_counter += 1
            event.sequence_number = self._sequence_counter
            self._append_to_store(event)
            matched = self._match_subscriptions(event)
            for sub in matched:
                if sub.handler:
                    try:
                        sub.handler(event)
                        sub.delivered_count += 1
                        sub.last_delivered = datetime.now().isoformat()
                    except Exception as e:
                        sub.error_count += 1
                        logger.error(f"[EventBusPro] 同步投递失败: {e}")
            self._bus_stats["events_published"] += 1
            return Result(success=True, data={"event_id": event.event_id, "matched": len(matched)})
        except Exception as e:
            return Result(success=False, error=str(e))

    def _match_subscriptions(self, event: DomainEvent) -> List[Subscription]:
        """匹配订阅者（消费者组内负载均衡）"""
        matched = []
        for pattern, subs in self._subscriptions.items():
            if not subs:
                continue
            # 检查通配符匹配
            if not any(s.event_pattern == "*" or fnmatch.fnmatch(event.event_type, s.event_pattern) for s in subs):
                continue
            active_subs = [s for s in subs if s.active]
            if not active_subs:
                continue
            # 消费者组内轮询
            groups = defaultdict(list)
            for s in active_subs:
                groups[s.consumer_group].append(s)
            for group_name, group_subs in groups.items():
                # 轮询选一个
                idx = self._sequence_counter % len(group_subs)
                matched.append(group_subs[idx])
        return matched

    # ----------------------------------------------------------------
    # 投递调度
    # ----------------------------------------------------------------

    def _dispatch_worker(self, worker_name: str):
        """投递工作协程"""
        while True:
            try:
                item = asyncio.wait_for(self._pending_envelopes.get(), timeout=1.0)
                _, _, _, envelope = item
                if envelope is None:  # 毒丸
                    break
                self._dispatch_envelope(envelope)
                # 背压恢复
                if self._backpressure and self._pending_envelopes.qsize() < self._queue_low_watermark:
                    self._backpressure = False
                    logger.info("[EventBusPro] 背压解除")
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"[EventBusPro] {worker_name} 异常: {e}")

    def _dispatch_envelope(self, envelope: EventEnvelope):
        """投递单个信封"""
        sub = envelope.subscription
        event = envelope.event
        envelope.delivery_count += 1
        try:
            if sub.async_handler:
                sub.async_handler(event)
            elif sub.handler:
                # 在executor中运行同步handler
                loop = asyncio.get_event_loop()
                loop.run_in_executor(None, sub.handler, event)
            sub.delivered_count += 1
            sub.last_delivered = datetime.now().isoformat()
            envelope.status = "delivered"
            self._bus_stats["events_delivered"] += 1
        except Exception as e:
            sub.error_count += 1
            envelope.last_error = str(e)
            if envelope.delivery_count < envelope.max_deliveries:
                envelope.status = "retry"
                # 重试入队
                self._pending_envelopes.put((-event.priority.value, event.timestamp, event.event_id, envelope))
                self._bus_stats["events_failed"] += 1
            else:
                envelope.status = "dead_letter"
                self._dead_letters.append(envelope)
                if len(self._dead_letters) > 5000:
                    self._dead_letters = self._dead_letters[-2500:]
                self._bus_stats["events_dead_letter"] += 1
                logger.warning(f"[EventBusPro] 死信: {event.event_id} -> {str(e)[:100]}")

    # ----------------------------------------------------------------
    # 事件溯源
    # ----------------------------------------------------------------

    def _append_to_store(self, event: DomainEvent):
        """追加到事件存储"""
        self._event_store.append(event)
        if len(self._event_store) > self._event_store_max:
            self._event_store = self._event_store[-self._event_store_max // 2:]

    def replay_events(self, event_type: Optional[str] = None, aggregate_id: Optional[str] = None,
                        since: Optional[str] = None, limit: int = 100) -> List[Dict]:
        """事件回溯/重放"""
        events = self._event_store
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        if aggregate_id:
            events = [e for e in events if e.aggregate_id == aggregate_id]
        if since:
            events = [e for e in events if e.timestamp >= since]
        return [e.to_dict() for e in events[-limit:]]

    def get_aggregate_history(self, aggregate_id: str) -> List[Dict]:
        """获取聚合根的事件历史"""
        return self.replay_events(aggregate_id=aggregate_id, limit=500)

    # ----------------------------------------------------------------
    # 查询接口
    # ----------------------------------------------------------------

    def get_stats(self) -> Dict[str, Any]:
        """获取总线统计"""
        return {
            **self._bus_stats,
            "pending_queue_size": self._pending_envelopes.qsize(),
            "event_store_size": len(self._event_store),
            "dead_letter_count": len(self._dead_letters),
            "sequence_number": self._sequence_counter,
            "backpressure": self._backpressure,
            "module_stats": self.stats.to_dict()
        }

    def get_dead_letters(self, limit: int = 50) -> List[Dict]:
        """查看死信"""
        return [
            {"event_id": e.event.event_id, "event_type": e.event.event_type,
             "subscription_id": e.subscription.subscription_id,
             "deliveries": e.delivery_count, "error": e.last_error,
             "timestamp": e.event.timestamp}
            for e in self._dead_letters[-limit:]
        ]


# ============================================================================
# 模块注册
# ============================================================================

module_class = EventBusPro
