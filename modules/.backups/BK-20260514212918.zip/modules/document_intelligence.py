"""
Document Intelligence - Enterprise Document Processing Module
Parse documents, extract entities, compare documents, and generate summaries.
"""

import re
import json
import time
import uuid
import hashlib
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Tuple
from collections import defaultdict, deque
from enum import Enum, auto

from modules._base.enterprise_module import EnterpriseModule


class DocumentType(Enum):
    PDF = "pdf"
    WORD = "word"
    EXCEL = "excel"
    TEXT = "text"
    IMAGE = "image"
    CODE = "code"
    HTML = "html"
    JSON = "json"


class DocumentParser:
    """Parse and analyze document content across formats."""

    def __init__(self):
        self._parsers = {
            "pdf": self._parse_text_content,
            "word": self._parse_text_content,
            "text": self._parse_text_content,
            "md": self._parse_text_content,
            "json": self._parse_json_content,
            "csv": self._parse_csv_content,
            "html": self._parse_text_content,
            "py": self._parse_code_content,
            "js": self._parse_code_content,
        }

    def parse(self, content: str, format_hint: str = "text") -> Dict:
        parser = self._parsers.get(format_hint, self._parse_text_content)
        return parser(content)

    def _parse_text_content(self, content: str) -> Dict:
        lines = content.split("\n")
        paragraphs = [p.strip() for p in content.split("\n\n") if p.strip()]
        headings = [l.strip() for l in lines if l.strip() and re.match(r"^#{1,6}\s", l.strip())]
        return {"type": "text", "paragraphs": paragraphs[:100], "headings": headings,
                "word_count": len(content.split()), "char_count": len(content),
                "line_count": len(lines), "heading_count": len(headings)}

    def _parse_json_content(self, content: str) -> Dict:
        try:
            data = json.loads(content)
            return {"type": "json", "valid": True, "keys": list(data.keys()) if isinstance(data, dict) else [],
                    "item_count": len(data) if isinstance(data, (list, dict)) else 0}
        except json.JSONDecodeError as e:
            return {"type": "json", "valid": False, "error": str(e)}

    def _parse_csv_content(self, content: str) -> Dict:
        lines = [l for l in content.split("\n") if l.strip()]
        if not lines:
            return {"type": "csv", "headers": [], "rows": 0}
        rows = []
        for line in lines:
            if "," in line:
                rows.append(line.split(","))
            elif "\t" in line:
                rows.append(line.split("\t"))
            else:
                rows.append([line])
        return {"type": "csv", "headers": rows[0] if rows else [], "row_count": len(rows) - 1,
                "total_rows": len(rows), "sample": rows[:10]}

    def _parse_code_content(self, content: str) -> Dict:
        functions = re.findall(r"def\s+(\w+)\s*\(", content)
        classes = re.findall(r"class\s+(\w+)", content)
        imports = re.findall(r"^(?:import|from)\s+[\w.]+", content, re.MULTILINE)
        return {"type": "code", "functions": functions, "classes": classes,
                "imports": imports, "loc": len(content.split("\n")),
                "complexity": len(functions) * 3 + len(classes) * 5}

    def compare(self, content_a: str, content_b: str) -> Dict:
        matcher = difflib.SequenceMatcher(None, content_a.splitlines(), content_b.splitlines())
        ratio = matcher.ratio()
        changes = []
        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag != "equal":
                changes.append({"type": tag, "old_start": i1, "old_end": i2,
                                 "new_start": j1, "new_end": j2})
        return {"similarity": round(ratio, 4), "change_count": len(changes),
                "changes": changes[:50], "lines_added": sum(j2 - j1 for t, i1, i2, j1, j2 in matcher.get_opcodes() if t in ("insert", "replace")),
                "lines_removed": sum(i2 - i1 for t, i1, i2, j1, j2 in matcher.get_opcodes() if t in ("delete", "replace"))}


class DocumentIntelligence(EnterpriseModule):
    MODULE_ID = "document_intelligence"
    MODULE_NAME = "DocumentIntelligence"
    VERSION = "2.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._parser = DocumentParser()
        self._documents: Dict[str, Dict] = {}
        self._parse_history: deque = deque(maxlen=1000)
        self._operation_count = 0
        self._error_count = 0

    def execute(self, action: 

str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                handler = getattr(self, f"_action_{action}", None)
                if handler:
                    result = handler(params)
                else:
                    return {"success": False, "error": f"Unknown action: {action}"}
                self._operation_count += 1
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                self._error_count += 1
                return {"success": False, "error": str(e), "action": action}

    def _action_parse_document(self, p: Dict) -> Dict:
        doc_id = p.get("doc_id", f"doc_{uuid.uuid4().hex[:8]}")
        content = p.get("content", "")
        fmt = p.get("format", "text")
        result = self._parser.parse(content, fmt)
        doc = {"doc_id": doc_id, "format": fmt, "parsed": result,
               "created_at": datetime.now(timezone.utc).isoformat()}
        self._documents[doc_id] = doc
        self._parse_history.append({"doc_id": doc_id, "format": fmt, "timestamp": datetime.now(timezone.utc).isoformat()})
        return {"doc_id": doc_id, "format": fmt, "word_count": result.get("word_count", 0)}

    def _action_compare_documents(self, p: Dict) -> Dict:
        content_a = p.get("content_a", "")
        content_b = p.get("content_b", "")
        result = self._parser.compare(content_a, content_b)
        return result

    def _action_extract_entities(self, p: Dict) -> Dict:
        content = p.get("content", "")
        email_pattern = r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
        url_pattern = r"https?://[^\s<>\"']+"
        date_pattern = r"\d{4}[-/]\d{1,2}[-/]\d{1,2}"
        phone_pattern = r"\+?\d{1,4}[-.\s]?\(?\d{1,4}\)?[-.\s]?\d{1,9}"
        entities = {"emails": re.findall(email_pattern, content),
                    "urls": re.findall(url_pattern, content),
                    "dates": re.findall(date_pattern, content),
                    "phones": re.findall(phone_pattern, content)}
        total = sum(len(v) for v in entities.values())
        return {"entities": entities, "total_count": total}

    def _action_generate_summary(self, p: Dict) -> Dict:
        content = p.get("content", "")
        sentences = [s.strip() for s in re.split(r'[.!?]+', content) if len(s.strip()) > 20]
        max_sentences = p.get("max_sentences", 3)
        summary = ". ".join(sentences[:max_sentences])
        return {"summary": summary, "original_sentences": len(sentences),
                "summary_length": max_sentences}

    def _action_analyze(self, p: Dict) -> Dict:
        content = p.get("content", "")
        context = p.get("context", {})
        parsed = self._parser.parse(content)
        result = {"analyzer": "DocumentIntelligence", "timestamp": time.time(),
                  "records": 1, "summary": parsed, "context": context}
        self._parse_history.append(result)
        return {"status": "analyzed", "parsed": parsed}

    def _action_search_history(self, p: Dict) -> Dict:
        query = p.get("query", "").lower()
        results = [h for h in self._parse_history if query in str(h).lower()]
        return {"results": results[-p.get("limit", 50):], "total": len(results)}

    def _action_compare_periods(self, p: Dict) -> Dict:
        period_a = p.get("period_a", "last_7d")
        period_b = p.get("period_b", "last_30d")
        count_a = sum(1 for h in self._parse_history if period_a in str(h.get("timestamp", "")))
        count_b = sum(1 for h in self._parse_history if period_b in str(h.get("timestamp", "")))
        return {"period_a": period_a, "count_a": count_a, "period_b": period_b,
                "count_b": count_b, "change": count_b - count_a}

    def _action_cleanup_stale(self, p: Dict) -> Dict:
        max_age = p.get("max_age_days", 30)
        before = len(self._parse_history)
        cutoff = time.time() - max_age * 86400
        self._parse_history = deque([h for h in self._parse_history if time.time() - 86400 * max_age < time.time()], maxlen=1000)
        return {"removed": before - len(self._parse_history), "remaining": len(self._parse_history)}

    def _action_aggregate(self, p: Dict) -> Dict:
        by_format = defaultdict(int)
        for h in self._parse_history:
            by_format[h.get("format", "unknown")] += 1
        return {"total": len(self._parse_history), "by_format": dict(by_format)}

    def _action_batch_analyze(self, p: Dict) -> Dict:
        docs = p.get("documents", [])
        results = []
        for doc in docs:
            content = doc.get("content", "")
            fmt = doc.get("format", "text")
            parsed = self._parser.parse(content, fmt)
            results.append({"doc_id": doc.get("doc_id", "unknown"), "format": fmt,
                             "word_count": parsed.get("word_count", 0), "status": "ok"})
        return {"results": results, "total": len(results)}

    def _action_get_statistics(self) -> Dict:
        return {"total_documents": len(self._documents), "parse_history": len(self._parse_history),
                "supported_formats": list(self._parser._parsers.keys())}

    def _action_validate_config(self, p: Dict) -> Dict:
        return {"valid": True, "supported_formats": list(self._parser._parsers.keys())}

    def _action_export_report(self, p: Dict) -> Dict:
        return {"report": {"module": self.MODULE_ID, "documents": len(self._documents),
                "history": len(self._parse_history),
                "timestamp": datetime.now(timezone.utc).isoformat()}}

    def _action_reset_metrics(self, p: Dict) -> Dict:
        self._parse_history.clear()
        return {"status": "reset_ok"}

    def _action_get_health_detail(self, p: Dict) -> Dict:
        return {"healthy": True, "documents": len(self._documents),
                "history_size": len(self._parse_history)}

    def _action_status(self, p: Dict) -> Dict:
        return {"module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
                "version": self.VERSION, "status": "running"}

    def _action_stats(self, p: Dict) -> Dict:
        return {"operations": self._operation_count, "errors": self._error_count,
                "documents": len(self._documents), "history": len(self._parse_history)}

    def _action_health(self, p: Dict) -> Dict:
        return {"healthy": True, "status": "ok"}

    def _action_configure(self, p: Dict) -> Dict:
        return {"configured": list(p.keys()), "status": "ok"}

    def _action_reset(self, p: Dict) -> Dict:
        self._documents.clear()
        self._parse_history.clear()
        return {"status": "reset_ok"}


import difflib
module_class = DocumentIntelligence
