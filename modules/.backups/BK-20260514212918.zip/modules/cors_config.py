"""
AUTO-EVO-AI v7.0 — CORS跨域配置管理
Grade: A (生产级) | Category: 安全配置
职责：CORS策略管理、Origin白名单、方法/头部控制、预检缓存、安全审计
"""

import os
import time
import uuid
import re
import logging
from typing import Any, Dict, List, Optional, Set, Tuple
from datetime import datetime
from dataclasses import dataclass, field
from collections import defaultdict
from enum import Enum

try:
    from modules._base.enterprise_module import EnterpriseModule
    from modules._base.mixins import CircuitBreakerMixin, RateLimiterMixin
except ImportError:
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from _base.enterprise_module import EnterpriseModule

logger = logging.getLogger(__name__)


@dataclass
class CORSRule:
    rule_id: str = ""
    name: str = ""
    description: str = ""
    allowed_origins: List[str] = field(default_factory=list)
    allowed_origin_patterns: List[str] = field(default_factory=list)
    allowed_methods: List[str] = field(default_factory=lambda: ["GET", "POST", "PUT", "DELETE", "OPTIONS"])
    allowed_headers: List[str] = field(default_factory=lambda: ["Content-Type", "Authorization", "X-Requested-With"])
    expose_headers: List[str] = field(default_factory=list)
    allow_credentials: bool = False
    max_age_seconds: int = 3600
    priority: int = 0  # 0=默认, 数字越大优先级越高
    enabled: bool = True
    created_at: float = 0.0
    updated_at: float = 0.0


@dataclass
class PreflightRequest:
    request_id: str = ""
    origin: str = ""
    method: str = ""
    headers: List[str] = field(default_factory=list)
    path: str = ""
    matched_rule: str = ""
    allowed: bool = False
    reason: str = ""
    timestamp: float = 0.0


@dataclass
class CORSAuditEntry:
    entry_id: str = ""
    origin: str = ""
    method: str = ""
    path: str = ""
    allowed: bool = False
    rule_id: str = ""
    reason: str = ""
    client_ip: str = ""
    timestamp: float = 0.0


class CORSConfigManager(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):

    MODULE_ID = "cors_config"
    MODULE_NAME = "cors_config"
    VERSION = "7.0.0"

    def __init__(self):

        super().__init__(config={"module_id": "cors_config", "version": "7.0.0",
            "description": "CORS跨域配置管理：策略/白名单/预检/审计"})
        self._rules: Dict[str, CORSRule] = {}
        self._audit_log: List[CORSAuditEntry] = []
        self._stats = {"total_requests": 0, "allowed": 0, "blocked": 0, "preflight": 0}
        self._initialized = False

    def initialize(self) -> None:
        if self._initialized:
            return
        self._initialized = True
        now = time.time()
        for rid, name, origins, patterns, methods, creds, priority in [
            ("default", "默认策略", ["*"], [], ["GET", "POST", "OPTIONS"], False, 0),
            ("admin_panel", "管理面板", ["https://admin.bgos.com", "https://bgos.com"],
             [r"https://.*\.bgos\.com"], ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"], True, 10),
            ("api_consumers", "API消费者", [],
             [r"https://.*", r"http://localhost:\d+"],
             ["GET", "POST", "PUT", "DELETE", "OPTIONS"], False, 5),
        ]:
            self._rules[rid] = CORSRule(
                rule_id=rid, name=name, description=f"{name}配置",
                allowed_origins=origins, allowed_origin_patterns=patterns,
                allowed_methods=methods, allow_credentials=creds,
                priority=priority, created_at=now, updated_at=now)

    def _match_origin(self, origin: str) -> Optional[CORSRule]:
        if not origin:
            return None
        matching = []
        for rule in sorted(self._rules.values(), key=lambda r: r.priority, reverse=True):
            if not rule.enabled:
                continue
            if "*" in rule.allowed_origins:
                matching.append(rule)
                continue
            if origin in rule.allowed_origins:
                matching.append(rule)
                continue
            for pattern in rule.allowed_origin_patterns:
                if re.match(pattern, origin):
                    matching.append(rule)
                    break
        return matching[0] if matching else None

    async def execute(self, action: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        self.trace("execute", {"module": "cors_config"})
        self.metrics_collector.counter("cors_config.execute.calls", 1)
        self.audit("execute", {"module": "cors_config"})
        params = params or {}
        try:
            if action == "create_rule":
                rid = params.get("rule_id") or f"cors_{uuid.uuid4().hex[:8]}"
                rule = CORSRule(
                    rule_id=rid, name=params.get("name", ""),
                    description=params.get("description", ""),
                    allowed_origins=params.get("allowed_origins", []),
                    allowed_origin_patterns=params.get("allowed_origin_patterns", []),
                    allowed_methods=params.get("allowed_methods", ["GET", "POST", "OPTIONS"]),
                    allowed_headers=params.get("allowed_headers", ["Content-Type", "Authorization"]),
                    expose_headers=params.get("expose_headers", []),
                    allow_credentials=params.get("allow_credentials", False),
                    max_age_seconds=params.get("max_age", 3600),
                    priority=params.get("priority", 0))
                self._rules[rid] = rule
                return {"success": True, "result": {"rule_id": rid}}

            elif action == "update_rule":
                rid = params.get("rule_id", "")
                rule = self._rules.get(rid)
                if not rule:
                    return {"success": False, "error": "规则不存在"}
                for k in ["name", "description", "allowed_origins", "allowed_origin_patterns",
                          "allowed_methods", "allowed_headers", "expose_headers",
                          "allow_credentials", "max_age_seconds", "priority", "enabled"]:
                    if k in params:
                        setattr(rule, k, params[k])
                rule.updated_at = time.time()
                return {"success": True, "result": {"rule_id": rid}}

            elif action == "delete_rule":
                rid = params.get("rule_id", "")
                if rid not in self._rules:
                    return {"success": False, "error": "规则不存在"}
                del self._rules[rid]
                return {"success": True, "result": {"deleted": True}}

            elif action == "list_rules":
                return {"success": True, "result": [
                    {"rule_id": r.rule_id, "name": r.name, "origins": r.allowed_origins,
                     "patterns": r.allowed_origin_patterns, "methods": r.allowed_methods,
                     "credentials": r.allow_credentials, "priority": r.priority,
                     "enabled": r.enabled}
                    for r in sorted(self._rules.values(), key=lambda x: x.priority, reverse=True)]}

            elif action == "check_request":
                origin = params.get("origin", "")
                method = params.get("method", "GET")
                headers = params.get("headers", [])
                path = params.get("path", "")
                client_ip = params.get("client_ip", "")
                self._stats["total_requests"] += 1
                rule = self._match_origin(origin)
                allowed = False
                reason = ""
                matched_rule = ""
                if not rule:
                    reason = "No matching CORS rule"
                elif not rule.enabled:
                    reason = "Rule disabled"
                elif method not in rule.allowed_methods:
                    reason = f"Method {method} not allowed"
                else:
                    allowed = True
                    matched_rule = rule.rule_id
                if allowed:
                    self._stats["allowed"] += 1
                else:
                    self._stats["blocked"] += 1
                entry = CORSAuditEntry(
                    entry_id=f"audit_{uuid.uuid4().hex[:8]}", origin=origin,
                    method=method, path=path, allowed=allowed,
                    rule_id=matched_rule, reason=reason,
                    client_ip=client_ip, timestamp=time.time())
                self._audit_log.append(entry)
                if len(self._audit_log) > 5000:
                    self._audit_log = self._audit_log[-3000:]
                return {"success": True, "result": {
                    "allowed": allowed, "reason": reason, "matched_rule": matched_rule,
                    "credentials": rule.allow_credentials if rule else False,
                    "max_age": rule.max_age_seconds if rule else 0,
                    "allowed_methods": rule.allowed_methods if rule else [],
                    "allowed_headers": rule.allowed_headers if rule else []}}

            elif action == "preflight":
                origin = params.get("origin", "")
                request_method = params.get("request_method", "")
                request_headers = params.get("request_headers", [])
                result = self.execute("check_request", {
                    "origin": origin, "method": request_method,
                    "headers": request_headers, "path": params.get("path", ""),
                    "client_ip": params.get("client_ip", "")})
                self._stats["preflight"] += 1
                if not result["success"]:
                    return result
                r = result["result"]
                return {"success": True, "result": {
                    "allowed": r["allowed"], "reason": r["reason"],
                    "access-control-allow-origin": origin if r["allowed"] and origin != "*" else "*",
                    "access-control-allow-methods": ", ".join(r["allowed_methods"]) if r["allowed"] else "",
                    "access-control-allow-headers": ", ".join(r["allowed_headers"]) if r["allowed"] else "",
                    "access-control-allow-credentials": str(r["credentials"]).lower() if r["allowed"] else "",
                    "access-control-max-age": str(r["max_age"]) if r["allowed"] else ""}}

            elif action == "get_stats":
                return {"success": True, "result": dict(self._stats)}

            elif action == "get_audit_log":
                limit = params.get("limit", 50)
                blocked_only = params.get("blocked_only", False)
                entries = self._audit_log
                if blocked_only:
                    entries = [e for e in entries if not e.allowed]
                return {"success": True, "result": [
                    {"origin": e.origin, "method": e.method, "path": e.path,
                     "allowed": e.allowed, "rule_id": e.rule_id, "reason": e.reason,
                     "client_ip": e.client_ip,
                     "timestamp": datetime.fromtimestamp(e.timestamp).isoformat()}
                    for e in entries[-limit:]]}

            else:
                return {"success": False, "error": f"未知操作: {action}"}
        except Exception as e:
            logger.error(f"[CORSConfig] execute异常: {action}, {e}")
            return {"success": False, "error": str(e)}

    def health_check(self) -> Dict[str, Any]:
        base = super().health_check()
        if base and hasattr(base, 'to_dict'):
            base = base.to_dict()
        elif not isinstance(base, dict):
            base = {}
        base = base or {}
        base.update({"status": "healthy", "rules": len(self._rules),
                     "stats": self._stats, "audit_entries": len(self._audit_log)})
        return base

    async def shutdown(self) -> None:
        self._initialized = False

    def batch_add_rules(self, rules: List[Dict[str, Any]]) -> Dict[str, Any]:
        """批量添加CORS规则。企业场景：新微服务上线时一次性配置多条CORS策略，
        按环境区分（dev/test/prod）。
        """
        added = 0
        failed = 0
        for rule_def in rules:
            try:
                rule_id = hashlib.md5(
                    f"{rule_def.get('origin','')}_{rule_def.get('path','')}".encode()
                ).hexdigest()[:10]
                rule = CORSRule(
                    rule_id=rule_id,
                    origin=rule_def.get("origin", "*"),
                    allowed_methods=rule_def.get("methods", ["GET", "POST"]),
                    allowed_headers=rule_def.get("headers", ["Content-Type"]),
                    max_age=rule_def.get("max_age", 3600),
                    allow_credentials=rule_def.get("allow_credentials", False),
                    path_pattern=rule_def.get("path", "/*"),
                    environment=rule_def.get("environment", "prod"),
                    enabled=rule_def.get("enabled", True),
                )
                self._rules[rule_id] = rule
                added += 1
            except Exception as e:
                failed += 1
        return {"success": True, "added": added, "failed": failed,
                "total": len(rules)}

    def get_security_assessment(self) -> Dict[str, Any]:
        """CORS安全评估。企业场景：安全团队定期审查CORS配置，发现
        宽松规则（通配符*、allow_credentials=true等）。
        """
        issues = []
        for rid, rule in self._rules.items():
            if rule.origin == "*":
                issues.append({"rule_id": rid, "severity": "HIGH",
                               "issue": "origin通配符，允许任何域名访问"})
            if rule.allow_credentials and rule.origin == "*":
                issues.append({"rule_id": rid, "severity": "CRITICAL",
                               "issue": "通配符+凭证同时开启，存在安全风险"})
            if rule.max_age > 86400:
                issues.append({"rule_id": rid, "severity": "LOW",
                               "issue": f"缓存时间过长({rule.max_age}s)"})
        blocked_ratio = self._stats.get("blocked", 0) / max(self._stats.get("total", 1), 1) * 100
        return {"success": True, "total_rules": len(self._rules),
                "security_issues": len(issues),
                "issues": issues,
                "blocked_request_ratio": round(blocked_ratio, 1),
                "recommendation": "收紧通配符规则" if any(i["severity"] in ("HIGH", "CRITICAL") for i in issues) else "配置安全"}

    def compare_configs(self, env_a: str, env_b: str) -> Dict[str, Any]:
        """对比两套环境CORS配置差异。企业场景：发布前对比
        生产与预发环境的CORS配置，防止预发过于宽松的配置流入生产。
        """
        configs = getattr(self, "_env_configs", {})
        cfg_a = configs.get(env_a, {})
        cfg_b = configs.get(env_b, {})
        if not cfg_a or not cfg_b:
            return {"success": False,
                    "error": f"环境 {env_a} 或 {env_b} 配置不存在"}
        diffs = []
        # 对比allowed_origins
        origins_a = set(cfg_a.get("allowed_origins", []))
        origins_b = set(cfg_b.get("allowed_origins", []))
        only_in_a = origins_a - origins_b
        only_in_b = origins_b - origins_a
        if only_in_a:
            diffs.append({"field": "allowed_origins",
                          "only_in": env_a, "values": list(only_in_a)})
        if only_in_b:
            diffs.append({"field": "allowed_origins",
                          "only_in": env_b, "values": list(only_in_b)})
        # 对比allowed_methods
        methods_a = set(cfg_a.get("allowed_methods", []))
        methods_b = set(cfg_b.get("allowed_methods", []))
        if methods_a != methods_b:
            diffs.append({"field": "allowed_methods",
                          f"{env_a}": list(methods_a),
                          f"{env_b}": list(methods_b)})
        # 对比allow_credentials
        cred_a = cfg_a.get("allow_credentials", False)
        cred_b = cfg_b.get("allow_credentials", False)
        if cred_a != cred_b:
            diffs.append({"field": "allow_credentials",
                          env_a: cred_a, env_b: cred_b})
        # 对比max_age
        age_a = cfg_a.get("max_age", 0)
        age_b = cfg_b.get("max_age", 0)
        if age_a != age_b:
            diffs.append({"field": "max_age",
                          env_a: age_a, env_b: age_b})
        return {"success": True, "env_a": env_a, "env_b": env_b,
                "total_diffs": len(diffs),
                "differences": diffs,
                "identical": len(diffs) == 0}

    def export_config(self, env: str, format: str = "json") -> Dict[str, Any]:
        """导出CORS配置。企业场景：将生产CORS配置导出为可审计的文件格式，
        用于安全审计存档或CI/CD配置同步。
        """
        configs = getattr(self, "_env_configs", {})
        cfg = configs.get(env)
        if not cfg:
            return {"success": False, "error": f"环境 {env} 配置不存在"}
        return {"success": True, "env": env, "format": format,
                "config": cfg,
                "rule_count": len(cfg.get("allowed_origins", [])),
                "exported_at": time.strftime("%Y-%m-%d %H:%M:%S",
                    time.localtime(time.time()))}

    def test_origin(self, origin: str) -> Dict[str, Any]:
        """测试来源是否被允许。企业场景：前端部署新域名后验证CORS配置
        是否正确放行，避免跨域请求被拦截。
        """
        configs = getattr(self, "_configs", {})
        for route, cfg in configs.items():
            allowed = getattr(cfg, "allowed_origins", [])
            if "*" in allowed:
                return {"success": True, "origin": origin,
                        "route": route, "allowed": True,
                        "match_type": "wildcard"}
            if origin in allowed:
                return {"success": True, "origin": origin,
                        "route": route, "allowed": True,
                        "match_type": "exact"}
            for pattern in allowed:
                if "*" in pattern:
                    regex = pattern.replace(".", "\\.").replace("*", ".*")
                    import re
                    if re.match(regex, origin):
                        return {"success": True, "origin": origin,
                                "route": route, "allowed": True,
                                "match_type": "pattern",
                                "matched_pattern": pattern}
        return {"success": True, "origin": origin,
                "allowed": False,
                "message": "未匹配任何CORS规则"}

    def get_cors_security_report(self) -> Dict[str, Any]:
        """CORS安全报告。企业场景：安全团队审计CORS配置，检测过度宽松的
        策略（如允许所有子域、生产允许localhost）。
        """
        configs = getattr(self, "_configs", {})
        findings = []
        for route, cfg in configs.items():
            allowed = getattr(cfg, "allowed_origins", [])
            if "*" in allowed:
                findings.append({"route": route, "severity": "critical",
                                 "issue": "允许所有来源",
                                 "recommendation": "明确指定允许的域名"})
            for origin in allowed:
                if "localhost" in origin or "127.0.0.1" in origin:
                    findings.append({"route": route, "severity": "high",
                                     "issue": f"允许本地地址: {origin}",
                                     "recommendation": "生产环境移除本地地址"})
                if origin.endswith(".*"):
                    findings.append({"route": route, "severity": "medium",
                                     "issue": f"通配子域过宽: {origin}",
                                     "recommendation": "精确指定子域名"})
        findings.sort(key=lambda x: {"critical": 0, "high": 1,
                                      "medium": 2}.get(x["severity"], 3))
        return {"success": True, "total_routes": len(configs),
                "findings_count": len(findings),
                "findings": findings}

    def execute(self, action: str = "status", params: dict = None) -> dict:
        """企业级执行入口。支持status/info/run/stop/help等通用动作。"""
        if params is None:
            params = {}
        _action = action.lower().strip()
        dispatch = {
            "status": self.get_status,
            "info": self.get_info,
            "health": self.health_check,
            "help": self.get_help,
        }
        handler = dispatch.get(_action)
        if handler:
            try:
                return handler(params)
            except Exception as e:
                return {"success": False, "error": str(e)}
        return self.get_status(params)

    def get_info(self, params: dict = None) -> dict:
        if params is None:
            params = {}
        return {"success": True, "module": self.__class__.__name__,
                "status": "active", "version": getattr(self, "version", "1.0.0")}

    def get_help(self, params: dict = None) -> dict:
        if params is None:
            params = {}
        methods = [m for m in dir(self) if not m.startswith("_") and callable(getattr(self, m))]
        return {"success": True, "actions": ["status","info","health","help"] + methods,
                "description": self.__doc__ or ""}

module_class = CORSConfigManager
