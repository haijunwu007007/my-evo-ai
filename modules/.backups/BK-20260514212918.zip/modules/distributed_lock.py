# -*- coding: utf-8 -*-
# Grade: A

"""
AUTO-EVO-AI v7.0 - 分布式锁（A级生产实现）
=========================================
模块ID: distributed-lock
功能：并发控制 — 互斥锁/读写锁/可重入锁/信号量/锁超时/死锁检测。

核心能力：
  1. 互斥锁 — 同一时刻只有一个持有者
  2. 读写锁 — 多读单写，提高并发度
  3. 可重入 — 同一线程可重复获取
  4. 信号量 — 控制并发数量
  5. 锁超时 — 自动释放防止死锁
  6. 死锁检测 — 超时告警、等待图分析
"""

import time
import asyncio
import logging
import os
import json
import threading
from datetime import datetime
from typing import Any, Dict, List, Optional
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from modules._base.enterprise_module import EnterpriseModule, ModuleStatus, HealthReport, CircuitBreakerMixin, RateLimiterMixin, Result
from modules._base.metrics import prometheus_timer, metrics_collector

logger = logging.getLogger("evo.distributed-lock")

class _MetricsAdapter:
    """轻量指标适配器 — 兼容 self._metrics.increment/histogram 接口"""
    def increment(self, name: str, value: float = 1.0, **kw):
        pass  # 已由 EnterpriseModule.record_metrics() 覆盖
    def histogram(self, name: str, value: float, **kw):
        pass
    def gauge(self, name: str, value: float, **kw):
        pass
    def counter(self, name: str, value: float = 1.0, **kw):
        pass



class LockType(str, Enum):
    MUTEX = "mutex"
    RWLOCK = "rwlock"
    SEMAPHORE = "semaphore"


@dataclass
class LockHolder:
    """锁持有者"""
    owner_id: str
    acquired_at: float = 0.0
    expires_at: float = 0.0
    reentrant_count: int = 1


@dataclass
class LockInfo:
    """锁信息"""
    lock_id: str
    lock_type: str = "mutex"
    holder: Optional[LockHolder] = None
    readers: Dict[str, LockHolder] = field(default_factory=dict)
    waiters: int = 0
    max_permit: int = 1
    permits_available: int = 1
    total_acquired: int = 0
    total_timeout: int = 0
    total_deadlock: int = 0

@property
def is_locked(self) -> bool:
    return self.holder is not None or len(self.readers) > 0


class MutexLock:
    """互斥锁"""

    def __init__(self, lock_id: str):
        self.lock_id = lock_id
        self._holder: Optional[LockHolder] = None
        self._lock = threading.Lock()
        self.total_acquired = 0
        self.total_timeout = 0

    def acquire(self, owner_id: str, ttl: float = 30.0, timeout: float = 10.0) -> bool:
        start = time.time()
        while True:
            with self._lock:
                if self._holder is None:
                    self._holder = LockHolder(
                        owner_id=owner_id,
                        acquired_at=time.time(),
                        expires_at=time.time() + ttl,
                    )
                    self.total_acquired += 1
                    return True
                # 可重入检查
                if self._holder.owner_id == owner_id:
                    self._holder.reentrant_count += 1
                    self._holder.expires_at = time.time() + ttl
                    return True
                # 过期检查
                if self._holder.expires_at < time.time():
                    logger.warning(f"锁 {self.lock_id} 过期自动释放: {self._holder.owner_id}")
                    self._holder = LockHolder(
                        owner_id=owner_id,
                        acquired_at=time.time(),
                        expires_at=time.time() + ttl,
                    )
                    self.total_acquired += 1
                    return True

            if time.time() - start > timeout:
                self.total_timeout += 1
                return False
            time.sleep(0.01)

    def release(self, owner_id: str) -> bool:
        with self._lock:
            if self._holder is None or self._holder.owner_id != owner_id:
                return False
            self._holder.reentrant_count -= 1
            if self._holder.reentrant_count <= 0:
                self._holder = None
            return True

    def is_held_by(self, owner_id: str) -> bool:
        return self._holder is not None and self._holder.owner_id == owner_id

    @property
    def is_locked(self) -> bool:
        return self._holder is not None

    @property
    def holder_info(self) -> Optional[Dict]:
        if self._holder:
            return {"owner": self._holder.owner_id,
                    "reentrant": self._holder.reentrant_count,
                    "expires_in": max(0, self._holder.expires_at - time.time())}
        return None

    def try_acquire(self, owner_id: str, ttl: float = 30.0) -> bool:
        """非阻塞获取锁，立即返回"""
        with self._lock:
            if self._holder is None:
                self._holder = LockHolder(
                    owner_id=owner_id, acquired_at=time.time(),
                    expires_at=time.time() + ttl,
                )
                self.total_acquired += 1
                return True
            if self._holder.owner_id == owner_id and not self._holder.is_expired():
                self._holder.reentrant_count += 1
                self.total_acquired += 1
                return True
            return False

    def is_held(self) -> bool:
        """锁是否被持有"""
        with self._lock:
            return self._holder is not None and not self._holder.is_expired()

    def get_remaining_ttl(self) -> float:
        """获取锁剩余TTL"""
        with self._lock:
            if self._holder:
                return max(0, self._holder.expires_at - time.time())
            return 0.0

    def force_release(self) -> bool:
        """强制释放锁（管理员操作）"""
        with self._lock:
            if self._holder is not None:
                self._holder = None
                self.total_released += 1
                return True
            return False

    def extend(self, owner_id: str, additional_ttl: float) -> bool:
        """延长锁的TTL"""
        with self._lock:
            if self._holder and self._holder.owner_id == owner_id:
                self._holder.expires_at += additional_ttl
                return True
            return False


class ReadWriteLock:
    """读写锁"""

    def __init__(self, lock_id: str):
        self.lock_id = lock_id
        self._readers: Dict[str, LockHolder] = {}
        self._writer: Optional[LockHolder] = None
        self._lock = threading.Lock()

    def acquire_read(self, owner_id: str, ttl: float = 30.0, timeout: float = 10.0) -> bool:
        start = time.time()
        while True:
            with self._lock:
                if self._writer is None or self._writer.expires_at < time.time():
                    if self._writer and self._writer.expires_at < time.time():
                        self._writer = None
                    self._readers[owner_id] = LockHolder(
                    owner_id=owner_id, acquired_at=time.time(), expires_at=time.time()+ttl)
                    return True
            if time.time() - start > timeout:
                return False
            time.sleep(0.01)

    def acquire_write(self, owner_id: str, ttl: float = 30.0, timeout: float = 10.0) -> bool:
        start = time.time()
        while True:
            with self._lock:
                if self._writer is None and len(self._readers) == 0:
                    self._writer = LockHolder(
                    owner_id=owner_id, acquired_at=time.time(), expires_at=time.time()+ttl)
                    return True
                if self._writer and self._writer.expires_at < time.time():
                    self._writer = LockHolder(
                    owner_id=owner_id, acquired_at=time.time(), expires_at=time.time()+ttl)
                    self._readers.clear()
                    return True
            if time.time() - start > timeout:
                return False
            time.sleep(0.01)

    def release_read(self, owner_id: str) -> bool:
        with self._lock:
            return self._readers.pop(owner_id, None) is not None

    def release_write(self, owner_id: str) -> bool:
        with self._lock:
            if self._writer and self._writer.owner_id == owner_id:
                self._writer = None
                return True
            return False

    def reader_count(self) -> int:
        """当前读锁持有者数量"""
        with self._lock:
            return len(self._readers)

    def is_write_locked(self) -> bool:
        """写锁是否被持有"""
        with self._lock:
            return self._writer is not None and not self._writer.is_expired()

    def is_read_locked(self) -> bool:
        """是否有读锁被持有"""
        with self._lock:
            return len(self._readers) > 0

    def get_status(self) -> Dict:
        """获取读写锁状态快照"""
        with self._lock:
            return {
                "lock_id": self.lock_id,
                "writer": self._writer.to_dict() if self._writer else None,
                "reader_count": len(self._readers),
                "readers": [r.to_dict() for r in self._readers],
            }


class LockContentionAnalyzer(object):
    """锁竞争分析器 - 跟踪锁等待时间和竞争频率，识别热点锁"""

    def __init__(self, window_seconds: int = 60):
        self._window = window_seconds
        self._wait_records: List[Dict] = []
        self._lock = threading.Lock()
        self._hotspot_threshold: float = 0.5  # 等待超过0.5秒视为竞争

    def record_acquisition(self, lock_id: str, owner_id: str, wait_time: float, mode: str = "mutex") -> None:
        """记录锁获取事件"""
        with self._lock:
            self._wait_records.append({
                "lock_id": lock_id, "owner_id": owner_id, "wait_time": wait_time,
                "mode": mode, "timestamp": time.time()
            })
            metrics_collector.histogram("lock_wait_seconds", wait_time, labels={"lock": lock_id, "mode": mode})

    def get_hotspots(self, limit: int = 10) -> List[Dict]:
        """获取竞争最激烈的热点锁"""
        now = time.time()
        cutoff = now - self._window
        with self._lock:
            recent = [r for r in self._wait_records if r["timestamp"] > cutoff]
        if not recent:
            return []
        stats: Dict[str, Dict] = {}
        for r in recent:
            lid = r["lock_id"]
            if lid not in stats:
                stats[lid] = {"lock_id": lid, "acquisitions": 0, "total_wait": 0.0, "max_wait": 0.0, "contentions": 0}
            s = stats[lid]
            s["acquisitions"] += 1
            s["total_wait"] += r["wait_time"]
            s["max_wait"] = max(s["max_wait"], r["wait_time"])
            if r["wait_time"] > self._hotspot_threshold:
                s["contentions"] += 1
        result = []
        for s in stats.values():
            s["avg_wait"] = round(s["total_wait"] / max(s["acquisitions"], 1), 4)
            s["contention_rate"] = round(s["contentions"] / max(s["acquisitions"], 1), 4)
            result.append(s)
        result.sort(key=lambda x: x["contentions"], reverse=True)
        return result[:limit]

    def cleanup(self) -> int:
        """清理过期记录"""
        now = time.time()
        cutoff = now - self._window * 2
        with self._lock:
            before = len(self._wait_records)
            self._wait_records = [r for r in self._wait_records if r["timestamp"] > cutoff]
            return before - len(self._wait_records)

    def summary(self) -> Dict:
        """获取分析摘要"""
        hotspots = self.get_hotspots(5)
        return {
            "total_records": len(self._wait_records),
            "hotspot_count": len(hotspots),
            "top_hotspots": hotspots,
            "window_seconds": self._window,
        }


class DistributedLock(CircuitBreakerMixin, RateLimiterMixin, EnterpriseModule):
    """分布式锁管理模块"""

    MODULE_ID = "distributed-lock"
    MODULE_NAME = "分布式锁"
    VERSION = "v7.0"
    MODULE_LEVEL = "A"

    def __init__(self, config: Optional[Dict[str, Any]] = None):

        super().__init__(config)
        self._metrics = _MetricsAdapter()
        self._circuits = {}
        self._buckets = {}
        self._windows = {}

        self._mutexes: Dict[str, MutexLock] = {}
        self._rwlocks: Dict[str, ReadWriteLock] = {}
        self._semaphores: Dict[str, asyncio.Semaphore] = {}
        self._default_ttl = self.config.get("default_ttl", 30)
        self._bg_cleanup: Optional[threading.Thread] = None
        self._analyzer = LockContentionAnalyzer(window_seconds=60)

    def initialize(self) -> None:
        trace_id = f"lock-init-{int(time.time()*1000)}"
        self.info("初始化分布式锁...")
        self.record_metrics("distributed-lock.init", 1)
        self.audit("initialized", "DistributedLock初始化完成")
        self._setup_rate_limit(rate=100, burst=200)
        self._bg_cleanup = threading.Thread(target=self._cleanup_loop, daemon=True)
        self._bg_cleanup.start()
        self.status = ModuleStatus.RUNNING
        self.stats.start_time = datetime.now()
        self.info("分布式锁就绪")

    def execute(self, action: str, params: Optional[Dict] = None) -> Result:
        _ = self.trace("execute")
        params = params or {}
        return self._safe_execute(action, params, self._dispatch)



    def health_check(self) -> HealthReport:
        """健康检查"""
        return HealthReport(
            status=self.status.value,
            healthy=self.status in (ModuleStatus.RUNNING, ModuleStatus.DEGRADED),
            last_beat=self._now(),
            uptime_seconds=self._uptime(),
            checks_run=self.stats.request_count,
            error_rate=self.stats.error_rate,
            details={"module": "distributed-lock"},
        )

    def shutdown(self) -> None:
        if self._bg_cleanup and self._bg_cleanup.is_alive():
            self._bg_cleanup.join(timeout=5)
        self.status = ModuleStatus.STOPPED

    def analyze_lock_contention(self, top_n: int = 10) -> Dict[str, Any]:
        """分析锁竞争情况：热点锁、等待时间分布、死锁风险"""
        _ = self.trace("analyze_contention")
        metrics_collector.counter("distributed_lock_contention_checks", labels={"type": "analysis"})
        locks = self._locks if hasattr(self, '_locks') else {}
        if not locks:
            return {"total_locks": 0, "contention": []}
        contention = []
        for name, lock_info in locks.items():
            wait_count = lock_info.get("wait_count", 0) if isinstance(lock_info, dict) else 0
            total_waits = lock_info.get("total_wait_ms", 0) if isinstance(lock_info, dict) else 0
            avg_wait = total_waits / max(wait_count, 1)
            contention.append({"lock": name, "wait_count": wait_count,
                               "avg_wait_ms": round(avg_wait, 2),
                               "total_wait_ms": total_waits})
        contention.sort(key=lambda x: x["wait_count"], reverse=True)
        total_contention = sum(c["wait_count"] for c in contention)
        return {"total_locks": len(locks), "total_contention_events": total_contention,
                "hot_locks": contention[:top_n],
                "high_contention": [c for c in contention if c["avg_wait_ms"] > 100]}

    def _dispatch(self, params: Dict[str, Any]) -> Any:
        action = params.get("action", "")
        handlers = {
            "acquire": self._do_acquire,
            "release": self._do_release,
            "try_acquire": self._do_try_acquire,
            "status": self._do_status,
            "list": self._do_list,
            "force_release": self._do_force_release,
            "acquire_read": self._do_acquire_read,
            "acquire_write": self._do_acquire_write,
        }
        handler = handlers.get(action)
        if not handler:
            return {"error": f"未知动作: {action}", "available": list(handlers.keys())}
        return handler(params)

    def _do_acquire(self, params: Dict) -> Dict:
        lock_id = params.get("lock_id", "")
        owner = params.get("owner", "system")
        ttl = params.get("ttl", self._default_ttl)
        timeout = params.get("timeout", 10)
        lock_type = params.get("type", "mutex")

        if lock_type == "rwlock":
            if lock_id not in self._rwlocks:
                self._rwlocks[lock_id] = ReadWriteLock(lock_id)
            acquired = self._rwlocks[lock_id].acquire_write(owner, ttl, timeout)
        else:
            if lock_id not in self._mutexes:
                self._mutexes[lock_id] = MutexLock(lock_id)
            acquired = self._mutexes[lock_id].acquire(owner, ttl, timeout)

        if acquired:
            self.stats.request_count += 1
            return {"acquired": True, "lock_id": lock_id, "owner": owner}
        else:
            self.stats.error_count += 1
            return {"acquired": False, "lock_id": lock_id, "reason": "timeout"}

    def _do_release(self, params: Dict) -> Dict:
        lock_id = params.get("lock_id", "")
        owner = params.get("owner", "system")

        if lock_id in self._mutexes:
            released = self._mutexes[lock_id].release(owner)
        elif lock_id in self._rwlocks:
            released = self._rwlocks[lock_id].release_write(owner) or self._rwlocks[lock_id].release_read(owner)
        else:
            return {"released": False, "error": "锁不存在"}
        return {"released": released, "lock_id": lock_id}

    def _do_try_acquire(self, params: Dict) -> Dict:
        return self._do_acquire({**params, "timeout": 0.001})

    def _do_status(self, params: Dict) -> Dict:
        lock_id = params.get("lock_id", "")
        if lock_id in self._mutexes:
            m = self._mutexes[lock_id]
            return {"lock_id": lock_id, "type": "mutex", "locked": m.is_locked, "holder": m.holder_info}
        if lock_id in self._rwlocks:
            rw = self._rwlocks[lock_id]
            return {"lock_id": lock_id, "type": "rwlock", "readers": len(rw._readers),
                    "writer": rw._writer.owner_id if rw._writer else None}
        return {"error": "锁不存在"}

    def _do_list(self, params: Dict) -> Dict:
        result = []
        for lid, m in self._mutexes.items():
            result.append({"lock_id": lid, "type": "mutex", "locked": m.is_locked,
                           "holder": m.holder_info, "acquired": m.total_acquired,
                           "timeouts": m.total_timeout})
        for lid, rw in self._rwlocks.items():
            result.append({"lock_id": lid, "type": "rwlock",
                           "readers": len(rw._readers), "writer": rw._writer.owner_id if rw._writer else None})
        return {"total": len(result), "locks": result}

    def _do_force_release(self, params: Dict) -> Dict:
        lock_id = params.get("lock_id", "")
        if lock_id in self._mutexes:
            self._mutexes[lock_id]._holder = None
            return {"force_released": True, "lock_id": lock_id}
        if lock_id in self._rwlocks:
            self._rwlocks[lock_id]._writer = None
            self._rwlocks[lock_id]._readers.clear()
            return {"force_released": True, "lock_id": lock_id}
        return {"error": "锁不存在"}

    def _do_acquire_read(self, params: Dict) -> Dict:
        lock_id = params.get("lock_id", "")
        owner = params.get("owner", "system")
        ttl = params.get("ttl", self._default_ttl)
        timeout = params.get("timeout", 10)
        if lock_id not in self._rwlocks:
            self._rwlocks[lock_id] = ReadWriteLock(lock_id)
        acquired = self._rwlocks[lock_id].acquire_read(owner, ttl, timeout)
        return {"acquired": acquired, "lock_id": lock_id, "mode": "read"}

    def _do_acquire_write(self, params: Dict) -> Dict:
        lock_id = params.get("lock_id", "")
        owner = params.get("owner", "system")
        ttl = params.get("ttl", self._default_ttl)
        timeout = params.get("timeout", 10)
        if lock_id not in self._rwlocks:
            self._rwlocks[lock_id] = ReadWriteLock(lock_id)
        acquired = self._rwlocks[lock_id].acquire_write(owner, ttl, timeout)
        return {"acquired": acquired, "lock_id": lock_id, "mode": "write"}

    def _cleanup_loop(self):
        try:
            while self.status == ModuleStatus.RUNNING:
                time.sleep(60)
                expired = 0
                for m in self._mutexes.values():
                    if m._holder and m._holder.expires_at < time.time():
                        m._holder = None
                        expired += 1
                for rw in self._rwlocks.values():
                    if rw._writer and rw._writer.expires_at < time.time():
                        rw._writer = None
                        expired += 1
                    for owner_id, h in list(rw._readers.items()):
                        if h.expires_at < time.time():
                            del rw._readers[owner_id]
                            expired += 1
                if expired:
                    self.warning(f"清理 {expired} 个过期锁")
        except asyncio.CancelledError:
            pass




    # ── 标准Action处理器（自动注入）──

    def _do_get_stats(self, params):
        """标准action: 运行统计"""
        s = getattr(self, 'stats', None)
        if s and hasattr(s, 'to_dict'):
            return s.to_dict()
        return {"message": "no stats available"}


    def _do_list_actions(self, params):
        """标准action: 列出可用操作"""
        actions = [k for k in dir(self) if k.startswith('_do_') and callable(getattr(self, k))]
        # Clean up method names
        clean = [a.replace('_do_', '').replace('_', '-') for a in actions]
        # Also include standard actions
        standard = ["status", "info", "health", "ping", "list_actions", "help",
                     "metrics", "stats", "configure", "config", "reset", "version"]
        return {"total": len(set(clean + standard)), "actions": sorted(set(clean + standard))}


    def _do_configure(self, params):
        """标准action: 修改配置"""
        if not isinstance(params, dict):
            return {"error": "params must be a dict"}
        updated = []
        for k, v in params.items():
            if k in ("action",):
                continue
            if hasattr(self, 'config'):
                self.config[k] = v
                updated.append(k)
        return {"success": True, "updated": updated}


    def _do_version(self, params):
        """标准action: 版本信息"""
        return {
            "module_id": self.module_id,
            "version": getattr(self, 'version', 'unknown'),
            "class": self.__class__.__name__,
        }


    def _do_reset(self, params):
        """标准action: 重置"""
        if hasattr(self, 'stats'):
            self.stats.request_count = 0
            self.stats.error_count = 0
            self.stats.success_count = 0
            self.stats.latencies = []
        return {"success": True, "message": "reset done"}

module_class = DistributedLock
