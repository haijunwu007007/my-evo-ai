"""
        文件监控模块 - 企业级实时文件系统事件监控
提供文件变更检测、事件分发、模式匹配、延迟去抖、递归监控
"""
import os
import time
import uuid
import fnmatch
import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from enum import Enum
from collections import defaultdict, deque
from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector
logger = logging.getLogger(__name__)


class FileWatcherAnalyzer(object):
    """file_watcher 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "file_watcher"
        self.version = "1.0.0"
        self._analyzer = FileWatcherAnalyzer()
        self._history = []
        self._max_history = 10000
    
    def analyze(self, context: dict = None) -> dict:
        context = context or {}
        result = {"analyzer": "FileWatcherAnalyzer", "timestamp": time.time(), "records": len(self._history), "summary": self._summary()}
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-5000:]
        return result
    
    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "file_watcher"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== file_watcher ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}

class WatchEventType(Enum):
    CREATED = "created"
    MODIFIED = "modified"
    DELETED = "deleted"
    RENAMED = "renamed"
    MOVED = "moved"
    ACCESSED = "accessed"


@dataclass
class WatchEvent:
    """文件监控事件"""
    event_id: str = ""
    event_type: WatchEventType = WatchEventType.MODIFIED
    path: str = ""
    old_path: str = ""
    file_size: int = 0
    checksum: str = ""
    timestamp: float = field(default_factory=time.time)
    source: str = "watcher"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {"event_id": self.event_id, "type": self.event_type.value,
                "path": self.path, "old_path": self.old_path,
                "size": self.file_size, "timestamp": self.timestamp,
                "source": self.source}


@dataclass
class WatchConfig:
    """监控配置"""
    path: str = ""
    recursive: bool = True
    patterns: List[str] = field(default_factory=lambda: ["*"])
    ignore_patterns: List[str] = field(default_factory=lambda: ["*.tmp", "*.swp", ".git", "__pycache__"])
    debounce_ms: int = 500
    events: List[str] = field(default_factory=lambda: ["created", "modified", "deleted", "moved"])
    batch_size: int = 100
    batch_interval_ms: int = 1000
    checksum_on_write: bool = False


@dataclass
class WatcherInfo:
    """监控器信息"""
    watch_id: str = ""
    config: WatchConfig = field(default_factory=WatchConfig)
    created: float = field(default_factory=time.time)
    event_count: int = 0
    error_count: int = 0
    last_event: float = 0
    active: bool = True


@dataclass
class DebounceState:
    """去抖状态"""
    path: str = ""
    pending_events: List[WatchEventType] = field(default_factory=list)
    last_trigger: float = 0
    timer_id: str = ""


class FileWatcherModule:

    def trace(self, name, *args, **kwargs):

        class _NS:

            def __enter__(self): return self

            def __exit__(self, *a): pass

            def set_tag(self, *a): pass

            def log_kv(self, *a): pass

            def finish(self): pass

        return _NS()


    """企业级文件监控模块"""

    def __init__(self):
        self._watchers: Dict[str, WatcherInfo] = {}
        self._configs: Dict[str, WatchConfig] = {}
        self._handlers: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self._event_buffer: deque = deque(maxlen=10000)
        self._debounce: Dict[str, DebounceState] = {}
        self._event_history: List[WatchEvent] = deque(maxlen=5000)
        self._snapshot_cache: Dict[str, Dict[str, float]] = {}
        self.metrics_collector = type("_NMC", (), {
        "counter": lambda *a, **k: type("_R", (), {"inc": lambda s,*a:None,"dec": lambda s,*a:None,"labels": lambda s,*a:s,"tags": lambda s,*a:s})(),
        "histogram": lambda *a, **k: type("_R", (), {"observe": lambda s,*a:None,"labels": lambda s,*a:s,"tags": lambda s,*a:s})(),
        "gauge": lambda *a, **k: type("_R", (), {"set": lambda s,*a:None,"inc": lambda s,*a:None,"dec": lambda s,*a:None,"labels": lambda s,*a:s})(),
        "timer": lambda *a, **k: type("_R", (), {"observe": lambda s,*a:None,"labels": lambda s,*a:s})(),
    })()
        self._stats = {"events_total": 0, "events_created": 0, "events_modified": 0,
                       "events_deleted": 0, "events_moved": 0, "debounced": 0,
                       "dispatched": 0, "errors": 0}
        self._initialized = False
        self._running = False

    def initialize(self) -> Dict[str, Any]:
        try:
            self._running = False
            self._initialized = True
            return {"success": True, "max_buffer": 10000, "max_history": 5000}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def health_check(self) -> Dict[str, Any]:
        if not self._initialized:
            return {"healthy": False, "reason": "not_initialized"}
        active = sum(1 for w in self._watchers.values() if w.active)
        return {"healthy": True, "status": "healthy",
                "active_watchers": active, "buffer_size": len(self._event_buffer),
                "history_size": len(self._event_history), "stats": self._stats}

    # --- Watcher Management ---
    def add_watch(self, path: str, recursive: bool = True, patterns: List[str] = None,
                  ignore_patterns: List[str] = None, debounce_ms: int = 500,
                  events: List[str] = None) -> Dict[str, Any]:
        if not self._initialized:
            return {"success": False, "error": "not_initialized"}
        watch_id = f"w_{uuid.uuid4().hex[:8]}"
        config = WatchConfig(
            path=path, recursive=recursive,
            patterns=patterns or ["*"],
            ignore_patterns=ignore_patterns or ["*.tmp", "*.swp"],
            debounce_ms=debounce_ms,
            events=events or ["created", "modified", "deleted", "moved"],
        )
        self._watchers[watch_id] = WatcherInfo(watch_id=watch_id, config=config)
        self._snapshot_cache[watch_id] = {}
        return {"success": True, "watch_id": watch_id, "path": path,
                "patterns": config.patterns, "recursive": recursive}

    def remove_watch(self, watch_id: str) -> Dict[str, Any]:
        if watch_id not in self._watchers:
            return {"success": False, "error": "watch_not_found", "watch_id": watch_id}
        info = self._watchers.pop(watch_id)
        self._snapshot_cache.pop(watch_id, None)
        self._handlers.pop(watch_id, None)
        return {"success": True, "watch_id": watch_id, "events_processed": info.event_count}

    def list_watches(self) -> Dict[str, Any]:
        items = []
        for wid, info in self._watchers.items():
            items.append({"watch_id": wid, "path": info.config.path,
                          "recursive": info.config.recursive, "active": info.active,
                          "event_count": info.event_count, "error_count": info.error_count,
                          "patterns": info.config.patterns})
        return {"success": True, "watchers": items, "total": len(items)}

    def pause_watch(self, watch_id: str) -> Dict[str, Any]:
        if watch_id not in self._watchers:
            return {"success": False, "error": "not_found"}
        self._watchers[watch_id].active = False
        return {"success": True, "watch_id": watch_id, "state": "paused"}

    def resume_watch(self, watch_id: str) -> Dict[str, Any]:
        if watch_id not in self._watchers:
            return {"success": False, "error": "not_found"}
        self._watchers[watch_id].active = True
        return {"success": True, "watch_id": watch_id, "state": "active"}

    # --- Event Handling ---
    def register_handler(self, watch_id: str, handler_name: str,
                         event_types: List[str] = None,
                         file_patterns: List[str] = None) -> Dict[str, Any]:
        if watch_id not in self._watchers:
            return {"success": False, "error": "watch_not_found"}
        handler = {"name": handler_name, "events": event_types or ["*"],
                    "patterns": file_patterns or ["*"],
                    "registered": time.time(), "dispatched": 0, "errors": 0}
        self._handlers[watch_id].append(handler)
        return {"success": True, "watch_id": watch_id, "handler": handler_name}

    def unregister_handler(self, watch_id: str, handler_name: str) -> Dict[str, Any]:
        if watch_id in self._handlers:
            before = len(self._handlers[watch_id])
            self._handlers[watch_id] = [h for h in self._handlers[watch_id]
                                         if h["name"] != handler_name]
            removed = before - len(self._handlers[watch_id])
            return {"success": True, "removed": removed}
        return {"success": False, "error": "watch_not_found"}

    def emit_event(self, watch_id: str, event_type: str, path: str,
                   old_path: str = "", file_size: int = 0,
                   metadata: Dict[str, Any] = None) -> Dict[str, Any]:
        if watch_id not in self._watchers:
            return {"success": False, "error": "watch_not_found"}
        info = self._watchers[watch_id]
        if not info.active:
            return {"success": True, "skipped": True, "reason": "watch_paused"}
        config = info.config
        if not self._match_patterns(path, config.patterns, config.ignore_patterns):
            return {"success": True, "skipped": True, "reason": "pattern_mismatch"}
        try:
            etype = WatchEventType(event_type)
        except ValueError:
            return {"success": False, "error": f"invalid_event_type: {event_type}"}
        if event_type not in config.events:
            return {"success": True, "skipped": True, "reason": "event_filtered"}
        # Debounce
        debounce_key = f"{watch_id}:{path}"
        if config.debounce_ms > 0:
            if debounce_key in self._debounce:
                state = self._debounce[debounce_key]
                if time.time() - state.last_trigger < config.debounce_ms / 1000:
                    state.pending_events.append(etype)
                    self._stats["debounced"] += 1
                    return {"success": True, "debounced": True}
            self._debounce[debounce_key] = DebounceState(path=path, last_trigger=time.time())
        event = WatchEvent(
            event_id=f"evt_{uuid.uuid4().hex[:10]}",
            event_type=etype, path=path, old_path=old_path,
            file_size=file_size, source=watch_id,
            metadata=metadata or {}
        )
        self._event_buffer.append(event)
        self._event_history.append(event)
        info.event_count += 1
        info.last_event = time.time()
        self._stats["events_total"] += 1
        attr = f"events_{event_type}"
        if attr in self._stats:
            self._stats[attr] += 1
        # Dispatch
        dispatched = self._dispatch_event(watch_id, event)
        self._stats["dispatched"] += dispatched
        return {"success": True, "event_id": event.event_id, "type": event_type,
                "path": path, "dispatched": dispatched}

    def _dispatch_event(self, watch_id: str, event: WatchEvent) -> int:
        count = 0
        for handler in self._handlers.get(watch_id, []):
            if "*" not in handler["events"] and event.event_type.value not in handler["events"]:
                continue
            if not self._match_patterns(event.path, handler["patterns"], []):
                continue
            handler["dispatched"] += 1
            count += 1
        return count

    def _match_patterns(self, path: str, include: List[str], exclude: List[str]) -> bool:
        name = os.path.basename(path)
        if any(fnmatch.fnmatch(name, p) for p in exclude):
            return False
        if not any(fnmatch.fnmatch(name, p) for p in include):
            return False
        return True

    # --- Query ---
    def get_events(self, watch_id: str = None, event_type: str = None,
                   path_pattern: str = None, limit: int = 100,
                   since: float = 0) -> Dict[str, Any]:
        events = []
        for evt in reversed(self._event_history):
            if watch_id and evt.source != watch_id:
                continue
            if event_type and evt.event_type.value != event_type:
                continue
            if path_pattern and path_pattern not in evt.path:
                continue
            if evt.timestamp < since:
                break
            events.append(evt.to_dict())
            if len(events) >= limit:
                break
        return {"success": True, "events": events, "total": len(events), "query": {
            "watch_id": watch_id, "event_type": event_type, "limit": limit}}

    def get_stats(self) -> Dict[str, Any]:
        return {"success": True, **self._stats,
                "active_watchers": sum(1 for w in self._watchers.values() if w.active),
                "total_watchers": len(self._watchers),
                "buffer_size": len(self._event_buffer),
                "handlers": {wid: len(hs) for wid, hs in self._handlers.items()}}

    def flush_debounced(self) -> Dict[str, Any]:
        flushed = len(self._debounce)
        self._debounce.clear()
        return {"success": True, "flushed": flushed}

    def clear_history(self) -> Dict[str, Any]:
        count = len(self._event_history)
        self._event_history.clear()
        return {"success": True, "cleared": count}

    def execute(self, action="status", params=None, **kwargs) -> dict:
        params = params or {}
        self.trace("file_watcher.execute", "start", action=action)
        self.metrics_collector.counter("file_watcher.execute.total", 1)
        try:
            action = action.lower().strip()
            if action in ("status", "info"):
                result = self.health_check()
            elif action == "help":
                result = {"actions": ["status", "info", "help"], "module": "file_watcher"}
            else:
                result = self._dispatch(action, params)
            return {"success": True, "data": result, "action": action}
        except Exception as e:
            return {"success": False, "error": str(e)}

module_class = FileWatcherModule
