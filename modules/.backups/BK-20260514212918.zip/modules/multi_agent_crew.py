import time
import os
import json
import logging
import hashlib
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional

from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)

logger = logging.getLogger(__name__)

class MultiAgentCrewAnalyzer(EnterpriseModule):
    """multi_agent_crew 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        super().__init__()
        self._operation_count = 0
        self._error_count = 0
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "multi_agent_crew"
        self.version = "1.0.0"
        self._analyzer = self
        self._history = []
        self._max_history = 10000
    
    def analyze(self, context: dict = None) -> dict:
        context = context or {}
        result = {"analyzer": "MultiAgentCrewAnalyzer", "timestamp": time.time(), "records": len(self._history), "summary": self._summary()}
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-5000:]
        return result
    
    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "multi_agent_crew"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== multi_agent_crew ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}
    async def execute(self, action: str = "status", params: dict = None) -> dict:
            params = params or {}
            action = action or "status"
            try:
                self._operation_count += 1
                if action == "status":
                    return {"success": True, "data": {"status": "running", "operations": self._operation_count, "errors": self._error_count}}
                elif action == "stats":
                    return {"success": True, "data": {"operations": self._operation_count, "errors": self._error_count}}
                elif action == "health":
                    return {"success": True, "data": {"healthy": True}}
                elif action == "configure":
                    return {"success": True, "data": {"message": "Configured"}}
                elif action == "reset":
                    self._operation_count = 0
                    self._error_count = 0
                    return {"success": True, "data": {"message": "Reset"}}
                else:
                    return {"success": False, "error": f"Unknown action: {action}"}
            except Exception as e:
                self._error_count += 1
                return {"success": False, "error": str(e)}

class Agent(object):
    """智能体定义"""
    
    def __init__(self, name: str, role: str, goal: str, skills: List[str] = None):
    
        self.name = name
        self.role = role
        self.goal = goal
        self.skills = skills or []
        self.status = "idle"  # idle, working, completed, error
        self.tasks_completed = 0
        self.memory = []
        
    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "role": self.role,
            "goal": self.goal,
            "skills": self.skills,
            "status": self.status,
            "tasks_completed": self.tasks_completed
        }


class Task:
    """任务定义"""
    
    def __init__(self, description: str, agent: Agent = None, context: str = ""):
        self.description = description
        self.agent = agent
        self.context = context
        self.status = "pending"  # pending, in_progress, completed, failed
        self.result = None
        self.created_at = datetime.now().isoformat()
        self.completed_at = None
        
    def to_dict(self) -> Dict:
        return {
            "description": self.description,
            "agent": self.agent.name if self.agent else None,
            "status": self.status,
            "result": self.result,
            "created_at": self.created_at,
            "completed_at": self.completed_at
        }


class MultiAgentCrew:
    """多智能体团队 - CrewAI风格协作"""
    
    def __init__(self):
        self.agents: Dict[str, Agent] = {}
        self.tasks: List[Task] = []
        self.execution_log: List[Dict] = []
        self.version = "1.0.0"
        self.enabled = True
        
        # 初始化默认智能体团队
        self._init_default_crew()
        
    def _init_default_crew(self):
        """初始化默认智能体团队"""
        default_agents = [
            Agent("研究员", "researcher", "收集和分析信息", ["search", "analyze", "summarize"]),
            Agent("程序员", "coder", "编写和优化代码", ["code", "debug", "optimize"]),
            Agent("分析师", "analyst", "数据分析和报告", ["analyze", "report", "visualize"]),
            Agent("审查员", "reviewer", "质量检查和审查", ["review", "test", "validate"]),
            Agent("项目经理", "manager", "协调和管理任务", ["plan", "coordinate", "track"])
        ]
        
        for agent in default_agents:
            self.agents[agent.name] = agent
            
    def create_agent(self, name: str, role: str, goal: str, skills: List[str] = None) -> Agent:
        """创建新智能体"""
        agent = Agent(name, role, goal, skills)
        self.agents[name] = agent
        logger.info(f"[Crew] 创建智能体: {name} ({role})")
        return agent
    
    def create_task(self, description: str, agent_name: str = None, context: str = "") -> Task:
        """创建任务"""
        agent = self.agents.get(agent_name) if agent_name else None
        task = Task(description, agent, context)
        self.tasks.append(task)
        logger.info(f"[Crew] 创建任务: {description[:50]}...")
        return task
    
    def assign_task(self, task: Task, agent_name: str) -> bool:
        """分配任务给智能体"""
        agent = self.agents.get(agent_name)
        if not agent:
            return False
        task.agent = agent
        logger.info(f"[Crew] 任务分配给: {agent_name}")
        return True
    
    def execute_task(self, task: 

Task) -> Dict:
        """执行任务"""
        try:
            if not task.agent:
                # 自动分配给最合适的智能体
                task.agent = self._find_best_agent(task)
                
            task.status = "in_progress"
            task.agent.status = "working"
            
            # 模拟任务执行
            result = self._simulate_task_execution(task)
            
            task.result = result
            task.status = "completed"
            task.completed_at = datetime.now().isoformat()
            task.agent.status = "completed"
            task.agent.tasks_completed += 1
            
            self.execution_log.append({
                "task": task.description,
                "agent": task.agent.name,
                "result": result,
                "timestamp": task.completed_at
            })
            
            logger.info(f"[Crew] 任务完成: {task.agent.name} - {task.description[:50]}...")
            return {"success": True, "result": result}
            
        except Exception as e:
            task.status = "failed"
            if task.agent:
                task.agent.status = "error"
            logger.error(f"[Crew] 任务失败: {e}")
            return {"success": False, "error": str(e)}
    
    def _find_best_agent(self, task: Task) -> Agent:
        """找到最适合执行任务的智能体"""
        # 简单的匹配逻辑
        task_desc = task.description.lower()
        
        if any(kw in task_desc for kw in ["代码", "程序", "开发", "bug", "code"]):
            return self.agents.get("程序员", list(self.agents.values())[0])
        elif any(kw in task_desc for kw in ["分析", "数据", "报告", "统计", "analyze"]):
            return self.agents.get("分析师", list(self.agents.values())[0])
        elif any(kw in task_desc for kw in ["研究", "搜索", "调查", "research"]):
            return self.agents.get("研究员", list(self.agents.values())[0])
        elif any(kw in task_desc for kw in ["检查", "审查", "测试", "review"]):
            return self.agents.get("审查员", list(self.agents.values())[0])
        else:
            # 找空闲的智能体
            for agent in self.agents.values():
                if agent.status == "idle":
                    return agent
            return list(self.agents.values())[0]
    
    def _simulate_task_execution(self, task: Task) -> str:
        """模拟任务执行结果"""
        agent = task.agent
        
        if agent.role == "researcher":
            return f"[{agent.name}] 已完成信息收集和分析，发现关键洞察..."
        elif agent.role == "coder":
            return f"[{agent.name}] 已生成优化代码，通过测试..."
        elif agent.role == "analyst":
            return f"[{agent.name}] 数据分析完成，生成详细报告..."
        elif agent.role == "reviewer":
            return f"[{agent.name}] 质量检查通过，无重大问题..."
        elif agent.role == "manager":
            return f"[{agent.name}] 任务协调完成，进度正常..."
        else:
            return f"[{agent.name}] 任务执行完成"
    
    def execute_crew(self, mission: str, tasks: List[str] = None) -> Dict:
        """执行团队任务 - CrewAI风格"""
        try:
            logger.info(f"[Crew] 开始执行任务: {mission}")
            
            # 1. 项目经理规划任务
            manager = self.agents.get("项目经理")
            if manager:
                manager.status = "working"
            
            # 2. 如果没有指定任务，根据mission生成
            if not tasks:
                tasks = self._generate_tasks_from_mission(mission)
            
            # 3. 顺序执行任务（协作模式）
            results = []
            for i, task_desc in enumerate(tasks):
                task = self.create_task(task_desc, context=mission)
                result = self.execute_task(task)
                results.append(result)
                
                # 任务间传递上下文
                if i < len(tasks) - 1 and result["success"]:
                    self.tasks[i+1].context += f"\n前序任务结果: {result['result']}"
            
            # 4. 项目经理总结
            summary = self._generate_summary(mission, results)
            
            if manager:
                manager.status = "completed"
            
            return {
                "success": True,
                "mission": mission,
                "tasks_completed": len([r for r in results if r["success"]]),
                "tasks_failed": len([r for r in results if not r["success"]]),
                "summary": summary,
                "details": results
            }
            
        except Exception as e:
            logger.error(f"[Crew] 团队任务失败: {e}")
            return {"success": False, "error": str(e)}
    
    def _generate_tasks_from_mission(self, mission: str) -> List[str]:
        """根据任务目标生成具体任务列表"""
        mission_lower = mission.lower()
        
        if any(kw in mission_lower for kw in ["网站", "web", "页面", "frontend"]):
            return [
                "研究需求和竞品分析",
                "设计网站架构和UI",
                "编写前端代码",
                "编写后端API",
                "测试和优化性能"
            ]
        elif any(kw in mission_lower for kw in ["分析", "报告", "数据", "report"]):
            return [
                "收集相关数据",
                "清洗和整理数据",
                "分析数据趋势",
                "生成可视化图表",
                "撰写分析报告"
            ]
        elif any(kw in mission_lower for kw in ["代码", "程序", "开发", "app"]):
            return [
                "分析需求和设计架构",
                "编写核心功能代码",
                "编写单元测试",
                "代码审查和优化",
                "部署和监控"
            ]
        else:
            return [
                "分析任务需求",
                "制定执行计划",
                "执行核心任务",
                "检查结果质量",
                "总结和归档"
            ]
    
    def _generate_summary(self, mission: str, results: List[Dict]) -> str:
        """生成任务总结"""
        success_count = len([r for r in results if r["success"]])
        total = len(results)
        return f"任务 '{mission}' 完成。成功: {success_count}/{total}"
    
    def get_crew_status(self) -> Dict:
        """获取团队状态"""
        return {
            "agents": {name: agent.to_dict() for name, agent in self.agents.items()},
            "total_tasks": len(self.tasks),
            "pending": len([t for t in self.tasks if t.status == "pending"]),
            "in_progress": len([t for t in self.tasks if t.status == "in_progress"]),
            "completed": len([t for t in self.tasks if t.status == "completed"]),
            "failed": len([t for t in self.tasks if t.status == "failed"])
        }
    
    def health_check(self) -> Dict:
        """健康检查"""
        return {
            "status": "ok",
            "version": self.version,
            "agents": len(self.agents),
            "tasks": len(self.tasks),
            "executions": len(self.execution_log)
        }
    
    def get_stats(self) -> Dict:
        """获取统计"""
        return {
            "agents": len(self.agents),
            "tasks": len(self.tasks),
            "completed": len([t for t in self.tasks if t.status == "completed"]),
            "status": "running"
        }


# 模块导出
main_class = MultiAgentCrew
module_class = MultiAgentCrewAnalyzer

