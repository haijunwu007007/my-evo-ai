"""oauth_server - Enterprise OAuth2 Server Module
AUTO-EVO-AI v6.39 | Grade: A | Category: 安全认证
OAuth2服务端: Token端点/授权端点/用户确认/令牌内省/撤销
子引擎: TokenRevocationEngine(令牌撤销策略+批量管理)
"""
import logging, time, uuid, threading, secrets
from typing import Dict, Any, Optional, List
from datetime import datetime
from dataclasses import dataclass, field
from collections import defaultdict

from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)

logger = logging.getLogger(__name__)


@dataclass
class Client:
    client_id: str = ""
    name: str = ""
    secret: str = ""
    redirect_uris: List[str] = field(default_factory=list)
    grant_types: List[str] = field(default_factory=list)
    scopes: List[str] = field(default_factory=list)
    trusted: bool = False

    def __post_init__(self):
        if not self.client_id:
            self.client_id = str(uuid.uuid4())[:12]
        if not self.secret:
            self.secret = secrets.token_hex(16)


@dataclass
class AuthRequest:
    request_id: str = ""
    client_id: str = ""
    user_id: str = ""
    redirect_uri: str = ""
    scope: str = ""
    state: str = ""
    status: str = "pending"  # pending/approved/denied
    created_at: float = 0.0

    def __post_init__(self):
        if not self.request_id:
            self.request_id = str(uuid.uuid4())[:8]
        if not self.created_at:
            self.created_at = time.time()


@dataclass
class ServerToken:
    token_id: str = ""
    client_id: str = ""
    user_id: str = ""
    access_token: str = ""
    refresh_token: str = ""
    scope: str = ""
    created_at: float = 0.0
    expires_at: float = 0.0
    revoked: bool = False

    def __post_init__(self):
        if not self.token_id:
            self.token_id = str(uuid.uuid4())[:8]
        if not self.access_token:
            self.access_token = secrets.token_hex(32)
        if not self.refresh_token:
            self.refresh_token = secrets.token_hex(32)
        if not self.created_at:
            self.created_at = time.time()
        if not self.expires_at:
            self.expires_at = self.created_at + 3600


class TokenRevocationEngine:
    """令牌撤销引擎"""

    def __init__(self):
        self._revocation_log: List[Dict] = []

    def revoke(self, token_id: str, reason: str = "manual"):
        self._revocation_log.append({
            "token_id": token_id, "reason": reason,
            "time": datetime.now().isoformat(),
        })
        if len(self._revocation_log) > 5000:
            self._revocation_log = self._revocation_log[-3000:]

    def batch_revoke(self, token_ids: List[str], reason: str = "batch"):
        for tid in token_ids:
            self.revoke(tid, reason)

    def revocation_stats(self) -> Dict[str, Any]:
        from collections import Counter
        reasons = Counter(r["reason"] for r in self._revocation_log)
        return {"total_revoked": len(self._revocation_log),
                "by_reason": dict(reasons.most_common(10))}

    def get_log(self, limit: int = 50) -> List[Dict]:
        return self._revocation_log[-limit:]


class OauthServer(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    AUTO-EVO-AI v6.39 - OAuth2服务端模块
    """

    MODULE_ID = "oauth_server"
    MODULE_NAME = "OauthServer"
    VERSION = "1.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._clients: Dict[str, Client] = {}
        self._requests: Dict[str, AuthRequest] = {}
        self._tokens: Dict[str, ServerToken] = {}
        self._refresh_map: Dict[str, str] = {}
        self._revocation = TokenRevocationEngine()
        self._lock = threading.Lock()
        self._total_auth = 0
        self._total_tokens = 0
        self._init_default_client()

    def _init_default_client(self):
        c = Client(name="default_client", grant_types=["authorization_code", "client_credentials"],
                   scopes=["read", "write", "profile"], trusted=True)
        self._clients[c.client_id] = c

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                result = self._dispatch(action, params)
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                logger.error(f"[oauth_server] {action} error: {e}")
                return {"success": False, "error": str(e), "action": action}

    def _dispatch(self, action: str, params: Dict[str, Any]) -> Any:
        handler = {
            "status": self._get_status, "stats": self._get_stats,
            "health": self.health_check, "reset": self._reset,
            "configure": self._configure,
            # 客户端
            "register_client": self._register_client, "list_clients": self._list_clients,
            "remove_client": self._remove_client,
            # 授权
            "authorize": self._authorize, "approve": self._approve, "deny": self._deny,
            # 令牌
            "token": self._issue_token, "refresh": self._refresh_token,
            "introspect": self._introspect, "revoke": self._revoke,
            # 撤销日志
            "revocation_log": self._revocation_log, "revocation_stats": self._revocation_stats,
        }.get(action)
        if handler:
            return handler(params)
        return {"action": action, "module_id": self.MODULE_ID}

    def _register_client(self, params: Dict[str, Any]) -> Dict[str, Any]:
        c = Client(name=params.get("name", ""), redirect_uris=params.get("redirect_uris", []),
                   grant_types=params.get("grant_types", []), scopes=params.get("scopes", []))
        self._clients[c.client_id] = c
        self.audit("register_client", f"id={c.client_id} name={c.name}")
        return {"client_id": c.client_id, "client_secret": c.secret, "name": c.name}

    def _list_clients(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"clients": [{"client_id": c.client_id, "name": c.name,
                              "grant_types": c.grant_types, "scopes": c.scopes,
                              "trusted": c.trusted}
                             for c in self._clients.values()], "total": len(self._clients)}

    def _remove_client(self, params: Dict[str, Any]) -> Dict[str, Any]:
        cid = params.get("client_id", "")
        if cid in self._clients:
            del self._clients[cid]
            return {"client_id": cid, "removed": True}
        return {"error": "not_found"}

    def _authorize(self, params: Dict[str, Any]) -> Dict[str, Any]:
        client_id = params.get("client_id", "")
        user_id = params.get("user_id", "")
        redirect_uri = params.get("redirect_uri", "")
        scope = params.get("scope", "read")
        state = params.get("state", "")
        client = self._clients.get(client_id)
        if not client:
            return {"error": "client not found"}
        req = AuthRequest(client_id=client_id, user_id=user_id,
                          redirect_uri=redirect_uri, scope=scope, state=state)
        if client.trusted:
            req.status = "approved"
        self._requests[req.request_id] = req
        self._total_auth += 1
        return {"request_id": req.request_id, "status": req.status,
                "auto_approved": client.trusted}

    def _approve(self, params: Dict[str, Any]) -> Dict[str, Any]:
        rid = params.get("request_id", "")
        req = self._requests.get(rid)
        if not req:
            return {"error": "request not found"}
        req.status = "approved"
        return {"request_id": rid, "status": "approved"}

    def _deny(self, params: Dict[str, Any]) -> Dict[str, Any]:
        rid = params.get("request_id", "")
        req = self._requests.get(rid)
        if not req:
            return {"error": "request not found"}
        req.status = "denied"
        return {"request_id": rid, "status": "denied"}

    def _issue_token(self, params: Dict[str, Any]) -> Dict[str, Any]:
        grant_type = params.get("grant_type", "")
        if grant_type == "authorization_code":
            code = params.get("code", params.get("request_id", ""))
            req = self._requests.get(code)
            if not req or req.status != "approved":
                return {"error": "invalid or unapproved request"}
            token = ServerToken(client_id=req.client_id, user_id=req.user_id, scope=req.scope)
        elif grant_type == "client_credentials":
            client_id = params.get("client_id", "")
            client = self._clients.get(client_id)
            if not client:
                return {"error": "invalid client"}
            token = ServerToken(client_id=client_id, user_id="client", scope=params.get("scope", ""))
        else:
            return {"error": "unsupported_grant_type"}
        self._tokens[token.token_id] = token
        self._refresh_map[token.refresh_token] = token.token_id
        self._total_tokens += 1
        return {"access_token": token.access_token, "refresh_token": token.refresh_token,
                "expires_in": 3600, "scope": token.scope}

    def _refresh_token(self, params: Dict[str, Any]) -> Dict[str, Any]:
        rt = params.get("refresh_token", "")
        tid = self._refresh_map.get(rt)
        if not tid or tid not in self._tokens:
            return {"error": "invalid refresh_token"}
        old = self._tokens[tid]
        new = ServerToken(client_id=old.client_id, user_id=old.user_id, scope=old.scope)
        self._tokens[new.token_id] = new
        del self._refresh_map[rt]
        self._refresh_map[new.refresh_token] = new.token_id
        return {"access_token": new.access_token, "refresh_token": new.refresh_token}

    def _introspect(self, params: Dict[str, Any]) -> Dict[str, Any]:
        at = params.get("token", "")
        for t in self._tokens.values():
            if t.access_token == at and not t.revoked:
                return {"active": time.time() <= t.expires_at, "client_id": t.client_id,
                        "user_id": t.user_id, "scope": t.scope, "expires_at": t.expires_at}
        return {"active": False}

    def _revoke(self, params: Dict[str, Any]) -> Dict[str, Any]:
        at = params.get("token", "")
        reason = params.get("reason", "manual")
        for t in self._tokens.values():
            if t.access_token == at:
                t.revoked = True
                self._revocation.revoke(t.token_id, reason)
                return {"revoked": True, "token_id": t.token_id}
        return {"error": "token not found"}

    def _revocation_log(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"log": self._revocation.get_log(params.get("limit", 50))}

    def _revocation_stats(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return self._revocation.revocation_stats()

    def _get_status(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
            "version": self.VERSION, "status": "running",
            "clients": len(self._clients), "active_tokens": len([t for t in self._tokens.values() if not t.revoked]),
            "pending_requests": len([r for r in self._requests.values() if r.status == "pending"]),
        }

    def _get_stats(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {"total_auth": self._total_auth, "total_tokens": self._total_tokens,
                "clients": len(self._clients), "revoked": len(self._revocation._revocation_log)}

    def _reset(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        self._requests.clear()
        self._tokens.clear()
        self._refresh_map.clear()
        return {"status": "reset_ok"}

    def _configure(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"configured": list(params.keys())}

    def health_check(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {"healthy": True, "status": "ok", "clients": len(self._clients)}


module_class = OauthServer
