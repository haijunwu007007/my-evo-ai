"""oauth_provider - Enterprise OAuth2 Provider Module
AUTO-EVO-AI v6.39 | Grade: A | Category: 安全认证
OAuth2: 授权码/客户端凭证/密码/隐式模式, 应用注册, 令牌管理, scope权限控制
子引擎: ScopePermissionEngine(scope权限评估+审批)
"""
import logging, hashlib, json, time, uuid, threading, secrets
from typing import Dict, Any, Optional, List, Set, Tuple
from datetime import datetime
from dataclasses import dataclass, field
from collections import defaultdict

from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)

logger = logging.getLogger(__name__)


@dataclass
class OAuthApp:
    """OAuth应用注册"""
    app_id: str = ""
    name: str = ""
    client_id: str = ""
    client_secret: str = ""
    redirect_uris: List[str] = field(default_factory=list)
    grant_types: List[str] = field(default_factory=lambda: ["authorization_code"])
    scopes: List[str] = field(default_factory=lambda: ["read"])
    enabled: bool = True
    created_at: str = ""

    def __post_init__(self):
        if not self.app_id:
            self.app_id = str(uuid.uuid4())[:8]
        if not self.client_id:
            self.client_id = f"client_{self.app_id}"
        if not self.client_secret:
            self.client_secret = secrets.token_hex(32)
        if not self.created_at:
            self.created_at = datetime.now().isoformat()


@dataclass
class AuthCode:
    """授权码"""
    code: str = ""
    app_id: str = ""
    user_id: str = ""
    redirect_uri: str = ""
    scopes: List[str] = field(default_factory=list)
    created_at: float = 0.0
    expires_at: float = 0.0
    used: bool = False

    def __post_init__(self):
        if not self.code:
            self.code = secrets.token_hex(16)
        if not self.created_at:
            self.created_at = time.time()
        if not self.expires_at:
            self.expires_at = self.created_at + 300  # 5min


@dataclass
class OAuthToken:
    """OAuth令牌"""
    token_id: str = ""
    app_id: str = ""
    user_id: str = ""
    access_token: str = ""
    refresh_token: str = ""
    token_type: str = "Bearer"
    scopes: List[str] = field(default_factory=list)
    created_at: float = 0.0
    expires_at: float = 0.0

    def __post_init__(self):
        if not self.token_id:
            self.token_id = str(uuid.uuid4())[:12]
        if not self.access_token:
            self.access_token = secrets.token_hex(32)
        if not self.refresh_token:
            self.refresh_token = secrets.token_hex(32)
        if not self.created_at:
            self.created_at = time.time()
        if not self.expires_at:
            self.expires_at = self.created_at + 3600


class ScopePermissionEngine:
    """Scope权限引擎 — 评估、审批、冲突检测"""

    SYSTEM_SCOPES = {
        "read": "读取资源", "write": "写入资源", "delete": "删除资源",
        "admin": "管理权限", "profile": "用户信息", "email": "邮箱访问",
        "openid": "身份认证", "offline_access": "离线访问",
    }

    def evaluate(self, requested: List[str], granted: List[str]) -> Dict[str, Any]:
        """评估scope请求"""
        allowed = [s for s in requested if s in granted]
        denied = [s for s in requested if s not in granted]
        unknown = [s for s in requested if s not in self.SYSTEM_SCOPES]
        return {
            "allowed": allowed, "denied": denied, "unknown": unknown,
            "approved": len(denied) == 0,
            "risk_level": "high" if "admin" in allowed else "medium" if "delete" in allowed else "low",
        }

    def check_conflict(self, scopes: List[str]) -> Dict[str, Any]:
        """检查scope冲突"""
        conflicts = []
        if "admin" in scopes and "read" not in scopes:
            conflicts.append("admin scope通常应配合read使用")
        if len(scopes) > 5:
            conflicts.append("请求scope过多,建议缩减")
        return {"has_conflict": len(conflicts) > 0, "conflicts": conflicts}

    def get_scope_info(self, scopes: List[str]) -> List[Dict]:
        return [{"scope": s, "description": self.SYSTEM_SCOPES.get(s, "自定义scope")}
                for s in scopes]


class OauthProvider(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    AUTO-EVO-AI v6.39 - OAuth2认证提供者模块
    """

    MODULE_ID = "oauth_provider"
    MODULE_NAME = "OauthProvider"
    VERSION = "1.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._apps: Dict[str, OAuthApp] = {}
        self._auth_codes: Dict[str, AuthCode] = {}
        self._tokens: Dict[str, OAuthToken] = {}
        self._refresh_index: Dict[str, str] = {}  # refresh_token -> token_id
        self._scope_engine = ScopePermissionEngine()
        self._lock = threading.Lock()
        self._total_authorizations = 0
        self._total_token_issued = 0
        self._total_revoked = 0
        self._init_default_app()

    def _init_default_app(self):
        app = OAuthApp(name="default_app", redirect_uris=["http://localhost:8766/callback"],
                       grant_types=["authorization_code", "client_credentials"],
                       scopes=["read", "write", "profile"])
        self._apps[app.app_id] = app

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                result = self._dispatch(action, params)
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                logger.error(f"[oauth_provider] {action} error: {e}")
                return {"success": False, "error": str(e), "action": action}

    def _dispatch(self, action: str, params: Dict[str, Any]) -> Any:
        handler = {
            "status": self._get_status, "stats": self._get_stats,
            "health": self.health_check, "reset": self._reset,
            "configure": self._configure,
            # 应用管理
            "register_app": self._register_app,
            "list_apps": self._list_apps,
            "remove_app": self._remove_app,
            "get_app": self._get_app,
            # OAuth流程
            "authorize": self._authorize,
            "token": self._exchange_token,
            "refresh": self._refresh_token,
            "revoke": self._revoke_token,
            # 验证
            "validate": self._validate_token,
            "introspect": self._introspect_token,
            # Scope
            "evaluate_scopes": self._evaluate_scopes,
            "scope_info": self._scope_info,
        }.get(action)
        if handler:
            return handler(params)
        return {"action": action, "module_id": self.MODULE_ID}

    def _register_app(self, params: Dict[str, Any]) -> Dict[str, Any]:
        app = OAuthApp(
            name=params.get("name", "unnamed"),
            redirect_uris=params.get("redirect_uris", []),
            grant_types=params.get("grant_types", ["authorization_code"]),
            scopes=params.get("scopes", ["read"]),
        )
        self._apps[app.app_id] = app
        self.audit("register_app", f"app={app.app_id} name={app.name}")
        return {"app_id": app.app_id, "client_id": app.client_id,
                "client_secret": app.client_secret, "name": app.name}

    def _list_apps(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"apps": [{"app_id": a.app_id, "name": a.name, "client_id": a.client_id,
                          "grant_types": a.grant_types, "scopes": a.scopes, "enabled": a.enabled}
                         for a in self._apps.values()], "total": len(self._apps)}

    def _remove_app(self, params: Dict[str, Any]) -> Dict[str, Any]:
        aid = params.get("app_id", "")
        if aid in self._apps:
            del self._apps[aid]
            return {"app_id": aid, "removed": True}
        return {"error": "not_found"}

    def _get_app(self, params: Dict[str, Any]) -> Dict[str, Any]:
        aid = params.get("app_id", "")
        a = self._apps.get(aid)
        if not a:
            return {"error": "not_found"}
        return {"app_id": a.app_id, "name": a.name, "client_id": a.client_id,
                "redirect_uris": a.redirect_uris, "grant_types": a.grant_types, "scopes": a.scopes}

    def _authorize(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """生成授权码"""
        app_id = params.get("app_id", "")
        user_id = params.get("user_id", "")
        redirect_uri = params.get("redirect_uri", "")
        scopes = params.get("scopes", ["read"])
        app = self._apps.get(app_id)
        if not app:
            return {"error": "app not found"}
        eval_result = self._scope_engine.evaluate(scopes, app.scopes)
        code = AuthCode(app_id=app_id, user_id=user_id, redirect_uri=redirect_uri, scopes=eval_result["allowed"])
        self._auth_codes[code.code] = code
        self._total_authorizations += 1
        self.audit("authorize", f"app={app_id} user={user_id} scopes={eval_result['allowed']}")
        return {"code": code.code, "redirect_uri": redirect_uri,
                "scopes": eval_result["allowed"], "expires_in": 300}

    def _exchange_token(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """授权码换令牌"""
        code_str = params.get("code", "")
        grant_type = params.get("grant_type", "authorization_code")
        if grant_type == "client_credentials":
            return self._client_credentials(params)
        code = self._auth_codes.get(code_str)
        if not code or code.used:
            return {"error": "invalid or used code"}
        if time.time() > code.expires_at:
            return {"error": "code expired"}
        code.used = True
        token = OAuthToken(app_id=code.app_id, user_id=code.user_id, scopes=code.scopes)
        self._tokens[token.token_id] = token
        self._refresh_index[token.refresh_token] = token.token_id
        self._total_token_issued += 1
        return {"access_token": token.access_token, "refresh_token": token.refresh_token,
                "token_type": token.token_type, "expires_in": 3600, "scopes": token.scopes}

    def _client_credentials(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """客户端凭证模式"""
        client_id = params.get("client_id", "")
        client_secret = params.get("client_secret", "")
        scopes = params.get("scopes", ["read"])
        app = None
        for a in self._apps.values():
            if a.client_id == client_id and a.client_secret == client_secret:
                app = a
                break
        if not app:
            return {"error": "invalid client credentials"}
        eval_result = self._scope_engine.evaluate(scopes, app.scopes)
        token = OAuthToken(app_id=app.app_id, user_id="client", scopes=eval_result["allowed"])
        self._tokens[token.token_id] = token
        self._total_token_issued += 1
        return {"access_token": token.access_token, "token_type": token.token_type,
                "expires_in": 3600, "scopes": token.scopes}

    def _refresh_token(self, params: Dict[str, Any]) -> Dict[str, Any]:
        refresh_token = params.get("refresh_token", "")
        token_id = self._refresh_index.get(refresh_token)
        if not token_id:
            return {"error": "invalid refresh_token"}
        old = self._tokens.get(token_id)
        if not old:
            return {"error": "token not found"}
        new = OAuthToken(app_id=old.app_id, user_id=old.user_id, scopes=old.scopes)
        self._tokens[new.token_id] = new
        del self._refresh_index[refresh_token]
        self._refresh_index[new.refresh_token] = new.token_id
        return {"access_token": new.access_token, "refresh_token": new.refresh_token,
                "expires_in": 3600}

    def _revoke_token(self, params: Dict[str, Any]) -> Dict[str, Any]:
        token_id = params.get("token_id", "")
        access_token = params.get("access_token", "")
        tid = token_id
        if not tid:
            for t in self._tokens.values():
                if t.access_token == access_token:
                    tid = t.token_id
                    break
        if tid and tid in self._tokens:
            tok = self._tokens[tid]
            self._refresh_index.pop(tok.refresh_token, None)
            del self._tokens[tid]
            self._total_revoked += 1
            return {"revoked": True, "token_id": tid}
        return {"error": "token not found"}

    def _validate_token(self, params: Dict[str, Any]) -> Dict[str, Any]:
        access_token = params.get("access_token", "")
        for t in self._tokens.values():
            if t.access_token == access_token:
                if time.time() > t.expires_at:
                    return {"valid": False, "error": "expired"}
                return {"valid": True, "app_id": t.app_id, "user_id": t.user_id, "scopes": t.scopes}
        return {"valid": False, "error": "not_found"}

    def _introspect_token(self, params: Dict[str, Any]) -> Dict[str, Any]:
        access_token = params.get("access_token", "")
        for t in self._tokens.values():
            if t.access_token == access_token:
                return {
                    "active": time.time() <= t.expires_at,
                    "client_id": t.app_id, "user_id": t.user_id,
                    "scopes": t.scopes, "token_type": t.token_type,
                    "expires_at": t.expires_at,
                }
        return {"active": False}

    def _evaluate_scopes(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return self._scope_engine.evaluate(params.get("requested", []), params.get("granted", []))

    def _scope_info(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"scopes": self._scope_engine.get_scope_info(params.get("scopes", []))}

    def _get_status(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
            "version": self.VERSION, "status": "running",
            "apps": len(self._apps), "active_tokens": len(self._tokens),
            "pending_codes": len([c for c in self._auth_codes.values() if not c.used]),
        }

    def _get_stats(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "total_authorizations": self._total_authorizations,
            "total_token_issued": self._total_token_issued,
            "total_revoked": self._total_revoked,
            "apps": len(self._apps),
            "active_tokens": len(self._tokens),
        }

    def _reset(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        self._auth_codes.clear()
        self._tokens.clear()
        self._refresh_index.clear()
        self._total_authorizations = 0
        self._total_token_issued = 0
        self._total_revoked = 0
        return {"status": "reset_ok"}

    def _configure(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"configured": list(params.keys())}

    def health_check(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {"healthy": True, "status": "ok", "apps": len(self._apps)}


module_class = OauthProvider
