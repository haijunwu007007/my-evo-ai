import time
import os
import json
import logging
import hashlib
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional

from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)

logger = logging.getLogger(__name__)

class IotEdgeAnalyzer(EnterpriseModule):
    """iot_edge 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        super().__init__()
        self._operation_count = 0
        self._error_count = 0
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "iot_edge"
        self.version = "1.0.0"
        self._analyzer = self
        self._history = []
        self._max_history = 10000
    
    def analyze(self, context: dict = None) -> dict:
        context = context or {}
        result = {"analyzer": "IotEdgeAnalyzer", "timestamp": time.time(), "records": len(self._history), "summary": self._summary()}
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-5000:]
        return result
    
    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "iot_edge"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== iot_edge ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}
    async def execute(self, action: str = "status", params: dict = None) -> dict:
            

            params = params or {}
            action = action or "status"
            try:
                self._operation_count += 1
                if action == "status":
                    return {"success": True, "data": {"status": "running", "operations": self._operation_count, "errors": self._error_count}}
                elif action == "stats":
                    return {"success": True, "data": {"operations": self._operation_count, "errors": self._error_count}}
                elif action == "health":
                    return {"success": True, "data": {"healthy": True}}
                elif action == "configure":
                    return {"success": True, "data": {"message": "Configured"}}
                elif action == "reset":
                    self._operation_count = 0
                    self._error_count = 0
                    return {"success": True, "data": {"message": "Reset"}}
                else:
                    return {"success": False, "error": f"Unknown action: {action}"}
            except Exception as e:
                self._error_count += 1
                return {"success": False, "error": str(e)}

class IoTDevice(object):
    """物联网设备"""
    
    def __init__(self, device_id: str, name: str, device_type: str, location: str = ""):
    
        self.id = device_id
        self.name = name
        self.type = device_type
        self.location = location
        self.status = "online"  # online, offline, error, maintenance
        self.last_seen = datetime.now().isoformat()
        self.sensors: Dict[str, Any] = {}
        self.data_history: List[Dict] = []
        self.firmware_version = "1.0.0"
        self.battery_level = 100.0
        
    def update_sensor(self, sensor_name: str, value: Any, unit: str = ""):
        """更新传感器数据"""
        self.sensors[sensor_name] = {
            "value": value,
            "unit": unit,
            "updated_at": datetime.now().isoformat()
        }
        
        self.data_history.append({
            "sensor": sensor_name,
            "value": value,
            "unit": unit,
            "timestamp": datetime.now().isoformat()
        })
        
        # 只保留最近1000条
        if len(self.data_history) > 1000:
            self.data_history = self.data_history[-1000:]
        
        self.last_seen = datetime.now().isoformat()
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "name": self.name,
            "type": self.type,
            "location": self.location,
            "status": self.status,
            "last_seen": self.last_seen,
            "sensors": self.sensors,
            "battery_level": self.battery_level,
            "firmware": self.firmware_version
        }


class IoTEdge:
    """物联网边缘计算引擎"""
    
    def __init__(self):
        self.version = "1.0.0"
        self.enabled = True
        self.devices: Dict[str, IoTDevice] = {}
        self.device_types = {
            "temperature": {"name": "温度传感器", "unit": "°C"},
            "humidity": {"name": "湿度传感器", "unit": "%"},
            "motion": {"name": "运动检测器", "unit": "bool"},
            "light": {"name": "光照传感器", "unit": "lux"},
            "pressure": {"name": "压力传感器", "unit": "Pa"},
            "camera": {"name": "摄像头", "unit": "image"},
            "smart_lock": {"name": "智能门锁", "unit": "status"},
            "energy_meter": {"name": "电能表", "unit": "kWh"}
        }
        self.rules: List[Dict] = []
        self.edge_algorithms: Dict[str, Any] = {}
        
        # 初始化示例设备
        self._init_sample_devices()
        
    def _init_sample_devices(self):
        """初始化示例设备"""
        sample_devices = [
            ("temp_001", "客厅温度传感器", "temperature", "客厅"),
            ("hum_001", "卧室湿度传感器", "humidity", "卧室"),
            ("motion_001", "门口运动检测", "motion", "门口"),
            ("light_001", "阳台光照传感器", "light", "阳台"),
            ("lock_001", "大门智能锁", "smart_lock", "大门"),
            ("energy_001", "总电表", "energy_meter", "配电箱")
        ]
        
        for device_id, name, dtype, location in sample_devices:
            device = IoTDevice(device_id, name, dtype, location)
            self.devices[device_id] = device
            
            # 模拟初始数据
            if dtype == "temperature":
                device.update_sensor("temperature", 25.5, "°C")
            elif dtype == "humidity":
                device.update_sensor("humidity", 60, "%")
            elif dtype == "motion":
                device.update_sensor("motion", False, "bool")
            elif dtype == "light":
                device.update_sensor("light", 500, "lux")
            elif dtype == "smart_lock":
                device.update_sensor("locked", True, "bool")
            elif dtype == "energy_meter":
                device.update_sensor("power", 2.5, "kW")
    
    def register_device(self, device_id: str, name: str, device_type: str, location: str = "") -> Dict:
        """注册设备"""
        try:
            if device_type not in self.device_types:
                return {"success": False, "error": f"不支持的设备类型: {device_type}"}
            
            if device_id in self.devices:
                return {"success": False, "error": "设备ID已存在"}
            
            device = IoTDevice(device_id, name, device_type, location)
            self.devices[device_id] = device
            
            logger.info(f"[IoT] 注册设备: {name} ({device_type})")
            
            return {
                "success": True,
                "device_id": device_id,
                "type": device_type,
                "status": "registered"
            }
            
        except Exception as e:
            logger.error(f"[IoT] 注册设备失败: {e}")
            return {"success": False, "error": str(e)}
    
    def get_device_data(self, device_id: str) -> Dict:
        """获取设备数据"""
        try:
            device = self.devices.get(device_id)
            if not device:
                return {"success": False, "error": "设备不存在"}
            
            return {
                "success": True,
                "device": device.to_dict()
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def update_device_data(self, device_id: str, sensor_data: Dict) -> Dict:
        """更新设备传感器数据"""
        try:
            device = self.devices.get(device_id)
            if not device:
                return {"success": False, "error": "设备不存在"}
            
            for sensor_name, value in sensor_data.items():
                device_type_info = self.device_types.get(device.type, {})
                unit = device_type_info.get("unit", "")
                device.update_sensor(sensor_name, value, unit)
            
            # 检查规则触发
            triggered = self._check_rules(device)
            
            return {
                "success": True,
                "device_id": device_id,
                "sensors_updated": len(sensor_data),
                "rules_triggered": triggered
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def _check_rules(self, device: IoTDevice) -> List[Dict]:
        """检查触发的规则"""
        triggered = []
        
        for rule in self.rules:
            if rule["device_id"] == device.id:
                sensor = rule.get("sensor")
                condition = rule.get("condition")
                threshold = rule.get("threshold")
                
                if sensor in device.sensors:
                    value = device.sensors[sensor]["value"]
                    
                    triggered_rule = False
                    if condition == ">" and value > threshold:
                        triggered_rule = True
                    elif condition == "<" and value < threshold:
                        triggered_rule = True
                    elif condition == "==" and value == threshold:
                        triggered_rule = True
                    
                    if triggered_rule:
                        triggered.append({
                            "rule_id": rule["id"],
                            "action": rule["action"],
                            "value": value,
                            "threshold": threshold
                        })
        
        return triggered
    
    def add_rule(self, name: str, device_id: str, sensor: str, condition: str, threshold: float, action: str) -> Dict:
        """添加自动化规则"""
        try:
            rule_id = f"rule_{len(self.rules)+1:03d}"
            
            rule = {
                "id": rule_id,
                "name": name,
                "device_id": device_id,
                "sensor": sensor,
                "condition": condition,
                "threshold": threshold,
                "action": action,
                "enabled": True,
                "created_at": datetime.now().isoformat()
            }
            
            self.rules.append(rule)
            
            return {
                "success": True,
                "rule_id": rule_id,
                "rule": rule
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def edge_compute(self, device_id: str, algorithm: str, params: Dict = None) -> Dict:
        """边缘计算"""
        try:
            device = self.devices.get(device_id)
            if not device:
                return {"success": False, "error": "设备不存在"}
            
            params = params or {}
            
            if algorithm == "average":
                # 计算平均值
                sensor = params.get("sensor", "")
                if sensor in device.sensors:
                    history = [d["value"] for d in device.data_history if d["sensor"] == sensor]
                    if history:
                        avg = sum(history) / len(history)
                        return {"success": True, "result": avg, "algorithm": "average", "samples": len(history)}
                
            elif algorithm == "anomaly_detection":
                # 异常检测
                sensor = params.get("sensor", "")
                if sensor in device.sensors:
                    current = device.sensors[sensor]["value"]
                    history = [d["value"] for d in device.data_history if d["sensor"] == sensor][-100:]
                    if history:
                        avg = sum(history) / len(history)
                        std = (sum((x - avg) ** 2 for x in history) / len(history)) ** 0.5
                        is_anomaly = abs(current - avg) > 2 * std
                        return {
                            "success": True,
                            "is_anomaly": is_anomaly,
                            "current": current,
                            "average": avg,
                            "threshold": 2 * std
                        }
            
            elif algorithm == "forecast":
                # 简单预测
                sensor = params.get("sensor", "")
                if sensor in device.sensors:
                    history = [d["value"] for d in device.data_history if d["sensor"] == sensor][-10:]
                    if len(history) >= 2:
                        # 线性趋势
                        trend = (history[-1] - history[0]) / len(history)
                        forecast = history[-1] + trend * params.get("steps", 1)
                        return {"success": True, "forecast": forecast, "trend": trend}
            
            return {"success": False, "error": "算法不支持或数据不足"}
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def list_devices(self) -> List[Dict]:
        """列出所有设备"""
        return [device.to_dict() for device in self.devices.values()]
    
    def get_stats(self) -> Dict:
        return {
            "devices": len(self.devices),
            "online": len([d for d in self.devices.values() if d.status == "online"]),
            "rules": len(self.rules),
            "data_points": sum(len(d.data_history) for d in self.devices.values()),
            "status": "running"
        }
    
    def health_check(self) -> Dict:
        return {
            "status": "ok",
            "version": self.version,
            "features": ["device_mgmt", "sensor_data", "rules", "edge_compute"]
        }

        main_class = IoTEdge
module_class = IotEdgeAnalyzer

