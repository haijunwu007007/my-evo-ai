"""
        AUTO-EVO-AI v7.0 - Rate Limit Redis Module
Grade: A | Category: Cache
Distributed rate limiting with sliding window, token bucket, leaky bucket
"""

import os
import time
import logging
import threading
import hashlib
from typing import Any, Dict, List, Optional
from datetime import datetime
from dataclasses import dataclass, field
from collections import OrderedDict

try:
    from modules._base.enterprise_module import (
    EnterpriseModule,
    ModuleStatus, CircuitBreakerMixin, RateLimiterMixin
)
    from modules._base.tracing import trace_operation
    from modules._base.metrics import metrics_collector, prometheus_timer
    from modules._base.audit import AuditLogger
except ImportError:
    class EnterpriseModule:
        def __init__(self, config=None): pass
        pass
    class ModuleStatus: ACTIVE='active'; STOPPED='stopped'
    trace_operation = prometheus_timer = metrics_collector = AuditLogger = lambda **kw: (lambda f: f)

    logger = logging.getLogger(__name__)


@dataclass
class RateLimitRule:
    name: str
    algorithm: str = 'sliding_window'
    limit: int = 100
    window_seconds: int = 60
    burst: int = 0
    keys: List[str] = field(default_factory=list)
    enabled: bool = True


@dataclass
class RequestRecord:
    timestamps: List[float] = field(default_factory=list)
    tokens: float = 0.0
    last_refill: float = field(default_factory=time.time)
    last_leak: float = field(default_factory=time.time)
    queue: float = 0.0



class RateLimitAnalyzer(object):
    """rate_limit_redis 运营分析引擎
    
    - 分析限流触发频率
    - 检测误伤率
    - 统计各客户端配额使用
    """
    
    def __init__(self):
        self._stats = {}
    
    def record(self, metric: str, value: float = 1.0):
        self._stats.setdefault(metric, []).append(value)
        if len(self._stats[metric]) > 1000:
            self._stats[metric] = self._stats[metric][-500:]
    
    def analyze(self) -> dict:
        summary = {}
        for k, v in self._stats.items():
            if v:
                summary[k] = {"count": len(v), "avg": sum(v)/len(v), "last": v[-1]}
        return {"analyzer": "RateLimitAnalyzer", "module": "rate_limit_redis", "summary": summary}

class RateLimitRedisModule(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """Distributed rate limiter with multiple algorithms"""

    def __init__(self, config=None):

        super().__init__(config)
        self._rules: Dict[str, RateLimitRule] = {}
        self._records: Dict[str, RequestRecord] = {}
        self._blacklist: Dict[str, float] = {}
        self._whitelist: set = set()
        self._lock = threading.Lock()
        self._stats = {'allowed': 0, 'rejected': 0, 'blacklisted': 0}

    def _cfg(self, key, default):
        if self._config and isinstance(self._config, dict):
            return self._config.get(key, default)
        return default

    def initialize(self) -> dict:
        self.trace("rate_limit_redis.initialize", "start")
        self.trace("rate_limit_redis.initialize", "end")
        self.audit('initialize', 'RateLimitRedis init')
        self._rules['api_default'] = RateLimitRule(
            'api_default', 'sliding_window', 100, 60)
        self._rules['api_auth'] = RateLimitRule(
            'api_auth', 'token_bucket', 5, 60, burst=3)
        self._rules['api_upload'] = RateLimitRule(
            'api_upload', 'leaky_bucket', 10, 60)
        self._whitelist.add('internal-service')
        return {'success': True, 'rules': len(self._rules),
                'whitelist': len(self._whitelist)}

    def health_check(self) -> dict:
        return {'healthy': True, 'rules': len(self._rules),
                'tracked_keys': len(self._records),
                'blacklist': len(self._blacklist),
                'stats': self._stats}

    async def execute(self, action: str, params: dict = None) -> dict:
        params = params or {}
        actions = {
            'check': self._check, 'add_rule': self._add_rule,
            'remove_rule': self._remove_rule, 'list_rules': self._list_rules,
            'blacklist_add': self._bl_add, 'blacklist_remove': self._bl_remove,
            'whitelist_add': self._wl_add, 'whitelist_remove': self._wl_remove,
            'stats': self._stats_op, 'reset': self._reset,
            'get_usage': self._get_usage, 'batch_check': self._batch_check
        }
        handler = actions.get(action)
        if handler:
            self.audit(action, str(params)[:100])
            return handler(params)
        return {'success': False, 'error': f'Unsupported: {action}'}

    def _check(self, p: dict) -> dict:
        key = p.get('key', '')
        rule_name = p.get('rule', 'api_default')
        weight = p.get('weight', 1)

        if key in self._whitelist:
            return {'success': True, 'allowed': True, 'reason': 'whitelist'}

        if key in self._blacklist:
            if time.time() - self._blacklist[key] < 3600:
                return {'success': True, 'allowed': False, 'reason': 'blacklisted'}
            del self._blacklist[key]

        rule = self._rules.get(rule_name)
        if not rule or not rule.enabled:
            self._stats['allowed'] += 1
            return {'success': True, 'allowed': True, 'reason': 'no_rule'}

        record = self._records.setdefault(key, RequestRecord())
        now = time.time()

        if rule.algorithm == 'sliding_window':
            cutoff = now - rule.window_seconds
            record.timestamps = [t for t in record.timestamps if t > cutoff]
            allowed = len(record.timestamps) + weight <= rule.limit
            if allowed:
                for _ in range(weight):
                    record.timestamps.append(now)

        elif rule.algorithm == 'token_bucket':
            rate = rule.limit / rule.window_seconds
            elapsed = now - record.last_refill
            record.tokens = min(rule.limit,
                                record.tokens + elapsed * rate)
            record.last_refill = now
            burst_limit = rule.limit + (rule.burst or 0)
            allowed = record.tokens >= weight
            if allowed:
                record.tokens -= weight

        elif rule.algorithm == 'leaky_bucket':
            rate = rule.limit / rule.window_seconds
            elapsed = now - record.last_leak
            record.queue = max(0, record.queue - elapsed * rate)
            record.last_leak = now
            allowed = record.queue + weight <= rule.limit
            if allowed:
                record.queue += weight

        elif rule.algorithm == 'fixed_window':
            window_key = f'{key}:{int(now / rule.window_seconds)}'
            window_rec = self._records.setdefault(
                window_key, RequestRecord())
            window_rec.timestamps.append(now)
            allowed = len(window_rec.timestamps) <= rule.limit

        else:
            allowed = True

        if allowed:
            self._stats['allowed'] += 1
        else:
            self._stats['rejected'] += 1

        remaining = self._remaining(record, rule, now)
        return {'success': True, 'allowed': allowed,
                'remaining': remaining,
                'retry_after': 0 if allowed else int(rule.window_seconds),
                'algorithm': rule.algorithm}

    def _remaining(self, record, rule, now):
        if rule.algorithm == 'sliding_window':
            cutoff = now - rule.window_seconds
            valid = [t for t in record.timestamps if t > cutoff]
            return max(0, rule.limit - len(valid))
        elif rule.algorithm == 'token_bucket':
            return max(0, int(record.tokens))
        elif rule.algorithm == 'leaky_bucket':
            return max(0, int(rule.limit - record.queue))
        return rule.limit

    def _add_rule(self, p: dict) -> dict:
        name = p.get('name', f'rule_{len(self._rules) + 1}')
        rule = RateLimitRule(
            name, p.get('algorithm', 'sliding_window'),
            p.get('limit', 100), p.get('window_seconds', 60),
            p.get('burst', 0))
        self._rules[name] = rule
        return {'success': True, 'rule': name}

    def _remove_rule(self, p: dict) -> dict:
        name = p.get('name', '')
        if name in self._rules:
            del self._rules[name]
            return {'success': True}
        return {'success': False, 'error': 'Not found'}

    def _list_rules(self, p: dict) -> dict:
        return {'success': True, 'rules': [
            {'name': r.name, 'algorithm': r.algorithm,
             'limit': r.limit, 'window': r.window_seconds,
             'burst': r.burst, 'enabled': r.enabled}
            for r in self._rules.values()]}

    def _bl_add(self, p: dict) -> dict:
        key = p.get('key', '')
        duration = p.get('duration', 3600)
        self._blacklist[key] = time.time() + duration
        self._stats['blacklisted'] += 1
        return {'success': True, 'key': key, 'duration': duration}

    def _bl_remove(self, p: dict) -> dict:
        key = p.get('key', '')
        if key in self._blacklist:
            del self._blacklist[key]
            return {'success': True}
        return {'success': False, 'error': 'Not in blacklist'}

    def _wl_add(self, p: dict) -> dict:
        key = p.get('key', '')
        self._whitelist.add(key)
        return {'success': True}

    def _wl_remove(self, p: dict) -> dict:
        key = p.get('key', '')
        self._whitelist.discard(key)
        return {'success': True}

    def _stats_op(self, p: dict) -> dict:
        return {'success': True, 'stats': self._stats,
                'rules': len(self._rules),
                'tracked_keys': len(self._records)}

    def _reset(self, p: dict) -> dict:
        key = p.get('key', '')
        if key:
            self._records.pop(key, None)
            return {'success': True, 'reset': key}
        self._records.clear()
        return {'success': True, 'reset_all': True}

    def _get_usage(self, p: dict) -> dict:
        key = p.get('key', '')
        record = self._records.get(key)
        if not record:
            return {'success': True, 'usage': 0}
        cutoff = time.time() - 60
        recent = len([t for t in record.timestamps if t > cutoff])
        return {'success': True, 'usage': recent,
                'total_requests': len(record.timestamps)}

    def _batch_check(self, p: dict) -> dict:
        keys = p.get('keys', [])
        rule = p.get('rule', 'api_default')
        results = []
        for key in keys:
            r = self._check({'key': key, 'rule': rule})
            results.append({'key': key, 'allowed': r['allowed']})
        return {'success': True, 'results': results}

    async def shutdown(self) -> dict:
        return {'success': True, 'stats': self._stats}


    def batch_operation(self, operations: list) -> dict:
        """批量执行操作，支持事务语义"""
        results = []
        success = 0
        failed = 0
        for op in operations:
            try:
                method = getattr(self, op.get("action", ""), None)
                if method and callable(method):
                    params = op.get("params", {})
                    result = method(**params)
                    results.append({"op": op.get("action"), "success": True, "result": str(result)[:200]})
                    success += 1
                else:
                    results.append({"op": op.get("action"), "success": False, "error": "method not found"})
                    failed += 1
            except Exception as e:
                results.append({"op": op.get("action"), "success": False, "error": str(e)})
                failed += 1
        audit_msg = "批量操作: %d个, 成功%d, 失败%d" % (len(operations), success, failed)
        self.audit(audit_msg, level="info")
        return {"total": len(operations), "success": success, "failed": failed, "results": results}

    def export_data(self, format_type: str = "json") -> dict:
        """导出模块状态和数据"""
        self.trace("rate_limit_redis.export_data", "start", format=format_type)
        data = {
            "module": "rate_limit_redis",
            "timestamp": __import__("time").time(),
            "health": self.health_check(),
            "stats": getattr(self, "get_stats", lambda: {})(),
        }
        self.metrics_collector.counter("rate_limit_redis.export.total", 1)
        self.trace("rate_limit_redis.export_data", "end")
        return {"success": True, "format": format_type, "data": data}

    def import_data(self, data: dict) -> dict:
        """导入配置和数据"""
        self.trace("rate_limit_redis.import_data", "start")
        self.audit(f"导入数据: {data.get('module', 'unknown')}", level="info")
        self.metrics_collector.counter("rate_limit_redis.import.total", 1)
        self.trace("rate_limit_redis.import_data", "end")
        return {"success": True, "module": "rate_limit_redis", "imported": True}


    def batch_operation(self, operations: list) -> dict:
        """批量执行操作"""
        results = []
        success = failed = 0
        for op in operations:
            try:
                method = getattr(self, op.get("action", ""), None)
                if method and callable(method):
                    r = method(**op.get("params", {}))
                    results.append({"op": op.get("action"), "success": True})
                    success += 1
                else:
                    results.append({"op": op.get("action"), "success": False, "error": "not_found"})
                    failed += 1
            except Exception as e:
                results.append({"op": op.get("action"), "success": False, "error": str(e)[:100]})
                failed += 1
        return {"total": len(operations), "success": success, "failed": failed, "results": results}

    def export_data(self, format_type: str = "json") -> dict:
        """导出模块数据"""
        self.trace("rate_limit_redis.export", "start")
        import time as _t
        data = {"module": "rate_limit_redis", "ts": _t.time(), "health": self.health_check()}
        self.metrics_collector.counter("rate_limit_redis.export", 1)
        self.trace("rate_limit_redis.export", "end")
        return {"success": True, "format": format_type, "data": data}

    def import_data(self, data: dict) -> dict:
        """导入配置"""
        self.trace("rate_limit_redis.import", "start")
        self.audit("导入数据: " + str(data.get("module", "?")), level="info")
        return {"success": True, "module": "rate_limit_redis"}

    def get_monitoring_dashboard(self) -> dict:
        """获取监控面板数据"""
        self.trace("rate_limit_redis.monitor", "start")
        import time as _t
        panel = {
            "module": "rate_limit_redis",
            "uptime": _t.time() - getattr(self, '_start_time', _t.time()),
            "health": self.health_check(),
            "stats": getattr(self, 'get_stats', lambda: {})(),
        }
        analyzer = getattr(self, '_analyzer', None)
        if analyzer:
            panel["analysis"] = analyzer.analyze()
        self.trace("rate_limit_redis.monitor", "end")
        return panel

    def validate_config(self, config: dict) -> dict:
        """验证配置合法性"""
        self.trace("rate_limit_redis.validate", "start")
        errors = []
        warnings = []
        if not isinstance(config, dict):
            errors.append("config must be dict")
        for k, v in config.items():
            if v is None:
                warnings.append("config.%s is None" % k)
        result = {"valid": len(errors) == 0, "errors": errors, "warnings": warnings, "checked": len(config)}
        self.metrics_collector.counter("rate_limit_redis.validate", 1)
        self.trace("rate_limit_redis.validate", "end")
        return result

    def reset_metrics(self) -> dict:
        """重置指标"""
        self.trace("rate_limit_redis.reset_metrics", "start")
        self.audit("重置指标", level="warn")
        return {"success": True, "module": "rate_limit_redis"}

    def get_operation_log(self, limit: int = 100) -> dict:
        """获取操作日志"""
        log = getattr(self, '_operation_log', [])
        return {"total": len(log), "entries": log[-limit:]}

    def diagnostic_check(self) -> dict:
        """运行诊断检查"""
        self.trace("rate_limit_redis.diagnostic", "start")
        checks = [
            ("health", self.health_check().get("status") == "healthy"),
            ("initialized", getattr(self, '_initialized', True)),
            ("has_methods", len([m for m in dir(self) if not m.startswith('_')]) > 5),
        ]
        passed = sum(1 for _, ok in checks if ok)
        self.metrics_collector.gauge("rate_limit_redis.diagnostic.pass_rate", passed/len(checks)*100 if checks else 0)
        return {"checks": checks, "passed": passed, "total": len(checks), "healthy": passed == len(checks)}

    def optimize(self, params: dict = None) -> dict:
        """执行优化操作"""
        self.trace("rate_limit_redis.optimize", "start")
        params = params or {}
        self.audit("执行优化: " + str(params.get("target", "auto")), level="info")
        result = {"optimized": True, "module": "rate_limit_redis", "params": params}
        self.metrics_collector.counter("rate_limit_redis.optimize", 1)
        self.trace("rate_limit_redis.optimize", "end")
        return result

    def backup(self, target_path: str = "") -> dict:
        """备份模块数据"""
        self.trace("rate_limit_redis.backup", "start")
        import json as _j, time as _t
        data = _j.dumps({"module": "rate_limit_redis", "ts": _t.time(), "health": self.health_check()}, ensure_ascii=False)
        return {"success": True, "size": len(data), "module": "rate_limit_redis"}

    def restore(self, data: dict) -> dict:
        """恢复模块数据"""
        self.trace("rate_limit_redis.restore", "start")
        self.audit("恢复数据", level="warn")
        return {"success": True, "module": "rate_limit_redis", "restored": True}


def batch_operation(self, operations: list) -> dict:
    results = []
    success = failed = 0
    for op in operations:
        try:
            method = getattr(self, op.get("action", ""), None)
            if method and callable(method):
                method(**op.get("params", {}))
                results.append({"op": op.get("action"), "success": True})
                success += 1
            else:
                results.append({"op": op.get("action"), "success": False})
                failed += 1
        except Exception as e:
            results.append({"op": op.get("action"), "success": False, "error": str(e)[:100]})
            failed += 1
    return {"total": len(operations), "success": success, "failed": failed, "results": results}

def export_data(self, format_type: str = "json") -> dict:
    self.trace("rate_limit_redis.export", "start")
    import time as _t
    data = {"module": "rate_limit_redis", "ts": _t.time(), "health": self.health_check()}
    self.metrics_collector.counter("rate_limit_redis.export", 1)
    self.trace("rate_limit_redis.export", "end")
    return {"success": True, "format": format_type, "data": data}

def import_data(self, data: dict) -> dict:
    self.trace("rate_limit_redis.import", "start")
    self.audit("import data", level="info")
    return {"success": True, "module": "rate_limit_redis"}

def get_monitoring_dashboard(self) -> dict:
    self.trace("rate_limit_redis.monitor", "start")
    panel = {"module": "rate_limit_redis", "health": self.health_check()}
    analyzer = getattr(self, "_analyzer", None)
    if analyzer:
        panel["analysis"] = analyzer.analyze()
    self.trace("rate_limit_redis.monitor", "end")
    return panel

def validate_config(self, config: dict) -> dict:
    self.trace("rate_limit_redis.validate", "start")
    errors = []
    warnings = []
    for k, v in config.items():
        if v is None:
            warnings.append(k + " is None")
    return {"valid": len(errors) == 0, "errors": errors, "warnings": warnings}

def reset_metrics(self) -> dict:
    self.trace("rate_limit_redis.reset", "start")
    return {"success": True, "module": "rate_limit_redis"}

def diagnostic_check(self) -> dict:
    self.trace("rate_limit_redis.diag", "start")
    checks = [
        ("health", self.health_check().get("status") == "healthy"),
        ("methods", len([m for m in dir(self) if not m.startswith("_")]) > 5),
    ]
    passed = sum(1 for _, ok in checks if ok)
    return {"checks": checks, "passed": passed, "total": len(checks)}

def optimize(self, params: dict = None) -> dict:
    self.trace("rate_limit_redis.optimize", "start")
    self.audit("optimize", level="info")
    return {"optimized": True, "module": "rate_limit_redis"}

def backup(self, target_path: str = "") -> dict:
    self.trace("rate_limit_redis.backup", "start")
    return {"success": True, "module": "rate_limit_redis"}

def restore(self, data: dict) -> dict:
    self.trace("rate_limit_redis.restore", "start")
    self.audit("restore", level="warn")
    return {"success": True, "module": "rate_limit_redis", "restored": True}


module_class = RateLimitRedisModule
