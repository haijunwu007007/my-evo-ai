"""
        健康监控仪表盘模块 - Health Dashboard Service
生产级实现：多维度健康监控、告警规则引擎、指标聚合、趋势分析、SLA计算
"""
import logging
import time
import math
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict, deque
from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector
logger = logging.getLogger(__name__)


class HealthDashboardAnalyzer(object):
    """health_dashboard 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "health_dashboard"
        self.version = "1.0.0"
        self._analyzer = HealthDashboardAnalyzer()
        self._history = []
        self._max_history = 10000
    
    def analyze(self, context: dict = None) -> dict:
        context = context or {}
        result = {"analyzer": "HealthDashboardAnalyzer", "timestamp": time.time(), "records": len(self._history), "summary": self._summary()}
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-5000:]
        return result
    
    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "health_dashboard"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== health_dashboard ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}

class HealthStatus(Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


class Severity(Enum):
    INFO = 0
    WARNING = 1
    CRITICAL = 2
    FATAL = 3


class AlertState(Enum):
    FIRING = "firing"
    RESOLVED = "resolved"
    SILENCED = "silenced"
    ACKNOWLEDGED = "acknowledged"


@dataclass
class HealthCheck:
    component: str
    status: HealthStatus
    message: str = ""
    latency_ms: float = 0.0
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AlertRule:
    rule_id: str
    name: str
    component: str
    condition: str
    threshold: float
    severity: Severity = Severity.WARNING
    cooldown_seconds: float = 300.0
    enabled: bool = True
    created_at: float = field(default_factory=time.time)
    last_triggered: float = 0.0

    def evaluate(self, value: float) -> bool:
        if not self.enabled:
            return False
        if time.time() - self.last_triggered < self.cooldown_seconds:
            return False
        ops = {"gt": lambda v, t: v > t, "lt": lambda v, t: v < t,
               "gte": lambda v, t: v >= t, "lte": lambda v, t: v <= t,
               "eq": lambda v, t: abs(v - t) < 1e-9, "neq": lambda v, t: abs(v - t) >= 1e-9}
        op = ops.get(self.condition)
        if not op:
            return False
        result = op(value, self.threshold)
        if result:
            self.last_triggered = time.time()
        return result


@dataclass
class Alert:
    alert_id: str
    rule_id: str
    component: str
    severity: Severity
    message: str
    value: float
    threshold: float
    state: AlertState = AlertState.FIRING
    fired_at: float = field(default_factory=time.time)
    resolved_at: Optional[float] = None
    acknowledged_by: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {"alert_id": self.alert_id, "rule_id": self.rule_id,
                "component": self.component, "severity": self.severity.name,
                "message": self.message, "value": round(self.value, 4),
                "threshold": self.threshold, "state": self.state.value,
                "fired_at": self.fired_at, "resolved_at": self.resolved_at}


class MetricCollector:
    """指标采集器 - 时间序列存储"""

    def __init__(self, max_points: int = 10000, retention_hours: int = 24):
        self._series: Dict[str, deque] = defaultdict(lambda: deque(maxlen=max_points))
        self._max_points = max_points
        self._retention = retention_hours * 3600

    def record(self, name: str, value: float, timestamp: float = None) -> None:
        ts = timestamp or time.time()
        self._series[name].append((ts, value))

    def get_latest(self, name: str) -> Optional[float]:
        if name in self._series and self._series[name]:
            return self._series[name][-1][1]
        return None

    def get_range(self, name: str, since: float) -> List[Tuple[float, float]]:
        if name not in self._series:
            return []
        return [(ts, v) for ts, v in self._series[name] if ts >= since]

    def aggregate(self, name: str, since: float,
                  agg: str = "avg") -> Optional[float]:
        points = self.get_range(name, since)
        if not points:
            return None
        values = [v for _, v in points]
        if agg == "avg":
            return sum(values) / len(values)
        elif agg == "max":
            return max(values)
        elif agg == "min":
            return min(values)
        elif agg == "sum":
            return sum(values)
        elif agg == "count":
            return float(len(values))
        elif agg == "p50":
            values.sort()
            return values[len(values) // 2]
        elif agg == "p95":
            values.sort()
            idx = int(len(values) * 0.95)
            return values[min(idx, len(values) - 1)]
        elif agg == "p99":
            values.sort()
            idx = int(len(values) * 0.99)
            return values[min(idx, len(values) - 1)]
        return None

    def trend(self, name: str, window: int = 10) -> str:
        if name not in self._series:
            return "unknown"
        points = list(self._series[name])
        if len(points) < window * 2:
            return "insufficient_data"
        recent = [v for _, v in points[-window:]]
        older = [v for _, v in points[-window * 2:-window]]
        recent_avg = sum(recent) / len(recent)
        older_avg = sum(older) / len(older)
        if older_avg == 0:
            return "stable"
        change = (recent_avg - older_avg) / older_avg * 100
        if change > 10:
            return "increasing"
        elif change < -10:
            return "decreasing"
        return "stable"

    def cleanup(self) -> int:
        cutoff = time.time() - self._retention
        removed = 0
        for name in list(self._series.keys()):
            before = len(self._series[name])
            self._series[name] = deque(
                [(ts, v) for ts, v in self._series[name] if ts >= cutoff],
                maxlen=self._max_points
            )
            removed += before - len(self._series[name])
            if not self._series[name]:
                del self._series[name]
        return removed

    @property
    def series_count(self) -> int:
        return len(self._series)

    @property
    def total_points(self) -> int:
        return sum(len(v) for v in self._series.values())


class SLACalculator:
    """SLA计算器"""

    @staticmethod
    def calculate(uptime_seconds: float, total_seconds: float,
                  target: float = 99.9) -> Dict[str, Any]:
        if total_seconds == 0:
            return {"sla_pct": 100.0, "target_pct": target, "met": True,
                    "downtime_seconds": 0}
        sla = uptime_seconds / total_seconds * 100
        return {"sla_pct": round(sla, 4), "target_pct": target,
                "met": sla >= target,
                "downtime_seconds": round(total_seconds - uptime_seconds, 1)}

    @staticmethod
    def monthly_downtime_budget(sla_target: float) -> Dict[str, float]:
        month_seconds = 30 * 24 * 3600
        allowed_downtime = month_seconds * (100 - sla_target) / 100
        return {"sla_target": sla_target,
                "total_seconds": month_seconds,
                "allowed_downtime_seconds": round(allowed_downtime, 1),
                "allowed_downtime_minutes": round(allowed_downtime / 60, 1),
                "allowed_downtime_hours": round(allowed_downtime / 3600, 2)}


class HealthDashboard:

    def trace(self, name, *args, **kwargs):

        class _NS:

            def __enter__(self): return self

            def __exit__(self, *a): pass

            def set_tag(self, *a): pass

            def log_kv(self, *a): pass

            def finish(self): pass

        return _NS()


    """健康监控仪表盘 - 生产级实现"""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._components: Dict[str, Dict[str, Any]] = {}
        self._checks: Dict[str, List[HealthCheck]] = defaultdict(list)
        self._alerts: Dict[str, Alert] = {}
        self._alert_rules: Dict[str, AlertRule] = {}
        self._metrics = MetricCollector(
            max_points=self.config.get("max_metric_points", 10000),
            retention_hours=self.config.get("retention_hours", 24)
        )
        self._sla = SLACalculator()
        self._initialized = False
        self._stats = {
            "total_checks": 0, "total_alerts_fired": 0,
            "total_alerts_resolved": 0, "components_monitored": 0,
            "metrics_collected": 0
        }
        self._uptime_tracking: Dict[str, Dict[str, Any]] = {}
        self._register_default_rules()

    def _register_default_rules(self):
        defaults = [
            ("cpu_high", "CPU使用率过高", "cpu_usage", "gt", 90.0, Severity.WARNING),
            ("cpu_critical", "CPU使用率严重过高", "cpu_usage", "gt", 95.0, Severity.CRITICAL),
            ("mem_high", "内存使用率过高", "memory_usage", "gt", 85.0, Severity.WARNING),
            ("mem_critical", "内存使用率严重过高", "memory_usage", "gt", 95.0, Severity.CRITICAL),
            ("disk_high", "磁盘使用率过高", "disk_usage", "gt", 90.0, Severity.WARNING),
            ("error_rate_high", "错误率过高", "error_rate", "gt", 5.0, Severity.CRITICAL),
            ("latency_high", "延迟过高", "latency_p99", "gt", 1000.0, Severity.WARNING),
            ("latency_critical", "延迟严重过高", "latency_p99", "gt", 5000.0, Severity.CRITICAL),
        ]
        for rule_id, name, component, cond, threshold, severity in defaults:
            self._alert_rules[rule_id] = AlertRule(
                rule_id=rule_id, name=name, component=component,
                condition=cond, threshold=threshold, severity=severity
            )

    def initialize(self) -> None:
        self.trace("health_dashboard.initialize", "start")
        self.audit("初始化health_dashboard", level="info")
        if self._initialized:
            return
        self._register_default_rules()
        self._initialized = True
        logger.info("HealthDashboard initialized with %d alert rules", len(self._alert_rules))

    def register_component(self, name: str, component_type: str = "",
                           metadata: Dict[str, Any] = None) -> Dict[str, Any]:
        self._components[name] = {
            "name": name, "type": component_type,
            "metadata": metadata or {}, "registered_at": time.time(),
            "status": HealthStatus.UNKNOWN
        }
        self._uptime_tracking[name] = {
            "total_seconds": 0, "up_seconds": 0,
            "last_check": 0, "period_start": time.time()
        }
        self._stats["components_monitored"] += 1
        return {"success": True, "component": name}

    def report_health(self, component: str, status: str, message: str = "",
                      latency_ms: float = 0.0, metrics: Dict[str, float] = None) -> Dict[str, Any]:
        self._stats["total_checks"] += 1
        health_status = HealthStatus(status)
        check = HealthCheck(
            component=component, status=health_status,
            message=message, latency_ms=latency_ms,
            timestamp=time.time()
        )
        self._checks[component].append(check)
        if len(self._checks[component]) > 1000:
            self._checks[component] = self._checks[component][-500:]
        if component in self._components:
            self._components[component]["status"] = health_status
        now = time.time()
        if component in self._uptime_tracking:
            ut = self._uptime_tracking[component]
            elapsed = now - ut["period_start"] if ut["period_start"] else 0
            if elapsed > 0:
                ut["total_seconds"] += elapsed
                if health_status == HealthStatus.HEALTHY:
                    ut["up_seconds"] += elapsed
            ut["period_start"] = now
        if metrics:
            for k, v in metrics.items():
                self._metrics.record(f"{component}.{k}", v)
                self._stats["metrics_collected"] += 1
        triggered_alerts = self._evaluate_rules(component, metrics or {})
        return {"success": True, "component": component, "status": status,
                "alerts_triggered": len(triggered_alerts)}

    def _evaluate_rules(self, component: str, metrics: Dict[str, float]) -> List[str]:
        triggered = []
        for rule_id, rule in self._alert_rules.items():
            if rule.component != component:
                continue
            value = metrics.get(rule.component)
            if value is None:
                continue
            if rule.evaluate(value):
                alert_id = f"{rule_id}:{time.time()}"
                alert = Alert(
                    alert_id=alert_id, rule_id=rule_id, component=component,
                    severity=rule.severity, message=rule.name,
                    value=value, threshold=rule.threshold
                )
                self._alerts[alert_id] = alert
                self._stats["total_alerts_fired"] += 1
                triggered.append(alert_id)
        return triggered

    def get_alerts(self, component: str = "", severity: str = "",
                   state: str = "") -> Dict[str, Any]:
        alerts = list(self._alerts.values())
        if component:
            alerts = [a for a in alerts if a.component == component]
        if severity:
            try:
                s = Severity[severity.upper()]
                alerts = [a for a in alerts if a.severity == s]
            except KeyError:
                pass
        if state:
            try:
                s = AlertState(state)
                alerts = [a for a in alerts if a.state == s]
            except ValueError:
                pass
        alerts.sort(key=lambda a: a.fired_at, reverse=True)
        return {"alerts": [a.to_dict() for a in alerts[:100]], "total": len(alerts)}

    def acknowledge_alert(self, alert_id: str, user: str = "") -> Dict[str, Any]:
        alert = self._alerts.get(alert_id)
        if not alert:
            return {"success": False, "error": "Alert not found"}
        alert.state = AlertState.ACKNOWLEDGED
        alert.acknowledged_by = user
        return {"success": True, "alert_id": alert_id}

    def resolve_alert(self, alert_id: str) -> Dict[str, Any]:
        alert = self._alerts.get(alert_id)
        if not alert:
            return {"success": False, "error": "Alert not found"}
        alert.state = AlertState.RESOLVED
        alert.resolved_at = time.time()
        self._stats["total_alerts_resolved"] += 1
        return {"success": True, "alert_id": alert_id}

    def get_component_health(self, component: str) -> Dict[str, Any]:
        comp = self._components.get(component, {})
        checks = self._checks.get(component, [])
        latest = checks[-1] if checks else None
        uptime = self._uptime_tracking.get(component, {})
        sla_info = self._sla.calculate(
            uptime.get("up_seconds", 0), uptime.get("total_seconds", 1)
        ) if uptime else None
        return {"component": component, "status": comp.get("status", "unknown").value if isinstance(comp.get("status"), HealthStatus) else str(comp.get("status", "unknown")),
                "latest_check": latest.__dict__ if latest else None,
                "check_count": len(checks), "sla": sla_info}

    def get_overview(self) -> Dict[str, Any]:
        statuses = {HealthStatus.HEALTHY: 0, HealthStatus.DEGRADED: 0,
                    HealthStatus.UNHEALTHY: 0, HealthStatus.UNKNOWN: 0}
        for comp in self._components.values():
            s = comp.get("status")
            if isinstance(s, HealthStatus):
                statuses[s] += 1
            else:
                statuses[HealthStatus.UNKNOWN] += 1
        firing = sum(1 for a in self._alerts.values() if a.state == AlertState.FIRING)
        return {
            "total_components": len(self._components),
            "by_status": {s.name: c for s, c in statuses.items()},
            "firing_alerts": firing,
            "metrics_series": self._metrics.series_count,
            "metrics_points": self._metrics.total_points,
            "uptime_components": len(self._uptime_tracking)
        }

    def get_stats(self) -> Dict[str, Any]:
        return {**self._stats, "overview": self.get_overview(),
                "alert_rules": len(self._alert_rules),
                "active_alerts": sum(1 for a in self._alerts.values()
                                    if a.state in (AlertState.FIRING, AlertState.ACKNOWLEDGED))}

    def execute(self, action: 

            str, **kwargs) -> Dict[str, Any]:
        self.trace("health_dashboard.execute", "start", action=action)

        if action == "register":
            return self.register_component(kwargs["name"], kwargs.get("type", ""),
                                            kwargs.get("metadata"))
        elif action == "report":
            return self.report_health(kwargs["component"], kwargs["status"],
                                      kwargs.get("message", ""), kwargs.get("latency_ms", 0),
                                      kwargs.get("metrics"))
        elif action == "alerts":
            return self.get_alerts(kwargs.get("component", ""),
                                    kwargs.get("severity", ""), kwargs.get("state", ""))
        elif action == "acknowledge":
            return self.acknowledge_alert(kwargs["alert_id"], kwargs.get("user", ""))
        elif action == "resolve":
            return self.resolve_alert(kwargs["alert_id"])
        elif action == "component":
            return self.get_component_health(kwargs["component"])
        elif action == "overview":
            return self.get_overview()
        elif action == "stats":
            return self.get_stats()
        else:
            return {"success": False, "error": f"Unknown action: {action}"}

    def health_check(self) -> Dict[str, Any]:
        self.trace("health_dashboard.health_check", "start")
        return {
            "healthy": True,
            "status": "running",
            "metrics": self.get_stats(),
            "checks": [
                ("initialized", self._initialized),
                ("components_monitored", len(self._components) >= 0),
                ("alert_rules_loaded", len(self._alert_rules) > 0),
                ("metrics_collector_ok", self._metrics.series_count >= 0),
            ]
        }

    def shutdown(self) -> None:
        self.trace("health_dashboard.shutdown", "start")
        self._metrics.cleanup()
        self._alerts.clear()
        self._checks.clear()
        self._initialized = False
        logger.info("HealthDashboard shutdown complete")

module_class = HealthDashboard
