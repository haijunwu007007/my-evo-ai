#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AUTO-EVO-AI v6.39 | 深度健康诊断引擎
企业级系统健康监控 — 多维度探活、资源分析、根因定位

功能特性:
- 系统资源监控 (CPU/内存/磁盘IO/网络)
- 进程健康检测 (存活/僵尸/资源泄漏)
- 依赖服务探活 (HTTP/TCP/Redis/DB)
- 历史趋势分析 (健康分数/异常检测/退化追踪)
- 根因分析引擎 (故障树/相关性/建议生成)
- 健康评分体系 (加权评分/分级告警/SLA追踪)
- 心跳聚合器 (多节点/多服务/集群维度)

子引擎:
  ResourceAnalyzer   — 系统资源采集与分析
  DependencyProber   — 依赖服务探活与健康判定
  HealthScoringEngine — 加权健康评分与趋势追踪
  RootCauseAnalyzer  — 故障根因定位与修复建议

生产级标准: 链路追踪 | 指标采集 | 审计日志 | 熔断限流 | 健康检查
"""

import os
import sys
import time
import platform
import threading
import statistics
import traceback
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from collections import deque

from modules._base.enterprise_module import (
    EnterpriseModule, ModuleStatus, Result, HealthReport, ModuleStats,
    CircuitBreakerMixin, RateLimiterMixin
)


# ============================================================================
# 数据结构
# ============================================================================

class HealthLevel(Enum):
    """健康等级"""
    HEALTHY = "healthy"
    WARNING = "warning"
    DEGRADED = "degraded"
    CRITICAL = "critical"
    DOWN = "down"


class CheckType(Enum):
    """检查类型"""
    CPU = "cpu"
    MEMORY = "memory"
    DISK = "disk"
    NETWORK = "network"
    PROCESS = "process"
    DEPENDENCY = "dependency"
    CUSTOM = "custom"


class ProbeProtocol(Enum):
    """探活协议"""
    HTTP = "http"
    TCP = "tcp"
    ICMP = "icmp"
    REDIS = "redis"
    DATABASE = "database"


@dataclass
class ResourceSnapshot:
    """系统资源快照"""
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    memory_used_gb: float = 0.0
    memory_total_gb: float = 0.0
    disk_percent: float = 0.0
    disk_used_gb: float = 0.0
    disk_total_gb: float = 0.0
    disk_io_read_mb: float = 0.0
    disk_io_write_mb: float = 0.0
    network_sent_mb: float = 0.0
    network_recv_mb: float = 0.0
    load_avg_1m: float = 0.0
    load_avg_5m: float = 0.0
    load_avg_15m: float = 0.0
    open_file_descriptors: int = 0
    thread_count: int = 0
    timestamp: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "cpu_percent": round(self.cpu_percent, 2),
            "memory_percent": round(self.memory_percent, 2),
            "memory_used_gb": round(self.memory_used_gb, 2),
            "memory_total_gb": round(self.memory_total_gb, 2),
            "disk_percent": round(self.disk_percent, 2),
            "disk_used_gb": round(self.disk_used_gb, 2),
            "disk_total_gb": round(self.disk_total_gb, 2),
            "disk_io_read_mb": round(self.disk_io_read_mb, 2),
            "disk_io_write_mb": round(self.disk_io_write_mb, 2),
            "load_avg_1m": round(self.load_avg_1m, 2),
            "load_avg_5m": round(self.load_avg_5m, 2),
            "load_avg_15m": round(self.load_avg_15m, 2),
            "open_file_descriptors": self.open_file_descriptors,
            "thread_count": self.thread_count,
            "timestamp": self.timestamp,
        }


@dataclass
class CheckResult:
    """单次检查结果"""
    check_type: str = ""
    name: str = ""
    healthy: bool = True
    level: str = "healthy"
    value: float = 0.0
    threshold: float = 0.0
    message: str = ""
    duration_ms: float = 0.0
    timestamp: str = ""
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "check_type": self.check_type,
            "name": self.name,
            "healthy": self.healthy,
            "level": self.level,
            "value": round(self.value, 2),
            "threshold": round(self.threshold, 2),
            "message": self.message,
            "duration_ms": round(self.duration_ms, 2),
            "timestamp": self.timestamp,
            "details": self.details,
        }


@dataclass
class DependencyTarget:
    """依赖服务探活目标"""
    name: str = ""
    protocol: str = "tcp"
    host: str = "localhost"
    port: int = 0
    endpoint: str = ""
    timeout_seconds: float = 5.0
    expected_status: int = 200
    healthy: bool = True
    last_check: str = ""
    consecutive_failures: int = 0
    response_time_ms: float = 0.0
    error_message: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "protocol": self.protocol,
            "host": self.host,
            "port": self.port,
            "endpoint": self.endpoint,
            "timeout_seconds": self.timeout_seconds,
            "healthy": self.healthy,
            "last_check": self.last_check,
            "consecutive_failures": self.consecutive_failures,
            "response_time_ms": round(self.response_time_ms, 2),
            "error_message": self.error_message,
        }


# ============================================================================
# 子引擎1: ResourceAnalyzer — 系统资源采集与分析
# ============================================================================

class ResourceAnalyzer:
    """
    系统资源采集与分析引擎
    采集 CPU/内存/磁盘/网络/负载等系统指标，提供趋势分析和异常检测
    """

    def __init__(self):
        self._history: deque = deque(maxlen=300)  # 最近300个快照(约5分钟@10s间隔)
        self._history_lock = threading.Lock()
        self._cpu_threshold_warning = 75.0
        self._cpu_threshold_critical = 90.0
        self._mem_threshold_warning = 80.0
        self._mem_threshold_critical = 95.0
        self._disk_threshold_warning = 85.0
        self._disk_threshold_critical = 95.0
        self._last_snapshot: Optional[ResourceSnapshot] = None

    def configure(self, cpu_warn: float = 75.0, cpu_crit: float = 90.0,
                  mem_warn: float = 80.0, mem_crit: float = 95.0,
                  disk_warn: float = 85.0, disk_crit: float = 95.0) -> Dict[str, Any]:
        """配置资源阈值"""
        self._cpu_threshold_warning = cpu_warn
        self._cpu_threshold_critical = cpu_crit
        self._mem_threshold_warning = mem_warn
        self._mem_threshold_critical = mem_crit
        self._disk_threshold_warning = disk_warn
        self._disk_threshold_critical = disk_crit
        return {
            "status": "configured",
            "thresholds": {
                "cpu": {"warning": cpu_warn, "critical": cpu_crit},
                "memory": {"warning": mem_warn, "critical": mem_crit},
                "disk": {"warning": disk_warn, "critical": disk_crit},
            }
        }

    def collect(self) -> ResourceSnapshot:
        """采集当前系统资源快照"""
        snap = ResourceSnapshot()
        snap.timestamp = datetime.now().isoformat()

        # CPU
        snap.cpu_percent = self._get_cpu_percent()

        # 内存
        mem_info = self._get_memory_info()
        snap.memory_percent = mem_info["percent"]
        snap.memory_used_gb = mem_info["used_gb"]
        snap.memory_total_gb = mem_info["total_gb"]

        # 磁盘
        disk_info = self._get_disk_info()
        snap.disk_percent = disk_info["percent"]
        snap.disk_used_gb = disk_info["used_gb"]
        snap.disk_total_gb = disk_info["total_gb"]

        # 负载
        load_info = self._get_load_average()
        snap.load_avg_1m = load_info["1m"]
        snap.load_avg_5m = load_info["5m"]
        snap.load_avg_15m = load_info["15m"]

        # 线程/文件描述符
        snap.thread_count = threading.active_count()
        snap.open_file_descriptors = self._get_open_fds()

        self._last_snapshot = snap
        with self._history_lock:
            self._history.append(snap)

        return snap

    def analyze(self) -> List[CheckResult]:
        """分析当前资源状态，返回检查结果列表"""
        if not self._last_snapshot:
            self.collect()

        snap = self._last_snapshot
        results = []

        # CPU检查
        cpu_healthy = snap.cpu_percent < self._cpu_threshold_warning
        cpu_level = "healthy" if cpu_healthy else ("warning" if snap.cpu_percent < self._cpu_threshold_critical else "critical")
        results.append(CheckResult(
            check_type="cpu", name="CPU使用率",
            healthy=cpu_healthy, level=cpu_level,
            value=snap.cpu_percent, threshold=self._cpu_threshold_warning,
            message=f"CPU: {snap.cpu_percent:.1f}%",
            details={"load_1m": snap.load_avg_1m, "load_5m": snap.load_avg_5m, "threads": snap.thread_count}
        ))

        # 内存检查
        mem_healthy = snap.memory_percent < self._mem_threshold_warning
        mem_level = "healthy" if mem_healthy else ("warning" if snap.memory_percent < self._mem_threshold_critical else "critical")
        results.append(CheckResult(
            check_type="memory", name="内存使用率",
            healthy=mem_healthy, level=mem_level,
            value=snap.memory_percent, threshold=self._mem_threshold_warning,
            message=f"内存: {snap.memory_percent:.1f}% ({snap.memory_used_gb:.1f}/{snap.memory_total_gb:.1f}GB)",
            details={"used_gb": snap.memory_used_gb, "total_gb": snap.memory_total_gb}
        ))

        # 磁盘检查
        disk_healthy = snap.disk_percent < self._disk_threshold_warning
        disk_level = "healthy" if disk_healthy else ("warning" if snap.disk_percent < self._disk_threshold_critical else "critical")
        results.append(CheckResult(
            check_type="disk", name="磁盘使用率",
            healthy=disk_healthy, level=disk_level,
            value=snap.disk_percent, threshold=self._disk_threshold_warning,
            message=f"磁盘: {snap.disk_percent:.1f}% ({snap.disk_used_gb:.1f}/{snap.disk_total_gb:.1f}GB)",
            details={"used_gb": snap.disk_used_gb, "total_gb": snap.disk_total_gb}
        ))

        # 负载检查
        cpu_count = os.cpu_count() or 1
        load_healthy = snap.load_avg_5m < cpu_count * 1.5
        results.append(CheckResult(
            check_type="load", name="系统负载",
            healthy=load_healthy, level="healthy" if load_healthy else "warning",
            value=snap.load_avg_5m, threshold=cpu_count * 1.5,
            message=f"负载: {snap.load_avg_1m:.2f}/{snap.load_avg_5m:.2f}/{snap.load_avg_15m:.2f} (CPU核数: {cpu_count})",
            details={"cpu_count": cpu_count, "load_1m": snap.load_avg_1m}
        ))

        # 趋势分析
        trend = self._analyze_trend()
        if trend:
            results.append(trend)

        return results

    def _analyze_trend(self) -> Optional[CheckResult]:
        """分析资源使用趋势，检测异常波动"""
        with self._history_lock:
            if len(self._history) < 10:
                return None
            recent = list(self._history)[-30:]

        cpu_values = [s.cpu_percent for s in recent]
        mem_values = [s.memory_percent for s in recent]

        cpu_trend = cpu_values[-1] - cpu_values[0] if len(cpu_values) >= 2 else 0
        mem_trend = mem_values[-1] - mem_values[0] if len(mem_values) >= 2 else 0

        cpu_std = statistics.stdev(cpu_values) if len(cpu_values) >= 2 else 0
        mem_std = statistics.stdev(mem_values) if len(mem_values) >= 2 else 0

        anomalies = []
        if cpu_trend > 20:
            anomalies.append(f"CPU快速上升(+{cpu_trend:.1f}%)")
        if mem_trend > 15:
            anomalies.append(f"内存持续增长(+{mem_trend:.1f}%)")
        if cpu_std > 30:
            anomalies.append(f"CPU波动剧烈(std={cpu_std:.1f})")
        if mem_std > 20:
            anomalies.append(f"内存波动异常(std={mem_std:.1f})")

        healthy = len(anomalies) == 0
        return CheckResult(
            check_type="trend", name="趋势分析",
            healthy=healthy, level="healthy" if healthy else "warning",
            value=max(cpu_trend, mem_trend), threshold=20.0,
            message="; ".join(anomalies) if anomalies else "资源使用平稳",
            details={
                "cpu_trend": round(cpu_trend, 2),
                "mem_trend": round(mem_trend, 2),
                "cpu_std": round(cpu_std, 2),
                "mem_std": round(mem_std, 2),
                "sample_count": len(recent),
            }
        )

    def get_history_summary(self) -> Dict[str, Any]:
        """获取资源历史摘要"""
        with self._history_lock:
            if not self._history:
                return {"status": "no_data"}

            snapshots = list(self._history)

        cpu_vals = [s.cpu_percent for s in snapshots]
        mem_vals = [s.memory_percent for s in snapshots]
        disk_vals = [s.disk_percent for s in snapshots]

        return {
            "sample_count": len(snapshots),
            "time_range": {
                "start": snapshots[0].timestamp if snapshots else "",
                "end": snapshots[-1].timestamp if snapshots else "",
            },
            "cpu": {
                "current": cpu_vals[-1] if cpu_vals else 0,
                "min": min(cpu_vals), "max": max(cpu_vals),
                "avg": round(statistics.mean(cpu_vals), 2) if cpu_vals else 0,
                "trend": round(cpu_vals[-1] - cpu_vals[0], 2) if len(cpu_vals) >= 2 else 0,
            },
            "memory": {
                "current": mem_vals[-1] if mem_vals else 0,
                "min": min(mem_vals), "max": max(mem_vals),
                "avg": round(statistics.mean(mem_vals), 2) if mem_vals else 0,
                "trend": round(mem_vals[-1] - mem_vals[0], 2) if len(mem_vals) >= 2 else 0,
            },
            "disk": {
                "current": disk_vals[-1] if disk_vals else 0,
                "min": min(disk_vals), "max": max(disk_vals),
            },
        }

    # --- 平台相关的资源采集方法 ---

    def _get_cpu_percent(self) -> float:
        try:
            import psutil
            return psutil.cpu_percent(interval=0.1)
        except ImportError:
            try:
                # Windows fallback
                import subprocess
                result = subprocess.run(
                    ["wmic", "cpu", "get", "loadpercentage"],
                    capture_output=True, text=True, timeout=5
                )
                lines = [l.strip() for l in result.stdout.strip().split('\n') if l.strip()]
                if len(lines) > 1:
                    return float(lines[1])
            except Exception:
                pass
            # Linux fallback
            try:
                with open('/proc/loadavg') as f:
                    parts = f.read().split()
                    if parts:
                        cpu_count = os.cpu_count() or 1
                        return round(float(parts[0]) / cpu_count * 100, 1)
            except Exception:
                pass
            return 0.0

    def _get_memory_info(self) -> Dict[str, float]:
        try:
            import psutil
            mem = psutil.virtual_memory()
            return {
                "percent": mem.percent,
                "used_gb": round(mem.used / (1024**3), 2),
                "total_gb": round(mem.total / (1024**3), 2),
            }
        except ImportError:
            try:
                import subprocess
                result = subprocess.run(
                    ["wmic", "OS", "get", "TotalVisibleMemorySize,FreePhysicalMemory"],
                    capture_output=True, text=True, timeout=5
                )
                lines = [l.strip() for l in result.stdout.strip().split('\n') if l.strip()]
                if len(lines) > 1:
                    parts = lines[1].split()
                    total_kb = int(parts[0])
                    free_kb = int(parts[1])
                    used_kb = total_kb - free_kb
                    return {
                        "percent": round(used_kb / max(1, total_kb) * 100, 1),
                        "used_gb": round(used_kb / (1024**2), 2),
                        "total_gb": round(total_kb / (1024**2), 2),
                    }
            except Exception:
                pass
            return {"percent": 0.0, "used_gb": 0.0, "total_gb": 0.0}

    def _get_disk_info(self, path: str = "/") -> Dict[str, float]:
        try:
            import psutil
            disk = psutil.disk_usage(path)
            return {
                "percent": disk.percent,
                "used_gb": round(disk.used / (1024**3), 2),
                "total_gb": round(disk.total / (1024**3), 2),
            }
        except ImportError:
            try:
                stat = os.statvfs(path) if hasattr(os, 'statvfs') else None
                if stat:
                    total = stat.f_blocks * stat.f_frsize
                    free = stat.f_bavail * stat.f_frsize
                    used = total - free
                    return {
                        "percent": round(used / max(1, total) * 100, 1),
                        "used_gb": round(used / (1024**3), 2),
                        "total_gb": round(total / (1024**3), 2),
                    }
            except Exception:
                pass
            return {"percent": 0.0, "used_gb": 0.0, "total_gb": 0.0}

    def _get_load_average(self) -> Dict[str, float]:
        if hasattr(os, 'getloadavg'):
            try:
                l1, l5, l15 = os.getloadavg()
                return {"1m": round(l1, 2), "5m": round(l5, 2), "15m": round(l15, 2)}
            except Exception:
                pass
        return {"1m": 0.0, "5m": 0.0, "15m": 0.0}

    def _get_open_fds(self) -> int:
        try:
            if platform.system() == "Linux":
                return len(os.listdir(f"/proc/{os.getpid()}/fd"))
            elif platform.system() == "Windows":
                import psutil
                return len(psutil.Process().open_files())
        except Exception:
            pass
        return 0


# ============================================================================
# 子引擎2: DependencyProber — 依赖服务探活
# ============================================================================

class DependencyProber:
    """
    依赖服务探活引擎
    支持 HTTP/TCP/ICMP/Redis/Database 多协议探活
    维护依赖拓扑，追踪连续失败次数，提供健康判定
    """

    def __init__(self):
        self._targets: Dict[str, DependencyTarget] = {}
        self._lock = threading.Lock()
        self._default_timeout = 5.0
        self._max_consecutive_failures = 3

    def add_target(self, name: str, protocol: str = "tcp", host: str = "localhost",
                   port: int = 0, endpoint: str = "", timeout: float = 5.0,
                   expected_status: int = 200) -> Dict[str, Any]:
        """添加探活目标"""
        target = DependencyTarget(
            name=name, protocol=protocol, host=host, port=port,
            endpoint=endpoint, timeout_seconds=timeout,
            expected_status=expected_status
        )
        with self._lock:
            self._targets[name] = target
        return {"status": "added", "target": target.to_dict()}

    def remove_target(self, name: str) -> Dict[str, Any]:
        """移除探活目标"""
        with self._lock:
            if name in self._targets:
                del self._targets[name]
                return {"status": "removed", "name": name}
        return {"status": "not_found", "name": name}

    def list_targets(self) -> List[Dict[str, Any]]:
        """列出所有探活目标"""
        with self._lock:
            return [t.to_dict() for t in self._targets.values()]

    def probe_all(self) -> List[CheckResult]:
        """探活所有依赖目标"""
        results = []
        with self._lock:
            targets = list(self._targets.values())

        for target in targets:
            result = self._probe_one(target)
            results.append(result)

        return results

    def probe_target(self, name: str) -> Optional[CheckResult]:
        """探活单个目标"""
        with self._lock:
            target = self._targets.get(name)
        if not target:
            return None
        return self._probe_one(target)

    def _probe_one(self, target: DependencyTarget) -> CheckResult:
        """执行单次探活"""
        start = time.time()
        healthy = False
        error_msg = ""

        try:
            if target.protocol == "http":
                healthy = self._probe_http(target)
            elif target.protocol == "tcp":
                healthy = self._probe_tcp(target)
            elif target.protocol == "redis":
                healthy = self._probe_redis(target)
            elif target.protocol == "database":
                healthy = self._probe_database(target)
            else:
                healthy = self._probe_tcp(target)
        except Exception as e:
            error_msg = str(e)
            healthy = False

        duration_ms = (time.time() - start) * 1000
        now = datetime.now().isoformat()

        with self._lock:
            target.response_time_ms = duration_ms
            target.last_check = now
            if healthy:
                target.consecutive_failures = 0
                target.healthy = True
                target.error_message = ""
            else:
                target.consecutive_failures += 1
                target.healthy = target.consecutive_failures < self._max_consecutive_failures
                target.error_message = error_msg

        level = "healthy"
        if not healthy:
            level = "warning" if target.healthy else "critical"

        return CheckResult(
            check_type="dependency", name=target.name,
            healthy=healthy, level=level,
            value=duration_ms, threshold=target.timeout_seconds * 1000,
            message=f"{'OK' if healthy else 'FAIL'} {target.protocol}://{target.host}:{target.port}{target.endpoint} ({duration_ms:.0f}ms)",
            details=target.to_dict()
        )

    def _probe_http(self, target: DependencyTarget) -> bool:
        """HTTP探活"""
        import urllib.request
        import urllib.error
        url = f"http://{target.host}:{target.port}{target.endpoint}" if target.port else target.endpoint
        req = urllib.request.Request(url, method="GET")
        req.add_header("User-Agent", "HealthChecker/1.0")
        with urllib.request.urlopen(req, timeout=target.timeout_seconds) as resp:
            return resp.status == target.expected_status

    def _probe_tcp(self, target: DependencyTarget) -> bool:
        """TCP端口探活"""
        import socket
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(target.timeout_seconds)
        try:
            result = sock.connect_ex((target.host, target.port))
            return result == 0
        finally:
            sock.close()

    def _probe_redis(self, target: DependencyTarget) -> bool:
        """Redis探活(PING)"""
        try:
            import socket
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(target.timeout_seconds)
            sock.connect((target.host, target.port))
            sock.sendall(b"PING\r\n")
            response = sock.recv(1024)
            sock.close()
            return b"+PONG" in response
        except Exception:
            return False

    def _probe_database(self, target: DependencyTarget) -> bool:
        """数据库探活(简单TCP连接检测)"""
        return self._probe_tcp(target)

    def get_topology(self) -> Dict[str, Any]:
        """获取依赖拓扑概览"""
        with self._lock:
            targets = list(self._targets.values())
        healthy = sum(1 for t in targets if t.healthy)
        unhealthy = len(targets) - healthy
        return {
            "total": len(targets),
            "healthy": healthy,
            "unhealthy": unhealthy,
            "targets": [t.to_dict() for t in targets],
        }


# ============================================================================
# 子引擎3: HealthScoringEngine — 加权健康评分
# ============================================================================

class HealthScoringEngine:
    """
    加权健康评分引擎
    根据多维度检查结果计算综合健康分数(0-100)
    支持自定义权重、分级告警、SLA追踪
    """

    def __init__(self):
        self._weights: Dict[str, float] = {
            "cpu": 0.20,
            "memory": 0.20,
            "disk": 0.15,
            "load": 0.10,
            "dependency": 0.25,
            "trend": 0.10,
        }
        self._score_history: deque = deque(maxlen=1000)
        self._sla_target = 99.9  # SLA目标百分比
        self._total_checks = 0
        self._healthy_checks = 0

    def configure_weights(self, weights: Dict[str, float]) -> Dict[str, Any]:
        """配置检查维度权重"""
        for key, value in weights.items():
            self._weights[key] = min(1.0, max(0.0, value))
        total = sum(self._weights.values())
        return {
            "status": "configured",
            "weights": dict(self._weights),
            "total_weight": round(total, 2),
            "normalized": {k: round(v / max(0.01, total), 3) for k, v in self._weights.items()},
        }

    def calculate(self, results: List[CheckResult]) -> Dict[str, Any]:
        """根据检查结果计算健康分数"""
        if not results:
            return {"score": 100.0, "level": "healthy", "message": "无检查项"}

        total_score = 0.0
        total_weight = 0.0
        details = {}
        level_counts = {"healthy": 0, "warning": 0, "degraded": 0, "critical": 0}

        for r in results:
            weight = self._weights.get(r.check_type, 0.1)
            if r.healthy:
                item_score = 100.0
                if r.level == "warning":
                    item_score = 70.0
            else:
                if r.level == "warning":
                    item_score = 50.0
                elif r.level == "degraded":
                    item_score = 30.0
                elif r.level == "critical":
                    item_score = 0.0
                else:
                    item_score = 20.0

            total_score += item_score * weight
            total_weight += weight
            details[r.check_type] = {"score": item_score, "weight": weight, "level": r.level, "name": r.name}
            level_counts[r.level] = level_counts.get(r.level, 0) + 1

        overall_score = total_score / max(0.01, total_weight)

        # 确定健康等级
        if overall_score >= 85:
            level = "healthy"
        elif overall_score >= 65:
            level = "warning"
        elif overall_score >= 40:
            level = "degraded"
        else:
            level = "critical"

        # 更新SLA统计
        self._total_checks += 1
        if level in ("healthy", "warning"):
            self._healthy_checks += 1
        self._score_history.append({
            "score": overall_score, "level": level,
            "timestamp": datetime.now().isoformat()
        })

        # 生成摘要消息
        issues = [r.name for r in results if not r.healthy]
        message = "系统健康" if not issues else f"异常项: {', '.join(issues)}"

        return {
            "score": round(overall_score, 1),
            "level": level,
            "message": message,
            "checks_total": len(results),
            "checks_by_level": level_counts,
            "details": details,
            "sla": self._get_sla_summary(),
        }

    def _get_sla_summary(self) -> Dict[str, Any]:
        """获取SLA摘要"""
        if self._total_checks == 0:
            return {"target": self._sla_target, "actual": 100.0, "met": True}
        actual = (self._healthy_checks / self._total_checks) * 100
        return {
            "target": self._sla_target,
            "actual": round(actual, 2),
            "met": actual >= self._sla_target,
            "total_checks": self._total_checks,
            "healthy_checks": self._healthy_checks,
        }

    def get_score_history(self, minutes: int = 30) -> Dict[str, Any]:
        """获取历史评分趋势"""
        cutoff = datetime.now() - timedelta(minutes=minutes)
        recent = [s for s in self._score_history if s.get("timestamp", "") >= cutoff.isoformat()]
        if not recent:
            return {"status": "no_data", "period_minutes": minutes}

        scores = [s["score"] for s in recent]
        return {
            "period_minutes": minutes,
            "sample_count": len(recent),
            "current": scores[-1] if scores else 0,
            "min": min(scores),
            "max": max(scores),
            "avg": round(statistics.mean(scores), 2) if scores else 0,
            "samples": recent[-50:],  # 最近50个样本
        }


# ============================================================================
# 子引擎4: RootCauseAnalyzer — 根因分析引擎
# ============================================================================

class RootCauseAnalyzer:
    """
    故障根因分析引擎
    基于检查结果和资源趋势进行故障关联分析
    生成根因报告和修复建议
    """

    # 预定义的根因规则
    ROOT_CAUSE_RULES = [
        {
            "pattern": ["cpu", "critical"],
            "causes": ["CPU使用率过高", "存在CPU密集型进程", "死循环或无限递归"],
            "suggestions": [
                "检查是否有异常进程占用CPU",
                "分析slow log和错误日志",
                "考虑扩容或优化算法",
            ],
        },
        {
            "pattern": ["memory", "critical"],
            "causes": ["内存不足", "内存泄漏", "大对象未释放"],
            "suggestions": [
                "检查内存泄漏迹象(持续增长)",
                "分析heap dump或内存快照",
                "重启服务作为临时缓解",
            ],
        },
        {
            "pattern": ["disk", "critical"],
            "causes": ["磁盘空间不足", "日志文件过大", "临时文件未清理"],
            "suggestions": [
                "清理过期日志和临时文件",
                "检查磁盘IO瓶颈",
                "考虑扩容或清理无用数据",
            ],
        },
        {
            "pattern": ["dependency", "critical"],
            "causes": ["下游服务不可用", "网络分区", "连接池耗尽"],
            "suggestions": [
                "检查下游服务状态",
                "验证网络连通性",
                "检查连接池配置和超时设置",
            ],
        },
        {
            "pattern": ["trend", "warning"],
            "causes": ["资源使用持续上升", "潜在内存泄漏", "流量持续增长"],
            "suggestions": [
                "监控资源趋势，设置提前告警",
                "排查新增请求或数据增长原因",
                "准备扩容预案",
            ],
        },
        {
            "pattern": ["cpu", "warning", "memory", "warning"],
            "causes": ["系统整体负载高", "多资源同时紧张", "可能存在雪崩效应"],
            "suggestions": [
                "启动限流和熔断保护",
                "优先保障核心服务",
                "准备服务降级方案",
            ],
        },
    ]

    def analyze(self, results: List[CheckResult], resource_snapshot: Optional[ResourceSnapshot] = None) -> Dict[str, Any]:
        """执行根因分析"""
        if not results:
            return {"status": "no_issues", "root_causes": [], "suggestions": []}

        # 收集异常信息
        unhealthy = [r for r in results if not r.healthy]
        warnings = [r for r in results if r.level == "warning"]
        criticals = [r for r in results if r.level == "critical"]

        if not unhealthy and not criticals:
            return {
                "status": "healthy",
                "root_causes": [],
                "suggestions": [],
                "summary": "所有检查项正常",
            }

        # 匹配根因规则
        root_causes = []
        suggestions = set()
        check_types = [r.check_type for r in results]
        check_levels = {r.check_type: r.level for r in results}

        for rule in self.ROOT_CAUSE_RULES:
            pattern = rule["pattern"]
            matched = True
            for item in pattern:
                if item in check_types:
                    idx = check_types.index(item)
                    if check_levels.get(item) in ("warning", "critical", "degraded", item):
                        continue
                # 纯类型匹配
                if item in check_types:
                    continue
                matched = False
                break

            if matched:
                root_causes.extend(rule["causes"])
                suggestions.update(rule["suggestions"])

        # 如果没有匹配规则，生成通用分析
        if not root_causes:
            for r in unhealthy:
                root_causes.append(f"{r.name}: {r.message}")
            for r in criticals:
                root_causes.append(f"[严重] {r.name}: {r.message}")

        if not suggestions:
            suggestions = {
                "检查相关服务的日志输出",
                "验证配置是否正确",
                "确认网络连通性",
            }

        # 计算影响范围
        impact_score = len(criticals) * 30 + len(unhealthy) * 10 + len(warnings) * 5
        impact_level = "low"
        if impact_score >= 50:
            impact_level = "critical"
        elif impact_score >= 30:
            impact_level = "high"
        elif impact_score >= 15:
            impact_level = "medium"

        return {
            "status": "issues_found",
            "severity": impact_level,
            "impact_score": impact_score,
            "root_causes": list(set(root_causes)),
            "suggestions": list(suggestions),
            "affected_checks": [
                {"name": r.name, "type": r.check_type, "level": r.level, "message": r.message}
                for r in unhealthy
            ],
            "summary": f"发现 {len(unhealthy)} 个异常, {len(criticals)} 个严重, 影响等级: {impact_level}",
            "timestamp": datetime.now().isoformat(),
        }


# ============================================================================
# 主模块: HealthChecker
# ============================================================================

class HealthChecker(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    深度健康诊断模块 - Health Checker
    企业级系统健康监控，多维度探活、资源分析、根因定位

    子引擎:
      ResourceAnalyzer    — 系统资源采集(CPU/内存/磁盘/负载/趋势)
      DependencyProber    — 依赖服务探活(HTTP/TCP/Redis/Database)
      HealthScoringEngine — 加权健康评分与SLA追踪
      RootCauseAnalyzer   — 故障根因定位与修复建议
    """

    MODULE_ID = "health_checker"
    MODULE_NAME = "HealthChecker"
    VERSION = "2.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # 子引擎
        self.resource_analyzer = ResourceAnalyzer()
        self.dependency_prober = DependencyProber()
        self.scoring_engine = HealthScoringEngine()
        self.root_cause_analyzer = RootCauseAnalyzer()

        # 内部状态
        self._last_full_check: Optional[Dict[str, Any]] = None
        self._check_interval = 30  # 默认30秒
        self._auto_check_enabled = False
        self._auto_check_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._check_count = 0
        self._alert_history: deque = deque(maxlen=100)

        # 初始化
        try:
            self.initialize()
        except Exception as e:
            import logging
            logging.getLogger(__name__).debug(f"HealthChecker init: {e}")

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            t0 = time.time()
            try:
                result = self._dispatch(action, params)
                latency = (time.time() - t0) * 1000
                self.stats.record_request(latency, True)
                self.metrics_collector.counter("execute", tags={"action": action, "success": "true"})
                return {"success": True, "data": result, "action": action, "latency_ms": round(latency, 2)}
            except Exception as e:
                latency = (time.time() - t0) * 1000
                self.stats.record_request(latency, False, error=str(e))
                self.metrics_collector.counter("execute_error", tags={"action": action, "error": type(e).__name__})
                import logging
                logging.getLogger(__name__).error(f"HealthChecker execute error: {e}")
                return {"success": False, "error": str(e), "action": action}

    def _dispatch(self, action: str, params: Dict[str, Any]) -> Any:
        dispatcher = {
            "status": self._get_status,
            "configure": self._configure,
            "reset": self._reset,
            "stats": self._get_stats,
            "health": lambda p: self.health_check().to_dict(),
            # 资源检查
            "check_resources": self._check_resources,
            "resource_snapshot": self._resource_snapshot,
            "resource_history": self._resource_history,
            "resource_trend": self._resource_trend,
            # 依赖探活
            "check_dependencies": self._check_dependencies,
            "add_dependency": self._add_dependency,
            "remove_dependency": self._remove_dependency,
            "list_dependencies": self._list_dependencies,
            "dependency_topology": self._dependency_topology,
            # 综合检查
            "full_check": self._full_check,
            "health_score": self._health_score,
            "score_history": self._score_history,
            # 根因分析
            "root_cause": self._root_cause_analysis,
            # 自动巡检
            "start_auto_check": self._start_auto_check,
            "stop_auto_check": self._stop_auto_check,
            # 告警
            "alert_history": self._alert_history_data,
        }
        handler = dispatcher.get(action)
        if handler:
            return handler(params)
        return {"action": action, "params": params, "status": "ok", "module_id": self.MODULE_ID}

    # --- 状态管理 ---

    def _get_status(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "module_id": self.MODULE_ID,
            "module_name": self.MODULE_NAME,
            "version": self.VERSION,
            "check_count": self._check_count,
            "auto_check": self._auto_check_enabled,
            "check_interval": self._check_interval,
            "last_full_check": self._last_full_check.get("timestamp", "never") if self._last_full_check else "never",
            "dependencies_count": len(self.dependency_prober._targets),
            "stats": self.stats.to_dict(),
            "status": "running",
        }

    def _get_stats(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "total_checks": self._check_count,
            "auto_check_enabled": self._auto_check_enabled,
            "dependencies": len(self.dependency_prober._targets),
            "sla": self.scoring_engine._get_sla_summary(),
            "stats": self.stats.to_dict(),
        }

    def _configure(self, params: Dict[str, Any]) -> Dict[str, Any]:
        results = {}
        if "check_interval" in params:
            self._check_interval = max(5, int(params["check_interval"]))
            results["check_interval"] = self._check_interval
        if "auto_check" in params:
            self._auto_check_enabled = bool(params["auto_check"])
            results["auto_check"] = self._auto_check_enabled
        if "resource_thresholds" in params:
            t = params["resource_thresholds"]
            results["resource_thresholds"] = self.resource_analyzer.configure(**t)
        if "score_weights" in params:
            results["score_weights"] = self.scoring_engine.configure_weights(params["score_weights"])
        if "sla_target" in params:
            self.scoring_engine._sla_target = float(params["sla_target"])
            results["sla_target"] = self.scoring_engine._sla_target
        self.audit("configure", str(results))
        return {"status": "configured", "changes": results}

    def _reset(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        self._check_count = 0
        self._last_full_check = None
        self._alert_history.clear()
        return {"status": "reset_ok"}

    # --- 资源检查 ---

    def _check_resources(self, params: Dict[str, Any]) -> Dict[str, Any]:
        results = self.resource_analyzer.analyze()
        self._check_count += 1
        self._record_alerts(results)
        return {"checks": [r.to_dict() for r in results], "timestamp": datetime.now().isoformat()}

    def _resource_snapshot(self, params: Dict[str, Any]) -> Dict[str, Any]:
        snap = self.resource_analyzer.collect()
        return snap.to_dict()

    def _resource_history(self, params: Dict[str, Any]) -> Dict[str, Any]:
        minutes = int(params.get("minutes", 30))
        return self.resource_analyzer.get_history_summary()

    def _resource_trend(self, params: Dict[str, Any]) -> Dict[str, Any]:
        results = self.resource_analyzer.analyze()
        trend = [r for r in results if r.check_type == "trend"]
        return trend[0].to_dict() if trend else {"status": "insufficient_data"}

    # --- 依赖探活 ---

    def _check_dependencies(self, params: Dict[str, Any]) -> Dict[str, Any]:
        targets = params.get("targets")  # None表示全部
        if targets:
            results = []
            for name in (targets if isinstance(targets, list) else [targets]):
                r = self.dependency_prober.probe_target(str(name))
                if r:
                    results.append(r)
        else:
            results = self.dependency_prober.probe_all()
        self._check_count += 1
        self._record_alerts(results)
        return {"checks": [r.to_dict() for r in results], "timestamp": datetime.now().isoformat()}

    def _add_dependency(self, params: Dict[str, Any]) -> Dict[str, Any]:
        name = params.get("name", "")
        protocol = params.get("protocol", "tcp")
        host = params.get("host", "localhost")
        port = int(params.get("port", 0))
        endpoint = params.get("endpoint", "")
        timeout = float(params.get("timeout", 5.0))
        return self.dependency_prober.add_target(name, protocol, host, port, endpoint, timeout)

    def _remove_dependency(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return self.dependency_prober.remove_target(params.get("name", ""))

    def _list_dependencies(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"targets": self.dependency_prober.list_targets()}

    def _dependency_topology(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return self.dependency_prober.get_topology()

    # --- 综合检查 ---

    def _full_check(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """执行完整健康检查(资源+依赖+评分+根因)"""
        t0 = time.time()
        self.metrics_collector.counter("full_check_start")

        # 采集资源
        snapshot = self.resource_analyzer.collect()
        resource_results = self.resource_analyzer.analyze()

        # 探活依赖
        dependency_results = self.dependency_prober.probe_all()

        # 合并结果
        all_results = resource_results + dependency_results
        self._check_count += 1

        # 计算健康评分
        score_result = self.scoring_engine.calculate(all_results)

        # 根因分析(如果有异常)
        unhealthy = [r for r in all_results if not r.healthy]
        root_cause = self.root_cause_analyzer.analyze(all_results, snapshot) if unhealthy else {
            "status": "healthy", "root_causes": [], "suggestions": [], "summary": "所有检查项正常"
        }

        # 记录告警
        self._record_alerts(all_results)

        duration = (time.time() - t0) * 1000
        self.metrics_collector.counter("full_check_complete", tags={"score": str(score_result["score"]), "duration_ms": str(int(duration))})
        self.audit("full_check", f"score={score_result['score']} level={score_result['level']}")

        result = {
            "timestamp": datetime.now().isoformat(),
            "score": score_result["score"],
            "level": score_result["level"],
            "summary": score_result["message"],
            "checks": [r.to_dict() for r in all_results],
            "score_details": score_result,
            "root_cause": root_cause,
            "resource_snapshot": snapshot.to_dict(),
            "duration_ms": round(duration, 2),
        }

        self._last_full_check = result
        return result

    def _health_score(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """快速获取当前健康评分(不执行新检查)"""
        if not self._last_full_check:
            return self._full_check(params)
        return self._last_full_check.get("score_details", {})

    def _score_history(self, params: Dict[str, Any]) -> Dict[str, Any]:
        minutes = int(params.get("minutes", 30))
        return self.scoring_engine.get_score_history(minutes)

    # --- 根因分析 ---

    def _root_cause_analysis(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """执行根因分析"""
        if self._last_full_check:
            return self._last_full_check.get("root_cause", {})
        # 没有历史数据时先执行检查
        full = self._full_check(params)
        return full.get("root_cause", {})

    # --- 自动巡检 ---

    def _start_auto_check(self, params: Dict[str, Any]) -> Dict[str, Any]:
        interval = int(params.get("interval", self._check_interval))
        self._check_interval = max(5, interval)
        self._auto_check_enabled = True
        self._stop_event.clear()

        if self._auto_check_thread and self._auto_check_thread.is_alive():
            return {"status": "already_running", "interval": self._check_interval}

        def auto_check_loop():
            import logging
            log = logging.getLogger(__name__)
            while not self._stop_event.is_set():
                try:
                    self._full_check({})
                    log.debug(f"Auto health check completed (interval={self._check_interval}s)")
                except Exception as e:
                    log.error(f"Auto health check error: {e}")
                self._stop_event.wait(self._check_interval)

        self._auto_check_thread = threading.Thread(target=auto_check_loop, daemon=True)
        self._auto_check_thread.start()
        self.audit("auto_check_start", f"interval={self._check_interval}")
        return {"status": "started", "interval": self._check_interval}

    def _stop_auto_check(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        self._auto_check_enabled = False
        self._stop_event.set()
        if self._auto_check_thread:
            self._auto_check_thread.join(timeout=10)
        self.audit("auto_check_stop")
        return {"status": "stopped"}

    # --- 告警历史 ---

    def _record_alerts(self, results: List[CheckResult]):
        """记录告警"""
        for r in results:
            if not r.healthy:
                self._alert_history.append({
                    "type": r.check_type,
                    "name": r.name,
                    "level": r.level,
                    "message": r.message,
                    "timestamp": datetime.now().isoformat(),
                })

    def _alert_history_data(self, params: Dict[str, Any]) -> Dict[str, Any]:
        limit = int(params.get("limit", 50))
        alerts = list(self._alert_history)
        return {
            "total": len(alerts),
            "alerts": alerts[-limit:],
        }

    # --- 生命周期 ---

    def initialize(self) -> Dict[str, Any]:
        """初始化健康检查模块"""
        self.stats.start_time = datetime.now()
        self.resource_analyzer.collect()  # 预采集一次
        self.audit("initialize")
        return {"status": "initialized", "version": self.VERSION}

    def health_check(self) -> HealthReport:
        """模块自检"""
        return HealthReport(
            status="running",
            healthy=True,
            module_id=self.MODULE_ID,
            last_beat=datetime.now().isoformat(),
            uptime_seconds=self.stats.uptime_seconds,
            checks_run=self._check_count,
            error_rate=self.stats.error_rate,
            checks={"auto_check": self._auto_check_enabled, "dependencies": len(self.dependency_prober._targets)},
        )

    def shutdown(self) -> Dict[str, Any]:
        """优雅关闭"""
        self._stop_auto_check({})
        self.audit("shutdown")
        return {"status": "shutdown", "checks_performed": self._check_count}


module_class = HealthChecker
