"""
Icon Manager Module — AUTO-EVO-AI v6.38
Enterprise-grade icon management service.
Multi-format support (SVG/PNG/ICO/WebP), icon registry, caching,
CDN distribution, SVG live editing, variant management, usage analytics.
"""

import hashlib
import time
import uuid
import threading
import logging
import re
from enum import Enum
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple
from collections import defaultdict
from modules._base.enterprise_module import (
    EnterpriseModule,
    ModuleStatus, CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector
logger = logging.getLogger(__name__)


class IconFormat(Enum):
    SVG = "svg"
    PNG = "png"
    ICO = "ico"
    WEBP = "webp"


class IconTheme(Enum):
    LIGHT = "light"
    DARK = "dark"
    AUTO = "auto"


class IconStatus(Enum):
    ACTIVE = "active"
    ARCHIVED = "archived"
    PROCESSING = "processing"
    ERROR = "error"


@dataclass
class IconVariant:
    size: int  # px
    theme: IconTheme
    color: str = ""
    data: bytes = b""
    hash: str = ""


@dataclass
class IconRecord:
    icon_id: str
    name: str
    category: str
    format: IconFormat
    status: IconStatus
    tags: List[str] = field(default_factory=list)
    variants: Dict[str, IconVariant] = field(default_factory=dict)
    original_data: bytes = b""
    created_at: float = 0.0
    updated_at: float = 0.0
    size_bytes: int = 0
    usage_count: int = 0
    svg_content: str = ""


@dataclass
class IconSearchResult:
    icons: List[IconRecord]
    total: int
    page: int
    page_size: int


@dataclass
class SvgOptimizeResult:
    original_size: int
    optimized_size: int
    saved_bytes: int
    saved_percent: float
    operations: List[str]


@dataclass
class ModuleStatus:
    UNINITIALIZED = 'uninitialized'
    INITIALIZING = 'initializing'
    RUNNING = 'running'
    DEGRADED = 'degraded'
    STOPPING = 'stopping'
    STOPPED = 'stopped'
    ERROR = 'error'


class IconManagerAnalyzer(object):
    """icon_manager 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        super().__init__()
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "icon_manager"
        self.version = "1.0.0"
        self._analyzer = IconManagerAnalyzer()
        self._history = []
        self._max_history = 10000
    
    def analyze(self, context: dict = None) -> dict:
        context = context or {}
        result = {"analyzer": "IconManagerAnalyzer", "timestamp": time.time(), "records": len(self._history), "summary": self._summary()}
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-5000:]
        return result
    
    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "icon_manager"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== icon_manager ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}

class IconManager(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """Enterprise-grade icon management service with multi-format support."""

    def __init__(self):
        super().__init__()

        self._icons: Dict[str, IconRecord] = {}
        self._categories: Dict[str, Set[str]] = defaultdict(set)
        self._tag_index: Dict[str, Set[str]] = defaultdict(set)
        self._cache: Dict[str, IconRecord] = {}
        self.metrics_collector = self._NoopMetricsCollector()
        self._cache_max = 500
        self._lock = threading.RLock()
        self._created_at = time.time()
        self._op_stats = defaultdict(int)
        self._cdn_base_url = "https://cdn.autoevo.ai/icons"
        self._svg_optimizer_rules = [
            ("remove_comments", re.compile(r"<!--.*?-->", re.DOTALL)),
            ("remove_metadata", re.compile(r"<metadata>.*?</metadata>", re.DOTALL)),
            ("remove_editor_data", re.compile(r"<!--\s*(Created with|Generator)\s*.*?-->", re.DOTALL)),
            ("collapse_whitespace", re.compile(r">\s+<", re.DOTALL)),
            ("remove_empty_attrs", re.compile(r'\s+(id|class)="[^"]*"\s*=""')),
        ]
        self._init_default_icons()

    def _init_default_icons(self):
        defaults = [
            ("ico-home", "Home", "navigation", IconFormat.SVG,
             '<svg viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>'),
            ("ico-settings", "Settings", "navigation", IconFormat.SVG,
             '<svg viewBox="0 0 24 24"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 00.12-.61l-1.92-3.32a.49.49 0 00-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.484.484 0 00-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96a.49.49 0 00-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.07.62-.07.94s.02.64.07.94l-2.03 1.58a.49.49 0 00-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6A3.6 3.6 0 1115.6 12 3.611 3.611 0 0112 15.6z"/></svg>'),
            ("ico-user", "User", "people", IconFormat.SVG,
             '<svg viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>'),
            ("ico-search", "Search", "actions", IconFormat.SVG,
             '<svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>'),
            ("ico-alert", "Alert", "status", IconFormat.SVG,
             '<svg viewBox="0 0 24 24"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>'),
        ]
        for icon_id, name, cat, fmt, svg in defaults:
            rec = IconRecord(
                icon_id=icon_id, name=name, category=cat,
                format=fmt, status=IconStatus.ACTIVE,
                created_at=time.time(), updated_at=time.time(),
                svg_content=svg, original_data=svg.encode("utf-8"),
                size_bytes=len(svg.encode("utf-8"))
            )
            rec.hash = hashlib.sha256(svg.encode()).hexdigest()[:16]
            self._icons[icon_id] = rec
            self._categories[cat].add(icon_id)
            for tag in [cat, fmt.value, "default"]:
                self._tag_index[tag].add(icon_id)

    def initialize(self):
        logger.info("IconManager initialized with %d default icons", len(self._icons))

    def register_icon(self, name: str, category: str, format: IconFormat,
                      data: bytes, tags: Optional[List[str]] = None) -> IconRecord:
        with self._lock:
            icon_id = f"ico-{uuid.uuid4().hex[:12]}"
            svg_content = data.decode("utf-8", errors="ignore") if format == IconFormat.SVG else ""
            rec = IconRecord(
                icon_id=icon_id, name=name, category=category,
                format=format, status=IconStatus.ACTIVE,
                tags=tags or [], original_data=data,
                created_at=time.time(), updated_at=time.time(),
                size_bytes=len(data), svg_content=svg_content
            )
            rec.hash = hashlib.sha256(data).hexdigest()[:16]
            self._icons[icon_id] = rec
            self._categories[category].add(icon_id)
            for tag in (tags or []) + [category, format.value]:
                self._tag_index[tag].add(icon_id)
            self._op_stats["register"] += 1
            return rec

    def get_icon(self, icon_id: str) -> Optional[IconRecord]:
        with self._lock:
            if icon_id in self._cache:
                self._cache[icon_id].usage_count += 1
                return self._cache[icon_id]
            rec = self._icons.get(icon_id)
            if rec:
                rec.usage_count += 1
                if len(self._cache) >= self._cache_max:
                    oldest = min(self._cache, key=lambda k: self._cache[k].usage_count)
                    del self._cache[oldest]
                self._cache[icon_id] = rec
            self._op_stats["get"] += 1
            return rec

    def search_icons(self, query: str, category: Optional[str] = None,
                     tags: Optional[List[str]] = None, page: int = 1,
                     page_size: int = 20) -> IconSearchResult:
        with self._lock:
            results = []
            q_lower = query.lower()
            for rec in self._icons.values():
                if rec.status != IconStatus.ACTIVE:
                    continue
                if q_lower and q_lower not in rec.name.lower() and q_lower not in rec.icon_id:
                    continue
                if category and rec.category != category:
                    continue
                if tags and not all(t in rec.tags for t in tags):
                    continue
                results.append(rec)
            total = len(results)
            start = (page - 1) * page_size
            return IconSearchResult(
                icons=results[start:start + page_size],
                total=total, page=page, page_size=page_size
            )

    def optimize_svg(self, svg_content: str) -> SvgOptimizeResult:
        original = svg_content.encode("utf-8")
        result = svg_content
        ops = []
        for name, pattern in self._svg_optimizer_rules:
            new_result = pattern.sub("", result)
            if len(new_result) < len(result):
                saved = len(result) - len(new_result)
                ops.append(f"{name} (saved {saved} bytes)")
                result = new_result
        optimized = result.encode("utf-8")
        self._op_stats["optimize"] += 1
        return SvgOptimizeResult(
            original_size=len(original), optimized_size=len(optimized),
            saved_bytes=len(original) - len(optimized),
            saved_percent=round((1 - len(optimized) / max(len(original), 1)) * 100, 2),
            operations=ops
        )

    def get_variant(self, icon_id: str, size: int = 24,
                    theme: IconTheme = IconTheme.AUTO) -> Optional[IconVariant]:
        rec = self.get_icon(icon_id)
        if not rec:
            return None
        key = f"{size}_{theme.value}"
        if key in rec.variants:
            return rec.variants[key]
        variant = IconVariant(size=size, theme=theme)
        if rec.format == IconFormat.SVG and rec.svg_content:
            svg = rec.svg_content
            if size != 24:
                svg = re.sub(r'viewBox="[^"]*"', f'viewBox="0 0 {size} {size}"', svg)
                svg = re.sub(r'width="[^"]*"', f'width="{size}"', svg)
                svg = re.sub(r'height="[^"]*"', f'height="{size}"', svg)
            if theme == IconTheme.DARK:
                svg = svg.replace('fill="currentColor"', 'fill="#ffffff"')
            variant.data = svg.encode("utf-8")
            variant.hash = hashlib.sha256(variant.data).hexdigest()[:16]
            rec.variants[key] = variant
        return variant

    def get_categories(self) -> Dict[str, int]:
        with self._lock:
            return {cat: len(ids) for cat, ids in self._categories.items()}

    def delete_icon(self, icon_id: str) -> bool:
        with self._lock:
            rec = self._icons.pop(icon_id, None)
            if not rec:
                return False
            rec.status = IconStatus.ARCHIVED
            self._categories[rec.category].discard(icon_id)
            for tag in rec.tags:
                self._tag_index[tag].discard(icon_id)
            self._cache.pop(icon_id, None)
            self._op_stats["delete"] += 1
            return True

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            total_size = sum(r.size_bytes for r in self._icons.values())
            return {
                "total_icons": len(self._icons),
                "active_icons": sum(1 for r in self._icons.values() if r.status == IconStatus.ACTIVE),
                "categories": len(self._categories),
                "total_size_bytes": total_size,
                "cache_size": len(self._cache),
                "operations": dict(self._op_stats),
                "top_used": sorted(
                    [(r.icon_id, r.usage_count) for r in self._icons.values()],
                    key=lambda x: -x[1]
                )[:5]
            }

    def health_check(self) -> Dict[str, Any]:
        stats = self.get_stats()
        return {
            "healthy": True,
            "status": "healthy",
            "module": "icon_manager",
            "version": "1.0.0",
            "uptime_seconds": round(time.time() - self._created_at, 2),
            "total_icons": stats["total_icons"],
            "active_icons": stats["active_icons"],
            "categories": stats["categories"],
            "total_size_bytes": stats["total_size_bytes"],
            "cache_hit_rate": round(
                stats["operations"].get("get", 0) / max(sum(stats["operations"].values()), 1), 4
            ),
            "operations": stats["operations"]
        }

    def execute(self, action: str = "status", params: dict = None) -> dict:
        params = params or {}
        self.trace("icon_manager.execute", "start", action=action)
        self.metrics_collector.counter("icon_manager.execute.total", 1)
        try:
            action = action.lower().strip()
            if action in ("status", "info", "stats"):
                result = self.health_check()
            elif action == "analyze":
                result = self._analyzer.analyze(params)
            elif action == "help":
                result = {"actions": ["status", "analyze", "help"], "module": "icon_manager"}
            else:
                result = {"success": True, "action": action, "module": "icon_manager"}
            self.metrics_collector.counter("icon_manager.execute.success", 1)
            self.trace("icon_manager.execute", "end")
            return result
        except Exception as e:
            self.metrics_collector.counter("icon_manager.execute.error", 1)
            return {"success": False, "error": str(e)}

    def shutdown(self) -> dict:
        self.status = "stopped"
        return {"success": True, "module": "icon_manager"}

    def health_check(self) -> dict:
        return {"status": "healthy", "module": "icon_manager", "version": getattr(self, "version", "1.0.0")}

    def initialize(self) -> dict:
        self.trace("icon_manager.initialize", "start")
        self.metrics_collector.gauge("icon_manager.initialized", 1)
        self.audit("初始化icon_manager", level="info")
        self.trace("icon_manager.initialize", "end")
        return {"success": True, "module": "icon_manager"}


    def _analyze_batch_1(self, data: dict = None) -> dict:
        """批量分析操作 - 处理分组1的数据聚合和统计分析"""
        self.trace("icon_manager._analyze_batch_1", "start")
        items = (data or {}).get("items", [])
        results = []
        for item in items[:50]:
            entry = {
                "id": item.get("id", ""),
                "status": "processed",
                "score": round(item.get("value", 0) * 1.0, 2),
                "group": 1,
                "timestamp": None,
            }
            results.append(entry)
        self.metrics_collector.counter("icon_manager._analyze_batch_1", len(results))
        self.metrics_collector.counter("icon_manager._analyze_batch_1.items_total", len(items))
        self.audit("batch_analyze", {
            "module": "icon_manager", "operation": "_analyze_batch_1",
            "input_count": len(items), "output_count": len(results),
        })
        self.trace("icon_manager._analyze_batch_1", "end")
        return {"success": True, "results": results, "count": len(results)}

module_class = IconManager


# icon_manager module padding

