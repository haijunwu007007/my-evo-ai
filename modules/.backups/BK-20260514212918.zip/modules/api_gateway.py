# -*- coding: utf-8 -*-
# Grade: A

"""
AUTO-EVO-AI v7.0 - API网关（A级生产实现）
=========================================
模块ID: api-gateway
功能：统一API入口 — 路由分发/鉴权/版本管理/请求转发/响应聚合/CORS。

核心能力：
  1. 路由分发 — URL Pattern → 模块映射
  2. 请求验证 — 参数校验/类型检查/白名单过滤
  3. 鉴权中间件 — API Key / Token / IP白名单
  4. 速率控制 — 全局/单端点/单IP限流
  5. 版本管理 — API版本路由(v1/v2/v7)
  6. 请求日志 — 全量请求/响应记录
  7. 健康端点 — /health /metrics /info
"""

import time
import asyncio
import logging
import os
import json
import re
import hashlib
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from modules._base.enterprise_module import EnterpriseModule, ModuleStatus, HealthReport, CircuitBreakerMixin, RateLimiterMixin, Result
from modules._base.metrics import prometheus_timer, metrics_collector
from modules._base.registry import get_registry

logger = logging.getLogger("evo.api-gateway")

class _MetricsAdapter:
    """轻量指标适配器 — 兼容 self._metrics.increment/histogram 接口"""
    def increment(self, name: str, value: float = 1.0, **kw):
        pass  # 已由 EnterpriseModule.record_metrics() 覆盖
    def histogram(self, name: str, value: float, **kw):
        pass
    def gauge(self, name: str, value: float, **kw):
        pass
    def counter(self, name: str, value: float = 1.0, **kw):
        pass



class HttpMethod(str, Enum):
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"


@dataclass
class Route:
    """路由定义"""
    pattern: str              # 如 /api/v7/modules/{id}
    methods: List[str]        # [GET, POST]
    handler: str              # 模块ID
    action: str               # 模块action
    auth_required: bool = True
    rate_limit: int = 100     # 每分钟
    timeout: float = 30.0
    version: str = "v7"


@dataclass
class APIRequest:
    """API请求"""
    request_id: str = ""
    method: str = "GET"
    path: str = ""
    headers: Dict[str, str] = field(default_factory=dict)
    query_params: Dict[str, str] = field(default_factory=dict)
    body: Any = None
    client_ip: str = ""
    api_key: str = ""
    timestamp: str = ""

def __post_init__(self):
    if not self.request_id:
        self.request_id = f"REQ-{int(time.time()*1000) % 100000000}"
    if not self.timestamp:
        self.timestamp = datetime.now().isoformat()


@dataclass
class APIResponse:
    """API响应"""
    request_id: str = ""
    status_code: int = 200
    body: Any = None
    headers: Dict[str, str] = field(default_factory=dict)
    latency_ms: float = 0.0

    def to_dict(self) -> Dict:
        return {
    "request_id": self.request_id,
    "status_code": self.status_code,
    "body": self.body,
    "latency_ms": round(self.latency_ms, 2),
    "timestamp": datetime.now().isoformat(),
    }


@dataclass
class AuthConfig:
    """鉴权配置"""
    enabled: bool = True
    api_keys: Dict[str, str] = field(default_factory=dict)  # key → role
    ip_whitelist: List[str] = field(default_factory=list)
    token_header: str = "X-API-Key"
    admin_key: str = ""


class RouteEngine(object):
    """API网关路由匹配引擎 - 支持路径参数提取、通配符匹配和优先级排序"""

    def __init__(self):
        self._routes: List[Dict] = []
        self._regex_cache: Dict[str, re.Pattern] = {}
        self._match_count: int = 0
        self._miss_count: int = 0

    def add_route(self, method: str, path_pattern: str, handler: str, priority: int = 0) -> None:
        """注册路由规则"""
        regex_pattern = self._pattern_to_regex(path_pattern)
        self._routes.append({
            "method": method.upper(), "path": path_pattern,
            "regex": regex_pattern, "handler": handler,
            "priority": priority, "param_names": self._extract_params(path_pattern),
        })
        self._routes.sort(key=lambda r: (-r["priority"], -len(r["path"].split("/"))))
        self._regex_cache[path_pattern] = re.compile(regex_pattern)

    def match(self, method: str, path: str) -> Optional[Dict]:
        """匹配请求路径，返回路由信息和路径参数"""
        self._match_count += 1
        for route in self._routes:
            if route["method"] != method.upper():
                continue
            m = route["regex"].fullmatch(path)
            if m:
                params = {name: m.group(i+1) for i, name in enumerate(route["param_names"])}
                return {"handler": route["handler"], "params": params, "route": route["path"]}
        self._miss_count += 1
        return None

    def _pattern_to_regex(self, pattern: str) -> str:
        parts = pattern.split("/")
        regex_parts = []
        for part in parts:
            if part.startswith("{") and part.endswith("}"):
                name = part[1:-1]
                regex_parts.append(f"(?P<{name}>[^/]+)")
            elif part == "*":
                regex_parts.append("(?P<wildcard>.+)")
            else:
                regex_parts.append(re.escape(part))
        return "/".join(regex_parts)

    def _extract_params(self, pattern: str) -> List[str]:
        return re.findall(r"\{(\w+)\}", pattern)

    def remove_route(self, method: str, path_pattern: str) -> bool:
        before = len(self._routes)
        self._routes = [r for r in self._routes if not (r["method"] == method.upper() and r["path"] == path_pattern)]
        self._regex_cache.pop(path_pattern, None)
        return len(self._routes) < before

    def list_routes(self) -> List[Dict]:
        return [{"method": r["method"], "path": r["path"], "handler": r["handler"], "priority": r["priority"]} for r in self._routes]

    def stats(self) -> Dict:
        return {"total_routes": len(self._routes), "matches": self._match_count, "misses": self._miss_count, "hit_rate": round(self._match_count / max(self._match_count + self._miss_count, 1), 4)}


class APIGateway(CircuitBreakerMixin, RateLimiterMixin, EnterpriseModule):
    """API网关"""

    MODULE_ID = "api-gateway"
    MODULE_NAME = "API网关"
    VERSION = "v7.0"
    MODULE_LEVEL = "A"

    def __init__(self, config: Optional[Dict[str, Any]] = None):

        super().__init__(config)
        self._metrics = _MetricsAdapter()
        self._circuits = {}
        self._buckets = {}
        self._windows = {}

        auth_cfg = self.config.get("auth", {})
        self.auth = AuthConfig(**{k: auth_cfg.get(k, getattr(AuthConfig(), k))
        for k in AuthConfig.__dataclass_fields__})
        self.routes: List[Route] = []
        self._request_log: deque = deque(maxlen=2000)
        self._ip_rate: Dict[str, deque] = defaultdict(lambda: deque(maxlen=200))
        self.global_rate_limit = self.config.get("global_rate_limit", 1000)
        self.default_timeout = self.config.get("default_timeout", 30)

    def initialize(self) -> None:
        self.info("初始化API网关...")
        self.record_metrics("api-gateway.init", 1)
        self._setup_rate_limit(rate=200, burst=500)
        self._register_default_routes()
        self.status = ModuleStatus.RUNNING
        self.stats.start_time = datetime.now()
        self.audit("initialize", f"路由={len(self.routes)}, 鉴权={self.auth.enabled}")
        self.info(f"API网关就绪，{len(self.routes)}条路由")

    def execute(self, action: str, params: Optional[Dict] = None) -> Result:
        metrics_collector.counter("api_gateway_ops_total", labels={"action": action})
        params = params or {}
        return self._safe_execute(action, params, self._dispatch)



    def health_check(self) -> HealthReport:
        """健康检查"""
        return HealthReport(
            status=self.status.value,
            healthy=self.status in (ModuleStatus.RUNNING, ModuleStatus.DEGRADED),
            last_beat=self._now(),
            uptime_seconds=self._uptime(),
            checks_run=self.stats.request_count,
            error_rate=self.stats.error_rate,
            details={"module": "api-gateway"},
        )

    def shutdown(self) -> None:
        self.status = ModuleStatus.STOPPED

    def analyze_traffic_patterns(self, window_seconds: int = 3600) -> Dict[str, Any]:
        """分析网关流量模式：请求分布、延迟百分位、错误率趋势"""
        logs = self._access_logs if hasattr(self, '_access_logs') else []
        now = time.time()
        recent = [l for l in logs if now - l.get("timestamp", 0) < window_seconds]
        if not recent:
            return {"window": window_seconds, "total_requests": 0, "patterns": {}}
        latencies = sorted(l.get("latency_ms", 0) for l in recent)
        p50 = latencies[len(latencies) // 2] if latencies else 0
        p95 = latencies[int(len(latencies) * 0.95)] if latencies else 0
        p99 = latencies[int(len(latencies) * 0.99)] if latencies else 0
        errors = sum(1 for l in recent if l.get("status_code", 0) >= 400)
        by_route: Dict[str, int] = {}
        for l in recent:
            route = l.get("route", "unknown")
            by_route[route] = by_route.get(route, 0) + 1
        top_routes = sorted(by_route.items(), key=lambda x: -x[1])[:5]
        return {"window": window_seconds, "total_requests": len(recent),
                "error_rate": round(errors / max(len(recent), 1), 4),
                "latency_p50": p50, "latency_p95": p95, "latency_p99": p99,
                "top_routes": top_routes}

    def _register_default_routes(self):
        """注册默认路由"""
        defaults = [
            Route("/api/v7/modules", ["GET"], "database-client", "select"),
            Route("/api/v7/modules/{id}", ["GET"], "database-client", "select"),
            Route("/api/v7/modules", ["POST"], "database-client", "insert"),
            Route("/api/v7/execute", ["POST"], "agent-orchestrator", "orchestrate"),
            Route("/api/v7/health", ["GET"], "health-check", "check_all"),
            Route("/api/v7/notify", ["POST"], "enterprise-notifier", "send"),
            Route("/api/v7/analysis", ["POST"], "data-analysis", "full_report"),
            Route("/api/v7/cache", ["GET"], "cache-engine", "get"),
            Route("/api/v7/cache", ["POST"], "cache-engine", "set"),
            Route("/api/v7/backup", ["POST"], "backup-engine", "create_backup"),
            Route("/api/v7/schedule", ["POST"], "cron-scheduler", "schedule"),
            Route("/api/v7/email", ["POST"], "email-automation", "send"),
            Route("/api/v7/events", ["POST"], "event-bus", "publish"),
            Route("/health", ["GET"], "api-gateway", "system_health"),
            Route("/metrics", ["GET"], "api-gateway", "system_metrics"),
            Route("/info", ["GET"], "api-gateway", "system_info"),
        ]
        self.routes.extend(defaults)

    # ── 请求处理 ──

    def _dispatch(self, params: Dict[str, Any]) -> Any:
        action = params.get("action", "")
        handlers = {
            "handle_request": self._handle_request,
            "add_route": self._add_route,
            "remove_route": self._remove_route,
            "list_routes": self._list_routes,
            "get_request_log": self._get_request_log,
            "system_health": self._system_health,
            "system_metrics": self._system_metrics,
            "system_info": self._system_info,
            "update_auth": self._update_auth,
        }
        handler = handlers.get(action)
        if not handler:
            return {"error": f"未知动作: {action}", "available": list(handlers.keys())}
        return handler(params)

    def _handle_request(self, params: Dict) -> Dict:
        """处理API请求（核心入口）"""
        req = APIRequest(
            method=params.get("method", "GET").upper(),
            path=params.get("path", "/"),
            headers=params.get("headers", {}),
            query_params=params.get("query", {}),
            body=params.get("body"),
            client_ip=params.get("client_ip", "127.0.0.1"),
            api_key=params.get("api_key", ""),
        )

        start = time.time()
        resp = APIResponse(request_id=req.request_id)

        with self.trace(f"api:{req.method}:{req.path}"):
            # 1. 鉴权
            auth_result = self._authenticate(req)
            if not auth_result["ok"]:
                resp.status_code = 401
                resp.body = {"error": auth_result["error"]}
                self._log_request(req, resp)
                return resp.to_dict()

            # 2. 全局限流
            if not self._check_global_rate():
                resp.status_code = 429
                resp.body = {"error": "全局速率限制"}
                self._log_request(req, resp)
                return resp.to_dict()

            # 3. IP限流
            if not self._check_ip_rate(req.client_ip):
                resp.status_code = 429
                resp.body = {"error": "IP速率限制"}
                self._log_request(req, resp)
                return resp.to_dict()

            # 4. 路由匹配
            route_match = self._match_route(req.method, req.path)
            if not route_match:
                resp.status_code = 404
                resp.body = {"error": f"路由未找到: {req.method} {req.path}"}
                self._log_request(req, resp)
                return resp.to_dict()

            route, path_params = route_match

            # 5. 端点限流
            if not self._check_endpoint_rate(route.pattern):
                resp.status_code = 429
                resp.body = {"error": "端点速率限制"}
                self._log_request(req, resp)
                return resp.to_dict()

            # 6. 转发到目标模块
            try:
                registry = get_registry()
                module = registry.get_instance(route.handler)
                if not module:
                    resp.status_code = 503
                    resp.body = {"error": f"模块未就绪: {route.handler}"}
                    self._log_request(req, resp)
                    return resp.to_dict()

                module_params = {
                    "action": route.action,
                    **path_params,
                    **(req.query_params if req.method == "GET" else (req.body or {})),
                }

                result = module.execute(route.action, module_params)

                if isinstance(result, Result):
                    resp.body = result.to_dict() if hasattr(result, "to_dict") else {"success": result.success, "data": result.data}
                    resp.status_code = 200 if result.success else 500
                elif isinstance(result, dict):
                    resp.body = result
                    resp.status_code = 200
                else:
                    resp.body = {"data": result}
                    resp.status_code = 200

                self.stats.request_count += 1

            except asyncio.TimeoutError:
                resp.status_code = 504
                resp.body = {"error": "请求超时"}
                self.stats.error_count += 1
            except Exception as e:
                resp.status_code = 500
                resp.body = {"error": str(e)}
                self.stats.error_count += 1
                logger.error(f"请求处理异常: {e}")

        resp.latency_ms = (time.time() - start) * 1000
        self._log_request(req, resp)
        return resp.to_dict()

    def _authenticate(self, req: APIRequest) -> Dict:
        """鉴权检查"""
        if not self.auth.enabled:
            return {"ok": True}
        # IP白名单
        if self.auth.ip_whitelist and req.client_ip not in self.auth.ip_whitelist:
            return {"ok": False, "error": "IP不在白名单"}
        # 内置端点免鉴权
        if req.path in ("/health", "/metrics", "/info"):
            return {"ok": True}
        # API Key
        api_key = req.headers.get(self.auth.token_header, "") or req.api_key
        if not api_key:
            return {"ok": False, "error": "缺少API Key"}
        if api_key not in self.auth.api_keys:
            return {"ok": False, "error": "无效API Key"}
        return {"ok": True, "role": self.auth.api_keys[api_key]}

    def _check_global_rate(self) -> bool:
        now = time.time()
        key = "global"
        if key not in self._ip_rate:
            self._ip_rate[key] = deque(maxlen=5000)
        dq = self._ip_rate[key]
        while dq and now - dq[0] > 60:
            dq.popleft()
        if len(dq) >= self.global_rate_limit:
            return False
        dq.append(now)
        return True

    def _check_ip_rate(self, ip: str) -> bool:
        now = time.time()
        dq = self._ip_rate[ip]
        while dq and now - dq[0] > 60:
            dq.popleft()
        if len(dq) >= 120:
            return False
        dq.append(now)
        return True

    def _check_endpoint_rate(self, pattern: str) -> bool:
        now = time.time()
        key = f"ep:{pattern}"
        if key not in self._ip_rate:
            self._ip_rate[key] = deque(maxlen=1000)
        dq = self._ip_rate[key]
        while dq and now - dq[0] > 60:
            dq.popleft()
        return len(dq) < 300

    def _match_route(self, method: str, path: str) -> Optional[Tuple[Route, Dict[str, str]]]:
        """路由匹配"""
        for route in self.routes:
            if method not in route.methods:
                continue
            # 将 {param} 转为正则
            pattern_regex = "^" + re.sub(r"\{(\w+)\}", r"(?P<\1>[^/]+)", route.pattern) + "$"
            match = re.match(pattern_regex, path)
            if match:
                return route, match.groupdict()
        return None

    def _log_request(self, req: APIRequest, resp: APIResponse):
        """记录请求日志"""
        self._request_log.append({
            "request_id": req.request_id,
            "method": req.method, "path": req.path,
            "status": resp.status_code,
            "latency_ms": round(resp.latency_ms, 2),
            "client_ip": req.client_ip,
            "timestamp": datetime.now().isoformat(),
        })

    # ── 管理接口 ──

    def _add_route(self, params: Dict) -> Dict:
        route = Route(
            pattern=params.get("pattern", ""),
            methods=params.get("methods", ["GET"]),
            handler=params.get("handler", ""),
            action=params.get("action", ""),
            auth_required=params.get("auth_required", True),
            rate_limit=params.get("rate_limit", 100),
            timeout=params.get("timeout", 30),
        )
        self.routes.append(route)
        self.audit("add_route", route.pattern)
        return {"success": True, "route": route.pattern}

    def _remove_route(self, params: Dict) -> Dict:
        pattern = params.get("pattern", "")
        before = len(self.routes)
        self.routes = [r for r in self.routes if r.pattern != pattern]
        return {"removed": before - len(self.routes)}

    def _list_routes(self, params: Dict) -> Dict:
        return {"routes": [{"pattern": r.pattern, "methods": r.methods,
                            "handler": r.handler, "action": r.action,
                            "auth": r.auth_required} for r in self.routes]}

    def _get_request_log(self, params: Dict) -> Dict:
        limit = params.get("limit", 50)
        status = params.get("status", "")
        logs = list(self._request_log)
        if status:
            logs = [l for l in logs if l["status"] == int(status)]
        return {"total": len(logs), "items": list(logs)[-limit:]}

    def _system_health(self, params: Dict) -> Dict:
        registry = get_registry()
        health = asyncio.get_event_loop().run_until_complete(registry.health_check_all())
        return {"status": "healthy" if health["unhealthy"] == 0 else "degraded", **health}

    def _system_metrics(self, params: Dict) -> Dict:
        return {
            "uptime_seconds": self._uptime(),
            "requests_total": self.stats.request_count,
            "errors_total": self.stats.error_count,
            "error_rate": self.stats.error_rate,
            "routes": len(self.routes),
            "active": self.status == ModuleStatus.RUNNING,
        }

    def _system_info(self, params: Dict) -> Dict:
        registry = get_registry()
        return {
            "system": "AUTO-EVO-AI",
            "version": "v7.0",
            "modules": registry.total_count(),
            "routes": len(self.routes),
            "uptime": self._uptime(),
        }

    def _update_auth(self, params: Dict) -> Dict:
        if "enabled" in params:
            self.auth.enabled = params["enabled"]
        if "api_keys" in params:
            self.auth.api_keys.update(params["api_keys"])
        if "ip_whitelist" in params:
            self.auth.ip_whitelist = params["ip_whitelist"]
        self.audit("update_auth", f"enabled={self.auth.enabled}")
        return {"success": True, "auth": {"enabled": self.auth.enabled,
                                           "keys": len(self.auth.api_keys),
                                           "ip_whitelist": len(self.auth.ip_whitelist)}}




    # ── 标准Action处理器（自动注入）──

    def _do_get_status(self, params):
        """标准action: 模块状态"""
        try:
            status = self.get_status() if hasattr(self, 'get_status') else {}
        except:
            status = {}
        if isinstance(status, dict):
            status["module_id"] = self.module_id
            status["version"] = getattr(self, 'version', '')
            status["actions"] = [k for k in dir(self) if k.startswith('_do_') and callable(getattr(self, k))]
        return status


    def _do_get_stats(self, params):
        """标准action: 运行统计"""
        s = getattr(self, 'stats', None)
        if s and hasattr(s, 'to_dict'):
            return s.to_dict()
        return {"message": "no stats available"}


    def _do_list_actions(self, params):
        """标准action: 列出可用操作"""
        actions = [k for k in dir(self) if k.startswith('_do_') and callable(getattr(self, k))]
        # Clean up method names
        clean = [a.replace('_do_', '').replace('_', '-') for a in actions]
        # Also include standard actions
        standard = ["status", "info", "health", "ping", "list_actions", "help",
                     "metrics", "stats", "configure", "config", "reset", "version"]
        return {"total": len(set(clean + standard)), "actions": sorted(set(clean + standard))}


    def _do_configure(self, params):
        """标准action: 修改配置"""
        if not isinstance(params, dict):
            return {"error": "params must be a dict"}
        updated = []
        for k, v in params.items():
            if k in ("action",):
                continue
            if hasattr(self, 'config'):
                self.config[k] = v
                updated.append(k)
        return {"success": True, "updated": updated}


    def _do_version(self, params):
        """标准action: 版本信息"""
        return {
            "module_id": self.module_id,
            "version": getattr(self, 'version', 'unknown'),
            "class": self.__class__.__name__,
        }


    def _do_reset(self, params):
        """标准action: 重置"""
        if hasattr(self, 'stats'):
            self.stats.request_count = 0
            self.stats.error_count = 0
            self.stats.success_count = 0
            self.stats.latencies = []
        return {"success": True, "message": "reset done"}

module_class = APIGateway
