"""permission_rbac - Enterprise RBAC Permission Module
AUTO-EVO-AI v6.39 | Grade: A | Category: 安全认证
角色/权限/用户组管理, 权限继承, 资源ACL, 操作审计
子引擎: PermissionAnalyzer(权限分析+冗余检测+覆盖率)
"""
import logging, hashlib, time, uuid, threading
from typing import Dict, Any, Optional, List, Set
from datetime import datetime
from dataclasses import dataclass, field
from collections import defaultdict

from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)

logger = logging.getLogger(__name__)


@dataclass
class Role:
    role_id: str = ""
    name: str = ""
    description: str = ""
    parent_id: str = ""  # 角色继承
    permissions: List[str] = field(default_factory=list)
    created_at: str = ""

    def __post_init__(self):
        if not self.role_id:
            self.role_id = str(uuid.uuid4())[:8]
        if not self.created_at:
            self.created_at = datetime.now().isoformat()


@dataclass
class ResourceACL:
    resource: str = ""
    owner: str = ""
    permissions: Dict[str, List[str]] = field(default_factory=dict)  # role_id -> [perms]

    def __post_init__(self):
        if not self.permissions:
            self.permissions = {}


@dataclass
class PermissionRecord:
    action: str = ""
    user_id: str = ""
    resource: str = ""
    role: str = ""
    allowed: bool = False
    timestamp: float = 0.0

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = time.time()


class PermissionAnalyzer:
    """权限分析引擎 — 冗余检测、覆盖率、角色建议"""

    def __init__(self):
        self._check_history: List[PermissionRecord] = []

    def record_check(self, record: PermissionRecord):
        self._check_history.append(record)
        if len(self._check_history) > 5000:
            self._check_history = self._check_history[-3000:]

    def find_redundant_permissions(self, roles: Dict[str, Role]) -> List[Dict]:
        """查找冗余权限(子角色包含父角色已有的权限)"""
        redundant = []
        for role in roles.values():
            if not role.parent_id:
                continue
            parent = roles.get(role.parent_id)
            if not parent:
                continue
            parent_perms = self._get_all_permissions(role.parent_id, roles)
            for perm in role.permissions:
                if perm in parent_perms:
                    redundant.append({
                        "role": role.name, "permission": perm,
                        "inherited_from": parent.name,
                    })
        return redundant

    def coverage_report(self, roles: Dict[str, Role], users: Dict[str, List[str]],
                        resources: List[str]) -> Dict[str, Any]:
        """权限覆盖率报告"""
        all_perms = set()
        for role in roles.values():
            all_perms.update(role.permissions)
        covered_resources: Dict[str, Set[str]] = defaultdict(set)
        for resource in resources:
            for role_id in users.values():
                for rid in role_id:
                    role = roles.get(rid)
                    if role:
                        covered_resources[resource].update(role.permissions)
        return {
            "total_roles": len(roles),
            "total_users": len(users),
            "total_resources": len(resources),
            "unique_permissions": len(all_perms),
            "resource_coverage": {r: len(perms) for r, perms in covered_resources.items()},
            "avg_permissions_per_role": round(
                sum(len(r.permissions) for r in roles.values()) / max(1, len(roles)), 1),
        }

    def access_summary(self) -> Dict[str, Any]:
        recent = [r for r in self._check_history if time.time() - r.timestamp < 3600]
        allowed = len([r for r in recent if r.allowed])
        denied = len([r for r in recent if not r.allowed])
        return {
            "total_checks_1h": len(recent),
            "allowed": allowed, "denied": denied,
            "deny_rate": round(denied / max(1, len(recent)) * 100, 1),
            "top_denied_resources": self._top_denied(recent),
        }

    def _top_denied(self, records: List[PermissionRecord], top: int = 5) -> List[Dict]:
        counts: Dict[str, int] = defaultdict(int)
        for r in records:
            if not r.allowed:
                counts[r.resource] += 1
        sorted_r = sorted(counts.items(), key=lambda x: -x[1])
        return [{"resource": r, "denied_count": c} for r, c in sorted_r[:top]]

    def _get_all_permissions(self, role_id: str, roles: Dict[str, Role]) -> Set[str]:
        perms = set()
        role = roles.get(role_id)
        if not role:
            return perms
        perms.update(role.permissions)
        if role.parent_id:
            perms.update(self._get_all_permissions(role.parent_id, roles))
        return perms


class PermissionRbac(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    AUTO-EVO-AI v6.39 - RBAC权限管理模块
    """

    MODULE_ID = "permission_rbac"
    MODULE_NAME = "PermissionRbac"
    VERSION = "1.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._roles: Dict[str, Role] = {}
        self._user_roles: Dict[str, List[str]] = defaultdict(list)
        self._user_groups: Dict[str, List[str]] = defaultdict(list)
        self._group_roles: Dict[str, List[str]] = defaultdict(list)
        self._resource_acls: Dict[str, ResourceACL] = {}
        self._analyzer = PermissionAnalyzer()
        self._lock = threading.Lock()
        self._total_checks = 0
        self._total_allowed = 0
        self._total_denied = 0
        self._init_default_roles()

    def _init_default_roles(self):
        for name, perms in [("admin", ["read", "write", "delete", "admin", "manage"]),
                            ("editor", ["read", "write"]),
                            ("viewer", ["read"]),
                            ("guest", [])]:
            self._roles[name] = Role(role_id=name, name=name, permissions=perms)

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                result = self._dispatch(action, params)
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                logger.error(f"[permission_rbac] {action} error: {e}")
                return {"success": False, "error": str(e), "action": action}

    def _dispatch(self, action: str, params: Dict[str, Any]) -> Any:
        handler = {
            "status": self._get_status, "stats": self._get_stats,
            "health": self.health_check, "reset": self._reset,
            "configure": self._configure,
            # 角色管理
            "create_role": self._create_role, "list_roles": self._list_roles,
            "remove_role": self._remove_role, "update_role": self._update_role,
            # 用户-角色
            "assign_role": self._assign_role, "revoke_role": self._revoke_role,
            "user_roles": self._user_roles_info,
            # 用户组
            "create_group": self._create_group, "assign_group": self._assign_group,
            "group_roles": self._group_roles_info,
            # 权限检查
            "check": self._check_permission, "check_batch": self._check_batch,
            # ACL
            "set_acl": self._set_acl, "get_acl": self._get_acl, "remove_acl": self._remove_acl,
            # 分析
            "analyze_redundant": self._analyze_redundant,
            "coverage": self._coverage_report,
            "access_summary": self._access_summary,
        }.get(action)
        if handler:
            return handler(params)
        return {"action": action, "module_id": self.MODULE_ID}

    def _create_role(self, params: Dict[str, Any]) -> Dict[str, Any]:
        role = Role(name=params.get("name", ""),
                    description=params.get("description", ""),
                    parent_id=params.get("parent_id", ""),
                    permissions=params.get("permissions", []))
        self._roles[role.role_id] = role
        self.audit("create_role", f"role={role.role_id} perms={role.permissions}")
        return {"role_id": role.role_id, "name": role.name}

    def _list_roles(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"roles": [{"role_id": r.role_id, "name": r.name, "description": r.description,
                           "parent_id": r.parent_id, "permissions": r.permissions}
                          for r in self._roles.values()], "total": len(self._roles)}

    def _remove_role(self, params: Dict[str, Any]) -> Dict[str, Any]:
        rid = params.get("role_id", "")
        if rid in self._roles:
            del self._roles[rid]
            for uid in self._user_roles:
                self._user_roles[uid] = [r for r in self._user_roles[uid] if r != rid]
            return {"role_id": rid, "removed": True}
        return {"error": "not_found"}

    def _update_role(self, params: Dict[str, Any]) -> Dict[str, Any]:
        rid = params.get("role_id", "")
        role = self._roles.get(rid)
        if not role:
            return {"error": "not_found"}
        if "name" in params:
            role.name = params["name"]
        if "description" in params:
            role.description = params["description"]
        if "parent_id" in params:
            role.parent_id = params["parent_id"]
        if "permissions" in params:
            role.permissions = params["permissions"]
        return {"role_id": rid, "updated": True}

    def _assign_role(self, params: Dict[str, Any]) -> Dict[str, Any]:
        user_id = params.get("user_id", "")
        role_id = params.get("role_id", "")
        if role_id not in self._roles:
            return {"error": "role not found"}
        if role_id not in self._user_roles[user_id]:
            self._user_roles[user_id].append(role_id)
        self.audit("assign_role", f"user={user_id} role={role_id}")
        return {"user_id": user_id, "role_id": role_id, "assigned": True}

    def _revoke_role(self, params: Dict[str, Any]) -> Dict[str, Any]:
        user_id = params.get("user_id", "")
        role_id = params.get("role_id", "")
        before = len(self._user_roles[user_id])
        self._user_roles[user_id] = [r for r in self._user_roles[user_id] if r != role_id]
        removed = before - len(self._user_roles[user_id])
        return {"user_id": user_id, "role_id": role_id, "removed": removed}

    def _user_roles_info(self, params: Dict[str, Any]) -> Dict[str, Any]:
        user_id = params.get("user_id", "")
        role_ids = self._user_roles.get(user_id, [])
        roles = [{"role_id": rid, "name": self._roles[rid].name,
                  "permissions": self._roles[rid].permissions}
                 for rid in role_ids if rid in self._roles]
        return {"user_id": user_id, "roles": roles, "count": len(roles)}

    def _create_group(self, params: Dict[str, Any]) -> Dict[str, Any]:
        group = params.get("group", "")
        if group:
            return {"group": group, "created": True}
        return {"error": "group name required"}

    def _assign_group(self, params: Dict[str, Any]) -> Dict[str, Any]:
        user_id = params.get("user_id", "")
        group = params.get("group", "")
        role_ids = params.get("roles", [])
        if group not in self._user_groups[user_id]:
            self._user_groups[user_id].append(group)
        if role_ids:
            self._group_roles[group] = list(set(self._group_roles[group] + role_ids))
        return {"user_id": user_id, "group": group, "roles_added": len(role_ids)}

    def _group_roles_info(self, params: Dict[str, Any]) -> Dict[str, Any]:
        group = params.get("group", "")
        members = [uid for uid, groups in self._user_groups.items() if group in groups]
        roles = self._group_roles.get(group, [])
        return {"group": group, "members": members, "roles": roles}

    def _check_permission(self, params: Dict[str, Any]) -> Dict[str, Any]:
        user_id = params.get("user_id", "")
        permission = params.get("permission", "")
        resource = params.get("resource", "")
        self._total_checks += 1
        all_perms = self._get_user_permissions(user_id)
        allowed = permission in all_perms
        if allowed:
            self._total_allowed += 1
        else:
            self._total_denied += 1
        record = PermissionRecord(action=permission, user_id=user_id,
                                   resource=resource, allowed=allowed)
        self._analyzer.record_check(record)
        return {"user_id": user_id, "permission": permission,
                "resource": resource, "allowed": allowed}

    def _check_batch(self, params: Dict[str, Any]) -> Dict[str, Any]:
        user_id = params.get("user_id", "")
        permissions = params.get("permissions", [])
        resource = params.get("resource", "")
        all_perms = self._get_user_permissions(user_id)
        results = [{"permission": p, "allowed": p in all_perms} for p in permissions]
        return {"user_id": user_id, "results": results, "resource": resource}

    def _set_acl(self, params: Dict[str, Any]) -> Dict[str, Any]:
        resource = params.get("resource", "")
        owner = params.get("owner", "")
        acl = ResourceACL(resource=resource, owner=owner)
        if "permissions" in params:
            acl.permissions = params["permissions"]
        self._resource_acls[resource] = acl
        return {"resource": resource, "acl_set": True}

    def _get_acl(self, params: Dict[str, Any]) -> Dict[str, Any]:
        resource = params.get("resource", "")
        acl = self._resource_acls.get(resource)
        if not acl:
            return {"resource": resource, "acl": None}
        return {"resource": resource, "owner": acl.owner, "permissions": acl.permissions}

    def _remove_acl(self, params: Dict[str, Any]) -> Dict[str, Any]:
        resource = params.get("resource", "")
        if resource in self._resource_acls:
            del self._resource_acls[resource]
            return {"resource": resource, "removed": True}
        return {"error": "not_found"}

    def _analyze_redundant(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"redundant": self._analyzer.find_redundant_permissions(self._roles)}

    def _coverage_report(self, params: Dict[str, Any]) -> Dict[str, Any]:
        resources = params.get("resources", list(self._resource_acls.keys()))
        return self._analyzer.coverage_report(self._roles, dict(self._user_roles), resources)

    def _access_summary(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return self._analyzer.access_summary()

    def _get_user_permissions(self, user_id: str) -> Set[str]:
        perms = set()
        for role_id in self._user_roles.get(user_id, []):
            perms.update(self._analyzer._get_all_permissions(role_id, self._roles))
        for group in self._user_groups.get(user_id, []):
            for role_id in self._group_roles.get(group, []):
                perms.update(self._analyzer._get_all_permissions(role_id, self._roles))
        return perms

    def _get_status(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
            "version": self.VERSION, "status": "running",
            "roles": len(self._roles), "users": len(self._user_roles),
            "groups": len(self._group_roles), "acls": len(self._resource_acls),
        }

    def _get_stats(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "total_checks": self._total_checks,
            "total_allowed": self._total_allowed,
            "total_denied": self._total_denied,
            "deny_rate": round(self._total_denied / max(1, self._total_checks) * 100, 1),
            "roles": len(self._roles), "users": len(self._user_roles),
            "acls": len(self._resource_acls),
        }

    def _reset(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        self._user_roles.clear()
        self._user_groups.clear()
        self._group_roles.clear()
        self._resource_acls.clear()
        self._total_checks = 0
        self._total_allowed = 0
        self._total_denied = 0
        return {"status": "reset_ok"}

    def _configure(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"configured": list(params.keys())}

    def health_check(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {"healthy": True, "status": "ok", "roles": len(self._roles)}


module_class = PermissionRbac
