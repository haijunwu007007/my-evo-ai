"""
        AUTO-EVO-AI v6.28 — m16 多模型调度中心 (Model Router)
======================================================
功能：多 LLM 提供商统一调度、负载均衡、智能路由、用量追踪、回退机制、成本控制
"""

from __future__ import annotations

import time
import logging
import hashlib
import asyncio
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
from enum import Enum
from datetime import datetime
from collections import defaultdict
from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector
logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────
# 数据模型
# ──────────────────────────────────────────────


class ModelRouterAnalyzer(object):
    """model_router 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "model_router"
        self.version = "1.0.0"
        self._analyzer = ModelRouterAnalyzer()
        self._history = []
        self._max_history = 10000
    
    def analyze(self, context: dict = None) -> dict:
        context = context or {}
        result = {"analyzer": "ModelRouterAnalyzer", "timestamp": time.time(), "records": len(self._history), "summary": self._summary()}
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-5000:]
        return result
    
    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "model_router"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== model_router ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}

class Provider(Enum):
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"
    AZURE = "azure"
    LOCAL = "local"
    CUSTOM = "custom"

class RoutingStrategy(Enum):
    ROUND_ROBIN = "round_robin"
    LEAST_LATENCY = "least_latency"
    COST_OPTIMIZED = "cost_optimized"
    QUALITY_FIRST = "quality_first"
    PRIORITY = "priority"

@dataclass
class ModelConfig:
    """模型配置"""
    model_id: str
    provider: Provider
    model_name: str
    api_base: str = ""
    api_key_env: str = ""  # 从环境变量读取密钥的 key 名
    max_tokens: int = 4096
    input_cost_per_1k: float = 0.0   # 每 1K token 输入成本 (USD)
    output_cost_per_1k: float = 0.0  # 每 1K token 输出成本 (USD)
    max_rpm: int = 60       # 每分钟请求数限制
    max_tpm: int = 100000   # 每分钟 token 限制
    priority: int = 5       # 优先级 1-10, 越高越优先
    enabled: bool = True
    supports_streaming: bool = True
    supports_vision: bool = False
    supports_functions: bool = True
    tags: List[str] = field(default_factory=list)

@dataclass
class RequestRecord:
    """请求记录"""
    request_id: str
    model_id: str
    provider: Provider
    prompt_tokens: int = 0
    completion_tokens: int = 0
    latency_ms: float = 0
    cost_usd: float = 0.0
    success: bool = True
    error: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

@dataclass
class ProviderStats:
    """提供商统计"""
    provider: Provider
    total_requests: int = 0
    success_count: int = 0
    fail_count: int = 0
    total_tokens_in: int = 0
    total_tokens_out: int = 0
    total_cost_usd: float = 0.0
    avg_latency_ms: float = 0.0
    current_rpm: int = 0
    current_tpm: int = 0
    last_used: str = ""

# ──────────────────────────────────────────────
# 预置模型配置
# ──────────────────────────────────────────────

PRESET_MODELS: List[ModelConfig] = [
    ModelConfig(
        model_id="gpt-4o", provider=Provider.OPENAI, model_name="gpt-4o",
        input_cost_per_1k=0.005, output_cost_per_1k=0.015, max_tokens=128000,
        priority=8, supports_vision=True, tags=["flagship", "vision"],
    ),
    ModelConfig(
        model_id="gpt-4o-mini", provider=Provider.OPENAI, model_name="gpt-4o-mini",
        input_cost_per_1k=0.00015, output_cost_per_1k=0.0006, max_tokens=128000,
        priority=6, supports_vision=True, tags=["cost-effective", "fast"],
    ),
    ModelConfig(
        model_id="claude-sonnet-4", provider=Provider.ANTHROPIC, model_name="claude-sonnet-4-20250514",
        input_cost_per_1k=0.003, output_cost_per_1k=0.015, max_tokens=200000,
        priority=8, supports_vision=True, tags=["flagship", "long-context"],
    ),
    ModelConfig(
        model_id="claude-haiku", provider=Provider.ANTHROPIC, model_name="claude-3-5-haiku-20241022",
        input_cost_per_1k=0.001, output_cost_per_1k=0.005, max_tokens=200000,
        priority=7, tags=["fast", "cost-effective"],
    ),
    ModelConfig(
        model_id="gemini-2.5-pro", provider=Provider.GOOGLE, model_name="gemini-2.5-pro-preview-05-06",
        input_cost_per_1k=0.00125, output_cost_per_1k=0.01, max_tokens=1000000,
        priority=8, supports_vision=True, tags=["flagship", "huge-context"],
    ),
    ModelConfig(
        model_id="glm-4-plus", provider=Provider.CUSTOM, model_name="glm-4-plus",
        api_base="https://open.bigmodel.cn/api/paas/v4",
        input_cost_per_1k=0.007, output_cost_per_1k=0.007, max_tokens=128000,
        priority=7, tags=["chinese", "local-friendly"],
    ),
    ModelConfig(
        model_id="local-llama", provider=Provider.LOCAL, model_name="llama3:70b",
        api_base="http://localhost:11434", input_cost_per_1k=0.0, output_cost_per_1k=0.0,
        max_tokens=8192, priority=3, tags=["local", "free", "offline"],
    ),
]

# ──────────────────────────────────────────────
# 速率限制器
# ──────────────────────────────────────────────

class RateLimiter:
    """滑动窗口速率限制"""

    def __init__(self, max_rpm: int = 60, max_tpm: int = 100000):
        self.max_rpm = max_rpm
        self.max_tpm = max_tpm
        self._request_times: List[float] = []
        self._token_buckets: List[Tuple[float, int]] = []  # (timestamp, tokens)
        self._lock = asyncio.Lock()

    async def acquire(self, tokens: int = 0) -> bool:
        """获取许可，返回是否允许"""
        async with self._lock:
            now = time.time()
            window = 60.0

            # 清理过期记录
            self._request_times = [t for t in self._request_times if now - t < window]
            self._token_buckets = [(t, tk) for t, tk in self._token_buckets if now - t < window]

            # RPM 检查
            if len(self._request_times) >= self.max_rpm:
                return False

            # TPM 检查
            current_tpm = sum(tk for _, tk in self._token_buckets)
            if current_tpm + tokens > self.max_tpm:
                return False

            self._request_times.append(now)
            if tokens > 0:
                self._token_buckets.append((now, tokens))
            return True

    @property
    def current_rpm(self) -> int:
        now = time.time()
        return len([t for t in self._request_times if now - t < 60])

    @property
    def current_tpm(self) -> int:
        now = time.time()
        return sum(tk for t, tk in self._token_buckets if now - t < 60)

# ──────────────────────────────────────────────
# 核心模块
# ──────────────────────────────────────────────

class ModelRouter:
    """多模型调度中心"""

    def __init__(self):
        self.models: Dict[str, ModelConfig] = {}
        self.providers_stats: Dict[str, ProviderStats] = {}
        self.request_history: List[RequestRecord] = []
        self.routing_strategy: RoutingStrategy = RoutingStrategy.PRIORITY
        self.rate_limiters: Dict[str, RateLimiter] = {}
        self.fallback_chain: List[str] = []  # model_id 回退链
        self._round_robin_idx: int = 0
        self._counter: int = 0
        self.budget_limit_usd: float = 0.0  # 0 = 无限制
        self.total_spent_usd: float = 0.0

        # 加载预置模型
        for mc in PRESET_MODELS:
            self.register_model(mc)

        logger.info("[ModelRouter] 多模型调度中心已初始化, 模型数: %d", len(self.models))

    # ── 模型管理 ──

    def register_model(self, config: ModelConfig):
        """注册模型"""
        self.models[config.model_id] = config
        self.rate_limiters[config.model_id] = RateLimiter(config.max_rpm, config.max_tpm)

        if config.provider.value not in self.providers_stats:
            self.providers_stats[config.provider.value] = ProviderStats(provider=config.provider)

        logger.info("[ModelRouter] 注册模型: %s (%s)", config.model_id, config.provider.value)

    def unregister_model(self, model_id: str) -> bool:
        """注销模型"""
        if model_id in self.models:
            del self.models[model_id]
            self.rate_limiters.pop(model_id, None)
            logger.info("[ModelRouter] 注销模型: %s", model_id)
            return True
        return False

    def enable_model(self, model_id: str, enabled: bool = True):
        if model_id in self.models:
            self.models[model_id].enabled = enabled

    def list_models(self, provider: Optional[Provider] = None,
                    tag: Optional[str] = None) -> List[ModelConfig]:
        """列出可用模型"""
        models = list(self.models.values())
        if provider:
            models = [m for m in models if m.provider == provider]
        if tag:
            models = [m for m in models if tag in m.tags]
        return [m for m in models if m.enabled]

    # ── 智能路由 ──

    def route(self, requirements: Optional[Dict[str, Any]] = None) -> Optional[ModelConfig]:
        """根据策略选择最优模型"""
        reqs = requirements or {}
        candidates = self._filter_candidates(reqs)

        if not candidates:
            return None

        strategy = self.routing_strategy

        if strategy == RoutingStrategy.PRIORITY:
            return self._route_priority(candidates)
        elif strategy == RoutingStrategy.LEAST_LATENCY:
            return self._route_latency(candidates)
        elif strategy == RoutingStrategy.COST_OPTIMIZED:
            return self._route_cost(candidates)
        elif strategy == RoutingStrategy.QUALITY_FIRST:
            return self._route_quality(candidates)
        elif strategy == RoutingStrategy.ROUND_ROBIN:
            return self._route_round_robin(candidates)

        return candidates[0]

    def _filter_candidates(self, reqs: Dict) -> List[ModelConfig]:
        """根据需求过滤候选模型"""
        candidates = [m for m in self.models.values() if m.enabled]

        if reqs.get("vision"):
            candidates = [m for m in candidates if m.supports_vision]
        if reqs.get("streaming") is False:
            candidates = [m for m in candidates if m.supports_streaming]
        if reqs.get("functions"):
            candidates = [m for m in candidates if m.supports_functions]
        if reqs.get("max_tokens"):
            candidates = [m for m in candidates if m.max_tokens >= reqs["max_tokens"]]
        if reqs.get("tag"):
            candidates = [m for m in candidates if reqs["tag"] in m.tags]
        if reqs.get("provider"):
            candidates = [m for m in candidates if m.provider.value == reqs["provider"]]

        return candidates

    def _route_priority(self, candidates: List[ModelConfig]) -> ModelConfig:
        return max(candidates, key=lambda m: m.priority)

    def _route_latency(self, candidates: List[ModelConfig]) -> ModelConfig:
        """选延迟最低的提供商"""
        best = candidates[0]
        best_latency = float("inf")
        for m in candidates:
            stats = self.providers_stats.get(m.provider.value)
            if stats and stats.avg_latency_ms < best_latency:
                best_latency = stats.avg_latency_ms
                best = m
        return best

    def _route_cost(self, candidates: List[ModelConfig]) -> ModelConfig:
        """选成本最低的"""
        return min(candidates, key=lambda m: m.input_cost_per_1k + m.output_cost_per_1k)

    def _route_quality(self, candidates: List[ModelConfig]) -> ModelConfig:
        """选最高优先级（质量最好）"""
        return max(candidates, key=lambda m: m.priority)

    def _route_round_robin(self, candidates: List[ModelConfig]) -> ModelConfig:
        idx = self._round_robin_idx % len(candidates)
        self._round_robin_idx += 1
        return candidates[idx]

    # ── 请求执行 ──

    async def execute(self, prompt: str, model_id: Optional[str] = None,
                      system_prompt: str = "", temperature: float = 0.7,
                      max_tokens: int = 2048, **kwargs) -> Dict[str, Any]:
        """执行 LLM 请求（含回退机制）"""
        

        self._counter += 1
        request_id = f"REQ-{self._counter:06d}"

        # 选择模型
        if model_id and model_id in self.models and self.models[model_id].enabled:
            model = self.models[model_id]
        else:
            model = self.route(kwargs.get("requirements"))

        if not model:
            return {
                "request_id": request_id,
                "success": False,
                "error": "无可用模型",
                "model": model_id or "auto",
            }

        # 速率检查
        limiter = self.rate_limiters.get(model.model_id)
        if limiter:
            allowed = await limiter.acquire(max_tokens)
            if not allowed:
                # 尝试回退
                fallback = self._get_fallback(model.model_id)
                if fallback:
                    logger.info("[ModelRouter] 速率限制, 回退: %s → %s", model.model_id, fallback.model_id)
                    model = fallback
                else:
                    return {
                        "request_id": request_id,
                        "success": False,
                        "error": f"模型 {model.model_id} 速率受限且无回退",
                        "model": model.model_id,
                    }

        # 预算检查
        estimated_cost = ((len(prompt) / 1000) * model.input_cost_per_1k +
                          (max_tokens / 1000) * model.output_cost_per_1k)
        if self.budget_limit_usd > 0 and self.total_spent_usd + estimated_cost > self.budget_limit_usd:
            return {
                "request_id": request_id,
                "success": False,
                "error": f"预算超限: ${self.total_spent_usd:.4f}/${self.budget_limit_usd:.4f}",
                "model": model.model_id,
            }

        # 模拟请求（实际使用时接入真实 API）
        start = time.time()
        try:
            # placeholder: 实际接入各提供商 SDK
            result_text = f"[ModelRouter placeholder] 使用 {model.model_id} 处理请求"
            latency = (time.time() - start) * 1000

            record = RequestRecord(
                request_id=request_id,
                model_id=model.model_id,
                provider=model.provider,
                prompt_tokens=len(prompt),
                completion_tokens=len(result_text),
                latency_ms=round(latency, 2),
                cost_usd=round(estimated_cost, 6),
                success=True,
            )
            self._update_stats(record)
            self.request_history.append(record)
            self.total_spent_usd += record.cost_usd

            return {
                "request_id": request_id,
                "success": True,
                "model": model.model_id,
                "provider": model.provider.value,
                "text": result_text,
                "latency_ms": record.latency_ms,
                "cost_usd": record.cost_usd,
                "prompt_tokens": record.prompt_tokens,
                "completion_tokens": record.completion_tokens,
            }

        except Exception as e:
            latency = (time.time() - start) * 1000
            record = RequestRecord(
                request_id=request_id,
                model_id=model.model_id,
                provider=model.provider,
                latency_ms=round(latency, 2),
                success=False,
                error=str(e),
            )
            self._update_stats(record)
            self.request_history.append(record)

            # 尝试回退
            fallback = self._get_fallback(model.model_id)
            if fallback:
                logger.info("[ModelRouter] 请求失败, 回退: %s → %s", model.model_id, fallback.model_id)
                return await self._execute_with_model(
                    request_id, fallback, prompt, system_prompt, temperature, max_tokens, kwargs
                )

            return {
                "request_id": request_id,
                "success": False,
                "error": str(e),
                "model": model.model_id,
            }

    async def _execute_with_model(self, request_id: str, model: ModelConfig,
                                   prompt: str, system: str, temp: float,
                                   max_tok: int, kwargs: Dict) -> Dict[str, Any]:
        """用指定模型重新执行"""
        start = time.time()
        try:
            result_text = f"[ModelRouter fallback] 使用 {model.model_id} 处理请求"
            latency = (time.time() - start) * 1000
            return {
                "request_id": request_id,
                "success": True,
                "model": model.model_id,
                "provider": model.provider.value,
                "text": result_text,
                "latency_ms": round(latency, 2),
                "fallback": True,
            }
        except Exception as e:
            return {"request_id": request_id, "success": False, "error": str(e), "model": model.model_id}

    def _get_fallback(self, model_id: str) -> Optional[ModelConfig]:
        """获取回退模型"""
        for fid in self.fallback_chain:
            if fid != model_id and fid in self.models and self.models[fid].enabled:
                return self.models[fid]
        # 默认回退：本地模型
        for m in self.models.values():
            if m.provider == Provider.LOCAL and m.enabled:
                return m
        return None

    def set_fallback_chain(self, chain: List[str]):
        """设置回退链"""
        self.fallback_chain = chain

    # ── 统计 ──

    def _update_stats(self, record: RequestRecord):
        stats = self.providers_stats.get(record.provider.value)
        if not stats:
            stats = ProviderStats(provider=record.provider)
            self.providers_stats[record.provider.value] = stats

        stats.total_requests += 1
        if record.success:
            stats.success_count += 1
        else:
            stats.fail_count += 1
        stats.total_tokens_in += record.prompt_tokens
        stats.total_tokens_out += record.completion_tokens
        stats.total_cost_usd += record.cost_usd
        stats.last_used = record.timestamp

        # 更新平均延迟
        successful = [r for r in self.request_history if r.success and r.provider == record.provider]
        if successful:
            stats.avg_latency_ms = sum(r.latency_ms for r in successful) / len(successful)

    def get_stats(self) -> Dict[str, Any]:
        """获取调度统计"""
        total = len(self.request_history)
        success = sum(1 for r in self.request_history if r.success)
        return {
            "total_requests": total,
            "success_count": success,
            "fail_count": total - success,
            "success_rate": (success / max(total, 1)) * 100,
            "total_tokens_in": sum(r.prompt_tokens for r in self.request_history),
            "total_tokens_out": sum(r.completion_tokens for r in self.request_history),
            "total_cost_usd": round(sum(r.cost_usd for r in self.request_history), 6),
            "budget_spent": round(self.total_spent_usd, 6),
            "budget_limit": self.budget_limit_usd,
            "routing_strategy": self.routing_strategy.value,
            "models_registered": len(self.models),
            "models_enabled": sum(1 for m in self.models.values() if m.enabled),
            "providers": {
                name: {
                    "requests": s.total_requests,
                    "success_rate": (s.success_count / max(s.total_requests, 1)) * 100,
                    "avg_latency_ms": round(s.avg_latency_ms, 2),
                    "cost_usd": round(s.total_cost_usd, 6),
                }
                for name, s in self.providers_stats.items()
            },
        }

    def get_model_info(self, model_id: str) -> Optional[Dict[str, Any]]:
        if model_id in self.models:
            m = self.models[model_id]
            return {
                "model_id": m.model_id,
                "provider": m.provider.value,
                "model_name": m.model_name,
                "enabled": m.enabled,
                "max_tokens": m.max_tokens,
                "cost_in": m.input_cost_per_1k,
                "cost_out": m.output_cost_per_1k,
                "priority": m.priority,
                "tags": m.tags,
                "supports_vision": m.supports_vision,
                "supports_streaming": m.supports_streaming,
                "supports_functions": m.supports_functions,
            }
        return None

    def set_budget(self, limit_usd: float):
        """设置预算上限"""
        self.budget_limit_usd = limit_usd
        logger.info("[ModelRouter] 预算上限: $%.2f", limit_usd)

    def set_strategy(self, strategy: RoutingStrategy):
        """设置路由策略"""
        self.routing_strategy = strategy
        logger.info("[ModelRouter] 路由策略: %s", strategy.value)


# ──────────────────────────────────────────────
# 模块接口
# ──────────────────────────────────────────────

_module: Optional[ModelRouter] = None

def get_module() -> ModelRouter:
    global _module
    if _module is None:
        _module = ModelRouter()
    return _module

    API_ENDPOINTS = {
    "model_router_list": "/api/v1/model-router/models",
    "model_router_execute": "/api/v1/model-router/execute",
    "model_router_stats": "/api/v1/model-router/stats",
    "model_router_budget": "/api/v1/model-router/budget",
    "model_router_strategy": "/api/v1/model-router/strategy",
    "model_router_fallback": "/api/v1/model-router/fallback",
}

module_class = ModelRouter

