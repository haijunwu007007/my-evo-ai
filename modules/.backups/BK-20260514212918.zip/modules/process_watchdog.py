"""
    Process Watchdog Monitor
    Enterprise-grade process monitoring with automatic restart, resource tracking, and anomaly detection.
"""

import time
import json
import logging
import os
import subprocess
import psutil
from typing import Dict, List, Any, Optional
from collections import defaultdict
from datetime import datetime

from modules._base.enterprise_module import EnterpriseModule

logger = logging.getLogger(__name__)


class ProcessAnomalyEngine:
    """Analyzes process behavior for anomalies: CPU spikes, memory leaks, zombie processes."""

    def __init__(self):
        self._history: Dict[int, List[Dict]] = defaultdict(list)
        self._max_history = 100

    def record(self, pid: int, cpu: float, memory_mb: float, status: str):
        self._history[pid].append({
            "ts": datetime.now().isoformat(),
            "cpu": cpu, "memory_mb": memory_mb, "status": status
        })
        if len(self._history[pid]) > self._max_history:
            self._history[pid] = self._history[pid][-self._max_history:]

    def analyze(self, pid: int) -> Dict[str, Any]:
        hist = self._history.get(pid, [])
        if len(hist) < 3:
            return {"anomaly": False, "reason": "insufficient_data"}
        cpus = [h["cpu"] for h in hist[-20:]]
        mems = [h["memory_mb"] for h in hist[-20:]]
        avg_cpu = sum(cpus) / len(cpus)
        avg_mem = sum(mems) / len(mems)
        anomalies = []
        if avg_cpu > 80:
            anomalies.append(f"high_cpu_avg={avg_cpu:.1f}%")
        if len(mems) >= 5 and mems[-1] > mems[0] * 1.5 and mems[-1] > 100:
            anomalies.append(f"memory_leak suspected: {mems[0]:.1f}MB -> {mems[-1]:.1f}MB")
        return {"anomaly": len(anomalies) > 0, "anomalies": anomalies, "avg_cpu": round(avg_cpu, 2), "avg_memory_mb": round(avg_mem, 2)}


class ProcessWatchdog(EnterpriseModule):
    """Enterprise process watchdog with monitoring, auto-restart, and anomaly detection."""

    module_class = "ProcessWatchdog"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._operation_count = 0
        self._error_count = 0
        self._watched_processes: Dict[str, Dict] = {}
        self._anomaly_engine = ProcessAnomalyEngine()
        self._check_interval = 30

    def execute(self, action: str = "status", params: Optional[Dict] = None) -> Dict[str, Any]:
        params = params or {}
        self.trace("process_watchdog.execute", "start", action=action)
        self.metrics_collector.counter("process_watchdog.execute.total", 1)
        self._operation_count += 1
        try:
            result = self._dispatch(action, params)
            self.trace("process_watchdog.execute", "end")
            return result
        except Exception as e:
            self._error_count += 1
            self.metrics_collector.counter("process_watchdog.execute.errors", 1)
            self.trace("process_watchdog.execute", "error", error=str(e))
            return {"success": False, "error": str(e)}

    def _dispatch(self, action: str, params: Dict) -> Dict[str, Any]:
        handler = {
            "status": self._action_status,
            "list": self._action_list,
            "watch": self._action_watch,
            "unwatch": self._action_unwatch,
            "check": self._action_check,
            "top": self._action_top,
            "kill": self._action_kill,
            "anomaly_report": self._action_anomaly_report,
            "stats": self._action_stats,
            "configure": self._action_configure,
            "help": self._action_help,
        }.get(action, self._action_default)
        return handler(params)

    def _action_status(self, params: Dict) -> Dict:
        return {
            "success": True,
            "data": {
                "module": "process_watchdog",
                "status": "running",
                "watched_count": len(self._watched_processes),
                "watched": list(self._watched_processes.keys()),
                "uptime": self._get_uptime(),
                "stats": self._get_stats()
            }
        }

    def _action_list(self, params: Dict) -> Dict:
        procs = []
        for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_info", "status"]):
            try:
                info = p.info
                mem = info["memory_info"]
                procs.append({
                    "pid": info["pid"],
                    "name": info["name"],
                    "cpu_percent": info["cpu_percent"] or 0,
                    "memory_mb": round((mem.rss / 1048576) if mem else 0, 2),
                    "status": info["status"]
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        procs.sort(key=lambda x: x["memory_mb"], reverse=True)
        limit = params.get("limit", 30)
        return {"success": True, "data": {"processes": procs[:limit], "total": len(procs)}}

    def _action_watch(self, params: Dict) -> Dict:
        name = params.get("name", "")
        restart_cmd = params.get("restart_cmd", "")
        max_restarts = params.get("max_restarts", 3)
        if not name:
            return {"success": False, "error": "name required"}
        self._watched_processes[name] = {
            "restart_cmd": restart_cmd,
            "max_restarts": max_restarts,
            "restart_count": 0,
            "added_at": datetime.now().isoformat()
        }
        return {"success": True, "data": {"message": f"Now watching: {name}", "watched": list(self._watched_processes.keys())}}

    def _action_unwatch(self, params: Dict) -> Dict:
        name = params.get("name", "")
        if name in self._watched_processes:
            del self._watched_processes[name]
            return {"success": True, "data": {"message": f"Stopped watching: {name}"}}
        return {"success": False, "error": f"{name} not watched"}

    def _action_check(self, params: Dict) -> Dict:
        results = []
        for name, cfg in self._watched_processes.items():
            found = False
            for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_info"]):
                try:
                    if name.lower() in p.info["name"].lower():
                        info = p.info
                        mem = info["memory_info"]
                        cpu = info["cpu_percent"] or 0
                        mem_mb = round((mem.rss / 1048576) if mem else 0, 2)
                        self._anomaly_engine.record(info["pid"], cpu, mem_mb, info.get("status", "?"))
                        anomaly = self._anomaly_engine.analyze(info["pid"])
                        results.append({"name": name, "pid": info["pid"], "alive": True, "cpu": cpu, "memory_mb": mem_mb, "anomaly": anomaly})
                        found = True
                        break
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            if not found:
                results.append({"name": name, "alive": False, "anomaly": None})
        return {"success": True, "data": {"checked": results, "count": len(results)}}

    def _action_top(self, params: Dict) -> Dict:
        sort_by = params.get("sort_by", "memory")
        limit = params.get("limit", 10)
        procs = []
        for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_info"]):
            try:
                info = p.info
                mem = info["memory_info"]
                procs.append({"pid": info["pid"], "name": info["name"], "cpu": info["cpu_percent"] or 0, "memory_mb": round((mem.rss / 1048576) if mem else 0, 2)})
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        procs.sort(key=lambda x: x.get(sort_by, 0), reverse=True)
        return {"success": True, "data": {"top_processes": procs[:limit], "sort_by": sort_by}}

    def _action_kill(self, params: Dict) -> Dict:
        pid = params.get("pid")
        if not pid:
            return {"success": False, "error": "pid required"}
        try:
            p = psutil.Process(int(pid))
            name = p.name()
            p.terminate()
            return {"success": True, "data": {"message": f"Terminated {name} (PID {pid})"}}
        except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
            return {"success": False, "error": str(e)}

    def _action_anomaly_report(self, params: Dict) -> Dict:
        report = []
        for pid, hist in self._anomaly_engine._history.items():
            analysis = self._anomaly_engine.analyze(pid)
            if analysis.get("anomaly"):
                report.append({"pid": pid, **analysis})
        return {"success": True, "data": {"anomalies": report, "total_anomalous": len(report)}}

    def _action_stats(self, params: Dict) -> Dict:
        return {"success": True, "data": self._get_stats()}

    def _action_configure(self, params: Dict) -> Dict:
        if "check_interval" in params:
            self._check_interval = int(params["check_interval"])
        return {"success": True, "data": {"config": {"check_interval": self._check_interval}}}

    def _action_help(self, params: Dict) -> Dict:
        return {"success": True, "data": {"actions": ["status", "list", "watch", "unwatch", "check", "top", "kill", "anomaly_report", "stats", "configure", "help"]}}

    def _action_default(self, params: Dict) -> Dict:
        return {"success": True, "data": {"action": "unknown", "available_actions": ["status", "list", "watch", "check", "top", "kill", "anomaly_report", "stats"]}}

    def _get_stats(self) -> Dict:
        return {
            "operation_count": self._operation_count,
            "error_count": self._error_count,
            "watched_processes": len(self._watched_processes),
            "check_interval": self._check_interval
        }

    def _get_uptime(self) -> float:
        if hasattr(self, "_start_time"):
            return round(time.time() - self._start_time, 2)
        return 0.0
