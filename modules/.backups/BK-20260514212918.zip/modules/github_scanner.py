"""
GitHub Scanner - 企业级GitHub仓库扫描与分析模块
生产级功能：仓库搜索/趋势分析/依赖扫描/安全审计/Star增长追踪/活跃度评分/报告生成
"""

import time
import hashlib
import threading
import re as _re
import urllib.request
import urllib.error
import ssl
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple
from enum import Enum
from collections import defaultdict

from modules._base.enterprise_module import EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin

module_class = "GithubScanner"


class ScanType(Enum):
    FULL = "full"
    DEPENDENCY = "dependency"
    SECURITY = "security"
    LICENSE = "license"
    ACTIVITY = "activity"


class RiskLevel(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


# ─── 仓库数据模型 ──────────────────────────────────────────────

class RepoSnapshot:
    """仓库快照"""

    def __init__(self, repo_data: Dict):
        self.repo_id = repo_data.get("id", "")
        self.name = repo_data.get("full_name", "")
        self.owner = repo_data.get("owner", {}).get("login", "") if isinstance(repo_data.get("owner"), dict) else ""
        self.description = repo_data.get("description", "")
        self.stars = repo_data.get("stargazers_count", 0)
        self.forks = repo_data.get("forks_count", 0)
        self.watchers = repo_data.get("watchers_count", 0)
        self.language = repo_data.get("language", "")
        self.topics = repo_data.get("topics", [])
        self.created_at = repo_data.get("created_at", "")
        self.updated_at = repo_data.get("updated_at", "")
        self.pushed_at = repo_data.get("pushed_at", "")
        self.open_issues = repo_data.get("open_issues_count", 0)
        self.default_branch = repo_data.get("default_branch", "main")
        self.license = repo_data.get("license", {}).get("spdx_id", "") if isinstance(repo_data.get("license"), dict) else ""
        self.size_kb = repo_data.get("size", 0)
        self.homepage = repo_data.get("homepage", "")
        self.archived = repo_data.get("archived", False)
        self.scanned_at = datetime.utcnow().isoformat()

    def to_dict(self) -> Dict:
        return self.__dict__


# ─── 活跃度评分引擎 ────────────────────────────────────────────

class ActivityScoringEngine:
    """仓库活跃度多维评分"""

    def __init__(self):
        self._weight_config = {
            "star_growth": 0.25,
            "commit_frequency": 0.30,
            "issue_activity": 0.15,
            "contributor_count": 0.15,
            "release_frequency": 0.15,
        }

    def score(self, repo: RepoSnapshot, extra: Dict = None) -> Dict:
        extra = extra or {}
        scores = {}

        # Star增长评分 (0-100)
        stars = repo.stars
        if stars >= 100000:
            scores["star_growth"] = 100
        elif stars >= 10000:
            scores["star_growth"] = 80 + min(20, (stars - 10000) / 5000)
        elif stars >= 1000:
            scores["star_growth"] = 50 + min(30, (stars - 1000) / 500)
        elif stars >= 100:
            scores["star_growth"] = 20 + min(30, (stars - 100) / 50)
        else:
            scores["star_growth"] = min(20, stars / 5)

        # 提交频率 (0-100)
        commit_freq = extra.get("weekly_commits", 0)
        if commit_freq >= 50:
            scores["commit_frequency"] = 100
        elif commit_freq >= 20:
            scores["commit_frequency"] = 70 + min(30, (commit_freq - 20) / 4)
        elif commit_freq >= 5:
            scores["commit_frequency"] = 30 + min(40, (commit_freq - 5) / 1)
        else:
            scores["commit_frequency"] = min(30, commit_freq * 6)

        # Issue活跃度 (0-100)
        issues = repo.open_issues
        if 10 <= issues <= 500:
            scores["issue_activity"] = 70 + min(30, (500 - abs(issues - 50)) / 20)
        elif issues > 0:
            scores["issue_activity"] = 40 + min(30, issues / 10)
        else:
            scores["issue_activity"] = 10

        # 贡献者 (0-100)
        contributors = extra.get("contributors", 1)
        if contributors >= 100:
            scores["contributor_count"] = 100
        elif contributors >= 20:
            scores["contributor_count"] = 60 + min(40, (contributors - 20) / 2)
        else:
            scores["contributor_count"] = min(60, contributors * 3)

        # Release频率 (0-100)
        releases = extra.get("releases_last_year", 0)
        if releases >= 24:
            scores["release_frequency"] = 100
        elif releases >= 6:
            scores["release_frequency"] = 50 + min(50, (releases - 6) * 3)
        elif releases >= 1:
            scores["release_frequency"] = 20 + min(30, releases * 10)
        else:
            scores["release_frequency"] = 5

        # 加权总分
        total = sum(scores[k] * self._weight_config[k] for k in scores)
        return {
            "total_score": round(total, 1),
            "breakdown": scores,
            "weights": self._weight_config,
            "grade": self._grade(total),
        }

    def _grade(self, score: float) -> str:
        if score >= 90:
            return "A+"
        elif score >= 80:
            return "A"
        elif score >= 70:
            return "B+"
        elif score >= 60:
            return "B"
        elif score >= 50:
            return "C"
        elif score >= 30:
            return "D"
        return "F"


# ─── 安全审计引擎 ──────────────────────────────────────────────

class SecurityAuditEngine:
    """依赖安全与许可证审计"""

    KNOWN_VULN_PATTERNS = [
        {"pattern": "log4j", "severity": RiskLevel.CRITICAL.value, "cve": "CVE-2021-44228"},
        {"pattern": "spring-core.*4\\.3", "severity": RiskLevel.CRITICAL.value, "cve": "CVE-2022-22965"},
        {"pattern": "lodash<4\\.17\\.21", "severity": RiskLevel.HIGH.value, "cve": "CVE-2021-23337"},
        {"pattern": "node-fetch<2\\.6\\.7", "severity": RiskLevel.HIGH.value, "cve": "CVE-2022-0235"},
    ]

    RISKY_LICENSES = {"GPL-2.0", "GPL-3.0", "AGPL-3.0", "SSPL-1.0", "Commons-Clause"}

    def __init__(self):
        self._scan_results: Dict[str, List[Dict]] = {}

    def audit_dependencies(self, repo_name: str, dependencies: List[Dict]) -> Dict:
        """依赖安全扫描"""
        findings = []
        for dep in dependencies:
            name = dep.get("name", "")
            version = dep.get("version", "")
            for vuln in self.KNOWN_VULN_PATTERNS:
                if name.lower().startswith(vuln["pattern"].split("<")[0].split(".*")[0].lower()):
                    findings.append({
                        "dependency": name, "version": version,
                        "severity": vuln["severity"], "cve": vuln.get("cve", ""),
                        "recommendation": f"Upgrade {name} to latest version",
                    })
        self._scan_results[repo_name] = findings
        return {
            "repo": repo_name, "total_deps": len(dependencies),
            "findings": findings, "risk_level": self._assess_risk(findings),
        }

    def audit_license(self, repo_name: str, license_id: str) -> Dict:
        """许可证合规审计"""
        is_risky = license_id in self.RISKY_LICENSES
        return {
            "repo": repo_name, "license": license_id,
            "is_risky": is_risky,
            "risk_level": RiskLevel.HIGH.value if is_risky else RiskLevel.LOW.value,
            "note": "Copyleft license may require disclosure" if is_risky else "License is permissive",
        }

    def _assess_risk(self, findings: List[Dict]) -> str:
        if not findings:
            return RiskLevel.LOW.value
        severities = [f["severity"] for f in findings]
        if RiskLevel.CRITICAL.value in severities:
            return RiskLevel.CRITICAL.value
        if RiskLevel.HIGH.value in severities:
            return RiskLevel.HIGH.value
        return RiskLevel.MEDIUM.value


# ─── 趋势分析引擎 ──────────────────────────────────────────────

class TrendAnalysisEngine:
    """Star/Fork/Issue趋势分析"""

    def __init__(self):
        self._snapshots: Dict[str, List[Dict]] = defaultdict(list)

    def record_snapshot(self, repo_name: str, stars: int, forks: int, issues: int):
        snap = {
            "stars": stars, "forks": forks, "issues": issues,
            "timestamp": datetime.utcnow().isoformat(),
        }
        self._snapshots[repo_name].append(snap)
        if len(self._snapshots[repo_name]) > 1000:
            self._snapshots[repo_name] = self._snapshots[repo_name][-500:]

    def analyze(self, repo_name: str, days: int = 30) -> Dict:
        snaps = self._snapshots.get(repo_name, [])
        if len(snaps) < 2:
            return {"repo": repo_name, "trend": "insufficient_data", "snapshots": len(snaps)}

        first = snaps[0]
        last = snaps[-1]
        star_growth = last["stars"] - first["stars"]
        fork_growth = last["forks"] - first["forks"]
        issue_change = last["issues"] - first["issues"]

        # 趋势判断
        if star_growth > 100:
            trend = "rapidly_growing"
        elif star_growth > 10:
            trend = "growing"
        elif star_growth > 0:
            trend = "slowly_growing"
        elif star_growth == 0:
            trend = "stable"
        else:
            trend = "declining"

        return {
            "repo": repo_name, "trend": trend,
            "star_growth": star_growth, "fork_growth": fork_growth,
            "issue_change": issue_change,
            "first_snapshot": first, "last_snapshot": last,
            "total_snapshots": len(snaps),
        }


# ─── 主模块 ──────────────────────────────────────────────────

class GithubScanner(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    AUTO-EVO-AI v6.39 — GitHub Scanner (Production Grade)
    企业级GitHub仓库扫描：搜索/活跃度评分/安全审计/趋势分析/报告
    """

    MODULE_ID = "github_scanner"
    MODULE_NAME = "GithubScanner"
    VERSION = "2.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._repos: Dict[str, RepoSnapshot] = {}
        self._scoring = ActivityScoringEngine()
        self._security = SecurityAuditEngine()
        self._trends = TrendAnalysisEngine()
        self._scan_history: List[Dict] = []
        self._lock = threading.Lock()

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        return self._dispatch(action, params)

    def _dispatch(self, action: str, params: Dict) -> Dict[str, Any]:
        actions = {
            "status": self._action_status,
            "stats": self._action_stats,
            "health": self._action_health,
            "configure": self._action_configure,
            "reset": self._action_reset,
            # 仓库管理
            "add_repo": self._action_add_repo,
            "list_repos": self._action_list_repos,
            "get_repo": self._action_get_repo,
            "remove_repo": self._action_remove_repo,
            # 扫描
            "scan_repo": self._action_scan_repo,
            "batch_scan": self._action_batch_scan,
            "scan_history": self._action_scan_history,
            # 评分
            "score_repo": self._action_score_repo,
            "rank_repos": self._action_rank_repos,
            # 安全
            "audit_security": self._action_audit_security,
            "audit_license": self._action_audit_license,
            # 趋势
            "record_snapshot": self._action_record_snapshot,
            "analyze_trend": self._action_analyze_trend,
            "fetch_trending": self._action_fetch_trending,
            # 搜索
            "search": self._action_search,
            "filter_by_language": self._action_filter_by_language,
            "filter_by_topic": self._action_filter_by_topic,
        }
        handler = actions.get(action)
        if not handler:
            return {"success": False, "error": f"Unknown action: {action}", "available": list(actions.keys())}
        try:
            return handler(params)
        except Exception as e:
            self.logger.error(f"GithubScanner.{action} error: {e}")
            return {"success": False, "error": str(e), "action": action}

    def _action_status(self, params: Dict) -> Dict:
        return {"success": True, "data": {
            "module": "GithubScanner", "version": self.VERSION, "state": "active",
            "repos_tracked": len(self._repos),
            "scans_completed": len(self._scan_history),
        }}

    def _action_stats(self, params: Dict) -> Dict:
        total_stars = sum(r.stars for r in self._repos.values())
        languages = defaultdict(int)
        for r in self._repos.values():
            if r.language:
                languages[r.language] += 1
        return {"success": True, "data": {
            "repos": len(self._repos), "total_stars": total_stars,
            "languages": dict(languages), "scans": len(self._scan_history),
        }}

    def _action_health(self, params: Dict) -> Dict:
        return {"success": True, "data": {"healthy": True, "scanner_ok": True}}

    def _action_configure(self, params: Dict) -> Dict:
        return {"success": True, "data": {"configured": True}}

    def _action_reset(self, params: Dict) -> Dict:
        self._repos = {}
        self._scan_history = []
        self._security = SecurityAuditEngine()
        self._trends = TrendAnalysisEngine()
        return {"success": True, "data": {"reset": True}}

    # 仓库
    def _action_add_repo(self, params: Dict) -> Dict:
        name = params.get("name") or params.get("full_name", "")
        if not name:
            return {"success": False, "error": "name or full_name required"}
        if name in self._repos:
            return {"success": False, "error": f"Repo already tracked: {name}"}
        if "full_name" not in params:
            params["full_name"] = name
        repo = RepoSnapshot(params)
        self._repos[name] = repo
        self.audit("add_repo", f"name={name}")
        return {"success": True, "data": repo.to_dict()}

    def _action_list_repos(self, params: Dict) -> Dict:
        repos = [r.to_dict() for r in self._repos.values()]
        return {"success": True, "data": {"repos": repos, "total": len(repos)}}

    def _action_get_repo(self, params: Dict) -> Dict:
        name = params.get("name", "")
        repo = self._repos.get(name)
        if not repo:
            return {"success": False, "error": f"Repo not found: {name}"}
        return {"success": True, "data": repo.to_dict()}

    def _action_remove_repo(self, params: Dict) -> Dict:
        name = params.get("name", "")
        existed = name in self._repos
        self._repos.pop(name, None)
        return {"success": True, "data": {"removed": existed, "name": name}}

    # 扫描
    def _action_scan_repo(self, params: Dict) -> Dict:
        name = params.get("name", "")
        repo = self._repos.get(name)
        if not repo:
            return {"success": False, "error": f"Repo not found: {name}"}
        scan_type = params.get("scan_type", ScanType.FULL.value)
        extra = params.get("extra", {})
        # 活跃度评分
        score_result = self._scoring.score(repo, extra)
        # 趋势记录
        self._trends.record_snapshot(name, repo.stars, repo.forks, repo.open_issues)
        # 安全扫描
        deps = params.get("dependencies", [])
        sec_result = None
        if scan_type in (ScanType.FULL.value, ScanType.SECURITY.value) and deps:
            sec_result = self._security.audit_dependencies(name, deps)

        record = {
            "repo": name, "scan_type": scan_type,
            "score": score_result, "security": sec_result,
            "scanned_at": datetime.utcnow().isoformat(),
        }
        self._scan_history.append(record)
        if len(self._scan_history) > 1000:
            self._scan_history = self._scan_history[-500:]
        return {"success": True, "data": record}

    def _action_batch_scan(self, params: Dict) -> Dict:
        results = []
        for name, repo in self._repos.items():
            score = self._scoring.score(repo)
            self._trends.record_snapshot(name, repo.stars, repo.forks, repo.open_issues)
            results.append({"repo": name, "score": score})
            self._scan_history.append({
                "repo": name, "scan_type": "batch",
                "score": score, "scanned_at": datetime.utcnow().isoformat(),
            })
        return {"success": True, "data": {"scanned": len(results), "results": results}}

    def _action_scan_history(self, params: Dict) -> Dict:
        limit = int(params.get("limit", 50))
        return {"success": True, "data": {"history": self._scan_history[-limit:],
                                           "total": len(self._scan_history)}}

    # 评分
    def _action_score_repo(self, params: Dict) -> Dict:
        name = params.get("name", "")
        repo = self._repos.get(name)
        if not repo:
            return {"success": False, "error": f"Repo not found: {name}"}
        extra = params.get("extra", {})
        score = self._scoring.score(repo, extra)
        return {"success": True, "data": {"repo": name, **score}}

    def _action_rank_repos(self, params: Dict) -> Dict:
        scores = []
        for name, repo in self._repos.items():
            score = self._scoring.score(repo)
            scores.append({"repo": name, **score})
        scores.sort(key=lambda x: x["total_score"], reverse=True)
        return {"success": True, "data": {"rankings": scores, "total": len(scores)}}

    # 安全
    def _action_audit_security(self, params: Dict) -> Dict:
        name = params.get("name", "")
        deps = params.get("dependencies", [])
        return {"success": True, "data": self._security.audit_dependencies(name, deps)}

    def _action_audit_license(self, params: Dict) -> Dict:
        name = params.get("name", "")
        license_id = params.get("license", "")
        return {"success": True, "data": self._security.audit_license(name, license_id)}

    # 趋势
    def _action_record_snapshot(self, params: Dict) -> Dict:
        name = params.get("name", "")
        stars = int(params.get("stars", 0))
        forks = int(params.get("forks", 0))
        issues = int(params.get("issues", 0))
        self._trends.record_snapshot(name, stars, forks, issues)
        return {"success": True, "data": {"recorded": True}}

    def _action_analyze_trend(self, params: Dict) -> Dict:
        name = params.get("name", "")
        days = int(params.get("days", 30))
        return {"success": True, "data": self._trends.analyze(name, days)}

    # Trending (真实HTTP拉取)
    def _action_fetch_trending(self, params: Dict) -> Dict:
        """从GitHub Trending页面实时拉取热门项目"""
        language = params.get("language", "")
        since = params.get("since", "daily")  # daily/weekly/monthly
        spoken_lang = params.get("spoken_language", "")

        # 支持中文关键词映射
        topic_filter = params.get("topic", "")
        keyword_filter = params.get("keyword", "")
        if params.get("query"):
            keyword_filter = params.get("query", "")

        try:
            repos = self._fetch_github_trending(language, since, spoken_lang)
        except Exception as e:
            self.logger.error(f"fetch_trending HTTP error: {e}")
            return {"success": False, "error": f"Failed to fetch trending: {str(e)}"}

        # 关键词过滤
        if keyword_filter:
            kw = keyword_filter.lower()
            repos = [r for r in repos if kw in r.get("name", "").lower()
                     or kw in r.get("description", "").lower()
                     or kw in r.get("language", "").lower()
                     or any(kw in t.lower() for t in r.get("topics", []))]

        if topic_filter:
            tf = topic_filter.lower()
            repos = [r for r in repos if tf in r.get("name", "").lower()
                     or tf in r.get("description", "").lower()
                     or any(tf in t.lower() for t in r.get("topics", []))]

        # 注入到内部追踪
        added_count = 0
        with self._lock:
            for repo_data in repos:
                full_name = repo_data.get("full_name", repo_data.get("name", ""))
                if full_name and full_name not in self._repos:
                    self._repos[full_name] = RepoSnapshot(repo_data)
                    self._trends.record_snapshot(full_name,
                                                  repo_data.get("stars", 0),
                                                  repo_data.get("forks", 0),
                                                  repo_data.get("issues", 0))
                    added_count += 1

        self.audit("fetch_trending", f"lang={language} since={since} fetched={len(repos)} added={added_count}")

        return {
            "success": True,
            "data": {
                "total_fetched": len(repos),
                "newly_added": added_count,
                "repos_tracked": len(self._repos),
                "filter": {"language": language, "since": since, "keyword": keyword_filter, "topic": topic_filter},
                "repos": repos[:50],  # 最多返回50个
            }
        }

    def _fetch_github_trending(self, language: str = "", since: str = "daily",
                                spoken_language: str = "") -> List[Dict]:
        """真实HTTP请求 GitHub Trending 页面并解析"""
        url = "https://github.com/trending"
        if language:
            url += f"/{language}"
        query_params = []
        if since:
            query_params.append(f"since={since}")
        if spoken_language:
            query_params.append(f"spoken_language_code={spoken_language}")
        if query_params:
            url += "?" + "&".join(query_params)

        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                          "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
        })

        with urllib.request.urlopen(req, timeout=30, context=ctx) as resp:
            html = resp.read().decode("utf-8", errors="replace")

        return self._parse_trending_html(html)

    def _parse_trending_html(self, html: str) -> List[Dict]:
        """解析GitHub Trending HTML，提取仓库信息（适配2026年GitHub页面结构）"""
        repos = []

        # 匹配每个仓库的article块
        articles = _re.findall(r'<article class="Box-row">(.*?)</article>', html, _re.DOTALL)

        for article in articles:
            repo = {}

            # ─── 仓库名：h2里的链接 /owner/repo ───────────────────
            # GitHub 2026结构: <h2><a href="/tinyhumansai/openhuman" ...>
            # 链接后面紧跟 stargazers/forks 等子链接，主链接是不含后缀的 /owner/repo
            h2_match = _re.search(r'<h2[^>]*>(.*?)</h2>', article, _re.DOTALL)
            if h2_match:
                h2_content = h2_match.group(1)
                # 找h2里的所有链接
                h2_links = _re.findall(r'href="(/[^"]+/[^"]+)"', h2_content)
                for link in h2_links:
                    # 主链接格式: /owner/repo（不含/stargazers、/forks等）
                    if not any(link.endswith(suffix) for suffix in ("/stargazers", "/forks", "/sponsors")):
                        parts = link.strip("/").split("/")
                        if len(parts) == 2:
                            repo["full_name"] = link.strip("/")
                            repo["owner"] = parts[0]
                            repo["name"] = parts[1]
                            repo["url"] = f"https://github.com{link}"
                            break

            if "full_name" not in repo:
                continue  # 无法提取仓库名，跳过

            # ─── 描述：在h2后面，不是<p>标签 ─────────────────────
            # GitHub 2026: 描述直接在h2后面，可能是文本节点或span内
            # 匹配h2之后到语言/统计信息之前的文本内容
            after_h2 = article[h2_match.end():] if h2_match else article
            # 尝试多种模式提取描述
            desc = ""
            # 模式1: <p class="col-9 ...">
            desc_match = _re.search(r'<p[^>]*class="[^"]*col-9[^"]*"[^>]*>\s*(.*?)\s*</p>', after_h2, _re.DOTALL)
            if desc_match:
                desc = _re.sub(r'<[^>]+>', '', desc_match.group(1)).strip()
            if not desc:
                # 模式2: 任意<p>标签
                desc_match = _re.search(r'<p[^>]*>\s*(.*?)\s*</p>', after_h2, _re.DOTALL)
                if desc_match:
                    desc = _re.sub(r'<[^>]+>', '', desc_match.group(1)).strip()
            if not desc:
                # 模式3: 文本节点紧跟在仓库名后（GitHub 2026格式）
                # 描述直接作为文本出现在仓库名后面
                text_after = _re.sub(r'<[^>]+>', '\n', after_h2[:500])
                lines = [l.strip() for l in text_after.split('\n') if l.strip()]
                # 找到第一个看起来像描述的行（非空，不含特殊字符，长度>5）
                for line in lines:
                    if len(line) > 5 and not line.startswith('/') and not line.startswith('Star') and not line.startswith('Fork') and not line.isdigit():
                        desc = line
                        break
            repo["description"] = desc

            # ─── 编程语言 ─────────────────────────────────────────
            lang_match = _re.search(r'itemprop="programmingLanguage">\s*(.*?)\s*</span>', article)
            if lang_match:
                repo["language"] = lang_match.group(1).strip()
            if "language" not in repo:
                # 备用模式: 链接 href="/trending/python" 等
                lang_match2 = _re.search(r'href="/trending/(\w+)"[^>]*>\s*<span[^>]*>\s*(\w+)\s*</span>', article)
                if lang_match2:
                    repo["language"] = lang_match2.group(2)

            # ─── Stars总数 ────────────────────────────────────────
            # /stargazers链接附近的数字
            stars = 0
            stars_area = ""
            sg_match = _re.search(r'href="[^"]*stargazers"[^>]*>(.*?)</a>', article, _re.DOTALL)
            if sg_match:
                stars_area = sg_match.group(1)
                num_match = _re.search(r'([\d,]+)\s*$', stars_area.strip())
                if num_match:
                    stars = int(num_match.group(1).replace(",", "").replace(".", ""))
            if stars == 0:
                # 备用: 查找"Built by"前面的数字区域
                built_by_pos = article.find("Built by")
                if built_by_pos > 0:
                    before_built = article[:built_by_pos]
                    nums = _re.findall(r'([\d,]+)\s*$', before_built.strip().split('\n')[-1] if '\n' in before_built else before_built.strip())
                    if nums:
                        stars = int(nums[-1].replace(",", ""))
            repo["stars"] = stars

            # ─── 今日Stars / 本周 / 本月 ────────────────────────────
            period_match = _re.search(r'([\d,]+)\s*stars\s*(today|this week|this month)', article)
            if period_match:
                repo["stars_period"] = int(period_match.group(1).replace(",", ""))
                repo["period"] = period_match.group(2)

            # ─── Forks ────────────────────────────────────────────
            forks = 0
            fork_match = _re.search(r'href="[^"]*forks"[^>]*>(.*?)</a>', article, _re.DOTALL)
            if fork_match:
                fork_area = fork_match.group(1)
                fork_num = _re.search(r'([\d,]+)\s*$', fork_area.strip())
                if fork_num:
                    forks = int(fork_num.group(1).replace(",", ""))
            repo["forks"] = forks

            # ─── Today/Week/Month Stars (另一个位置) ──────────────
            if "stars_period" not in repo:
                # 在forks之后、Built by之前找数字
                today_match = _re.findall(r'([\d,]+)\s*stars\s*(today|this week|this month)', article)
                if today_match:
                    repo["stars_period"] = int(today_match[0][0].replace(",", ""))
                    repo["period"] = today_match[0][1]

            # ─── Built by 贡献者 ──────────────────────────────────
            built_by = _re.findall(r'alt="@([^"]+)"', article)
            if built_by:
                repo["built_by"] = built_by[:5]

            # ─── Topics标签 ──────────────────────────────────────
            topics = _re.findall(r'<a class="topic-tag[^"]*"[^>]*>([^<]+)</a>', article)
            repo["topics"] = [t.strip() for t in topics]

            repo["scanned_at"] = datetime.utcnow().isoformat()
            repos.append(repo)

        return repos

    # 搜索
    def _action_search(self, params: Dict) -> Dict:
        query = params.get("query", "").lower()
        language = params.get("language")
        min_stars = int(params.get("min_stars", 0))
        results = []
        for name, repo in self._repos.items():
            if query and query not in name.lower() and query not in repo.description.lower():
                continue
            if language and repo.language != language:
                continue
            if repo.stars < min_stars:
                continue
            results.append(repo.to_dict())
        return {"success": True, "data": {"query": query, "results": results, "total": len(results)}}

    def _action_filter_by_language(self, params: Dict) -> Dict:
        language = params.get("language", "")
        repos = [r.to_dict() for r in self._repos.values() if r.language == language]
        return {"success": True, "data": {"language": language, "repos": repos, "total": len(repos)}}

    def _action_filter_by_topic(self, params: Dict) -> Dict:
        topic = params.get("topic", "").lower()
        repos = [r.to_dict() for r in self._repos.values() if topic in [t.lower() for t in r.topics]]
        return {"success": True, "data": {"topic": topic, "repos": repos, "total": len(repos)}}

    def get_status(self) -> Dict[str, Any]:
        return {"module": "GithubScanner", "state": "active", "repos": len(self._repos)}

module_class = GithubScanner
