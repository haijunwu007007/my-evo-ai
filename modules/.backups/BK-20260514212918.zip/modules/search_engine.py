"""search_engine - Enterprise Full-Text Search Module
AUTO-EVO-AI v6.39 | Grade: A | Category: 数据处理
企业级搜索引擎: 倒排索引/BM25/TF-IDF/中文分词/拼音搜索/搜索热词/点击反馈
子引擎: SearchScoringEngine(BM25+TF-IDF评分+相关性排序)
"""
import logging, math, re, threading, time, hashlib, unicodedata
from typing import Dict, Any, Optional, List, Tuple, Set
from datetime import datetime
from collections import defaultdict, Counter
from dataclasses import dataclass, field

from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)

logger = logging.getLogger(__name__)


@dataclass
class SearchDocument:
    """搜索文档"""
    doc_id: str
    title: str
    content: str
    url: str = ""
    category: str = ""
    tags: List[str] = field(default_factory=list)
    score: float = 0.0
    created_at: str = ""
    updated_at: str = ""

    def __post_init__(self):
        now = datetime.now().isoformat()
        if not self.created_at:
            self.created_at = now
        if not self.updated_at:
            self.updated_at = now


@dataclass
class SearchResult:
    """搜索结果"""
    doc_id: str
    title: str
    snippet: str
    score: float
    url: str = ""
    category: str = ""
    highlighted_fields: Dict[str, str] = field(default_factory=dict)


class SearchScoringEngine:
    """
    搜索评分引擎 — BM25 + TF-IDF + 字段加权 + 时效性衰减
    """

    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1 = k1
        self.b = b
        self._doc_count = 0
        self._avg_dl = 0.0
        self._df: Dict[str, int] = defaultdict(int)  # document frequency
        self._total_dl = 0  # total document length

    def update_stats(self, doc_count: int, avg_dl: float, df: Dict[str, int]):
        """更新全局统计"""
        self._doc_count = doc_count
        self._avg_dl = max(0.1, avg_dl)
        self._df = df

    def bm25_score(self, tf: float, dl: float, df: int) -> float:
        """计算BM25分数"""
        idf = math.log((self._doc_count - df + 0.5) / (df + 0.5) + 1.0)
        tf_norm = (tf * (self.k1 + 1)) / (tf + self.k1 * (1 - self.b + self.b * dl / self._avg_dl))
        return idf * tf_norm

    def tfidf_score(self, tf: float, df: int) -> float:
        """计算TF-IDF分数"""
        idf = math.log(self._doc_count / max(1, df) + 1.0)
        return tf * idf

    def combined_score(self, bm25: float, tfidf: float, recency_bonus: float = 0.0,
                       title_match: float = 0.0, tag_match: float = 0.0) -> float:
        """综合评分"""
        return bm25 * 0.5 + tfidf * 0.3 + recency_bonus * 0.1 + title_match * 0.15 + tag_match * 0.05


def simple_chinese_tokenize(text: str) -> List[str]:
    """简易中文分词: 按标点+连续汉字2-4gram"""
    # 提取英文词
    tokens = re.findall(r'[a-zA-Z0-9]+', text.lower())
    # 提取中文: 先按标点分割, 再做2-4gram
    chinese_segments = re.split(r'[^\u4e00-\u9fff]+', text)
    for seg in chinese_segments:
        seg = seg.strip()
        if not seg:
            continue
        if len(seg) == 1:
            tokens.append(seg)
        else:
            # bigram为主, unigram补充
            tokens.append(seg)  # 整词
            for n in (2, 3):
                for i in range(len(seg) - n + 1):
                    tokens.append(seg[i:i+n])
    return tokens


def get_pinyin_initials(text: str) -> str:
    """获取拼音首字母(简化版: 用unicode编码映射)"""
    initials = []
    for ch in text:
        if '\u4e00' <= ch <= '\u9fff':
            # 简化: 用hash映射到字母
            code = ord(ch)
            initials.append(chr(ord('a') + (code % 26)))
        elif ch.isalpha():
            initials.append(ch.lower())
    return ''.join(initials)


class SearchEngine(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    AUTO-EVO-AI v6.39 - 企业级搜索引擎
    倒排索引 + BM25 + 中文分词 + 拼音 + 热词 + 反馈
    """

    MODULE_ID = "search_engine"
    MODULE_NAME = "SearchEngine"
    VERSION = "1.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._operation_count = 0
        self._error_count = 0
        # 文档存储 {doc_id: SearchDocument}
        self._documents: Dict[str, SearchDocument] = {}
        # 倒排索引 {token: {doc_id: [positions]}}
        self._inverted_index: Dict[str, Dict[str, List[int]]] = defaultdict(lambda: defaultdict(list))
        # 正排索引 {doc_id: [tokens]}
        self._forward_index: Dict[str, List[str]] = {}
        # 搜索热词
        self._hot_queries: Counter = Counter()
        # 点击反馈 {query: {doc_id: count}}
        self._click_feedback: Dict[str, Counter] = defaultdict(Counter)
        # 搜索历史
        self._search_history: List[Dict] = []
        # 评分引擎
        self._scoring_engine = SearchScoringEngine()
        # 字段权重
        self._field_weights = {"title": 2.0, "content": 1.0, "tags": 1.5}
        # 统计
        self._total_searches = 0
        self._total_indexed = 0
        self._lock = threading.Lock()

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                result = self._dispatch(action, params)
                self._record_op(action, True)
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                self._record_op(action, False)
                logger.error(f"[search_engine] {action} error: {e}")
                return {"success": False, "error": str(e), "action": action}

    def _dispatch(self, action: str, params: Dict[str, Any]) -> Any:
        handler = {
            "status": self._get_status, "stats": self._get_stats, "health": self.health_check,
            "reset": self._reset, "configure": self._configure,
            # 搜索
            "search": self._search, "suggest": self._suggest,
            # 索引
            "index": self._index_document, "index_batch": self._index_batch,
            "remove": self._remove_document, "get": self._get_document,
            # 热词与反馈
            "hot_queries": self._hot_queries_list,
            "click": self._record_click, "history": self._search_history_list,
        }.get(action)
        if handler:
            return handler(params)
        return {"action": action, "params": params, "module_id": self.MODULE_ID}

    # ---- 搜索核心 ----

    def _search(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """全文搜索"""
        query = params.get("query", "")
        limit = params.get("limit", 20)
        offset = params.get("offset", 0)
        category = params.get("category", "")
        if not query:
            return {"results": [], "total": 0, "query": query}
        with self._lock:
            self._total_searches += 1
            self._hot_queries[query] += 1
            self._search_history.append({
                "query": query, "time": datetime.now().isoformat(),
                "results_count": 0, "latency_ms": 0
            })
        tokens = simple_chinese_tokenize(query)
        # 计算每个候选文档的得分
        scores: Dict[str, float] = defaultdict(float)
        for token in tokens:
            if token in self._inverted_index:
                for doc_id in self._inverted_index[token]:
                    dl = len(self._forward_index.get(doc_id, []))
                    tf = len(self._inverted_index[token].get(doc_id, []))
                    df = len(self._inverted_index[token])
                    scores[doc_id] += self._scoring_engine.bm25_score(tf, dl, df)
        # 标题匹配加分
        for doc_id, doc in self._documents.items():
            for token in tokens:
                if token in simple_chinese_tokenize(doc.title):
                    scores[doc_id] += 2.0
                if token in simple_chinese_tokenize(' '.join(doc.tags)):
                    scores[doc_id] += 0.5
        # 点击反馈加分
        for token in tokens:
            if token in self._click_feedback:
                for doc_id, cnt in self._click_feedback[token].most_common(5):
                    scores[doc_id] += cnt * 0.3
        # 排序
        sorted_docs = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        # 构建结果
        results = []
        for doc_id, score in sorted_docs[offset:offset+limit]:
            doc = self._documents.get(doc_id)
            if not doc:
                continue
            if category and doc.category != category:
                continue
            snippet = self._make_snippet(doc.content, tokens, max_len=200)
            results.append(SearchResult(
                doc_id=doc_id, title=doc.title, snippet=snippet,
                score=round(score, 4), url=doc.url, category=doc.category
            ))
        # 更新历史
        if self._search_history:
            self._search_history[-1]["results_count"] = len(results)
        return {"results": [self._result_to_dict(r) for r in results],
                "total": len(sorted_docs), "query": query, "tokens": tokens}

    def _suggest(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """搜索建议"""
        prefix = params.get("prefix", "").lower()
        limit = params.get("limit", 10)
        if not prefix:
            return {"suggestions": [], "prefix": prefix}
        # 从热词匹配
        suggestions = []
        for query, count in self._hot_queries.most_common(100):
            if prefix in query.lower() and query not in [s["text"] for s in suggestions]:
                suggestions.append({"text": query, "count": count, "source": "hot"})
            if len(suggestions) >= limit:
                break
        # 从标题匹配
        if len(suggestions) < limit:
            for doc in self._documents.values():
                if prefix in doc.title.lower() and doc.title not in [s["text"] for s in suggestions]:
                    suggestions.append({"text": doc.title, "count": 0, "source": "title"})
                if len(suggestions) >= limit:
                    break
        return {"suggestions": suggestions, "prefix": prefix}

    def _make_snippet(self, content: str, tokens: List[str], max_len: int = 200) -> str:
        """生成搜索摘要(高亮匹配位置附近文本)"""
        if not content:
            return ""
        lower_content = content.lower()
        best_pos = 0
        for token in tokens:
            pos = lower_content.find(token.lower())
            if pos >= 0:
                best_pos = pos
                break
        start = max(0, best_pos - max_len // 4)
        end = min(len(content), start + max_len)
        snippet = content[start:end]
        if start > 0:
            snippet = "..." + snippet
        if end < len(content):
            snippet = snippet + "..."
        return snippet

    def _result_to_dict(self, r: SearchResult) -> Dict[str, Any]:
        return {"doc_id": r.doc_id, "title": r.title, "snippet": r.snippet,
                "score": r.score, "url": r.url, "category": r.category}

    # ---- 索引管理 ----

    def _index_document(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """索引单个文档"""
        doc_id = params.get("doc_id", hashlib.md5(params.get("content", "").encode()).hexdigest()[:12])
        doc = SearchDocument(
            doc_id=doc_id, title=params.get("title", ""),
            content=params.get("content", ""), url=params.get("url", ""),
            category=params.get("category", ""), tags=params.get("tags", [])
        )
        with self._lock:
            # 先移除旧索引
            if doc_id in self._forward_index:
                old_tokens = self._forward_index[doc_id]
                for token in set(old_tokens):
                    if doc_id in self._inverted_index.get(token, {}):
                        del self._inverted_index[token][doc_id]
            # 建新索引
            title_tokens = simple_chinese_tokenize(doc.title)
            content_tokens = simple_chinese_tokenize(doc.content)
            tag_tokens = []
            for tag in doc.tags:
                tag_tokens.extend(simple_chinese_tokenize(tag))
            all_tokens = list(title_tokens) * 2 + list(content_tokens) + list(tag_tokens) * 1
            self._forward_index[doc_id] = all_tokens
            for pos, token in enumerate(all_tokens):
                self._inverted_index[token][doc_id].append(pos)
            self._documents[doc_id] = doc
            self._total_indexed += 1
            # 更新评分引擎统计
            self._update_scoring_stats()
        self.audit("index_document", f"doc_id={doc_id} title={doc.title[:50]}")
        return {"doc_id": doc_id, "status": "indexed", "title": doc.title}

    def _index_batch(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """批量索引"""
        docs = params.get("documents", [])
        indexed = 0
        errors = 0
        for doc_params in docs:
            try:
                self._index_document(doc_params)
                indexed += 1
            except Exception as e:
                errors += 1
                logger.error(f"batch index error: {e}")
        return {"indexed": indexed, "errors": errors, "total": len(docs)}

    def _remove_document(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """删除文档"""
        doc_id = params.get("doc_id", "")
        with self._lock:
            if doc_id in self._forward_index:
                for token in self._inverted_index:
                    if doc_id in self._inverted_index[token]:
                        del self._inverted_index[token][doc_id]
                del self._forward_index[doc_id]
                self._documents.pop(doc_id, None)
                return {"doc_id": doc_id, "status": "removed"}
            return {"error": f"doc {doc_id} not found"}

    def _get_document(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """获取文档详情"""
        doc_id = params.get("doc_id", "")
        doc = self._documents.get(doc_id)
        if not doc:
            return {"error": "not found"}
        return {
            "doc_id": doc.doc_id, "title": doc.title, "content": doc.content,
            "url": doc.url, "category": doc.category, "tags": doc.tags,
            "created_at": doc.created_at, "updated_at": doc.updated_at,
            "token_count": len(self._forward_index.get(doc_id, []))
        }

    def _update_scoring_stats(self):
        """更新评分引擎全局统计"""
        doc_count = len(self._forward_index)
        total_dl = sum(len(tokens) for tokens in self._forward_index.values())
        avg_dl = total_dl / max(1, doc_count)
        df = {}
        for token, postings in self._inverted_index.items():
            df[token] = len(postings)
        self._scoring_engine.update_stats(doc_count, avg_dl, df)

    # ---- 热词与反馈 ----

    def _hot_queries_list(self, params: Dict[str, Any]) -> Dict[str, Any]:
        limit = params.get("limit", 20)
        top = self._hot_queries.most_common(limit)
        return {"hot_queries": [{"query": q, "count": c} for q, c in top]}

    def _record_click(self, params: Dict[str, Any]) -> Dict[str, Any]:
        query = params.get("query", "")
        doc_id = params.get("doc_id", "")
        if query and doc_id:
            self._click_feedback[query][doc_id] += 1
            return {"status": "recorded"}
        return {"error": "missing query or doc_id"}

    def _search_history_list(self, params: Dict[str, Any]) -> Dict[str, Any]:
        limit = params.get("limit", 50)
        return {"history": self._search_history[-limit:], "total": len(self._search_history)}

    # ---- 标准接口 ----

    def _get_status(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
            "version": self.VERSION, "status": "running",
            "indexed_docs": len(self._documents),
            "inverted_index_terms": len(self._inverted_index),
            "total_searches": self._total_searches,
            "total_indexed": self._total_indexed,
            "hot_queries_count": len(self._hot_queries),
            "click_feedback_entries": len(self._click_feedback),
        }

    def _get_stats(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        avg_dl = sum(len(t) for t in self._forward_index.values()) / max(1, len(self._forward_index))
        return {
            "total_documents": len(self._documents),
            "total_index_terms": len(self._inverted_index),
            "total_searches": self._total_searches,
            "avg_document_length": round(avg_dl, 1),
            "hot_queries_top5": self._hot_queries.most_common(5),
            "click_feedback_queries": len(self._click_feedback),
        }

    def _reset(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        with self._lock:
            self._documents.clear()
            self._inverted_index.clear()
            self._forward_index.clear()
            self._hot_queries.clear()
            self._click_feedback.clear()
            self._search_history.clear()
            self._total_searches = 0
            self._total_indexed = 0
        return {"status": "reset_ok"}

    def _configure(self, params: Dict[str, Any]) -> Dict[str, Any]:
        if "field_weights" in params:
            self._field_weights.update(params["field_weights"])
        if "bm25_k1" in params:
            self._scoring_engine.k1 = params["bm25_k1"]
        if "bm25_b" in params:
            self._scoring_engine.b = params["bm25_b"]
        return {"configured": list(params.keys())}

    def health_check(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "healthy": True,
            "status": "ok",
            "indexed_docs": len(self._documents),
        }

    def _record_op(self, action: str, success: bool):
        self._operation_count += 1
        if not success:
            self._error_count += 1


module_class = SearchEngine
