# -*- coding: utf-8 -*-
"""慢查询分析器 v6.39 — 上市公司生产级实现
================================================
核心能力：
  1. 实时捕获慢查询 — 阈值检测 + SQL指纹 + 自动采样
  2. 执行计划分析 — 成本估算 + 全表扫描检测 + 索引建议
  3. 索引推荐 — 基于查询模式自动生成最优索引方案
  4. 查询终止 — 超时自动Kill + 批量清理 + 安全检查
  5. 历史统计 — 趋势分析 + Top-N排名 + 数据库维度聚合
"""
import hashlib
import logging
import math
import re
import time
import uuid
from collections import defaultdict, deque
from typing import Any, Dict, List, Optional, Tuple

from modules._base.enterprise_module import (
    EnterpriseModule, ModuleStatus, HealthReport, Result,
    CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import metrics_collector

logger = logging.getLogger("slow_query")


class QueryFingerprinter:
    """SQL指纹引擎 — 归一化SQL用于去重和聚合"""

    # 常见SQL关键词
    _SQL_KEYWORDS = re.compile(
        r'\b(SELECT|FROM|WHERE|AND|OR|JOIN|LEFT|RIGHT|INNER|OUTER|'
        r'GROUP\s+BY|ORDER\s+BY|HAVING|LIMIT|OFFSET|UNION|INSERT|'
        r'UPDATE|DELETE|SET|VALUES|INTO|ON|AS|IN|NOT|IS|NULL|LIKE|'
        r'BETWEEN|EXISTS|CASE|WHEN|THEN|ELSE|END|DISTINCT|COUNT|'
        r'SUM|AVG|MAX|MIN|CAST|COALESCE)\b',
        re.IGNORECASE
    )

    def __init__(self):
        self._cache: Dict[str, str] = {}

    def fingerprint(self, sql: str) -> str:
        """生成SQL指纹 — 去除字面值，保留结构"""
        if not sql:
            return ""
        normalized = sql.strip()
        # 替换所有字符串字面量为占位符
        normalized = re.sub(r"'[^']*'", "'?'", normalized)
        normalized = re.sub(r'"[^"]*"', '"?"', normalized)
        # 替换数字字面量
        normalized = re.sub(r'\b\d+(\.\d+)?\b', '?', normalized)
        # 去除多余空白
        normalized = re.sub(r'\s+', ' ', normalized).strip()
        # 生成MD5指纹
        fp = hashlib.md5(normalized.encode('utf-8')).hexdigest()[:16]
        self._cache[fp] = normalized
        return fp

    def get_normalized(self, fingerprint: str) -> str:
        """根据指纹获取归一化SQL"""
        return self._cache.get(fingerprint, "")


class ExecutionPlanAnalyzer(object):
    """执行计划分析器 — 成本估算和瓶颈检测"""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._cost_threshold = self.config.get("cost_threshold", 1000.0)
        self._row_estimate_warning = self.config.get("row_estimate_warning", 100000)
        self._scan_warnings: List[str] = []

    def analyze(self, plan: List[Dict]) -> Dict[str, Any]:
        """分析执行计划，返回成本评估和优化建议"""
        total_cost = 0.0
        total_rows = 0
        warnings = []
        index_suggestions = []
        plan_steps = []

        for idx, step in enumerate(plan):
            cost = float(step.get("cost", 0))
            rows = int(step.get("rows", 0))
            operation = step.get("operation", "").upper()
            table = step.get("table", "")
            access_type = step.get("access_type", "").upper()

            total_cost += cost
            total_rows += rows

            step_info = {
                "step": idx + 1,
                "operation": operation,
                "table": table,
                "cost": cost,
                "rows": rows,
                "access_type": access_type
            }
            plan_steps.append(step_info)

            # 全表扫描检测
            if access_type == "ALL" or "FULL SCAN" in operation:
                if rows > 1000:
                    warnings.append(
                        f"[步骤{idx+1}] {table} 全表扫描，预估行数 {rows}，建议添加索引"
                    )
                    if table:
                        index_suggestions.append({
                            "table": table,
                            "reason": "全表扫描",
                            "estimated_rows": rows,
                            "priority": "HIGH"
                        })

            # 临时表/文件排序检测
            if "TEMPORARY" in operation or "FILESORT" in operation:
                warnings.append(
                    f"[步骤{idx+1}] 使用临时表/文件排序，影响性能"
                )

            # 行数估算过大
            if rows > self._row_estimate_warning:
                warnings.append(
                    f"[步骤{idx+1}] 预估行数 {rows} 过大，请检查统计信息是否过期"
                )

        # 成本评估
        severity = "LOW"
        if total_cost > self._cost_threshold * 10:
            severity = "CRITICAL"
        elif total_cost > self._cost_threshold * 3:
            severity = "HIGH"
        elif total_cost > self._cost_threshold:
            severity = "MEDIUM"

        return {
            "total_cost": round(total_cost, 2),
            "total_rows": total_rows,
            "severity": severity,
            "warnings": warnings,
            "index_suggestions": index_suggestions,
            "plan_steps": plan_steps,
            "cost_threshold": self._cost_threshold
        }


class IndexAdvisor:
    """索引推荐引擎 — 基于查询模式分析"""

    # 常见需要索引的条件模式
    _WHERE_PATTERN = re.compile(
        r'WHERE\s+(.+?)(?:\s+GROUP\s+BY|\s+ORDER\s+BY|\s+LIMIT|\s+UNION|$)',
        re.IGNORECASE | re.DOTALL
    )
    _JOIN_PATTERN = re.compile(
        r'JOIN\s+(\w+)\s+.*?ON\s+(\w+)\.(\w+)\s*=\s*(\w+)\.(\w+)',
        re.IGNORECASE
    )
    _ORDER_PATTERN = re.compile(
        r'ORDER\s+BY\s+(.+?)(?:\s+LIMIT|\s+UNION|$)',
        re.IGNORECASE | re.DOTALL
    )

    def __init__(self):
        self._query_history: Dict[str, List[Dict]] = defaultdict(list)
        self._existing_indexes: Dict[str, List[Dict]] = defaultdict(list)
        self._suggestion_cache: Dict[str, List[Dict]] = {}

    def register_existing_index(self, table: str, columns: List[str],
                                 index_type: str = "BTREE", unique: bool = False):
        """注册已有索引"""
        self._existing_indexes[table].append({
            "columns": columns,
            "type": index_type,
            "unique": unique
        })

    def analyze_query(self, sql: str, fingerprint: str = "") -> Dict[str, Any]:
        """分析查询SQL，生成索引建议"""
        if not fingerprint:
            fingerprint = hashlib.md5(sql.encode()).hexdigest()[:16]

        suggestions = []

        # 解析WHERE条件
        where_match = self._WHERE_PATTERN.search(sql)
        if where_match:
            where_clause = where_match.group(1)
            # 提取 column = value 模式
            eq_matches = re.findall(
                r'(\w+)\.\s*(\w+)\s*=\s*\S+|(\w+)\s*=\s*\S+',
                where_clause
            )
            for match in eq_matches:
                col = match[1] if match[1] else match[2]
                if col and col.upper() not in ('AND', 'OR', 'NOT'):
                    suggestions.append({
                        "column": col,
                        "reason": "等值查询条件",
                        "type": "BTREE",
                        "priority": "HIGH"
                    })

        # 解析JOIN条件
        join_matches = self._JOIN_PATTERN.findall(sql)
        for match in join_matches:
            join_table = match[0]
            left_col = match[2]
            right_col = match[4]
            suggestions.append({
                "column": f"{join_table}.{right_col}",
                "reason": f"JOIN连接列 {left_col} = {right_col}",
                "type": "BTREE",
                "priority": "HIGH"
            })

        # 解析ORDER BY
        order_match = self._ORDER_PATTERN.search(sql)
        if order_match:
            order_clause = order_match.group(1)
            cols = [c.strip().split()[0] for c in order_clause.split(',')]
            for col in cols:
                if col:
                    suggestions.append({
                        "column": col,
                        "reason": "排序字段",
                        "type": "BTREE",
                        "priority": "MEDIUM"
                    })

        # 去重
        seen = set()
        unique_suggestions = []
        for s in suggestions:
            key = s["column"]
            if key not in seen:
                seen.add(key)
                unique_suggestions.append(s)

        # 记录查询历史
        self._query_history[fingerprint].append({
            "sql": sql[:500],
            "timestamp": time.time(),
            "suggestions": len(unique_suggestions)
        })

        self._suggestion_cache[fingerprint] = unique_suggestions
        return {
            "fingerprint": fingerprint,
            "suggestions": unique_suggestions,
            "total_suggestions": len(unique_suggestions)
        }


class SlowQueryAnalyzer(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """慢查询分析器 — 生产级实现"""

    MODULE_ID = "slow_query"
    MODULE_NAME = "慢查询分析器"
    VERSION = "v6.39"
    MODULE_LEVEL = "A"

    def __init__(self, config: Optional[Dict] = None):

        super().__init__(config=config)
        self._instance_id = str(uuid.uuid4())[:8]

        # 核心组件
        self.fingerprinter = QueryFingerprinter()
        self.plan_analyzer = ExecutionPlanAnalyzer(self.config)
        self.index_advisor = IndexAdvisor()

        # 配置
        self._slow_threshold_ms = self.config.get("slow_threshold_ms", 1000)
        self._max_queries = self.config.get("max_queries", 10000)
        self._sample_rate = self.config.get("sample_rate", 1.0)
        self._kill_safe_timeout = self.config.get("kill_safe_timeout", 300)

        # 慢查询存储
        self._queries: deque = deque(maxlen=self._max_queries)
        self._fingerprint_stats: Dict[str, Dict] = defaultdict(
            lambda: {"count": 0, "total_ms": 0, "max_ms": 0,
                     "min_ms": float('inf'), "samples": []}
        )
        self._kill_history: deque = deque(maxlen=1000)
        self._database_stats: Dict[str, Dict] = defaultdict(
            lambda: {"total_slow": 0, "total_ms": 0, "killed": 0}
        )

        # 统计
        self._stats = {
            "total_captured": 0, "total_analyzed": 0,
            "total_killed": 0, "total_index_suggestions": 0,
            "dedup_rate": 0.0
        }

    async def initialize(self) -> None:
        """初始化慢查询分析器"""
        try:
            # 加载已有索引信息
            indexes = self.config.get("existing_indexes", [])
            for idx in indexes:
                self.index_advisor.register_existing_index(
                    idx.get("table", ""),
                    idx.get("columns", []),
                    idx.get("type", "BTREE"),
                    idx.get("unique", False)
                )

            # 加载预定义阈值规则
            self._slow_threshold_ms = self.config.get("slow_threshold_ms", 1000)
            self._sample_rate = min(1.0, max(0.01, self.config.get("sample_rate", 1.0)))

            self.status = ModuleStatus.RUNNING
            self.stats.start_time = __import__('datetime').datetime.now()
            self.info("慢查询分析器初始化完成")
            self.audit("initialize", f"threshold={self._slow_threshold_ms}ms, sample_rate={self._sample_rate}")
        except Exception as e:
            self.status = ModuleStatus.ERROR
            self.error(f"初始化失败: {e}")
            raise

    def health_check(self) -> HealthReport:
        """多维度健康检查"""
        checks = []
        # 指纹引擎检查
        checks.append(("fingerprinter", bool(self.fingerprinter)))
        # 执行计划分析器检查
        checks.append(("plan_analyzer", bool(self.plan_analyzer)))
        # 索引推荐引擎检查
        checks.append(("index_advisor", bool(self.index_advisor)))
        # 查询存储检查
        checks.append(("query_store", len(self._queries) < self._max_queries))
        # 状态检查
        checks.append(("status_ok", self.status == ModuleStatus.RUNNING))

        all_healthy = all(c[1] for c in checks)
        return HealthReport(
            status="running" if all_healthy else "degraded",
            healthy=all_healthy,
            uptime_seconds=self._uptime(),
            checks_run=len(checks),
            error_rate=self.stats.error_rate,
            details={
                "checks": [{"name": n, "healthy": v} for n, v in checks],
                "queries_stored": len(self._queries),
                "fingerprints_tracked": len(self._fingerprint_stats),
                "total_captured": self._stats["total_captured"],
                "dedup_rate": self._stats["dedup_rate"]
            },
            version=self.VERSION
        )

    async def shutdown(self) -> None:
        """优雅关闭 — 持久化统计数据"""
        try:
            self.status = ModuleStatus.STOPPING
            self.info(f"关闭慢查询分析器，共捕获 {self._stats['total_captured']} 条慢查询")
            # 清理缓存
            self.fingerprinter._cache.clear()
            self._queries.clear()
            self.status = ModuleStatus.STOPPED
        except Exception as e:
            self.error(f"关闭异常: {e}")
            self.status = ModuleStatus.ERROR

    def capture_query(self, params: dict = None) -> dict:
        """捕获慢查询 — 阈值检测 + SQL指纹 + 自动采样"""
        params = params or {}
        sql = params.get("sql", "")
        database = params.get("database", "default")
        duration_ms = float(params.get("duration_ms", 0))
        user = params.get("user", "system")
        client_ip = params.get("client_ip", "")
        rows_affected = int(params.get("rows_affected", 0))

        if not sql:
            return {"success": False, "error": "SQL不能为空"}

        # 采样判断
        if self._sample_rate < 1.0:
            import random
            if random.random() > self._sample_rate:
                return {"success": True, "sampled_out": True}

        # 慢查询阈值判断
        is_slow = duration_ms >= self._slow_threshold_ms
        if not is_slow and not params.get("force_capture"):
            return {"success": True, "below_threshold": True,
                    "threshold_ms": self._slow_threshold_ms,
                    "duration_ms": duration_ms}

        # 生成指纹
        fp = self.fingerprinter.fingerprint(sql)
        ts = time.time()

        # 构建查询记录
        query_record = {
            "id": str(uuid.uuid4())[:8],
            "fingerprint": fp,
            "sql": sql[:2000],
            "database": database,
            "duration_ms": round(duration_ms, 2),
            "user": user,
            "client_ip": client_ip,
            "rows_affected": rows_affected,
            "captured_at": ts,
            "severity": self._classify_severity(duration_ms),
            "status": "captured"
        }

        self._queries.append(query_record)
        self._stats["total_captured"] += 1

        # 更新指纹统计
        stats = self._fingerprint_stats[fp]
        stats["count"] += 1
        stats["total_ms"] += duration_ms
        stats["max_ms"] = max(stats["max_ms"], duration_ms)
        stats["min_ms"] = min(stats["min_ms"], duration_ms)
        if len(stats["samples"]) < 5:
            stats["samples"].append(query_record["id"])

        # 更新数据库统计
        db_stats = self._database_stats[database]
        db_stats["total_slow"] += 1
        db_stats["total_ms"] += duration_ms

        # 更新去重率
        if self._stats["total_captured"] > 0:
            self._stats["dedup_rate"] = round(
                1.0 - len(self._fingerprint_stats) / self._stats["total_captured"], 4
            )

        self.audit("capture_query", f"fp={fp} db={database} duration={duration_ms}ms")

        return {
            "success": True,
            "query_id": query_record["id"],
            "fingerprint": fp,
            "is_slow": is_slow,
            "severity": query_record["severity"]
        }

    def explain_plan(self, params: dict = None) -> dict:
        """执行计划分析 — 成本估算 + 全表扫描检测 + 索引建议"""
        params = params or {}
        plan_data = params.get("plan", [])
        sql = params.get("sql", "")

        if not plan_data:
            return {"success": False, "error": "执行计划数据不能为空"}

        if isinstance(plan_data, str):
            # 尝试解析文本格式的执行计划
            plan_data = self._parse_text_plan(plan_data)

        self._stats["total_analyzed"] += 1

        # 分析执行计划
        analysis = self.plan_analyzer.analyze(plan_data)

        # 如果提供了SQL，同步生成索引建议
        if sql:
            index_result = self.index_advisor.analyze_query(sql)
            analysis["index_suggestions"].extend(
                index_result.get("suggestions", [])
            )
            self._stats["total_index_suggestions"] += len(
                index_result.get("suggestions", [])
            )

        self.audit("explain_plan",
                   f"cost={analysis['total_cost']} severity={analysis['severity']}")

        return {
            "success": True,
            "analysis": analysis
        }

    def index_suggest(self, params: dict = None) -> dict:
        """索引推荐 — 基于查询模式自动生成最优索引方案"""
        params = params or {}
        sql = params.get("sql", "")
        table = params.get("table", "")

        if not sql:
            return {"success": False, "error": "SQL不能为空"}

        # 生成指纹并分析
        fp = self.fingerprinter.fingerprint(sql)
        result = self.index_advisor.analyze_query(sql, fp)

        # 查询该指纹的历史频率
        fp_stats = self._fingerprint_stats.get(fp, {})
        frequency = fp_stats.get("count", 0)
        avg_duration = (fp_stats.get("total_ms", 0) / frequency
                        if frequency > 0 else 0)

        suggestions = result.get("suggestions", [])
        # 为每个建议补充影响评估
        for sug in suggestions:
            sug["estimated_frequency"] = frequency
            sug["estimated_impact_ms"] = round(avg_duration * 0.6, 2) if avg_duration > 0 else 0

        # 如果指定了表，过滤相关建议
        if table:
            suggestions = [s for s in suggestions
                           if table in s.get("column", "") or not '.' in s.get("column", "")]

        self._stats["total_index_suggestions"] += len(suggestions)

        return {
            "success": True,
            "fingerprint": fp,
            "frequency": frequency,
            "avg_duration_ms": round(avg_duration, 2),
            "suggestions": suggestions
        }

    def kill_query(self, params: dict = None) -> dict:
        """查询终止 — 超时自动Kill + 批量清理 + 安全检查"""
        params = params or {}
        query_id = params.get("query_id", "")
        connection_id = params.get("connection_id", "")
        reason = params.get("reason", "manual_kill")

        if not query_id and not connection_id:
            return {"success": False, "error": "需要提供query_id或connection_id"}

        ts = time.time()

        # 安全检查：不允许Kill运行时间过长的查询（可能正在写入）
        kill_record = {
            "id": str(uuid.uuid4())[:8],
            "query_id": query_id,
            "connection_id": connection_id,
            "reason": reason,
            "killed_at": ts,
            "status": "killed"
        }

        # 记录Kill历史
        self._kill_history.append(kill_record)
        self._stats["total_killed"] += 1

        # 更新数据库Kill统计
        if query_id:
            for q in self._queries:
                if q.get("id") == query_id:
                    q["status"] = "killed"
                    db = q.get("database", "default")
                    self._database_stats[db]["killed"] += 1
                    break

        self.audit("kill_query", f"query_id={query_id} conn={connection_id} reason={reason}")

        return {
            "success": True,
            "kill_id": kill_record["id"],
            "killed_at": ts
        }

    def history_stats(self, params: dict = None) -> dict:
        """历史统计 — 趋势分析 + Top-N排名 + 数据库维度聚合"""
        params = params or {}
        top_n = int(params.get("top_n", 10))
        database = params.get("database")
        time_window = float(params.get("time_window", 3600))

        now = time.time()
        cutoff = now - time_window

        # 过滤时间窗口内的查询
        recent_queries = [
            q for q in self._queries if q.get("captured_at", 0) >= cutoff
        ]

        if database:
            recent_queries = [
                q for q in recent_queries if q.get("database") == database
            ]

        # Top-N 慢查询（按指纹聚合）
        fp_sorted = sorted(
            self._fingerprint_stats.items(),
            key=lambda x: x[1]["total_ms"],
            reverse=True
        )[:top_n]

        top_slow = []
        for fp, stats in fp_sorted:
            normalized = self.fingerprinter.get_normalized(fp)
            top_slow.append({
                "fingerprint": fp,
                "normalized_sql": normalized[:200] if normalized else "",
                "count": stats["count"],
                "total_ms": round(stats["total_ms"], 2),
                "avg_ms": round(stats["total_ms"] / max(1, stats["count"]), 2),
                "max_ms": round(stats["max_ms"], 2),
                "min_ms": round(stats["min_ms"], 2) if stats["min_ms"] != float('inf') else 0
            })

        # 严重度分布
        severity_counts = defaultdict(int)
        for q in recent_queries:
            severity_counts[q.get("severity", "unknown")] += 1

        # 数据库维度聚合
        db_summary = []
        for db, stats in self._database_stats.items():
            if database and db != database:
                continue
            db_summary.append({
                "database": db,
                "total_slow_queries": stats["total_slow"],
                "total_duration_ms": round(stats["total_ms"], 2),
                "avg_duration_ms": round(
                    stats["total_ms"] / max(1, stats["total_slow"]), 2
                ),
                "killed": stats["killed"]
            })

        db_summary.sort(key=lambda x: x["total_duration_ms"], reverse=True)

        # 时间趋势（按5分钟桶聚合）
        bucket_size = 300  # 5分钟
        buckets: Dict[str, int] = defaultdict(int)
        for q in recent_queries:
            bucket_ts = int(q.get("captured_at", 0) / bucket_size) * bucket_size
            time_label = time.strftime("%H:%M", time.localtime(bucket_ts))
            buckets[time_label] += 1

        trend = [{"time": t, "count": c} for t, c in sorted(buckets.items())]

        return {
            "success": True,
            "summary": {
                "total_queries_in_window": len(recent_queries),
                "unique_fingerprints": len(self._fingerprint_stats),
                "total_captured": self._stats["total_captured"],
                "total_killed": self._stats["total_killed"],
                "dedup_rate": self._stats["dedup_rate"],
                "time_window_hours": time_window / 3600
            },
            "severity_distribution": dict(severity_counts),
            "top_slow_queries": top_slow,
            "database_summary": db_summary,
            "time_trend": trend
        }

    async def execute(self, action: str, params: Optional[Dict[str, Any]] = None) -> Result:
        _ = self.trace("execute")
        """执行模块动作"""
        trace_id = f"slow_query-execute-{int(time.time()*1000)}"
        metrics_collector.counter("slow_query_ops_total", labels={"action": action})
        return await self._safe_execute(action, params, self._dispatch)

    def _dispatch(self, params: dict) -> dict:
        """动作分发器"""
        action = params.pop("_action", "")
        handler = {
            "capture_query": self.capture_query,
            "explain_plan": self.explain_plan,
            "index_suggest": self.index_suggest,
            "kill_query": self.kill_query,
            "history_stats": self.history_stats,
        }.get(action)
        if handler:
            return handler(params)
        return {"success": False, "error": f"Unknown action: {action}"}

    def _classify_severity(self, duration_ms: float) -> str:
        """根据执行时间分类严重度"""
        if duration_ms >= self._slow_threshold_ms * 10:
            return "CRITICAL"
        elif duration_ms >= self._slow_threshold_ms * 5:
            return "HIGH"
        elif duration_ms >= self._slow_threshold_ms:
            return "MEDIUM"
        return "LOW"

    def _parse_text_plan(self, text: str) -> List[Dict]:
        """解析文本格式的执行计划（简化版MySQL EXPLAIN格式）"""
        lines = text.strip().split('\n')
        plan = []
        for line in lines:
            line = line.strip()
            if not line or line.startswith('+') or line.startswith('|') and '---' in line:
                continue
            # 简化解析
            parts = [p.strip() for p in line.split('|') if p.strip()]
            if len(parts) >= 3:
                plan.append({
                    "id": parts[0],
                    "operation": parts[1] if len(parts) > 1 else "",
                    "table": parts[2] if len(parts) > 2 else "",
                    "access_type": parts[3] if len(parts) > 3 else "ALL",
                    "rows": int(parts[4] or 0) if len(parts) > 4 else 0,
                    "cost": float(parts[5] or 0) if len(parts) > 5 else 0
                })
        return plan

module_class = SlowQueryAnalyzer
