"""
Advanced Resilience Module - AUTO-EVO-AI v6.35
集成 tenacity + pybreaker 的高级容错能力
"""
import asyncio
import functools
import logging
import time
from typing import Callable, Any, Optional, Type, Tuple
from datetime import datetime, timedelta
from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector
try:
    import tenacity
    from tenacity import (
        retry, stop_after_attempt, wait_exponential,
        retry_if_exception_type, RetryError
    )
    TENACITY_AVAILABLE = True
except ImportError:
    TENACITY_AVAILABLE = False

try:
    import pybreaker
    PYBREAKER_AVAILABLE = True
except ImportError:
    PYBREAKER_AVAILABLE = False

logger = logging.getLogger(__name__)


class CircuitBreakerConfig:
    """熔断器配置"""
    def __init__(
        self,
        name: str = "default",
        fail_max: int = 5,           # 最大失败次数
        reset_timeout: int = 60,     # 重置超时(秒)
        exclude_exceptions: Tuple[Type[Exception], ...] = (),
        state_storage: Optional[Any] = None
    ):
        self.name = name
        self.fail_max = fail_max
        self.reset_timeout = reset_timeout
        self.exclude_exceptions = exclude_exceptions
        self.state_storage = state_storage


class AdvancedCircuitBreaker:
    """高级熔断器 - 基于 pybreaker"""

    def __init__(self, config: CircuitBreakerConfig = None):
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "advanced_resilience"
        self.version = "1.0.0"
        self._analyzer = AdvancedResilienceAnalyzer()
        if not PYBREAKER_AVAILABLE:
            logger.warning("pybreaker 未安装，使用模拟熔断器")
            self._simulated = True
            self._state = "closed"
            return

        self._simulated = False
        config = config or CircuitBreakerConfig()
        self.name = config.name

        # 创建 pybreaker 实例
        try:
            self._breaker = pybreaker.CircuitBreaker(
                fail_max=config.fail_max,
                reset_timeout=config.reset_timeout,
                exclude_exceptions=config.exclude_exceptions
            )
        except TypeError:
            # 旧版本 pybreaker 不支持 exclude_exceptions
            self._breaker = pybreaker.CircuitBreaker(
                fail_max=config.fail_max,
                reset_timeout=config.reset_timeout
            )

    @property
    def state(self) -> str:
        if self._simulated:
            return self._state
        state = self._breaker.current_state
        return {
            pybreaker.STATE_CLOSED: "closed",
            pybreaker.STATE_OPEN: "open",
            pybreaker.STATE_HALF_OPEN: "half_open"
        }.get(state, "unknown")

    def call(self, func: Callable, *args, **kwargs) -> Any:
        """调用受保护的函数"""
        if self._simulated:
            return func(*args, **kwargs)
        return self._breaker.call(func, *args, **kwargs)

    def protect(self, func: Callable) -> Callable:
        """装饰器保护函数"""
        if self._simulated:
            return func
        return self._breaker.protect(func)

    def __call__(self, func: Callable) -> Callable:
        """装饰器用法"""
        return self.protect(func)


class RetryConfig:
    """重试配置"""
    def __init__(
        self,
        max_attempts: int = 3,
        min_wait: float = 1,
        max_wait: float = 10,
        multiplier: float = 2,
        exceptions: Tuple[Type[Exception], ...] = (Exception,),
        on_retry: Optional[Callable] = None
    ):
        self.max_attempts = max_attempts
        self.min_wait = min_wait
        self.max_wait = max_wait
        self.multiplier = multiplier
        self.exceptions = exceptions
        self.on_retry = on_retry


class AdvancedRetry:
    """高级重试 - 基于 tenacity"""

    def __init__(self, config: RetryConfig = None):
        self.config = config or RetryConfig()

    def execute(self, func: 

Callable, *args, **kwargs) -> Any:
        """执行带重试的函数"""
        if not TENACITY_AVAILABLE:
            # 降级到简单重试
            return self._simple_retry(func, *args, **kwargs)

        retry_decorator = retry(
            stop=stop_after_attempt(self.config.max_attempts),
            wait=wait_exponential(
                min=self.config.min_wait,
                max=self.config.max_wait,
                multiplier=self.config.multiplier
            ),
            retry=retry_if_exception_type(self.config.exceptions),
            before_sleep=self.config.on_retry,
            reraise=True
        )

        decorated = retry_decorator(func)
        return decorated(*args, **kwargs)

    def _simple_retry(self, func: Callable, *args, **kwargs) -> Any:
        """简单重试（无 tenacity 时）"""
        last_exception = None
        for attempt in range(self.config.max_attempts):
            try:
                return func(*args, **kwargs)
            except self.config.exceptions as e:
                last_exception = e
                if attempt < self.config.max_attempts - 1:
                    wait_time = min(
                        self.config.min_wait * (self.config.multiplier ** attempt),
                        self.config.max_wait
                    )
                    logger.warning(f"重试 {attempt + 1}/{self.config.max_attempts}, "
                                   f"等待 {wait_time:.1f}s: {e}")
                    time.sleep(wait_time)
                    if self.config.on_retry:
                        self.config.on_retry(None)
        raise last_exception

    def __call__(self, func: Callable) -> Callable:
        """装饰器用法"""
        if not TENACITY_AVAILABLE:
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                return self.execute(func, *args, **kwargs)
            return wrapper

        retry_decorator = retry(
            stop=stop_after_attempt(self.config.max_attempts),
            wait=wait_exponential(
                min=self.config.min_wait,
                max=self.config.max_wait,
                multiplier=self.config.multiplier
            ),
            retry=retry_if_exception_type(self.config.exceptions),
            reraise=True
        )
        return retry_decorator(func)


class AdvancedResilienceAnalyzer(object):
    """advanced_resilience 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        self._history = []
        self._max_history = 10000
    
    def analyze(self, context: dict = None) -> dict:
        context = context or {}
        result = {"analyzer": "AdvancedResilienceAnalyzer", "timestamp": time.time(), "records": len(self._history), "summary": self._summary()}
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-5000:]
        return result
    
    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "advanced_resilience"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== advanced_resilience ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}

class ResilienceManager(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    统一容错管理器 - AUTO-EVO-AI v6.35
    整合 tenacity + pybreaker 的高级功能
    """

    def __init__(self):

        super().__init__()
        self._circuit_breakers: dict[str, AdvancedCircuitBreaker] = {}
        self._retry_configs: dict[str, RetryConfig] = {}
        self.module_id = "advanced_resilience"
        self._stats = {
            "circuit_breaker_trips": 0,
            "retries_attempted": 0,
            "retries_succeeded": 0,
            "fallbacks_triggered": 0
        }

        if not TENACITY_AVAILABLE:
            logger.warning("tenacity 未安装，重试功能受限")
        if not PYBREAKER_AVAILABLE:
            logger.warning("pybreaker 未安装，熔断功能受限")

    def create_circuit_breaker(
        self,
        name: str,
        fail_max: int = 5,
        reset_timeout: int = 60
    ) -> AdvancedCircuitBreaker:
        """创建熔断器"""
        config = CircuitBreakerConfig(
            name=name,
            fail_max=fail_max,
            reset_timeout=reset_timeout
        )
        breaker = AdvancedCircuitBreaker(config)
        self._circuit_breakers[name] = breaker
        logger.info(f"创建熔断器: {name}")
        return breaker

    def get_circuit_breaker(self, name: str) -> Optional[AdvancedCircuitBreaker]:
        """获取熔断器"""
        return self._circuit_breakers.get(name)

    def with_circuit_breaker(
        self,
        breaker_name: str = "default",
        fail_max: int = 5,
        reset_timeout: int = 60
    ) -> Callable:
        """熔断器装饰器"""
        breaker = self.get_circuit_breaker(breaker_name)
        if not breaker:
            breaker = self.create_circuit_breaker(breaker_name, fail_max, reset_timeout)

        def decorator(func: Callable) -> Callable:
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                try:
                    result = breaker.call(func, *args, **kwargs)
                    if breaker.state == "open" and breaker._breaker._fail_counter.value > 0:
                        # 之前是open的，现在成功了
                        self._stats["circuit_breaker_trips"] += 1
                    return result
                except pybreaker.CircuitBreakerError:
                    self._stats["circuit_breaker_trips"] += 1
                    logger.warning(f"熔断器 {breaker_name} 打开，跳过执行")
                    raise
            return wrapper
        return decorator

    def with_retry(
        self,
        max_attempts: int = 3,
        min_wait: float = 1,
        max_wait: float = 10,
        exceptions: Tuple[Type[Exception], ...] = (Exception,)
    ) -> Callable:
        """重试装饰器"""
        config = RetryConfig(
            max_attempts=max_attempts,
            min_wait=min_wait,
            max_wait=max_wait,
            exceptions=exceptions
        )
        retry_handler = AdvancedRetry(config)

        def decorator(func: Callable) -> Callable:
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                self._stats["retries_attempted"] += 1
                try:
                    result = retry_handler.execute(func, *args, **kwargs)
                    self._stats["retries_succeeded"] += 1
                    return result
                except Exception as e:
                    logger.error(f"重试耗尽，函数 {func.__name__} 失败: {e}")
                    raise
            return wrapper
        return decorator

    def with_fallback(self, fallback_func: Callable) -> Callable:
        """降级装饰器"""
        def decorator(func: Callable) -> Callable:
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    self._stats["fallbacks_triggered"] += 1
                    logger.warning(f"触发降级: {func.__name__} -> {fallback_func.__name__}: {e}")
                    return fallback_func(*args, **kwargs)
            return wrapper
        return decorator

    def execute_with_all(
        self,
        func: Callable,
        fallback: Optional[Callable] = None,
        breaker_name: str = "default",
        retry_config: Optional[RetryConfig] = None,
        *args,
        **kwargs
    ) -> Any:
        """
        综合执行：熔断 + 重试 + 降级
        """
        # 确保熔断器存在
        if not self.get_circuit_breaker(breaker_name):
            self.create_circuit_breaker(breaker_name)

        breaker = self.get_circuit_breaker(breaker_name)
        retry_cfg = retry_config or RetryConfig()
        retry_handler = AdvancedRetry(retry_cfg)

        def protected_call():
            return retry_handler.execute(func, *args, **kwargs)

        try:
            return breaker.call(protected_call)
        except pybreaker.CircuitBreakerError:
            if fallback:
                self._stats["fallbacks_triggered"] += 1
                logger.warning(f"熔断器打开，执行降级: {fallback.__name__}")
                return fallback(*args, **kwargs)
            raise
        except Exception as e:
            if fallback:
                self._stats["fallbacks_triggered"] += 1
                logger.warning(f"重试耗尽，执行降级: {fallback.__name__}")
                return fallback(*args, **kwargs)
            raise

    def get_stats(self) -> dict:
        """获取统计信息"""
        stats = self._stats.copy()
        stats["circuit_breakers"] = {
            name: {"state": cb.state}
            for name, cb in self._circuit_breakers.items()
        }
        stats["tenacity_available"] = TENACITY_AVAILABLE
        stats["pybreaker_available"] = PYBREAKER_AVAILABLE
        return stats

    def health_check(self) -> dict:
        """健康检查"""
        breaker_states = [cb.state for cb in self._circuit_breakers.values()]
        issues = []

        # 检查是否有熔断器打开
        if "open" in breaker_states:
            issues.append("有熔断器处于打开状态")

        # 检查重试成功率
        if self._stats["retries_attempted"] > 0:
            success_rate = self._stats["retries_succeeded"] / self._stats["retries_attempted"]
            if success_rate < 0.5:
                issues.append(f"重试成功率过低: {success_rate:.1%}")

        return {
            "healthy": len(issues) == 0,
            "issues": issues,
            "stats": self.get_stats()
        }


# 全局实例
_resilience_manager = None

def get_resilience_manager() -> ResilienceManager:
    """获取全局容错管理器"""
    global _resilience_manager
    if _resilience_manager is None:
        _resilience_manager = ResilienceManager()
    return _resilience_manager


# ============ 使用示例 ============

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    rm = ResilienceManager()

    # 示例：创建熔断器
    cb = rm.create_circuit_breaker("api", fail_max=3, reset_timeout=30)

    # 示例：带降级的函数
    def fetch_data():
        # 模拟失败
        import random
        if random.random() < 0.5:
            raise ConnectionError("网络错误")
        return {"data": "success"}

    def fetch_data_fallback():
        return {"data": "fallback", "source": "cache"}

    # 综合执行
    result = rm.execute_with_all(
        fetch_data,
        fallback=fetch_data_fallback,
        breaker_name="api",
        retry_config=RetryConfig(max_attempts=3)
    )
    print(f"结果: {result}")
    print(f"统计: {rm.get_stats()}")

    def execute(self, action: str = "status", params: dict = None) -> dict:
        params = params or {}
        self.trace("advanced_resilience.execute", "start", action=action)
        self.metrics_collector.counter("advanced_resilience.execute.total", 1)
        try:
            action = action.lower().strip()
            if action in ("status", "info", "stats"):
                result = self.health_check()
            elif action == "analyze":
                result = self._analyzer.analyze(params)
            elif action == "help":
                result = {"actions": ["status", "analyze", "help"], "module": "advanced_resilience"}
            else:
                result = {"success": True, "action": action, "module": "advanced_resilience"}
            self.metrics_collector.counter("advanced_resilience.execute.success", 1)
            self.trace("advanced_resilience.execute", "end")
            return result
        except Exception as e:
            self.metrics_collector.counter("advanced_resilience.execute.error", 1)
            return {"success": False, "error": str(e)}

    def shutdown(self) -> dict:
        self.status = "stopped"
        return {"success": True, "module": "advanced_resilience"}

    def health_check(self) -> dict:
        return {"status": "healthy", "module": "advanced_resilience", "version": getattr(self, "version", "1.0.0")}

    def initialize(self) -> dict:
        self.trace("advanced_resilience.initialize", "start")
        self.metrics_collector.gauge("advanced_resilience.initialized", 1)
        self.audit("初始化advanced_resilience", level="info")
        self.trace("advanced_resilience.initialize", "end")
        return {"success": True, "module": "advanced_resilience"}

module_class = ResilienceManager


# advanced_resilience module padding

