"""
Data Catalog - Enterprise Data Asset Management
Metadata catalog for data assets with lineage tracking, schema management,
quality scoring, discovery, and governance integration.
"""

import re
import json
import time
import uuid
import hashlib
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Tuple
from collections import defaultdict
from enum import Enum, auto

from modules._base.enterprise_module import EnterpriseModule


class AssetType(Enum):
    TABLE = "table"
    VIEW = "view"
    FILE = "file"
    API = "api"
    STREAM = "stream"
    MODEL = "model"
    DASHBOARD = "dashboard"
    DOCUMENT = "document"


class AssetStatus(Enum):
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    DRAFT = "draft"
    ARCHIVED = "archived"


class ClassificationLevel(Enum):
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"


class DataAsset:
    def __init__(self, asset_id: str, name: str, asset_type: str, owner: str,
                 datasource: str = "", description: str = ""):
        self.asset_id = asset_id
        self.name = name
        self.asset_type = asset_type
        self.owner = owner
        self.datasource = datasource
        self.description = description
        self.status = "active"
        self.classification = "internal"
        self.tags: List[str] = []
        self.schema_fields: List[Dict] = []
        self.lineage_upstream: List[str] = []
        self.lineage_downstream: List[str] = []
        self.quality_score = 0.0
        self.usage_stats = {"access_count": 0, "last_accessed": None, "unique_users": set()}
        self.metadata: Dict[str, Any] = {}
        self.custom_properties: Dict[str, Any] = {}
        self.created_at = datetime.now(timezone.utc).isoformat()
        self.updated_at = datetime.now(timezone.utc).isoformat()
        self.version = 1
        self.certifications: List[Dict] = []

    def to_dict(self) -> Dict:
        return {
            "asset_id": self.asset_id, "name": self.name, "asset_type": self.asset_type,
            "owner": self.owner, "datasource": self.datasource, "description": self.description,
            "status": self.status, "classification": self.classification, "tags": self.tags,
            "schema_fields": self.schema_fields, "lineage_upstream": self.lineage_upstream,
            "lineage_downstream": self.lineage_downstream, "quality_score": self.quality_score,
            "usage_stats": {"access_count": self.usage_stats["access_count"],
                            "last_accessed": self.usage_stats["last_accessed"],
                            "unique_users": len(self.usage_stats["unique_users"])},
            "metadata": self.metadata, "custom_properties": self.custom_properties,
            "created_at": self.created_at, "updated_at": self.updated_at,
            "version": self.version, "certifications": self.certifications,
        }


class SchemaComparator:
    """Compare schemas between versions, detect breaking changes, generate migration suggestions."""

    def __init__(self):
        self.comparison_history: List[Dict] = []

    def compare(self, old_schema: List[Dict], new_schema: List[Dict]) -> Dict:
        old_map = {f["name"]: f for f in old_schema}
        new_map = {f["name"]: f for f in new_schema}
        added = [n for n in new_map if n not in old_map]
        removed = [n for n in old_map if n not in new_map]
        modified = []
        breaking = []
        for name in new_map:
            if name in old_map:
                o, n = old_map[name], new_map[name]
                changes = {}
                if o.get("type") != n.get("type"):
                    changes["type"] = {"old": o.get("type"), "new": n.get("type")}
                    breaking.append({"field": name, "change": "type_changed",
                                     "from": o.get("type"), "to": n.get("type")})
                if o.get("nullable") and not n.get("nullable"):
                    changes["nullable"] = {"old": True, "new": False}
                    breaking.append({"field": name, "change": "nullable_removed"})
                if changes:
                    modified.append({"field": name, "changes": changes})
        result = {"added": len(added), "removed": len(removed), "modified": len(modified),
                  "breaking_changes": breaking, "added_fields": added, "removed_fields": removed,
                  "modified_fields": modified, "is_backward_compatible": len(breaking) == 0}
        self.comparison_history.append({"timestamp": datetime.now(timezone.utc).isoformat(), **result})
        return result

    def suggest_migration(self, changes: Dict) -> Dict:
        suggestions = []
        for b in changes.get("breaking_changes", []):
            if b["change"] == "type_changed":
                suggestions.append(f"Add CAST({b['field']}) migration for {b['from']} to {b['to']}")
            elif b["change"] == "nullable_removed":
                suggestions.append(f"Set DEFAULT or backfill {b['field']} before removing nullable")
        for f in changes.get("removed_fields", []):
            suggestions.append(f"Verify no downstream dependencies on column {f}")
        return {"suggestions": suggestions, "risk_level": "high" if changes.get("breaking_changes") else "low"}


class DataCatalog(EnterpriseModule):
    MODULE_ID = "data_catalog"
    MODULE_NAME = "DataCatalog"
    VERSION = "2.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._assets: Dict[str, DataAsset] = {}
        self._schema_comparator = SchemaComparator()
        self._search_index: Dict[str, List[str]] = defaultdict(list)
        self._datasets: Dict[str, Dict] = {}
        self._business_terms: Dict[str, Dict] = {}
        self._access_requests: List[Dict] = []
        self._audit_log: List[Dict] = []
        self._operation_count = 0
        self._error_count = 0

    def execute(self, action: 

str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                handler = getattr(self, f"_action_{action}", None)
                if handler:
                    result = handler(params)
                else:
                    return {"success": False, "error": f"Unknown action: {action}"}
                self._operation_count += 1
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                self._error_count += 1
                return {"success": False, "error": str(e), "action": action}

    def _action_register_asset(self, p: Dict) -> Dict:
        aid = p.get("asset_id", f"asset_{uuid.uuid4().hex[:8]}")
        asset = DataAsset(aid, p["name"], p["asset_type"], p["owner"],
                          p.get("datasource", ""), p.get("description", ""))
        if "tags" in p:
            asset.tags = p["tags"]
        if "classification" in p:
            asset.classification = p["classification"]
        if "schema_fields" in p:
            asset.schema_fields = p["schema_fields"]
        if "metadata" in p:
            asset.metadata = p["metadata"]
        if "datasource" in p:
            asset.datasource = p["datasource"]
        self._assets[aid] = asset
        self._update_search_index(asset)
        return {"asset_id": aid, "name": asset.name}

    def _action_get_asset(self, p: Dict) -> Dict:
        aid = p.get("asset_id", "")
        if aid not in self._assets:
            return {"error": "Asset not found"}
        self._record_access(aid)
        return self._assets[aid].to_dict()

    def _action_update_asset(self, p: Dict) -> Dict:
        aid = p.get("asset_id", "")
        if aid not in self._assets:
            return {"error": "Asset not found"}
        asset = self._assets[aid]
        for key in ("name", "description", "owner", "status", "classification"):
            if key in p:
                setattr(asset, key, p[key])
        if "tags" in p:
            asset.tags = p["tags"]
        if "metadata" in p:
            asset.metadata.update(p["metadata"])
        asset.version += 1
        asset.updated_at = datetime.now(timezone.utc).isoformat()
        self._update_search_index(asset)
        return {"asset_id": aid, "version": asset.version}

    def _action_delete_asset(self, p: Dict) -> Dict:
        aid = p.get("asset_id", "")
        if aid not in self._assets:
            return {"error": "Asset not found"}
        del self._assets[aid]
        return {"asset_id": aid, "deleted": True}

    def _action_search_assets(self, p: Dict) -> Dict:
        query = p.get("query", "").lower()
        filters = p.get("filters", {})
        results = []
        for aid, asset in self._assets.items():
            text = f"{asset.name} {asset.description} {' '.join(asset.tags)} {asset.owner}".lower()
            if query and query not in text:
                continue
            if filters.get("type") and asset.asset_type != filters["type"]:
                continue
            if filters.get("owner") and asset.owner != filters["owner"]:
                continue
            if filters.get("status") and asset.status != filters["status"]:
                continue
            if filters.get("classification") and asset.classification != filters["classification"]:
                continue
            if filters.get("datasource") and asset.datasource != filters["datasource"]:
                continue
            results.append(asset.to_dict())
        limit = p.get("limit", 50)
        return {"results": results[:limit], "total": len(results)}

    def _action_list_assets(self, p: Dict) -> Dict:
        assets = list(self._assets.values())
        asset_type = p.get("asset_type")
        owner = p.get("owner")
        if asset_type:
            assets = [a for a in assets if a.asset_type == asset_type]
        if owner:
            assets = [a for a in assets if a.owner == owner]
        return {"assets": [a.to_dict() for a in assets], "count": len(assets)}

    def _action_add_lineage(self, p: Dict) -> Dict:
        aid = p.get("asset_id", "")
        if aid not in self._assets:
            return {"error": "Asset not found"}
        asset = self._assets[aid]
        if p.get("upstream"):
            for up in p["upstream"]:
                if up not in asset.lineage_upstream:
                    asset.lineage_upstream.append(up)
        if p.get("downstream"):
            for dn in p["downstream"]:
                if dn not in asset.lineage_downstream:
                    asset.lineage_downstream.append(dn)
        return {"asset_id": aid, "upstream": asset.lineage_upstream, "downstream": asset.lineage_downstream}

    def _action_get_lineage(self, p: Dict) -> Dict:
        aid = p.get("asset_id", "")
        depth = p.get("depth", 3)
        visited = set()
        graph = {}
        def _traverse(current, d):
            if current in visited or d <= 0:
                return
            visited.add(current)
            node = {"asset_id": current, "upstream": [], "downstream": []}
            asset = self._assets.get(current)
            if asset:
                node["name"] = asset.name
                for up in asset.lineage_upstream:
                    node["upstream"].append(up)
                    _traverse(up, d - 1)
                for dn in asset.lineage_downstream:
                    node["downstream"].append(dn)
                    _traverse(dn, d - 1)
            graph[current] = node
        _traverse(aid, depth)
        return {"asset_id": aid, "lineage_graph": graph, "depth": depth}

    def _action_update_schema(self, p: Dict) -> Dict:
        aid = p.get("asset_id", "")
        if aid not in self._assets:
            return {"error": "Asset not found"}
        asset = self._assets[aid]
        old_schema = asset.schema_fields[:]
        new_schema = p.get("schema_fields", [])
        comparison = self._schema_comparator.compare(old_schema, new_schema)
        migration = self._schema_comparator.suggest_migration(comparison)
        asset.schema_fields = new_schema
        asset.version += 1
        asset.updated_at = datetime.now(timezone.utc).isoformat()
        return {"asset_id": aid, "schema_changes": comparison, "migration_suggestions": migration}

    def _action_get_schema(self, p: Dict) -> Dict:
        aid = p.get("asset_id", "")
        if aid not in self._assets:
            return {"error": "Asset not found"}
        return {"asset_id": aid, "schema_fields": self._assets[aid].schema_fields}

    def _action_set_quality_score(self, p: Dict) -> Dict:
        aid = p.get("asset_id", "")
        if aid not in self._assets:
            return {"error": "Asset not found"}
        self._assets[aid].quality_score = p.get("score", 0.0)
        return {"asset_id": aid, "quality_score": self._assets[aid].quality_score}

    def _action_get_quality_report(self, p: Dict) -> Dict:
        results = []
        for aid, asset in self._assets.items():
            if asset.quality_score > 0:
                results.append({"asset_id": aid, "name": asset.name, "quality_score": asset.quality_score})
        results.sort(key=lambda x: x["quality_score"], reverse=True)
        avg = sum(r["quality_score"] for r in results) / max(1, len(results))
        return {"assets": results, "average_score": round(avg, 2), "total_scored": len(results)}

    def _action_register_dataset(self, p: Dict) -> Dict:
        ds_id = p.get("dataset_id", f"ds_{uuid.uuid4().hex[:8]}")
        ds = {"dataset_id": ds_id, "name": p["name"], "description": p.get("description", ""),
              "tables": p.get("tables", []), "owner": p.get("owner", ""),
              "frequency": p.get("frequency", "daily"), "format": p.get("format", "parquet"),
              "size_bytes": p.get("size_bytes", 0), "row_count": p.get("row_count", 0),
              "created_at": datetime.now(timezone.utc).isoformat()}
        self._datasets[ds_id] = ds
        return {"dataset_id": ds_id}

    def _action_add_business_term(self, p: Dict) -> Dict:
        tid = p.get("term_id", f"term_{uuid.uuid4().hex[:8]}")
        term = {"term_id": tid, "name": p["name"], "definition": p.get("definition", ""),
                "category": p.get("category", "general"), "related_assets": p.get("related_assets", []),
                "steward": p.get("steward", "")}
        self._business_terms[tid] = term
        return {"term_id": tid}

    def _action_request_access(self, p: Dict) -> Dict:
        req = {"request_id": f"ar_{uuid.uuid4().hex[:8]}", "asset_id": p["asset_id"],
               "requester": p.get("requester", ""), "purpose": p.get("purpose", ""),
               "status": "pending", "created_at": datetime.now(timezone.utc).isoformat()}
        self._access_requests.append(req)
        return {"request_id": req["request_id"], "status": "pending"}

    def _action_list_access_requests(self, p: Dict) -> Dict:
        status_filter = p.get("status")
        reqs = self._access_requests
        if status_filter:
            reqs = [r for r in reqs if r["status"] == status_filter]
        return {"requests": reqs, "count": len(reqs)}

    def _action_tag_asset(self, p: Dict) -> Dict:
        aid = p.get("asset_id", "")
        if aid not in self._assets:
            return {"error": "Asset not found"}
        asset = self._assets[aid]
        for tag in p.get("tags", []):
            if tag not in asset.tags:
                asset.tags.append(tag)
        self._update_search_index(asset)
        return {"asset_id": aid, "tags": asset.tags}

    def _action_stats(self, p: Dict) -> Dict:
        by_type = defaultdict(int)
        by_status = defaultdict(int)
        by_class = defaultdict(int)
        for a in self._assets.values():
            by_type[a.asset_type] += 1
            by_status[a.status] += 1
            by_class[a.classification] += 1
        return {"total_assets": len(self._assets), "total_datasets": len(self._datasets),
                "total_business_terms": len(self._business_terms),
                "access_requests": len(self._access_requests),
                "by_type": dict(by_type), "by_status": dict(by_status),
                "by_classification": dict(by_class)}

    def _action_status(self, p: Dict) -> Dict:
        return {"module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
                "version": self.VERSION, "assets_count": len(self._assets),
                "datasets_count": len(self._datasets), "status": "running"}

    def _action_health(self, p: Dict) -> Dict:
        return {"healthy": True, "status": "ok", "assets": len(self._assets)}

    def _action_configure(self, p: Dict) -> Dict:
        return {"configured": list(p.keys()), "status": "ok"}

    def _action_reset(self, p: Dict) -> Dict:
        self._assets.clear()
        self._datasets.clear()
        self._business_terms.clear()
        self._access_requests.clear()
        self._search_index.clear()
        return {"status": "reset_ok"}

    def _update_search_index(self, asset: DataAsset):
        for tag in asset.tags:
            if asset.asset_id not in self._search_index[tag]:
                self._search_index[tag].append(asset.asset_id)

    def _record_access(self, aid: str, user: str = "anonymous"):
        if aid in self._assets:
            self._assets[aid].usage_stats["access_count"] += 1
            self._assets[aid].usage_stats["last_accessed"] = datetime.now(timezone.utc).isoformat()
            self._assets[aid].usage_stats["unique_users"].add(user)


module_class = DataCatalog
