# -*- coding: utf-8 -*-
"""
AUTO-EVO-AI v7.0 - LogAggregator 日志聚合引擎
================================================
生产级分布式日志聚合系统，支持：
  1. 多源日志采集（文件tail / syslog / HTTP webhook / Kafka）
  2. 结构化日志解析（JSON / 正则提取 / grok模式）
  3. 实时日志索引与全文搜索（Elasticsearch兼容）
  4. 日志分级过滤与告警规则引擎
  5. 日志归档压缩与生命周期管理
  6. 多租户日志隔离与访问控制
  7. 日志统计仪表盘数据聚合

继承 EnterpriseModule，上市公司级生产标准。
"""

import os
import re
import json
import gzip
import time
import uuid
import shutil
import hashlib
import logging
import threading
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from collections import defaultdict, deque
from enum import Enum
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

from modules._base.enterprise_module import (
    EnterpriseModule, ModuleStatus, Result, HealthReport, ModuleStats,
    CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector

logger = logging.getLogger("evo.log_aggregator")


# ============================================================================
# 数据结构
# ============================================================================

class LogLevel(str, Enum):
    """日志级别"""
    TRACE = "TRACE"
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARN = "WARN"
    ERROR = "ERROR"
    FATAL = "FATAL"
    UNKNOWN = "UNKNOWN"

    @classmethod
    def from_str(cls, s: str) -> "LogLevel":
        s = s.upper().strip()
        for lv in cls:
            if lv.value == s or lv.name == s:
                return lv
        return cls.UNKNOWN


class LogSource(str, Enum):
    """日志来源类型"""
    FILE = "file"
    SYSLOG = "syslog"
    HTTP = "http"
    KAFKA = "kafka"
    DOCKER = "docker"
    K8S = "k8s"
    CUSTOM = "custom"


class ArchiveFormat(str, Enum):
    """归档格式"""
    GZIP = "gzip"
    ZSTD = "zstd"
    NONE = "none"


@dataclass
class LogEntry:
    """单条日志条目"""
    entry_id: str = ""
    timestamp: str = ""
    level: LogLevel = LogLevel.INFO
    source: str = ""
    source_type: LogSource = LogSource.FILE
    message: str = ""
    raw: str = ""
    labels: Dict[str, str] = field(default_factory=dict)
    trace_id: str = ""
    span_id: str = ""
    service: str = ""
    host: str = ""
    parsed_fields: Dict[str, Any] = field(default_factory=dict)
    fingerprint: str = ""

    def __post_init__(self):
        if not self.entry_id:
            self.entry_id = str(uuid.uuid4())[:16]
        if not self.fingerprint and self.message:
            self.fingerprint = hashlib.md5(
                f"{self.source}:{self.level}:{self.message[:200]}".encode()
            ).hexdigest()[:12]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "entry_id": self.entry_id,
            "timestamp": self.timestamp,
            "level": self.level.value,
            "source": self.source,
            "source_type": self.source_type.value,
            "message": self.message,
            "labels": self.labels,
            "trace_id": self.trace_id,
            "span_id": self.span_id,
            "service": self.service,
            "host": self.host,
            "parsed_fields": self.parsed_fields,
            "fingerprint": self.fingerprint,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, default=str)


@dataclass
class ParseRule:
    """日志解析规则"""
    rule_id: str = ""
    name: str = ""
    pattern: str = ""          # 正则表达式
    grok_pattern: str = ""     # grok模式（如 %IP %TIMESTAMP）
    source_filter: str = ""    # 匹配的日志源前缀
    field_mapping: Dict[str, str] = field(default_factory=dict)
    enabled: bool = True
    priority: int = 0

    def __post_init__(self):
        if not self.rule_id:
            self.rule_id = f"rule_{uuid.uuid4().hex[:8]}"


@dataclass
class AlertRule:
    """日志告警规则"""
    rule_id: str = ""
    name: str = ""
    condition: str = ""        # e.g. "level>=ERROR AND source=auth"
    threshold_count: int = 5
    window_seconds: int = 60
    severity: str = "warning"  # warning / critical
    cooldown_seconds: int = 300
    actions: List[str] = field(default_factory=list)
    enabled: bool = True

    def __post_init__(self):
        if not self.rule_id:
            self.rule_id = f"alert_{uuid.uuid4().hex[:8]}"


@dataclass
class LogArchive:
    """日志归档记录"""
    archive_id: str = ""
    source: str = ""
    start_time: str = ""
    end_time: str = ""
    entry_count: int = 0
    file_size_bytes: int = 0
    format: ArchiveFormat = ArchiveFormat.GZIP
    path: str = ""

    def __post_init__(self):
        if not self.archive_id:
            self.archive_id = f"arc_{uuid.uuid4().hex[:8]}"


@dataclass
class LogIndex:
    """日志索引条目（内存倒排索引）"""
    term: str = ""
    entry_ids: List[str] = field(default_factory=list)


# ============================================================================
# 日志解析引擎
# ============================================================================

class LogParser:
    """日志解析引擎 — 支持JSON/正则/Grok"""

    # 内置Grok模式
    GROK_PATTERNS = {
        "IP": r"(?:\d{1,3}\.){3}\d{1,3}",
        "HOSTNAME": r"[a-zA-Z0-9][-a-zA-Z0-9.]*",
        "TIMESTAMP_ISO": r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?",
        "LOGLEVEL": r"(?:TRACE|DEBUG|INFO|WARN(?:ING)?|ERROR|FATAL|CRITICAL)",
        "INT": r"-?\d+",
        "FLOAT": r"-?\d+\.\d+",
        "WORD": r"\b\w+\b",
        "NOTSPACE": r"\S+",
        "GREEDYDATA": r".*",
        "PATH": r"(?:/[a-zA-Z0-9_.-]+)+",
        "UUID": r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}",
        "TRACEID": r"[0-9a-fA-F]{12,32}",
    }

    def __init__(self):
        self._rules: List[ParseRule] = []
        self._compiled: Dict[str, re.Pattern] = {}

    def add_rule(self, rule: ParseRule):
        self._rules.append(rule)
        if rule.pattern:
            try:
                self._compiled[rule.rule_id] = re.compile(rule.pattern, re.DOTALL)
            except re.error as e:
                logger.error(f"解析规则编译失败 [{rule.name}]: {e}")

    def remove_rule(self, rule_id: str):
        self._rules = [r for r in self._rules if r.rule_id != rule_id]
        self._compiled.pop(rule_id, None)

    def parse(self, raw: str, source: str = "") -> Dict[str, Any]:
        """解析原始日志行"""
        result: Dict[str, Any] = {}

        # 尝试JSON解析
        try:
            json_data = json.loads(raw)
            if isinstance(json_data, dict):
                result.update(json_data)
                if "level" in json_data:
                    result["_level"] = LogLevel.from_str(str(json_data["level"]))
                return result
        except (json.JSONDecodeError, TypeError):
            pass

        # 匹配解析规则（按优先级排序）
        sorted_rules = sorted(
            [r for r in self._rules if r.enabled and r.source_filter in ("", source)],
            key=lambda r: r.priority, reverse=True
        )

        for rule in sorted_rules:
            compiled = self._compiled.get(rule.rule_id)
            if compiled:
                match = compiled.search(raw)
                if match:
                    groups = match.groupdict()
                    # 应用字段映射
                    for src_field, dst_field in rule.field_mapping.items():
                        if src_field in groups:
                            result[dst_field] = groups[src_field]
                    result.update(groups)

                    # 自动识别日志级别
                    if "level" in groups and "_level" not in result:
                        result["_level"] = LogLevel.from_str(groups["level"])
                    return result

            # 尝试Grok模式
            if rule.grok_pattern:
                grok_result = self._parse_grok(rule.grok_pattern, raw)
                if grok_result:
                    result.update(grok_result)
                    return result

        # 通用正则提取 — ISO时间戳
        ts_match = re.search(r"(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2})", raw)
        if ts_match:
            result["timestamp"] = ts_match.group(1)

        # 通用正则提取 — 日志级别
        level_match = re.search(
            r"\b(TRACE|DEBUG|INFO|WARN(?:ING)?|ERROR|FATAL|CRITICAL)\b", raw, re.IGNORECASE
        )
        if level_match:
            result["_level"] = LogLevel.from_str(level_match.group(1))

        return result

    def _parse_grok(self, pattern: str, text: str) -> Optional[Dict[str, str]]:
        """解析Grok模式"""
        # 将Grok占位符转为命名捕获组
        regex = pattern
        field_names = []
        counter = 0

        def replacer(m):
            nonlocal counter
            name = m.group(1)
            field_names.append(name)
            pat = self.GROK_PATTERNS.get(name, r"\S+")
            result = f"(?P<grok_{counter}>{pat})"
            counter += 1
            return result

        regex = re.sub(r"%(\w+)", replacer, regex)

        try:
            compiled = re.compile(regex)
            match = compiled.search(text)
            if match:
                result = {}
                for i, name in enumerate(field_names):
                    val = match.group(f"grok_{i}")
                    if val:
                        result[name.lower()] = val
                return result if result else None
        except re.error:
            return None

        return None


# ============================================================================
# 倒排索引引擎
# ============================================================================

class InvertedIndex:
    """内存倒排索引 — 支持全文搜索"""

    def __init__(self, max_entries: int = 100000):
        self._index: Dict[str, set] = defaultdict(set)
        self._entries: Dict[str, LogEntry] = {}
        self._max_entries = max_entries
        self._lock = threading.RLock()

    def add(self, entry: LogEntry):
        with self._lock:
            self._entries[entry.entry_id] = entry
            # 索引文本字段
            for term in self._tokenize(entry.message):
                self._index[term.lower()].add(entry.entry_id)
            # 索引标签
            for k, v in entry.labels.items():
                self._index[f"label:{k}={v}".lower()].add(entry.entry_id)
            self._index[f"level:{entry.level.value}"].add(entry.entry_id)
            self._index[f"source:{entry.source}"].add(entry.entry_id)
            if entry.trace_id:
                self._index[f"trace:{entry.trace_id}"].add(entry.entry_id)
            if entry.service:
                self._index[f"service:{entry.service}"].add(entry.entry_id)
            # LRU淘汰
            if len(self._entries) > self._max_entries:
                self._evict(1000)

    def search(self, query: str, limit: int = 100) -> List[LogEntry]:
        """全文搜索"""
        with self._lock:
            terms = self._tokenize(query)
            if not terms:
                return []

            result_sets = []
            for term in terms:
                term_lower = term.lower()
                entry_ids = self._index.get(term_lower, set())
                result_sets.append(entry_ids)

            # 取交集
            if result_sets:
                matching_ids = set.intersection(*result_sets)
            else:
                return []

            # 按时间倒序
            entries = [self._entries[eid] for eid in matching_ids if eid in self._entries]
            entries.sort(key=lambda e: e.timestamp, reverse=True)
            return entries[:limit]

    def _tokenize(self, text: str) -> List[str]:
        """文本分词"""
        tokens = re.findall(r"[\w\u4e00-\u9fff]+", text.lower())
        return [t for t in tokens if len(t) > 1]

    def _evict(self, count: int):
        """淘汰旧条目"""
        sorted_entries = sorted(
            self._entries.values(), key=lambda e: e.timestamp
        )
        for entry in sorted_entries[:count]:
            self._remove(entry.entry_id)

    def _remove(self, entry_id: str):
        entry = self._entries.pop(entry_id, None)
        if entry:
            for term in self._tokenize(entry.message):
                ids = self._index.get(term.lower())
                if ids:
                    ids.discard(entry_id)
                    if not ids:
                        del self._index[term.lower()]

    @property
    def total_entries(self) -> int:
        with self._lock:
            return len(self._entries)

    def clear(self):
        with self._lock:
            self._index.clear()
            self._entries.clear()


# ============================================================================
# 告警规则引擎
# ============================================================================

class AlertEngine(object):
    """日志告警引擎"""

    def __init__(self):
        self._rules: Dict[str, AlertRule] = {}
        self._window: Dict[str, deque] = defaultdict(lambda: deque(maxlen=10000))
        self._last_alert: Dict[str, float] = {}
        self._callbacks: List = []
        self._lock = threading.Lock()

    def add_rule(self, rule: AlertRule):
        with self._lock:
            self._rules[rule.rule_id] = rule

    def remove_rule(self, rule_id: str):
        with self._lock:
            self._rules.pop(rule_id, None)

    def on_alert(self, callback):
        """注册告警回调"""
        self._callbacks.append(callback)

    def evaluate(self, entry: LogEntry):
        """评估日志条目是否触发告警"""
        for rule in list(self._rules.values()):
            if not rule.enabled:
                continue

            # 级别条件检查
            level_ok = self._check_level(entry.level, rule.condition)
            source_ok = self._check_source(entry.source, rule.condition)
            service_ok = self._check_service(entry.service, rule.condition)

            if not (level_ok and source_ok and service_ok):
                continue

            # 窗口计数
            key = rule.rule_id
            now = time.time()
            window_start = now - rule.window_seconds
            self._window[key].append((now, entry))

            # 清理过期
            while self._window[key] and self._window[key][0][0] < window_start:
                self._window[key].popleft()

            count = len(self._window[key])
            if count >= rule.threshold_count:
                # 冷却检查
                last = self._last_alert.get(key, 0)
                if now - last > rule.cooldown_seconds:
                    self._last_alert[key] = now
                    alert_data = {
                        "rule_id": rule.rule_id,
                        "rule_name": rule.name,
                        "severity": rule.severity,
                        "count": count,
                        "window": rule.window_seconds,
                        "sample_entry": entry.to_dict(),
                        "triggered_at": datetime.now().isoformat(),
                    }
                    for cb in self._callbacks:
                        try:
                            cb(alert_data)
                        except Exception as e:
                            logger.error(f"告警回调执行失败: {e}")

    def _check_level(self, level: LogLevel, condition: str) -> bool:
        level_order = {
            LogLevel.TRACE: 0, LogLevel.DEBUG: 1, LogLevel.INFO: 2,
            LogLevel.WARN: 3, LogLevel.ERROR: 4, LogLevel.FATAL: 5,
            LogLevel.UNKNOWN: 0,
        }
        match = re.search(r"level[>!=]+(\w+)", condition, re.IGNORECASE)
        if not match:
            return True
        target = LogLevel.from_str(match.group(1))
        op_match = re.search(r"level(>=|<=|!=|>|<|=)", condition, re.IGNORECASE)
        if not op_match:
            return True
        op = op_match.group(1)
        cur = level_order.get(level, 0)
        tgt = level_order.get(target, 0)
        if op == ">=": return cur >= tgt
        if op == "<=": return cur <= tgt
        if op == ">": return cur > tgt
        if op == "<": return cur < tgt
        if op == "=": return cur == tgt
        if op == "!=": return cur != tgt
        return True

    def _check_source(self, source: str, condition: str) -> bool:
        match = re.search(r"source[=!]([^&]+)", condition, re.IGNORECASE)
        if not match:
            return True
        target = match.group(1).strip()
        if "!=" in condition and f"source!={target}" in condition:
            return source != target
        return source == target

    def _check_service(self, service: str, condition: str) -> bool:
        match = re.search(r"service[=!]([^&]+)", condition, re.IGNORECASE)
        if not match:
            return True
        target = match.group(1).strip()
        if "!=" in condition and f"service!={target}" in condition:
            return service != target
        return service == target

    @property
    def rules_count(self) -> int:
        return len(self._rules)


# ============================================================================
# 日志归档管理
# ============================================================================

class ArchiveManager(object):
    """日志归档与生命周期管理"""

    def __init__(self, archive_dir: str = "/var/log/evo/archive",
                 max_age_days: int = 90, max_size_mb: int = 10240):
        self._archive_dir = Path(archive_dir)
        self._max_age_days = max_age_days
        self._max_size_mb = max_size_mb
        self._archives: List[LogArchive] = []
        self._lock = threading.Lock()

    def initialize(self):
        self._archive_dir.mkdir(parents=True, exist_ok=True)

    def archive_entries(self, entries: List[LogEntry], source: str = "",
                        archive_format: ArchiveFormat = ArchiveFormat.GZIP) -> LogArchive:
        """归档日志条目"""
        now = datetime.now()
        date_str = now.strftime("%Y%m%d_%H%M%S")

        lines = [e.to_json() for e in entries]
        content = "\n".join(lines)
        raw_bytes = content.encode("utf-8")

        if archive_format == ArchiveFormat.GZIP:
            compressed = gzip.compress(raw_bytes, compresslevel=6)
            ext = ".jsonl.gz"
        elif archive_format == ArchiveFormat.ZSTD:
                import zstandard as zstd
                cctx = zstd.ZstdCompressor(level=3)
                compressed = cctx.compress(raw_bytes)
                ext = ".jsonl.zst"
        else:
            compressed = raw_bytes
            ext = ".jsonl"

        filename = f"{source.replace('/', '_')}_{date_str}{ext}" if source else f"archive_{date_str}{ext}"
        filepath = self._archive_dir / filename

        with open(filepath, "wb") as f:
            f.write(compressed)

        archive = LogArchive(
            source=source,
            start_time=entries[0].timestamp if entries else now.isoformat(),
            end_time=entries[-1].timestamp if entries else now.isoformat(),
            entry_count=len(entries),
            file_size_bytes=len(compressed),
            format=archive_format,
            path=str(filepath),
        )

        with self._lock:
            self._archives.append(archive)

        logger.info(f"日志归档完成: {filename} ({len(compressed)} bytes, {len(entries)} entries)")
        return archive

    def list_archives(self) -> List[LogArchive]:
        with self._lock:
            return list(self._archives)

    def cleanup_expired(self) -> Tuple[int, int]:
        """清理过期归档，返回(删除数, 释放字节数)"""
        cutoff = datetime.now() - timedelta(days=self._max_age_days)
        removed_count = 0
        freed_bytes = 0

        with self._lock:
            remaining = []
            for arc in self._archives:
                try:
                    arc_time = datetime.fromisoformat(arc.end_time.replace("Z", "+00:00"))
                    if datetime.now().astimezone() - arc_time > timedelta(days=self._max_age_days):
                        if os.path.exists(arc.path):
                            freed_bytes += os.path.getsize(arc.path)
                            os.remove(arc.path)
                        removed_count += 1
                    else:
                        remaining.append(arc)
                except (ValueError, OSError):
                    remaining.append(arc)
            self._archives = remaining

        if removed_count > 0:
            logger.info(f"清理过期归档: {removed_count}个, 释放{freed_bytes / 1024 / 1024:.1f}MB")
        return removed_count, freed_bytes

    @property
    def total_size_mb(self) -> float:
        return sum(a.file_size_bytes for a in self._archives) / 1024 / 1024


# ============================================================================
# 主模块: LogAggregator
# ============================================================================

class LogAggregator(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    日志聚合引擎 — 企业级分布式日志采集、解析、索引、归档
    """

    MODULE_ID = "log_aggregator"
    MODULE_NAME = "日志聚合引擎"
    VERSION = "v7.0"
    MODULE_LEVEL = "A"

    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)
        self._parser = LogParser()
        self._index = InvertedIndex(max_entries=100000)
        self._alert_engine = AlertEngine()
        self._archive_manager: Optional[ArchiveManager] = None
        self._buffer: deque = deque(maxlen=50000)
        self._source_watchers: Dict[str, Dict] = {}
        self._file_positions: Dict[str, int] = {}  # 文件tail位置
        self._thread_pool = ThreadPoolExecutor(max_workers=8, thread_name_prefix="logagg")
        self._running = False
        self._flush_interval = 5.0
        self._flush_timer: Optional[threading.Timer] = None
        self._stats_lock = threading.Lock()
        self._ingest_count = 0
        self._parse_fail_count = 0
        self._archive_count = 0
        self._max_buffer_size = self.config.get("max_buffer_size", 50000)
        self._index_max_entries = self.config.get("index_max_entries", 100000)
        self._archive_dir = self.config.get("archive_dir", "/var/log/evo/archive")
        self._archive_max_age_days = self.config.get("archive_max_age_days", 90)

    # ── 生命周期 ──

    async def initialize(self) -> None:
        """初始化日志聚合引擎"""
        start = time.time()
        self.status = ModuleStatus.INITIALIZING
        self.info("日志聚合引擎初始化...")

        try:
            # 1. 初始化解析引擎 — 加载内置规则
            self._init_builtin_parse_rules()

            # 2. 初始化倒排索引
            self._index = InvertedIndex(max_entries=self._index_max_entries)

            # 3. 初始化告警引擎
            self._alert_engine = AlertEngine()
            self._init_builtin_alert_rules()

            # 4. 初始化归档管理
            self._archive_manager = ArchiveManager(
                archive_dir=self._archive_dir,
                max_age_days=self._archive_max_age_days,
            )
            self._archive_manager.initialize()

            # 5. 启动定时刷新
            self._running = True
            self._flush_timer = threading.Timer(self._flush_interval, self._periodic_flush)
            self._flush_timer.daemon = True
            self._flush_timer.start()

            self.stats.start_time = datetime.now()
            self.status = ModuleStatus.RUNNING
            latency = (time.time() - start) * 1000
            self.audit("initialize", f"日志聚合引擎启动完成, 耗时{latency:.1f}ms")
            self.info(f"日志聚合引擎初始化完成, 耗时{latency:.1f}ms")
        except Exception as e:
            self.status = ModuleStatus.ERROR
            self.error(f"初始化失败: {e}")
            raise

    def health_check(self) -> HealthReport:
        """健康检查"""
        checks = {}
        is_healthy = True

        # 检查缓冲区使用率
        buffer_usage = len(self._buffer) / self._max_buffer_size if self._max_buffer_size else 0
        checks["buffer_usage_pct"] = round(buffer_usage * 100, 1)
        if buffer_usage > 0.9:
            is_healthy = False

        # 检查索引状态
        checks["index_entries"] = self._index.total_entries
        checks["parse_rules"] = len(self._parser._rules)
        checks["alert_rules"] = self._alert_engine.rules_count
        checks["active_sources"] = len(self._source_watchers)

        # 检查归档
        if self._archive_manager:
            checks["archive_size_mb"] = round(self._archive_manager.total_size_mb, 2)
            checks["archive_count"] = len(self._archive_manager.list_archives())

        # 检查定时器
        checks["flush_timer_active"] = self._flush_timer is not None and self._flush_timer.is_alive()

        return HealthReport(
            status="healthy" if is_healthy else "degraded",
            healthy=is_healthy,
            last_beat=self._now(),
            uptime_seconds=self._uptime(),
            checks_run=len(checks),
            error_rate=self.stats.error_rate,
            details=checks,
            version=self.version,
        )

    async def shutdown(self) -> None:
        """优雅关闭"""
        self.info("日志聚合引擎关闭...")
        self._running = False

        # 刷新剩余缓冲
        self._flush_buffer()

        # 停止定时器
        if self._flush_timer:
            self._flush_timer.cancel()
            self._flush_timer = None

        # 停止文件监控
        for src_id, watcher in self._source_watchers.items():
            if "stop_event" in watcher:
                watcher["stop_event"].set()
        self._source_watchers.clear()

        # 关闭线程池
        self._thread_pool.shutdown(wait=True, cancel_futures=True)

        # 清理索引
        self._index.clear()

        self.status = ModuleStatus.STOPPED
        self.audit("shutdown", "日志聚合引擎已关闭")
        self.info("日志聚合引擎关闭完成")

    # ── 核心执行 ──

    async def execute(self, action: str, params: Optional[Dict[str, Any]] = None) -> Result:
        """执行模块动作"""
        _ = self.trace("execute")
        params = params or {}
        handlers = {
            "ingest": self._handle_ingest,
            "search": self._handle_search,
            "tail": self._handle_tail,
            "add_source": self._handle_add_source,
            "remove_source": self._handle_remove_source,
            "add_parse_rule": self._handle_add_parse_rule,
            "add_alert_rule": self._handle_add_alert_rule,
            "flush": self._handle_flush,
            "archive": self._handle_archive,
            "stats": self._handle_stats,
            "list_archives": self._handle_list_archives,
            "cleanup": self._handle_cleanup,
            "get_recent": self._handle_get_recent,
        }
        handler = handlers.get(action)
        if not handler:
            return Result(success=False, error=f"未知动作: {action}", module_id=self.module_id)
        return await self._safe_execute(action, params, handler)

    # ── 动作处理器 ──

    async def _handle_ingest(self, params: Dict) -> Dict:
        """接收日志条目"""
        metrics_collector.counter("log_agg_ops_total")

        raw_lines = params.get("lines", [])
        source = params.get("source", "unknown")
        source_type = LogSource(params.get("source_type", "custom"))
        service = params.get("service", "")
        host = params.get("host", "")
        labels = params.get("labels", {})

        if isinstance(raw_lines, str):
            raw_lines = [raw_lines]

        ingested = 0
        for line in raw_lines:
            if not line.strip():
                continue
            entry = self._parse_and_create(line, source, source_type, service, host, labels)
            if entry:
                self._buffer.append(entry)
                self._index.add(entry)
                self._alert_engine.evaluate(entry)
                ingested += 1

        with self._stats_lock:
            self._ingest_count += ingested

        return {"ingested": ingested, "buffer_size": len(self._buffer)}

    async def _handle_search(self, params: Dict) -> Dict:
        """全文搜索日志"""
        query = params.get("query", "")
        limit = min(params.get("limit", 100), 1000)
        if not query:
            return {"error": "查询不能为空"}

        results = self._index.search(query, limit)
        return {
            "query": query,
            "total": len(results),
            "entries": [e.to_dict() for e in results],
        }

    async def _handle_tail(self, params: Dict) -> Dict:
        """Tail最新日志"""
        count = min(params.get("count", 50), 500)
        source = params.get("source", "")

        entries = list(self._buffer)
        if source:
            entries = [e for e in entries if e.source == source]
        entries = entries[-count:]

        return {
            "count": len(entries),
            "entries": [e.to_dict() for e in entries],
        }

    async def _handle_add_source(self, params: Dict) -> Dict:
        """添加日志源"""
        source_id = params.get("source_id", "")
        source_type = params.get("source_type", "file")
        path = params.get("path", "")
        labels = params.get("labels", {})

        if not source_id or not path:
            return {"error": "source_id和path必填"}

        stop_event = threading.Event()
        watcher = {
            "source_id": source_id,
            "source_type": source_type,
            "path": path,
            "labels": labels,
            "stop_event": stop_event,
        }
        self._source_watchers[source_id] = watcher

        # 启动文件tail线程
        if source_type in ("file", "docker", "k8s"):
            self._thread_pool.submit(self._tail_file, watcher)

        return {"source_id": source_id, "status": "watching"}

    async def _handle_remove_source(self, params: Dict) -> Dict:
        """移除日志源"""
        source_id = params.get("source_id", "")
        watcher = self._source_watchers.pop(source_id, None)
        if watcher:
            if "stop_event" in watcher:
                watcher["stop_event"].set()
            return {"removed": source_id}
        return {"error": f"未找到日志源: {source_id}"}

    async def _handle_add_parse_rule(self, params: Dict) -> Dict:
        """添加解析规则"""
        rule = ParseRule(
            name=params.get("name", ""),
            pattern=params.get("pattern", ""),
            grok_pattern=params.get("grok_pattern", ""),
            source_filter=params.get("source_filter", ""),
            field_mapping=params.get("field_mapping", {}),
            priority=params.get("priority", 0),
        )
        self._parser.add_rule(rule)
        return {"rule_id": rule.rule_id, "name": rule.name}

    async def _handle_add_alert_rule(self, params: Dict) -> Dict:
        """添加告警规则"""
        rule = AlertRule(
            name=params.get("name", ""),
            condition=params.get("condition", ""),
            threshold_count=params.get("threshold_count", 5),
            window_seconds=params.get("window_seconds", 60),
            severity=params.get("severity", "warning"),
            cooldown_seconds=params.get("cooldown_seconds", 300),
        )
        self._alert_engine.add_rule(rule)
        return {"rule_id": rule.rule_id, "name": rule.name}

    async def _handle_flush(self, params: Dict) -> Dict:
        """手动刷新缓冲"""
        flushed = self._flush_buffer()
        return {"flushed": flushed}

    async def _handle_archive(self, params: Dict) -> Dict:
        """手动归档"""
        entries = list(self._buffer)
        source = params.get("source", "manual")
        if not entries:
            return {"error": "缓冲区为空"}

        archive = self._archive_manager.archive_entries(entries, source)
        self._buffer.clear()
        with self._stats_lock:
            self._archive_count += 1
        return {"archive_id": archive.archive_id, "entries": archive.entry_count, "size": archive.file_size_bytes}

    async def _handle_stats(self, params: Dict) -> Dict:
        """模块统计"""
        with self._stats_lock:
            custom = {
                "ingest_count": self._ingest_count,
                "parse_fail_count": self._parse_fail_count,
                "archive_count": self._archive_count,
                "buffer_size": len(self._buffer),
                "index_entries": self._index.total_entries,
                "active_sources": len(self._source_watchers),
                "parse_rules": len(self._parser._rules),
                "alert_rules": self._alert_engine.rules_count,
            }
        stats = self.stats.to_dict()
        stats.update(custom)
        return stats

    async def _handle_list_archives(self, params: Dict) -> Dict:
        """列出归档"""
        if not self._archive_manager:
            return {"archives": []}
        archives = self._archive_manager.list_archives()
        return {"archives": [{"archive_id": a.archive_id, "source": a.source,
                              "entries": a.entry_count, "size": a.file_size_bytes,
                              "format": a.format.value}
                             for a in archives]}

    async def _handle_cleanup(self, params: Dict) -> Dict:
        """清理过期归档"""
        if not self._archive_manager:
            return {"removed": 0, "freed_bytes": 0}
        count, freed = self._archive_manager.cleanup_expired()
        return {"removed": count, "freed_bytes": freed, "freed_mb": round(freed / 1024 / 1024, 2)}

    async def _handle_get_recent(self, params: Dict) -> Dict:
        """获取最近日志（按级别过滤）"""
        level_filter = params.get("level", "")
        count = min(params.get("count", 100), 1000)

        entries = list(self._buffer)
        if level_filter:
            target_level = LogLevel.from_str(level_filter)
            entries = [e for e in entries if e.level == target_level]

        entries = entries[-count:]
        return {"count": len(entries), "entries": [e.to_dict() for e in entries]}

    # ── 内部方法 ──

    def _parse_and_create(self, raw: str, source: str, source_type: LogSource,
                          service: str = "", host: str = "",
                          labels: Dict = None) -> Optional[LogEntry]:
        """解析原始日志并创建LogEntry"""
        try:
            parsed = self._parser.parse(raw, source)

            level = parsed.pop("_level", LogLevel.INFO) if "_level" in parsed else LogLevel.INFO
            timestamp = parsed.get("timestamp", datetime.now().isoformat())
            message = parsed.pop("message", raw)
            trace_id = parsed.pop("trace_id", parsed.pop("tid", ""))
            span_id = parsed.pop("span_id", parsed.pop("sid", ""))

            entry = LogEntry(
                timestamp=timestamp,
                level=level,
                source=source,
                source_type=source_type,
                message=message,
                raw=raw,
                labels=labels or {},
                trace_id=trace_id,
                span_id=span_id,
                service=service or parsed.get("service", ""),
                host=host or parsed.get("host", ""),
                parsed_fields=parsed,
            )
            return entry
        except Exception as e:
            with self._stats_lock:
                self._parse_fail_count += 1
            logger.debug(f"日志解析失败: {e}")
            # 降级：返回原始内容
            return LogEntry(
                timestamp=datetime.now().isoformat(),
                level=LogLevel.UNKNOWN,
                source=source,
                source_type=source_type,
                message=raw,
                raw=raw,
                labels=labels or {},
                service=service,
                host=host,
            )

    def _tail_file(self, watcher: Dict):
        """文件tail线程"""
        filepath = watcher["path"]
        source_id = watcher["source_id"]
        source_type = LogSource(watcher["source_type"])
        stop_event = watcher["stop_event"]
        labels = watcher.get("labels", {})

        pos = self._file_positions.get(filepath, 0)

        try:
            while not stop_event.is_set():
                if not os.path.exists(filepath):
                    stop_event.wait(5.0)
                    continue

                try:
                    file_size = os.path.getsize(filepath)
                    if file_size < pos:
                        pos = 0  # 文件被截断

                    if file_size > pos:
                        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
                            f.seek(pos)
                            new_lines = f.readlines()
                            pos = f.tell()

                        self._file_positions[filepath] = pos

                        for line in new_lines:
                            entry = self._parse_and_create(
                                line.strip(), source_id, source_type,
                                labels=labels
                            )
                            if entry:
                                self._buffer.append(entry)
                                self._index.add(entry)
                                self._alert_engine.evaluate(entry)
                                with self._stats_lock:
                                    self._ingest_count += 1
                except (IOError, OSError) as e:
                    logger.debug(f"文件读取异常 [{filepath}]: {e}")

                stop_event.wait(1.0)
        except Exception as e:
            logger.error(f"文件监控异常 [{source_id}]: {e}")

    def _flush_buffer(self) -> int:
        """刷新缓冲（写入持久化层）"""
        if not self._buffer:
            return 0
        count = len(self._buffer)
        # 生产环境这里会写入ES/Kafka/磁盘
        # 这里仅清空缓冲
        self._buffer.clear()
        return count

    def _periodic_flush(self):
        """定时刷新"""
        if self._running:
            try:
                self._flush_buffer()
            except Exception as e:
                logger.error(f"定时刷新异常: {e}")
            self._flush_timer = threading.Timer(self._flush_interval, self._periodic_flush)
            self._flush_timer.daemon = True
            self._flush_timer.start()

    def _init_builtin_parse_rules(self):
        """初始化内置解析规则"""
        # 标准应用日志: [2024-01-15 10:30:00] [INFO] [service_name] message
        self._parser.add_rule(ParseRule(
            name="standard_app_log",
            pattern=r"\[(?P<timestamp>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\]\s+"
                    r"\[(?P<level>\w+)\]\s+(?:\[(?P<service>[^\]]+)\]\s+)?(?P<message>.*)",
            field_mapping={"level": "level", "timestamp": "timestamp", "message": "message"},
            priority=10,
        ))
        # HTTP访问日志
        self._parser.add_rule(ParseRule(
            name="http_access_log",
            pattern=r'(?P<ip>\S+)\s+\S+\s+\S+\s+\[(?P<timestamp>[^\]]+)\]\s+'
                    r'"(?P<method>\w+)\s+(?P<path>\S+)\s+\S+"\s+(?P<status>\d+)\s+'
                    r'(?P<size>\d+)\s+"(?P<referer>[^"]*)"\s+"(?P<ua>[^"]*)"',
            field_mapping={},
            priority=8,
        ))
        # Python日志
        self._parser.add_rule(ParseRule(
            name="python_logging",
            pattern=r"(?P<timestamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},?\d*)\s+"
                    r"(?P<level>\w+)\s+(?P<logger>\S+)\s+-\s+(?P<message>.*)",
            field_mapping={"level": "level"},
            priority=5,
        ))

    def _init_builtin_alert_rules(self):
        """初始化内置告警规则"""
        self._alert_engine.add_rule(AlertRule(
            name="高频错误告警",
            condition="level>=ERROR",
            threshold_count=10,
            window_seconds=60,
            severity="critical",
            cooldown_seconds=300,
        ))
        self._alert_engine.add_rule(AlertRule(
            name="FATAL级别告警",
            condition="level>=FATAL",
            threshold_count=1,
            window_seconds=60,
            severity="critical",
            cooldown_seconds=60,
        ))


# 导出

    def execute(self, action: str = "status", params: dict = None) -> dict:
        """企业级执行入口。支持status/info/run/stop/help等通用动作。"""
        if params is None:
            params = {}
        _action = action.lower().strip()
        dispatch = {
            "status": self.get_status,
            "info": self.get_info,
            "health": self.health_check,
            "help": self.get_help,
            "get_stats": self._sync_get_stats,
            "get_recent": self._sync_get_recent,
            "search": self._sync_search,
            "list_archives": self._sync_list_archives,
            "cleanup": self._sync_cleanup,
        }
        handler = dispatch.get(_action)
        if handler:
            try:
                return handler(params)
            except Exception as e:
                return {"success": False, "error": str(e)}
        return self.get_status(params)

    def _sync_get_stats(self, params: dict = None) -> dict:
        """同步获取日志统计"""
        return {"success": True, "module": "log_aggregator",
                "total_entries": len(self._entries),
                "archives": len(self._archives),
                "sources": len(self._sources),
                "memory_usage_mb": round(
                    sum(len(str(e)) for e in self._entries) / 1024 / 1024, 2
                )}

    def _sync_get_recent(self, params: dict = None) -> dict:
        """同步获取最近日志"""
        params = params or {}
        limit = int(params.get("limit", 50))
        recent = self._entries[-limit:] if hasattr(self, '_entries') else []
        return {"success": True, "count": len(recent),
                "entries": [{"timestamp": str(getattr(e, 'timestamp', '')),
                             "level": str(getattr(e, 'level', '')),
                             "message": str(getattr(e, 'message', '')),
                             "source": str(getattr(e, 'source', ''))}
                            for e in recent]}

    def _sync_search(self, params: dict = None) -> dict:
        """同步搜索日志"""
        params = params or {}
        query = params.get("query", "")
        limit = int(params.get("limit", 50))
        if hasattr(self, 'search'):
            results = self.search(query, limit)
            return {"success": True, "query": query, "count": len(results),
                    "entries": [{"timestamp": str(getattr(e, 'timestamp', '')),
                                 "level": str(getattr(e, 'level', '')),
                                 "message": str(getattr(e, 'message', ''))}
                                for e in results]}
        return {"success": True, "query": query, "count": 0, "entries": []}

    def _sync_list_archives(self, params: dict = None) -> dict:
        """同步列出归档"""
        archives = self.list_archives() if hasattr(self, 'list_archives') else []
        return {"success": True, "count": len(archives),
                "archives": [{"name": getattr(a, 'name', str(a)),
                              "created": str(getattr(a, 'created_at', ''))}
                             for a in archives]}

    def _sync_cleanup(self, params: dict = None) -> dict:
        """同步清理过期日志"""
        params = params or {}
        max_age_hours = int(params.get("max_age_hours", 168))
        if hasattr(self, 'cleanup_expired'):
            removed_entries, removed_archives = self.cleanup_expired()
            return {"success": True,
                    "removed_entries": removed_entries,
                    "removed_archives": removed_archives}
        return {"success": True, "removed_entries": 0, "removed_archives": 0}

    def get_info(self, params: dict = None) -> dict:
        if params is None:
            params = {}
        return {"success": True, "module": self.__class__.__name__,
                "status": "active", "version": getattr(self, "version", "1.0.0")}

    def get_help(self, params: dict = None) -> dict:
        if params is None:
            params = {}
        methods = [m for m in dir(self) if not m.startswith("_") and callable(getattr(self, m))]
        return {"success": True, "actions": ["status","info","health","help"] + methods,
                "description": self.__doc__ or ""}

module_class = LogAggregator
