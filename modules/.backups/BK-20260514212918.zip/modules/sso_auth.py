"""sso_auth - Enterprise SSO Authentication Module
AUTO-EVO-AI v6.39 | Grade: A | Category: 安全认证
SSO单点登录: OIDC/SAML协议模拟, 会话联邦, SLO单点登出, 提供商管理
子引擎: SessionFederationEngine(会话联邦+同步)
"""
import logging, hashlib, json, time, uuid, threading
from typing import Dict, Any, Optional, List, Set
from datetime import datetime
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict

from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)

logger = logging.getLogger(__name__)


class SsoProtocol(str, Enum):
    OIDC = "oidc"
    SAML = "saml"
    CAS = "cas"


@dataclass
class IdentityProvider:
    provider_id: str = ""
    name: str = ""
    protocol: str = "oidc"
    client_id: str = ""
    callback_url: str = ""
    issuer_url: str = ""
    scopes: List[str] = field(default_factory=lambda: ["openid", "profile", "email"])
    enabled: bool = True
    created_at: str = ""

    def __post_init__(self):
        if not self.provider_id:
            self.provider_id = str(uuid.uuid4())[:8]
        if not self.created_at:
            self.created_at = datetime.now().isoformat()


@dataclass
class SsoSession:
    session_id: str = ""
    user_id: str = ""
    provider_id: str = ""
    access_token: str = ""
    refresh_token: str = ""
    claims: Dict[str, Any] = field(default_factory=dict)
    created_at: float = 0.0
    expires_at: float = 0.0
    active: bool = True

    def __post_init__(self):
        if not self.session_id:
            self.session_id = str(uuid.uuid4())
        if not self.created_at:
            self.created_at = time.time()
        if not self.expires_at:
            self.expires_at = self.created_at + 7200


class SessionFederationEngine:
    """会话联邦引擎 — 跨提供商会话同步、SLO广播"""

    def __init__(self):
        self._federated: Dict[str, Set[str]] = defaultdict(set)  # user_id -> {session_ids}

    def link(self, user_id: str, session_id: str):
        self._federated[user_id].add(session_id)

    def unlink(self, user_id: str, session_id: str):
        self._federated[user_id].discard(session_id)

    def get_sessions(self, user_id: str) -> Set[str]:
        return self._federated.get(user_id, set())

    def slo_broadcast(self, user_id: str) -> List[str]:
        """SLO: 返回该用户所有需要登出的session_id"""
        sessions = list(self._federated.get(user_id, set()))
        self._federated[user_id].clear()
        return sessions

    def federated_users(self) -> Dict[str, int]:
        return {uid: len(sids) for uid, sids in self._federated.items()}


class SsoAuth(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    AUTO-EVO-AI v6.39 - SSO单点登录模块
    支持OIDC/SAML/CAS协议模拟, 会话管理, 联邦, SLO
    """

    MODULE_ID = "sso_auth"
    MODULE_NAME = "SsoAuth"
    VERSION = "1.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._providers: Dict[str, IdentityProvider] = {}
        self._sessions: Dict[str, SsoSession] = {}
        self._user_sessions: Dict[str, List[str]] = defaultdict(list)
        self._federation = SessionFederationEngine()
        self._lock = threading.Lock()
        self._total_logins = 0
        self._total_logouts = 0
        self._total_slo = 0
        self._init_default_provider()

    def _init_default_provider(self):
        p = IdentityProvider(name="local", protocol="oidc", client_id="local-sso",
                             callback_url="http://localhost:8766/auth/callback")
        self._providers[p.provider_id] = p

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                result = self._dispatch(action, params)
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                logger.error(f"[sso_auth] {action} error: {e}")
                return {"success": False, "error": str(e), "action": action}

    def _dispatch(self, action: str, params: Dict[str, Any]) -> Any:
        handler = {
            "status": self._get_status, "stats": self._get_stats,
            "health": self.health_check, "reset": self._reset,
            "configure": self._configure,
            # 提供商管理
            "register_provider": self._register_provider,
            "list_providers": self._list_providers,
            "remove_provider": self._remove_provider,
            "get_provider": self._get_provider,
            # 认证
            "login": self._login,
            "logout": self._logout,
            "slo": self._slo,
            # 会话
            "get_session": self._get_session,
            "list_sessions": self._list_sessions,
            "validate": self._validate,
            # 联邦
            "federate": self._federate,
            "federation_info": self._federation_info,
        }.get(action)
        if handler:
            return handler(params)
        return {"action": action, "module_id": self.MODULE_ID}

    def _register_provider(self, params: Dict[str, Any]) -> Dict[str, Any]:
        p = IdentityProvider(
            name=params.get("name", ""), protocol=params.get("protocol", "oidc"),
            client_id=params.get("client_id", ""), callback_url=params.get("callback_url", ""),
            issuer_url=params.get("issuer_url", ""),
            scopes=params.get("scopes", ["openid", "profile"]),
        )
        self._providers[p.provider_id] = p
        self.audit("register_provider", f"id={p.provider_id} name={p.name}")
        return {"provider_id": p.provider_id, "name": p.name}

    def _list_providers(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"providers": [{"provider_id": p.provider_id, "name": p.name,
                               "protocol": p.protocol, "enabled": p.enabled}
                              for p in self._providers.values()],
                "total": len(self._providers)}

    def _remove_provider(self, params: Dict[str, Any]) -> Dict[str, Any]:
        pid = params.get("provider_id", "")
        if pid in self._providers:
            del self._providers[pid]
            return {"provider_id": pid, "removed": True}
        return {"error": "not_found"}

    def _get_provider(self, params: Dict[str, Any]) -> Dict[str, Any]:
        pid = params.get("provider_id", "")
        p = self._providers.get(pid)
        if not p:
            return {"error": "not_found"}
        return {"provider_id": p.provider_id, "name": p.name, "protocol": p.protocol,
                "client_id": p.client_id, "callback_url": p.callback_url,
                "scopes": p.scopes, "enabled": p.enabled}

    def _login(self, params: Dict[str, Any]) -> Dict[str, Any]:
        user_id = params.get("user_id", "")
        provider_id = params.get("provider_id", "")
        claims = params.get("claims", {})
        ttl = params.get("ttl", 7200)
        if not user_id:
            return {"error": "user_id required"}
        provider = self._providers.get(provider_id)
        if not provider or not provider.enabled:
            return {"error": f"provider {provider_id} not found or disabled"}
        session = SsoSession(user_id=user_id, provider_id=provider_id,
                             claims=claims, expires_at=time.time() + ttl)
        access_token = hashlib.sha256(f"sso-{session.session_id}-{time.time()}".encode()).hexdigest()[:32]
        refresh_token = hashlib.sha256(f"sso-refresh-{session.session_id}".encode()).hexdigest()[:32]
        session.access_token = access_token
        session.refresh_token = refresh_token
        with self._lock:
            self._sessions[session.session_id] = session
            self._user_sessions[user_id].append(session.session_id)
            self._total_logins += 1
        self._federation.link(user_id, session.session_id)
        self.audit("login", f"user={user_id} provider={provider_id}")
        return {"session_id": session.session_id, "access_token": access_token,
                "refresh_token": refresh_token, "expires_at": session.expires_at}

    def _logout(self, params: Dict[str, Any]) -> Dict[str, Any]:
        session_id = params.get("session_id", "")
        session = self._sessions.get(session_id)
        if not session:
            return {"error": "session not found"}
        session.active = False
        self._federation.unlink(session.user_id, session_id)
        with self._lock:
            self._total_logouts += 1
        self.audit("logout", f"session={session_id} user={session.user_id}")
        return {"session_id": session_id, "logged_out": True}

    def _slo(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """SLO单点登出"""
        user_id = params.get("user_id", "")
        if not user_id:
            return {"error": "user_id required"}
        sessions_to_logout = self._federation.slo_broadcast(user_id)
        for sid in sessions_to_logout:
            if sid in self._sessions:
                self._sessions[sid].active = False
        self._total_slo += 1
        self.audit("slo", f"user={user_id} sessions={len(sessions_to_logout)}")
        return {"user_id": user_id, "logged_out_sessions": len(sessions_to_logout),
                "session_ids": sessions_to_logout}

    def _get_session(self, params: Dict[str, Any]) -> Dict[str, Any]:
        session_id = params.get("session_id", "")
        s = self._sessions.get(session_id)
        if not s:
            return {"error": "not_found"}
        return {"session_id": s.session_id, "user_id": s.user_id,
                "provider_id": s.provider_id, "active": s.active,
                "expires_at": s.expires_at, "claims": s.claims}

    def _list_sessions(self, params: Dict[str, Any]) -> Dict[str, Any]:
        user_id = params.get("user_id", "")
        active_only = params.get("active_only", True)
        sessions = list(self._sessions.values())
        if user_id:
            sessions = [s for s in sessions if s.user_id == user_id]
        if active_only:
            sessions = [s for s in sessions if s.active and s.expires_at > time.time()]
        return {"sessions": [{"session_id": s.session_id, "user_id": s.user_id,
                              "active": s.active, "expires_at": s.expires_at}
                             for s in sessions[-50:]],
                "total": len(sessions)}

    def _validate(self, params: Dict[str, Any]) -> Dict[str, Any]:
        session_id = params.get("session_id", "")
        s = self._sessions.get(session_id)
        if not s:
            return {"valid": False, "error": "not_found"}
        if not s.active:
            return {"valid": False, "error": "logged_out"}
        if time.time() > s.expires_at:
            return {"valid": False, "error": "expired"}
        return {"valid": True, "user_id": s.user_id, "provider_id": s.provider_id}

    def _federate(self, params: Dict[str, Any]) -> Dict[str, Any]:
        user_id = params.get("user_id", "")
        session_id = params.get("session_id", "")
        if user_id and session_id:
            self._federation.link(user_id, session_id)
            return {"user_id": user_id, "session_id": session_id, "federated": True}
        return {"error": "user_id and session_id required"}

    def _federation_info(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"federated_users": self._federation.federated_users()}

    def _get_status(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
            "version": self.VERSION, "status": "running",
            "providers": len(self._providers),
            "active_sessions": len([s for s in self._sessions.values() if s.active]),
            "total_logins": self._total_logins, "total_logouts": self._total_logouts,
        }

    def _get_stats(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "total_logins": self._total_logins,
            "total_logouts": self._total_logouts,
            "total_slo": self._total_slo,
            "providers": len(self._providers),
            "active_sessions": len([s for s in self._sessions.values() if s.active]),
            "federated_users": len(self._federation.federated_users()),
        }

    def _reset(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        self._sessions.clear()
        self._user_sessions.clear()
        self._total_logins = 0
        self._total_logouts = 0
        self._total_slo = 0
        return {"status": "reset_ok"}

    def _configure(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"configured": list(params.keys())}

    def health_check(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {"healthy": len(self._providers) > 0, "status": "ok", "providers": len(self._providers)}


module_class = SsoAuth
