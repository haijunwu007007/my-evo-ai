import time
"""
实时协作模块
支持多人编辑、WebSocket房间、协同工作
"""

import json
import logging
import uuid
from typing import Dict, List, Any, Optional, Set
from datetime import datetime
from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector
logger = logging.getLogger(__name__)


class RealtimeCollaborationAnalyzer(object):
    """realtime_collaboration 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "realtime_collaboration"
        self.version = "1.0.0"
        self._analyzer = RealtimeCollaborationAnalyzer()
        self._history = []
        self._max_history = 10000
    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "realtime_collaboration"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== realtime_collaboration ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}

class CollaborationRoom(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """协作房间"""
    
    def __init__(self, room_id: str=None, name: str=None, created_by: str=None):
        super().__init__()
    
        self.id = room_id
        self.name = name
        self.created_by = created_by
        self.created_at = datetime.now().isoformat()
        self.participants: Dict[str, Dict] = {}
        self.messages: List[Dict] = []
        self.documents: Dict[str, Dict] = {}
        self.cursor_positions: Dict[str, Dict] = {}
        self.is_active = True
        self._operation_count = 0
        self._error_count = 0
        

    def execute(self, action: str = "status", params: dict = None) -> dict:
        params = params or {}
        with self.trace("execute", action):
            try:
                result = self._dispatch(action, params)
                self._operation_count += 1
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                self._error_count += 1
                return {"success": False, "error": str(e), "action": action}

    def _dispatch(self, action: str, params: dict):
        if False:
            pass
        elif action == "create_room":
            result = self.create_room(params)
        elif action == "join_room":
            result = self.join_room(params)
        elif action == "leave_room":
            result = self.leave_room(params)
        elif action == "add_participant":
            result = self.add_participant(params)
        elif action == "remove_participant":
            result = self.remove_participant(params)
        elif action == "broadcast_message":
            result = self.broadcast_message(params)
        elif action == "update_document":
            result = self.update_document(params)
        elif action == "update_cursor":
            result = self.update_cursor(params)
        elif action == "search_history":
            result = self.search_history(params)
        elif action == "compare_periods":
            result = self.compare_periods(params)
        elif action == "cleanup_stale":
            result = self.cleanup_stale(params)
        elif action == "aggregate":
            result = self.aggregate(params)
        elif action == "batch_analyze":
            result = self.batch_analyze(params)
        elif action == "analyze":
            result = self.analyze(params)
        elif action == "get_statistics":
            result = self.get_statistics(params)
        elif action == "validate_config":
            result = self.validate_config(params)
        elif action == "export_report":
            result = self.export_report(params)
        elif action == "reset_metrics":
            result = self.reset_metrics(params)
        elif action == "get_health_detail":
            result = self.get_health_detail(params)
        elif action == "status":
            result = self._status(params)
        elif action == "stats":
            result = self._stats(params)
        elif action == "health":
            result = self._health(params)
        elif action == "configure":
            result = self._configure(params)
        elif action == "reset":
            result = self._reset(params)
        else:
            return {"error": "Unknown action: " + action}

    def _status(self, params):
        return {"module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
                "version": self.VERSION, "status": "running"}

    def _stats(self, params):
        stats_data = {}
        if hasattr(self, "get_statistics") and callable(self.get_statistics):
            stats_data = self.get_statistics()
        return {"operations": self._operation_count, "errors": self._error_count, **stats_data}

    def _health(self, params):
        if hasattr(self, "health_check") and callable(self.health_check):
            return self.health_check()
        return {"healthy": True, "status": "ok"}

    def _configure(self, params):
        return {"configured": list(params.keys()), "status": "ok"}

    def _reset(self, params):
        if hasattr(self, "reset_metrics") and callable(self.reset_metrics):
            self.reset_metrics()
        return {"status": "reset_ok"}

    def add_participant(self, user_id: str, user_name: str, role: str = "editor") -> bool:
        """添加参与者"""
        if user_id in self.participants:
            return False
        
        self.participants[user_id] = {
            "id": user_id,
            "name": user_name,
            "role": role,
            "joined_at": datetime.now().isoformat(),
            "status": "online"
        }
        
        self.messages.append({
            "type": "system",
            "content": f"{user_name} 加入了房间",
            "timestamp": datetime.now().isoformat()
        })
        
        return True
    
    def remove_participant(self, user_id: str) -> bool:
        """移除参与者"""
        if user_id not in self.participants:
            return False
        
        user_name = self.participants[user_id]["name"]
        del self.participants[user_id]
        
        self.messages.append({
            "type": "system",
            "content": f"{user_name} 离开了房间",
            "timestamp": datetime.now().isoformat()
        })
        
        return True
    
    def broadcast_message(self, user_id: str, content: str, msg_type: str = "chat") -> Dict:
        """广播消息"""
        user = self.participants.get(user_id, {"name": "Unknown"})
        
        msg = {
            "id": str(uuid.uuid4())[:8],
            "type": msg_type,
            "user_id": user_id,
            "user_name": user["name"],
            "content": content,
            "timestamp": datetime.now().isoformat()
        }
        
        self.messages.append(msg)
        
        # 只保留最近100条消息
        if len(self.messages) > 100:
            self.messages = self.messages[-100:]
        
        return msg
    
    def update_document(self, doc_id: str, user_id: str, changes: Dict) -> Dict:
        """更新文档（协同编辑）"""
        if doc_id not in self.documents:
            self.documents[doc_id] = {
                "id": doc_id,
                "content": "",
                "version": 0,
                "history": []
            }
        
        doc = self.documents[doc_id]
        doc["version"] += 1
        
        # 记录变更
        change_record = {
            "user_id": user_id,
            "changes": changes,
            "version": doc["version"],
            "timestamp": datetime.now().isoformat()
        }
        doc["history"].append(change_record)
        
        # 应用变更
        if "insert" in changes:
            pos = changes["insert"].get("position", 0)
            text = changes["insert"].get("text", "")
            doc["content"] = doc["content"][:pos] + text + doc["content"][pos:]
        elif "delete" in changes:
            start = changes["delete"].get("start", 0)
            end = changes["delete"].get("end", 0)
            doc["content"] = doc["content"][:start] + doc["content"][end:]
        
        return {
            "success": True,
            "doc_id": doc_id,
            "version": doc["version"],
            "content_length": len(doc["content"])
        }
    
    def update_cursor(self, user_id: str, position: int, selection: Dict = None):
        """更新光标位置"""
        self.cursor_positions[user_id] = {
            "position": position,
            "selection": selection,
            "updated_at": datetime.now().isoformat()
        }
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "name": self.name,
            "created_by": self.created_by,
            "created_at": self.created_at,
            "participant_count": len(self.participants),
            "participants": list(self.participants.values()),
            "message_count": len(self.messages),
            "document_count": len(self.documents),
            "is_active": self.is_active
        }


class RealtimeCollaboration:
    """实时协作引擎"""
    
    def __init__(self):
        self.version = "1.0.0"
        self.enabled = True
        self.rooms: Dict[str, CollaborationRoom] = {}
        self.user_sessions: Dict[str, Dict] = {}
        
    def create_room(self, name: str, created_by: str) -> Dict:
        """创建协作房间"""
        try:
            room_id = str(uuid.uuid4())[:12]
            room = CollaborationRoom(room_id, name, created_by)
            self.rooms[room_id] = room
            
            logger.info(f"[Collab] 创建房间: {name} ({room_id})")
            
            return {
                "success": True,
                "room_id": room_id,
                "name": name,
                "invite_link": f"/collab/room/{room_id}"
            }
            
        except Exception as e:
            logger.error(f"[Collab] 创建房间失败: {e}")
            return {"success": False, "error": str(e)}
    
    def join_room(self, room_id: str, user_id: str, user_name: str, role: str = "editor") -> Dict:
        """加入房间"""
        try:
            room = self.rooms.get(room_id)
            if not room:
                return {"success": False, "error": "房间不存在"}
            
            if not room.is_active:
                return {"success": False, "error": "房间已关闭"}
            
            success = room.add_participant(user_id, user_name, role)
            
            if success:
                self.user_sessions[user_id] = {
                    "room_id": room_id,
                    "joined_at": datetime.now().isoformat()
                }
            
            return {
                "success": success,
                "room": room.to_dict()
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def leave_room(self, room_id: str, user_id: str) -> Dict:
        """离开房间"""
        try:
            room = self.rooms.get(room_id)
            if not room:
                return {"success": False, "error": "房间不存在"}
            
            success = room.remove_participant(user_id)
            
            if user_id in self.user_sessions:
                del self.user_sessions[user_id]
            
            return {"success": success}
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def send_message(self, room_id: str, user_id: str, content: str, msg_type: str = "chat") -> Dict:
        """发送消息"""
        try:
            room = self.rooms.get(room_id)
            if not room:
                return {"success": False, "error": "房间不存在"}
            
            if user_id not in room.participants:
                return {"success": False, "error": "未加入房间"}
            
            msg = room.broadcast_message(user_id, content, msg_type)
            
            return {
                "success": True,
                "message": msg
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def edit_document(self, room_id: str, doc_id: str, user_id: str, changes: Dict) -> Dict:
        """协同编辑文档"""
        try:
            room = self.rooms.get(room_id)
            if not room:
                return {"success": False, "error": "房间不存在"}
            
            if user_id not in room.participants:
                return {"success": False, "error": "未加入房间"}
            
            result = room.update_document(doc_id, user_id, changes)
            return result
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def get_room_info(self, room_id: str) -> Dict:
        """获取房间信息"""
        try:
            room = self.rooms.get(room_id)
            if not room:
                return {"success": False, "error": "房间不存在"}
            
            return {
                "success": True,
                "room": room.to_dict(),
                "recent_messages": room.messages[-20:],
                "cursor_positions": room.cursor_positions
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def list_rooms(self) -> List[Dict]:
        """列出所有房间"""
        return [room.to_dict() for room in self.rooms.values() if room.is_active]
    
    def close_room(self, room_id: str, user_id: str) -> Dict:
        """关闭房间"""
        try:
            room = self.rooms.get(room_id)
            if not room:
                return {"success": False, "error": "房间不存在"}
            
            if room.created_by != user_id:
                return {"success": False, "error": "只有创建者可以关闭房间"}
            
            room.is_active = False
            
            return {"success": True, "message": "房间已关闭"}
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def get_stats(self) -> Dict:
        return {
            "rooms": len(self.rooms),
            "active_rooms": len([r for r in self.rooms.values() if r.is_active]),
            "total_participants": sum(len(r.participants) for r in self.rooms.values()),
            "total_messages": sum(len(r.messages) for r in self.rooms.values()),
            "status": "running"
        }
    
    def health_check(self) -> Dict:
        return {
            "status": "ok",
            "version": self.version,
            "features": ["room", "chat", "co_edit", "cursor_sync"]
        }

main_class = RealtimeCollaboration

module_class = CollaborationRoom

