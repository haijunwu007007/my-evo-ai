import time
"""
RAG知识检索增强引擎
基于向量检索+知识图谱的混合RAG系统
"""

import json
import logging
import hashlib
from typing import Dict, List, Any, Optional
from datetime import datetime
from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector
logger = logging.getLogger(__name__)

class Document:
    """文档对象"""
    def __init__(self, content: str, metadata: Dict = None):
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "rag_knowledge_engine"
        self.version = "1.0.0"
        self._analyzer = RagKnowledgeEngineAnalyzer()
        self._operation_count = 0
        self._error_count = 0
        self.id = hashlib.md5(content.encode()).hexdigest()[:12]
        self.content = content
        self.metadata = metadata or {}
        self.created_at = datetime.now().isoformat()
        self.embeddings = None
        
class KnowledgeGraph:
    """知识图谱"""
    def __init__(self):
        self.nodes: Dict[str, Dict] = {}
        self.edges: List[Dict] = []

    def add_node(self, id: str, name: str = "", properties: Dict = None):
        self.nodes[id] = {
            "id": id,
            "name": name,
            "properties": properties or {},
            "created_at": datetime.now().isoformat()
        }
        
    def add_edge(self, from_id: str, to_id: str, relation: str):
        self.edges.append({
            "from": from_id,
            "to": to_id,
            "relation": relation
        })
        
    def query(self, node_id: str) -> Dict:
        """查询节点及关联"""
        node = self.nodes.get(node_id)
        if not node:
            return {}
        
        relations = [
            e for e in self.edges 
            if e["from"] == node_id or e["to"] == node_id
        ]
        return {"node": node, "relations": relations}


class RagKnowledgeEngineAnalyzer(object):
    """rag_knowledge_engine 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        self._history = []
        self._max_history = 10000
    
    def analyze(self, context: dict = None) -> dict:
        context = context or {}
        return {"status": "analyzed", "nodes": len(self._history), "context_keys": list(context.keys())}

    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "rag_knowledge_engine"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== rag_knowledge_engine ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}

class RAGKnowledgeEngine(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """RAG知识检索引擎"""
    
    def __init__(self):
        super().__init__()
        self._operation_count = 0
        self._error_count = 0
        self.documents: Dict[str, Document] = {}
        self.knowledge_graph = KnowledgeGraph()
        self.version = "1.0.0"
        self.enabled = True
        
        # 初始化示例知识
        self._init_sample_knowledge()
        

    def execute(self, action: str = "status", params: dict = None) -> dict:
        params = params or {}
        with self.trace("execute", action):
            try:
                result = self._dispatch(action, params)
                self._operation_count += 1
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                self._error_count += 1
                return {"success": False, "error": str(e), "action": action}

    def _dispatch(self, action: str, params: dict):
        if False:
            pass
        elif action == "add_document":
            result = self.add_document(params)
        elif action == "search":
            result = self.search(params)
        elif action == "generate_answer":
            result = self.generate_answer(params)
        elif action == "query":
            result = self.query(params)
        elif action == "add_node":
            result = self.add_node(params)
        elif action == "add_edge":
            result = self.add_edge(params)
        elif action == "search_history":
            result = self.search_history(params)
        elif action == "compare_periods":
            result = self.compare_periods(params)
        elif action == "cleanup_stale":
            result = self.cleanup_stale(params)
        elif action == "aggregate":
            result = self.aggregate(params)
        elif action == "batch_analyze":
            result = self.batch_analyze(params)
        elif action == "analyze":
            result = self.analyze(params)
        elif action == "get_statistics":
            result = self.get_statistics(params)
        elif action == "validate_config":
            result = self.validate_config(params)
        elif action == "export_report":
            result = self.export_report(params)
        elif action == "reset_metrics":
            result = self.reset_metrics(params)
        elif action == "get_health_detail":
            result = self.get_health_detail(params)
        elif action == "status":
            result = self._status(params)
        elif action == "stats":
            result = self._stats(params)
        elif action == "health":
            result = self._health(params)
        elif action == "configure":
            result = self._configure(params)
        elif action == "reset":
            result = self._reset(params)
        else:
            return {"error": "Unknown action: " + action}

    def _status(self, params):
        return {"module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
                "version": self.VERSION, "status": "running"}

    def _stats(self, params):
        stats_data = {}
        if hasattr(self, "get_statistics") and callable(self.get_statistics):
            stats_data = self.get_statistics()
        return {"operations": self._operation_count, "errors": self._error_count, **stats_data}

    def _health(self, params):
        if hasattr(self, "health_check") and callable(self.health_check):
            return self.health_check()
        return {"healthy": True, "status": "ok"}

    def _configure(self, params):
        return {"configured": list(params.keys()), "status": "ok"}

    def _reset(self, params):
        if hasattr(self, "reset_metrics") and callable(self.reset_metrics):
            self.reset_metrics()
        return {"status": "reset_ok"}

    def _init_sample_knowledge(self):
        """初始化示例知识库"""
        samples = [
            ("Python是一种高级编程语言，由Guido van Rossum于1991年创建", {"category": "programming", "lang": "zh"}),
            ("FastAPI是一个现代、快速的Python Web框架，基于Starlette和Pydantic", {"category": "framework", "lang": "zh"}),
            ("人工智能(AI)是计算机科学的一个分支，致力于创建能够执行通常需要人类智能的任务的系统", {"category": "ai", "lang": "zh"}),
            ("机器学习是AI的一个子集，它使计算机能够从数据中学习而无需明确编程", {"category": "ai", "lang": "zh"}),
            ("深度学习是机器学习的一种方法，使用多层神经网络来模拟人脑的工作方式", {"category": "ai", "lang": "zh"}),
        ]
        
        for content, meta in samples:
            self.add_document(content, meta)
            
    def add_document(self, content: str, metadata: Dict = None) -> str:
        """添加文档到知识库"""
        try:
            doc = Document(content, metadata)
            self.documents[doc.id] = doc
            
            # 提取关键词并添加到知识图谱
            self._extract_knowledge_graph(doc)
            
            logger.info(f"[RAG] 添加文档: {doc.id}")
            return doc.id
        except Exception as e:
            logger.error(f"[RAG] 添加文档失败: {e}")
            return ""
    
    def _extract_knowledge_graph(self, doc: Document):
        """从文档提取知识图谱"""
        # 简化版：提取命名实体作为节点
        content = doc.content
        
        # 提取技术关键词作为节点
        tech_keywords = ["Python", "FastAPI", "AI", "人工智能", "机器学习", "深度学习", "神经网络"]
        found_entities = []
        
        for kw in tech_keywords:
            if kw in content:
                node_id = f"entity_{kw.lower().replace(' ', '_')}"
                if node_id not in self.knowledge_graph.nodes:
                    self.knowledge_graph.add_node(node_id, kw, {"type": "technology"})
                found_entities.append(node_id)
        
        # 建立实体间关系
        if len(found_entities) > 1:
            for i in range(len(found_entities) - 1):
                self.knowledge_graph.add_edge(
                    found_entities[i], 
                    found_entities[i+1], 
                    "related_to"
                )
    
    def search(self, query: str, top_k: int = 5) -> List[Dict]:
        """检索相关知识"""
        try:
            results = []
            query_lower = query.lower()
            
            # 1. 关键词匹配（简化版向量检索）
            for doc_id, doc in self.documents.items():
                score = self._calculate_relevance(query_lower, doc.content.lower())
                if score > 0:
                    results.append({
                        "id": doc_id,
                        "content": doc.content,
                        "score": score,
                        "metadata": doc.metadata
                    })
            
            # 2. 按分数排序
            results.sort(key=lambda x: x["score"], reverse=True)
            
            # 3. 知识图谱增强
            if results:
                top_doc = results[0]
                kg_info = self._get_kg_context(top_doc["content"])
                if kg_info:
                    top_doc["knowledge_graph"] = kg_info
            
            return results[:top_k]
            
        except Exception as e:
            logger.error(f"[RAG] 检索失败: {e}")
            return []
    
    def _calculate_relevance(self, query: str, content: str) -> float:
        """计算相关性分数"""
        query_words = set(query.split())
        content_words = set(content.split())
        
        if not query_words:
            return 0.0
        
        # Jaccard相似度
        intersection = query_words & content_words
        union = query_words | content_words
        
        return len(intersection) / len(union) if union else 0.0
    
    def _get_kg_context(self, content: str) -> Dict:
        """获取知识图谱上下文"""
        # 查找相关实体
        for node_id, node in self.knowledge_graph.nodes.items():
            if node["name"] in content:
                return self.knowledge_graph.query(node_id)
        return {}
    
    def generate_answer(self, query: str) -> Dict:
        """基于检索生成答案（RAG）"""
        try:
            # 1. 检索相关知识
            contexts = self.search(query, top_k=3)
            
            if not contexts:
                return {
                    "success": True,
                    "answer": "未找到相关知识，请尝试其他关键词。",
                    "sources": []
                }
            
            # 2. 构建上下文
            context_text = "\n".join([f"- {c['content']}" for c in contexts])
            
            # 3. 生成答案（简化版）
            answer = f"基于检索到的{len(contexts)}条知识：\n\n{context_text}\n\n"
            
            # 添加知识图谱信息
            if contexts[0].get("knowledge_graph"):
                kg = contexts[0]["knowledge_graph"]
                if kg.get("relations"):
                    answer += "\n相关知识关联：\n"
                    for rel in kg["relations"][:3]:
                        from_node = self.knowledge_graph.nodes.get(rel["from"], {}).get("name", "?")
                        to_node = self.knowledge_graph.nodes.get(rel["to"], {}).get("name", "?")
                        answer += f"- {from_node} → {rel['relation']} → {to_node}\n"
            
            return {
                "success": True,
                "answer": answer,
                "sources": [{"id": c["id"], "score": c["score"]} for c in contexts]
            }
            
        except Exception as e:
            logger.error(f"[RAG] 生成答案失败: {e}")
            return {"success": False, "error": str(e)}
    
    def get_stats(self) -> Dict:
        """获取统计"""
        return {
            "documents": len(self.documents),
            "kg_nodes": len(self.knowledge_graph.nodes),
            "kg_edges": len(self.knowledge_graph.edges),
            "status": "running"
        }
    
    def health_check(self) -> Dict:
        return {
            "status": "ok",
            "version": self.version,
            "documents": len(self.documents)
        }

main_class = RAGKnowledgeEngine

module_class = RAGKnowledgeEngine

