"""firewall_rules - Enterprise Firewall Rules Module
AUTO-EVO-AI v6.39 | Grade: A | Category: 安全监控
防火墙规则: IP过滤/端口管理/协议控制/流量统计/异常检测
子引擎: TrafficAnalyzer(流量分析+异常模式识别)
"""
import logging, time, uuid, threading, re, hashlib
from typing import Dict, Any, Optional, List, Set, Tuple
from datetime import datetime
from dataclasses import dataclass, field
from collections import defaultdict
from enum import Enum

from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)

logger = logging.getLogger(__name__)


class RuleAction(str, Enum):
    ALLOW = "allow"
    DENY = "deny"
    DROP = "drop"
    REJECT = "reject"
    LOG = "log"


class Protocol(str, Enum):
    TCP = "tcp"
    UDP = "udp"
    ICMP = "icmp"
    ALL = "all"


@dataclass
class FirewallRule:
    rule_id: str = ""
    name: str = ""
    action: str = "deny"
    source_ip: str = "*"  # * or CIDR or specific IP
    dest_ip: str = "*"
    source_port: str = "*"
    dest_port: str = "*"
    protocol: str = "all"
    direction: str = "ingress"  # ingress/egress/both
    enabled: bool = True
    priority: int = 0
    hit_count: int = 0
    created_at: str = ""

    def __post_init__(self):
        if not self.rule_id:
            self.rule_id = str(uuid.uuid4())[:8]
        if not self.created_at:
            self.created_at = datetime.now().isoformat()

    def matches(self, src_ip: str, dst_ip: str, dst_port: int, protocol: str = "tcp", direction: str = "ingress") -> bool:
        if not self.enabled:
            return False
        if self.direction != "both" and self.direction != direction:
            return False
        if self.protocol != "all" and self.protocol != protocol:
            return False
        if not self._ip_matches(self.source_ip, src_ip):
            return False
        if not self._ip_matches(self.dest_ip, dst_ip):
            return False
        if self.dest_port != "*" and str(dst_port) != self.dest_port:
            try:
                if "-" in self.dest_port:
                    lo, hi = self.dest_port.split("-")
                    if not (int(lo) <= dst_port <= int(hi)):
                        return False
                else:
                    if int(self.dest_port) != dst_port:
                        return False
            except ValueError:
                return False
        return True

    def _ip_matches(self, pattern: str, ip: str) -> bool:
        if pattern == "*":
            return True
        if pattern == ip:
            return True
        if "/" in pattern:
            return self._cidr_match(pattern, ip)
        return False

    def _cidr_match(self, cidr: str, ip: str) -> bool:
        try:
            network, bits = cidr.split("/")
            mask = int(bits)
            ip_int = self._ip_to_int(ip)
            net_int = self._ip_to_int(network)
            mask_int = (0xFFFFFFFF << (32 - mask)) & 0xFFFFFFFF
            return (ip_int & mask_int) == (net_int & mask_int)
        except (ValueError, IndexError):
            return False

    def _ip_to_int(self, ip: str) -> int:
        parts = ip.split(".")
        return sum(int(p) << (24 - 8 * i) for i, p in enumerate(parts[:4]))


@dataclass
class TrafficEvent:
    event_id: str = ""
    src_ip: str = ""
    dst_ip: str = ""
    dst_port: int = 0
    protocol: str = "tcp"
    direction: str = "ingress"
    action_taken: str = ""
    matched_rule: str = ""
    timestamp: float = 0.0

    def __post_init__(self):
        if not self.event_id:
            self.event_id = str(uuid.uuid4())[:8]
        if not self.timestamp:
            self.timestamp = time.time()


class TrafficAnalyzer:
    """流量分析引擎"""

    def __init__(self):
        self._events: List[TrafficEvent] = []
        self._max_events = 10000

    def record(self, event: TrafficEvent):
        self._events.append(event)
        if len(self._events) > self._max_events:
            self._events = self._events[-6000:]

    def analyze(self, window_sec: int = 3600) -> Dict[str, Any]:
        cutoff = time.time() - window_sec
        recent = [e for e in self._events if e.timestamp > cutoff]
        # 按IP统计
        ip_counts: Dict[str, int] = defaultdict(int)
        denied_ips: Dict[str, int] = defaultdict(int)
        for e in recent:
            ip_counts[e.src_ip] += 1
            if e.action_taken in ("deny", "drop", "reject"):
                denied_ips[e.src_ip] += 1
        # 端口扫描检测
        port_per_ip: Dict[str, Set[int]] = defaultdict(set)
        for e in recent:
            port_per_ip[e.src_ip].add(e.dst_port)
        scanners = {ip: ports for ip, ports in port_per_ip.items() if len(ports) > 20}
        # 协议分布
        proto_counts: Dict[str, int] = defaultdict(int)
        for e in recent:
            proto_counts[e.protocol] += 1
        # Top被攻击端口
        port_counts: Dict[int, int] = defaultdict(int)
        for e in recent:
            port_counts[e.dst_port] += 1
        return {
            "window_sec": window_sec, "total_events": len(recent),
            "unique_source_ips": len(ip_counts),
            "top_source_ips": sorted(ip_counts.items(), key=lambda x: -x[1])[:10],
            "top_denied_ips": sorted(denied_ips.items(), key=lambda x: -x[1])[:10],
            "suspected_scanners": {ip: len(ports) for ip, ports in scanners.items()},
            "protocol_distribution": dict(proto_counts),
            "top_target_ports": sorted(port_counts.items(), key=lambda x: -x[1])[:10],
        }

    def get_events(self, params: Dict[str, Any] = None) -> List[Dict]:
        events = self._events
        if params:
            if params.get("src_ip"):
                events = [e for e in events if e.src_ip == params["src_ip"]]
            if params.get("action"):
                events = [e for e in events if e.action_taken == params["action"]]
        limit = params.get("limit", 50) if params else 50
        return [{"event_id": e.event_id, "src_ip": e.src_ip, "dst_ip": e.dst_ip,
                 "dst_port": e.dst_port, "protocol": e.protocol,
                 "action": e.action_taken, "rule": e.matched_rule,
                 "timestamp": e.timestamp}
                for e in events[-limit:]]


class FirewallRules(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    AUTO-EVO-AI v6.39 - 防火墙规则模块
    """

    MODULE_ID = "firewall_rules"
    MODULE_NAME = "FirewallRules"
    VERSION = "1.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._rules: Dict[str, FirewallRule] = {}
        self._analyzer = TrafficAnalyzer()
        self._lock = threading.Lock()
        self._default_action = "deny"
        self._total_checked = 0
        self._total_denied = 0
        self._total_allowed = 0
        self._init_default_rules()

    def _init_default_rules(self):
        defaults = [
            FirewallRule(name="allow_localhost", action="allow", source_ip="127.0.0.1",
                         dest_port="*", priority=100),
            FirewallRule(name="allow_established", action="allow", protocol="tcp",
                         dest_port="*", priority=90),
            FirewallRule(name="deny_all", action="deny", source_ip="*",
                         dest_port="*", priority=0),
        ]
        for r in defaults:
            self._rules[r.rule_id] = r

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                result = self._dispatch(action, params)
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                logger.error(f"[firewall] {action} error: {e}")
                return {"success": False, "error": str(e), "action": action}

    def _dispatch(self, action: str, params: Dict[str, Any]) -> Any:
        handler = {
            "status": self._get_status, "stats": self._get_stats,
            "health": self.health_check, "reset": self._reset,
            "configure": self._configure,
            # 规则管理
            "add_rule": self._add_rule, "list_rules": self._list_rules,
            "remove_rule": self._remove_rule, "update_rule": self._update_rule,
            # 检测
            "check": self._check_traffic,
            "check_batch": self._check_batch,
            # 分析
            "traffic_analysis": self._traffic_analysis,
            "events": self._get_events,
        }.get(action)
        if handler:
            return handler(params)
        return {"action": action, "module_id": self.MODULE_ID}

    def _add_rule(self, params: Dict[str, Any]) -> Dict[str, Any]:
        r = FirewallRule(
            name=params.get("name", ""), action=params.get("action", "deny"),
            source_ip=params.get("source_ip", "*"), dest_ip=params.get("dest_ip", "*"),
            source_port=params.get("source_port", "*"), dest_port=params.get("dest_port", "*"),
            protocol=params.get("protocol", "all"), direction=params.get("direction", "ingress"),
            priority=params.get("priority", 10),
        )
        self._rules[r.rule_id] = r
        self.audit("add_rule", f"id={r.rule_id} action={r.action}")
        return {"rule_id": r.rule_id, "name": r.name}

    def _list_rules(self, params: Dict[str, Any]) -> Dict[str, Any]:
        rules = sorted(self._rules.values(), key=lambda x: -x.priority)
        return {"rules": [{"rule_id": r.rule_id, "name": r.name, "action": r.action,
                           "source_ip": r.source_ip, "dest_port": r.dest_port,
                           "protocol": r.protocol, "priority": r.priority,
                           "hit_count": r.hit_count, "enabled": r.enabled}
                          for r in rules], "total": len(rules)}

    def _remove_rule(self, params: Dict[str, Any]) -> Dict[str, Any]:
        rid = params.get("rule_id", "")
        if rid in self._rules:
            del self._rules[rid]
            return {"rule_id": rid, "removed": True}
        return {"error": "not_found"}

    def _update_rule(self, params: Dict[str, Any]) -> Dict[str, Any]:
        rid = params.get("rule_id", "")
        r = self._rules.get(rid)
        if not r:
            return {"error": "not_found"}
        for k in ("name", "action", "source_ip", "dest_ip", "dest_port", "protocol", "direction", "priority", "enabled"):
            if k in params:
                setattr(r, k, params[k])
        return {"rule_id": rid, "updated": True}

    def _check_traffic(self, params: Dict[str, Any]) -> Dict[str, Any]:
        src_ip = params.get("src_ip", "0.0.0.0")
        dst_ip = params.get("dst_ip", "0.0.0.0")
        dst_port = params.get("dst_port", 0)
        protocol = params.get("protocol", "tcp")
        direction = params.get("direction", "ingress")
        self._total_checked += 1
        sorted_rules = sorted(self._rules.values(), key=lambda x: -x.priority)
        matched = None
        for r in sorted_rules:
            if r.matches(src_ip, dst_ip, dst_port, protocol, direction):
                matched = r
                r.hit_count += 1
                break
        action = matched.action if matched else self._default_action
        allowed = action == "allow"
        if allowed:
            self._total_allowed += 1
        else:
            self._total_denied += 1
        event = TrafficEvent(src_ip=src_ip, dst_ip=dst_ip, dst_port=dst_port,
                              protocol=protocol, direction=direction,
                              action_taken=action, matched_rule=matched.rule_id if matched else "default")
        self._analyzer.record(event)
        return {"allowed": allowed, "action": action,
                "matched_rule": matched.rule_id if matched else None,
                "src_ip": src_ip, "dst_ip": dst_ip, "dst_port": dst_port}

    def _check_batch(self, params: Dict[str, Any]) -> Dict[str, Any]:
        items = params.get("items", [])
        results = []
        for item in items[:100]:
            r = self._check_traffic(item)
            results.append(r)
        allowed_count = len([r for r in results if r["allowed"]])
        return {"total": len(results), "allowed": allowed_count, "denied": len(results) - allowed_count,
                "results": results[:20]}

    def _traffic_analysis(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return self._analyzer.analyze(params.get("window", 3600))

    def _get_events(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"events": self._analyzer.get_events(params)}

    def _get_status(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
            "version": self.VERSION, "status": "running",
            "rules": len(self._rules), "default_action": self._default_action,
            "total_checked": self._total_checked,
        }

    def _get_stats(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "total_checked": self._total_checked,
            "total_allowed": self._total_allowed,
            "total_denied": self._total_denied,
            "deny_rate": round(self._total_denied / max(1, self._total_checked) * 100, 1),
            "rules": len(self._rules),
        }

    def _reset(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        for r in self._rules.values():
            r.hit_count = 0
        self._total_checked = 0
        self._total_allowed = 0
        self._total_denied = 0
        return {"status": "reset_ok"}

    def _configure(self, params: Dict[str, Any]) -> Dict[str, Any]:
        if "default_action" in params:
            self._default_action = params["default_action"]
        return {"configured": list(params.keys())}

    def health_check(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {"healthy": True, "status": "ok", "rules": len(self._rules)}


module_class = FirewallRules
