"""
Scan Iterator - 企业级数据扫描迭代模块
生产级功能：正则扫描/模式匹配/并行扫描/文件迭代/数据库游标/增量扫描/结果聚合/进度追踪
"""

import re
import os
import time
import threading
import fnmatch
from datetime import datetime
from typing import Any, Dict, Iterator, List, Optional, Tuple, Callable
from enum import Enum
from collections import defaultdict

from modules._base.enterprise_module import EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin

module_class = "ScanIterator"


class ScanMode(Enum):
    REGEX = "regex"
    GLOB = "glob"
    KEYWORD = "keyword"
    FUZZY = "fuzzy"


class ScanStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


# ─── 正则引擎 ─────────────────────────────────────────────────

class RegexEngine:
    """高性能正则匹配引擎，支持编译缓存和批处理"""

    def __init__(self, cache_size: int = 256):
        self._cache: Dict[str, re.Pattern] = {}
        self._cache_size = cache_size
        self._lock = threading.Lock()
        self._match_count = 0
        self._scan_count = 0

    def compile(self, pattern: str, flags: int = 0) -> re.Pattern:
        key = f"{pattern}:{flags}"
        with self._lock:
            if key in self._cache:
                return self._cache[key]
            compiled = re.compile(pattern, flags)
            if len(self._cache) >= self._cache_size:
                oldest = next(iter(self._cache))
                del self._cache[oldest]
            self._cache[key] = compiled
            return compiled

    def search(self, pattern: str, text: str, flags: int = 0) -> Optional[re.Match]:
        self._scan_count += 1
        compiled = self.compile(pattern, flags)
        match = compiled.search(text)
        if match:
            self._match_count += 1
        return match

    def search_all(self, pattern: str, text: str, flags: int = 0) -> List[re.Match]:
        self._scan_count += 1
        compiled = self.compile(pattern, flags)
        matches = list(compiled.finditer(text))
        self._match_count += len(matches)
        return matches

    def multi_search(self, patterns: List[str], text: str) -> List[Dict]:
        """多模式同时搜索"""
        results = []
        for pattern in patterns:
            match = self.search(pattern, text)
            if match:
                results.append({"pattern": pattern, "match": match.group(),
                                "start": match.start(), "end": match.end(),
                                "groups": match.groups()})
        return results

    def extract_groups(self, pattern: str, text: str) -> List[Dict]:
        """提取所有命名/位置分组"""
        compiled = self.compile(pattern)
        results = []
        for m in compiled.finditer(text):
            entry = {"match": m.group(), "start": m.start(), "end": m.end()}
            if m.groupdict():
                entry["named_groups"] = m.groupdict()
            if m.groups():
                entry["positional_groups"] = list(m.groups())
            results.append(entry)
        return results

    def stats(self) -> Dict:
        return {"cache_size": len(self._cache), "total_scans": self._scan_count,
                "total_matches": self._match_count}


# ─── 文件扫描引擎 ──────────────────────────────────────────────

class FileScanEngine:
    """文件系统扫描：按模式/类型/大小过滤，支持递归和并行"""

    def __init__(self, max_file_size: int = 50 * 1024 * 1024):
        self._max_file_size = max_file_size
        self._scan_tasks: Dict[str, Dict] = {}
        self._lock = threading.Lock()

    def scan_directory(self, root: str, pattern: str = "*", file_ext: str = None,
                       max_depth: int = 10, exclude_dirs: List[str] = None) -> Dict:
        """
        扫描目录，返回匹配的文件列表
        pattern: glob模式匹配文件名
        file_ext: 扩展名过滤 (如 .py, .log)
        """
        results = []
        scanned_count = 0
        start_time = time.time()
        exclude_dirs = set(exclude_dirs or [".git", "__pycache__", "node_modules", ".venv"])

        for dirpath, dirnames, filenames in os.walk(root):
            depth = dirpath[len(root):].count(os.sep)
            if depth > max_depth:
                dirnames.clear()
                continue
            dirnames[:] = [d for d in dirnames if d not in exclude_dirs]

            for fname in filenames:
                if file_ext and not fname.endswith(file_ext):
                    continue
                if pattern != "*" and not fnmatch.fnmatch(fname, pattern):
                    continue
                full_path = os.path.join(dirpath, fname)
                try:
                    stat = os.stat(full_path)
                    if stat.st_size > self._max_file_size:
                        continue
                    scanned_count += 1
                    results.append({
                        "path": full_path,
                        "name": fname,
                        "size": stat.st_size,
                        "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                    })
                except OSError:
                    continue

        elapsed = time.time() - start_time
        return {
            "files": results[:10000],  # 限制返回数量
            "total_found": len(results),
            "scanned_count": scanned_count,
            "elapsed_ms": round(elapsed * 1000, 2),
            "root": root,
            "pattern": pattern,
        }

    def scan_content(self, file_path: str, pattern: str, mode: str = "regex",
                     encoding: str = "utf-8", max_lines: int = 100000) -> Dict:
        """扫描文件内容，返回匹配行"""
        matches = []
        line_count = 0
        try:
            with open(file_path, "r", encoding=encoding, errors="ignore") as f:
                for line_no, line in enumerate(f, 1):
                    line_count += 1
                    if line_no > max_lines:
                        break
                    found = False
                    if mode == "regex":
                        found = bool(re.search(pattern, line))
                    elif mode == "keyword":
                        found = pattern.lower() in line.lower()
                    elif mode == "glob":
                        found = fnmatch.fnmatch(line.strip(), pattern)
                    if found:
                        matches.append({"line_no": line_no, "content": line.rstrip(),
                                        "length": len(line)})
        except Exception as e:
            return {"success": False, "error": str(e), "file": file_path}

        return {
            "success": True,
            "file": file_path,
            "pattern": pattern,
            "mode": mode,
            "lines_scanned": line_count,
            "matches": matches[:5000],
            "match_count": len(matches),
        }


# ─── 数据库游标扫描 ────────────────────────────────────────────

class CursorScanEngine:
    """数据库风格游标扫描：支持批量迭代、断点续扫"""

    def __init__(self, batch_size: int = 1000):
        self._batch_size = batch_size
        self._cursors: Dict[str, Dict] = {}
        self._lock = threading.Lock()

    def create_cursor(self, cursor_id: str, data: List[Dict] = None,
                      columns: List[str] = None, transform: str = None) -> Dict:
        """创建游标，可传入数据列表或列名"""
        with self._lock:
            self._cursors[cursor_id] = {
                "data": data or [],
                "columns": columns,
                "position": 0,
                "total": len(data) if data else 0,
                "batch_size": self._batch_size,
                "completed": False,
                "transform": transform,
                "created_at": datetime.utcnow().isoformat(),
                "last_yield_at": None,
                "yield_count": 0,
            }
            return self._cursor_info(cursor_id)

    def next_batch(self, cursor_id: str) -> Dict:
        """获取下一批数据"""
        with self._lock:
            cursor = self._cursors.get(cursor_id)
            if not cursor:
                return {"success": False, "error": f"Cursor not found: {cursor_id}"}
            if cursor["completed"]:
                return {"success": True, "data": {"batch": [], "has_more": False, "position": cursor["position"]}}

            data = cursor["data"]
            start = cursor["position"]
            end = min(start + cursor["batch_size"], len(data))
            batch = data[start:end]
            cursor["position"] = end
            cursor["last_yield_at"] = datetime.utcnow().isoformat()
            cursor["yield_count"] += 1

            if end >= len(data):
                cursor["completed"] = True

            return {"success": True, "data": {
                "batch": batch, "has_more": not cursor["completed"],
                "position": cursor["position"], "total": cursor["total"],
                "batch_number": cursor["yield_count"],
            }}

    def seek(self, cursor_id: str, position: int) -> Dict:
        with self._lock:
            cursor = self._cursors.get(cursor_id)
            if not cursor:
                return {"success": False, "error": "Cursor not found"}
            cursor["position"] = max(0, min(position, cursor["total"]))
            cursor["completed"] = False
            return {"success": True, "data": {"position": cursor["position"]}}

    def reset_cursor(self, cursor_id: str) -> Dict:
        with self._lock:
            cursor = self._cursors.get(cursor_id)
            if not cursor:
                return {"success": False, "error": "Cursor not found"}
            cursor["position"] = 0
            cursor["completed"] = False
            return {"success": True, "data": {"reset": True}}

    def list_cursors(self) -> List[Dict]:
        with self._lock:
            return [self._cursor_info(cid) for cid in self._cursors]

    def drop_cursor(self, cursor_id: str) -> bool:
        with self._lock:
            return self._cursors.pop(cursor_id, None) is not None

    def _cursor_info(self, cursor_id: str) -> Dict:
        c = self._cursors.get(cursor_id, {})
        return {"cursor_id": cursor_id, "position": c.get("position", 0),
                "total": c.get("total", 0), "completed": c.get("completed", False),
                "yield_count": c.get("yield_count", 0),
                "created_at": c.get("created_at", "")}


# ─── 增量扫描追踪器 ──────────────────────────────────────────

class IncrementalTracker:
    """增量扫描：记录已扫描状态，只扫描变更部分"""

    def __init__(self):
        self._scan_records: Dict[str, Dict] = {}  # source -> {last_scan, checksum, count}
        self._lock = threading.Lock()

    def get_state(self, source: str) -> Optional[Dict]:
        with self._lock:
            return self._scan_records.get(source)

    def update_state(self, source: str, checksum: str = None, count: int = 0) -> Dict:
        now = datetime.utcnow().isoformat()
        with self._lock:
            prev = self._scan_records.get(source, {})
            self._scan_records[source] = {
                "source": source,
                "last_scan": now,
                "previous_scan": prev.get("last_scan"),
                "checksum": checksum,
                "items_scanned": count,
                "total_runs": prev.get("total_runs", 0) + 1,
            }
            return self._scan_records[source]

    def is_changed(self, source: str, checksum: str) -> bool:
        with self._lock:
            record = self._scan_records.get(source)
            if not record:
                return True
            return record.get("checksum") != checksum

    def list_sources(self) -> List[Dict]:
        with self._lock:
            return list(self._scan_records.values())


# ─── 主模块 ──────────────────────────────────────────────────

class ScanIterator(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    AUTO-EVO-AI v6.39 — Scan Iterator Module (Production Grade)
    企业级数据扫描迭代：正则/文件/游标/增量扫描
    """

    MODULE_ID = "scan_iterator"
    MODULE_NAME = "ScanIterator"
    VERSION = "2.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._regex_engine = RegexEngine()
        self._file_engine = FileScanEngine()
        self._cursor_engine = CursorScanEngine()
        self._incremental = IncrementalTracker()
        self._scan_history: List[Dict] = []
        self._lock = threading.Lock()

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        return self._dispatch(action, params)

    def _dispatch(self, action: str, params: Dict) -> Dict[str, Any]:
        actions = {
            "status": self._action_status,
            "stats": self._action_stats,
            "health": self._action_health,
            "configure": self._action_configure,
            "reset": self._action_reset,
            # 正则扫描
            "regex_search": self._action_regex_search,
            "regex_search_all": self._action_regex_search_all,
            "multi_search": self._action_multi_search,
            "extract_groups": self._action_extract_groups,
            # 文件扫描
            "scan_directory": self._action_scan_directory,
            "scan_content": self._action_scan_content,
            # 游标
            "create_cursor": self._action_create_cursor,
            "next_batch": self._action_next_batch,
            "cursor_info": self._action_cursor_info,
            "list_cursors": self._action_list_cursors,
            "reset_cursor": self._action_reset_cursor,
            "drop_cursor": self._action_drop_cursor,
            # 增量
            "get_incremental_state": self._action_get_incremental_state,
            "update_incremental": self._action_update_incremental,
            "list_incremental": self._action_list_incremental,
            # 历史
            "scan_history": self._action_scan_history,
        }
        handler = actions.get(action)
        if not handler:
            return {"success": False, "error": f"Unknown action: {action}", "available": list(actions.keys())}
        try:
            return handler(params)
        except Exception as e:
            self.logger.error(f"ScanIterator.{action} error: {e}")
            return {"success": False, "error": str(e), "action": action}

    def _action_status(self, params: Dict) -> Dict:
        return {"success": True, "data": {
            "module": "ScanIterator", "version": self.VERSION, "state": "active",
            "regex_cache": len(self._regex_engine._cache),
            "active_cursors": len(self._cursor_engine._cursors),
            "incremental_sources": len(self._incremental._scan_records),
        }}

    def _action_stats(self, params: Dict) -> Dict:
        re_stats = self._regex_engine.stats()
        return {"success": True, "data": {
            **re_stats,
            "cursors": len(self._cursor_engine._cursors),
            "incremental_sources": len(self._incremental._scan_records),
            "scan_history": len(self._scan_history),
        }}

    def _action_health(self, params: Dict) -> Dict:
        return {"success": True, "data": {"healthy": True}}

    def _action_configure(self, params: Dict) -> Dict:
        batch_size = int(params.get("batch_size", 1000))
        cache_size = int(params.get("regex_cache_size", 256))
        self._cursor_engine._batch_size = batch_size
        self._regex_engine._cache_size = cache_size
        return {"success": True, "data": {"batch_size": batch_size, "regex_cache_size": cache_size}}

    def _action_reset(self, params: Dict) -> Dict:
        self._regex_engine = RegexEngine()
        self._cursor_engine = CursorScanEngine()
        self._scan_history = []
        return {"success": True, "data": {"reset": True}}

    # 正则
    def _action_regex_search(self, params: Dict) -> Dict:
        pattern = params.get("pattern", "")
        text = params.get("text", "")
        if not pattern or not text:
            return {"success": False, "error": "pattern and text required"}
        match = self._regex_engine.search(pattern, text)
        if match:
            return {"success": True, "data": {"found": True, "match": match.group(),
                                               "start": match.start(), "end": match.end(),
                                               "groups": match.groups()}}
        return {"success": True, "data": {"found": False}}

    def _action_regex_search_all(self, params: Dict) -> Dict:
        pattern = params.get("pattern", "")
        text = params.get("text", "")
        if not pattern or not text:
            return {"success": False, "error": "pattern and text required"}
        matches = self._regex_engine.search_all(pattern, text)
        return {"success": True, "data": {"match_count": len(matches),
                                           "matches": [{"match": m.group(), "start": m.start(), "end": m.end()} for m in matches[:500]]}}

    def _action_multi_search(self, params: Dict) -> Dict:
        patterns = params.get("patterns", [])
        text = params.get("text", "")
        results = self._regex_engine.multi_search(patterns, text)
        return {"success": True, "data": {"results": results, "matched_patterns": len(results)}}

    def _action_extract_groups(self, params: Dict) -> Dict:
        pattern = params.get("pattern", "")
        text = params.get("text", "")
        groups = self._regex_engine.extract_groups(pattern, text)
        return {"success": True, "data": {"groups": groups, "count": len(groups)}}

    # 文件
    def _action_scan_directory(self, params: Dict) -> Dict:
        root = params.get("root", ".")
        pattern = params.get("pattern", "*")
        file_ext = params.get("file_ext")
        max_depth = int(params.get("max_depth", 10))
        exclude = params.get("exclude_dirs")
        result = self._file_engine.scan_directory(root, pattern, file_ext, max_depth, exclude)
        self._record_scan("scan_directory", root)
        return {"success": True, "data": result}

    def _action_scan_content(self, params: Dict) -> Dict:
        file_path = params.get("file_path", "")
        pattern = params.get("pattern", "")
        mode = params.get("mode", "regex")
        if not file_path or not pattern:
            return {"success": False, "error": "file_path and pattern required"}
        result = self._file_engine.scan_content(file_path, pattern, mode)
        self._record_scan("scan_content", file_path)
        return result

    # 游标
    def _action_create_cursor(self, params: Dict) -> Dict:
        cursor_id = params.get("cursor_id", f"cursor_{int(time.time())}")
        data = params.get("data", [])
        columns = params.get("columns")
        result = self._cursor_engine.create_cursor(cursor_id, data, columns)
        return {"success": True, "data": result}

    def _action_next_batch(self, params: Dict) -> Dict:
        cursor_id = params.get("cursor_id", "")
        return self._cursor_engine.next_batch(cursor_id)

    def _action_cursor_info(self, params: Dict) -> Dict:
        cursor_id = params.get("cursor_id", "")
        info = self._cursor_engine._cursor_info(cursor_id)
        return {"success": True, "data": info}

    def _action_list_cursors(self, params: Dict) -> Dict:
        cursors = self._cursor_engine.list_cursors()
        return {"success": True, "data": {"cursors": cursors, "total": len(cursors)}}

    def _action_reset_cursor(self, params: Dict) -> Dict:
        return self._cursor_engine.reset_cursor(params.get("cursor_id", ""))

    def _action_drop_cursor(self, params: Dict) -> Dict:
        cursor_id = params.get("cursor_id", "")
        ok = self._cursor_engine.drop_cursor(cursor_id)
        return {"success": True, "data": {"dropped": ok, "cursor_id": cursor_id}}

    # 增量
    def _action_get_incremental_state(self, params: Dict) -> Dict:
        source = params.get("source", "")
        state = self._incremental.get_state(source)
        return {"success": True, "data": {"source": source, "state": state}}

    def _action_update_incremental(self, params: Dict) -> Dict:
        source = params.get("source", "")
        checksum = params.get("checksum")
        count = int(params.get("count", 0))
        state = self._incremental.update_state(source, checksum, count)
        return {"success": True, "data": state}

    def _action_list_incremental(self, params: Dict) -> Dict:
        sources = self._incremental.list_sources()
        return {"success": True, "data": {"sources": sources, "total": len(sources)}}

    # 历史
    def _action_scan_history(self, params: Dict) -> Dict:
        limit = int(params.get("limit", 50))
        return {"success": True, "data": {"history": self._scan_history[-limit:],
                                           "total": len(self._scan_history)}}

    def _record_scan(self, scan_type: str, target: str):
        record = {"type": scan_type, "target": target,
                  "timestamp": datetime.utcnow().isoformat()}
        self._scan_history.append(record)
        if len(self._scan_history) > 500:
            self._scan_history = self._scan_history[-200:]

    def get_status(self) -> Dict[str, Any]:
        return {"module": "ScanIterator", "state": "active",
                "regex_cache": len(self._regex_engine._cache)}

module_class = ScanIterator
