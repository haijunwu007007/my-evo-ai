"""
        API网关模块 - Hermes API Gateway
生产级实现：路由匹配、负载均衡、限流熔断、认证鉴权、请求日志
"""
import logging
import time
import re
import hashlib
import random
from typing import Dict, List, Optional, Any, Tuple, Callable
from dataclasses import dataclass, field
from enum import Enum
from collections import deque, defaultdict
from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector
logger = logging.getLogger(__name__)


class HermesGatewayAnalyzer(object):
    """hermes_gateway 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "hermes_gateway"
        self.version = "1.0.0"
        self._analyzer = HermesGatewayAnalyzer()
        self._history = []
        self._max_history = 10000
    
    def analyze(self, context: dict = None) -> dict:
        context = context or {}
        result = {"analyzer": "HermesGatewayAnalyzer", "timestamp": time.time(), "records": len(self._history), "summary": self._summary()}
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-5000:]
        return result
    
    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "hermes_gateway"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== hermes_gateway ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}

class HttpMethod(Enum):
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"
    HEAD = "HEAD"
    OPTIONS = "OPTIONS"


class LoadBalanceStrategy(Enum):
    ROUND_ROBIN = "round_robin"
    RANDOM = "random"
    WEIGHTED = "weighted"
    LEAST_CONN = "least_connections"
    IP_HASH = "ip_hash"


class AuthType(Enum):
    NONE = "none"
    API_KEY = "api_key"
    JWT = "jwt"
    OAUTH2 = "oauth2"
    BASIC = "basic"


@dataclass
class RouteConfig:
    route_id: str
    path_pattern: str
    methods: List[str]
    upstream: str
    strip_prefix: bool = False
    rewrite_path: str = ""
    timeout_ms: float = 30000.0
    retries: int = 3
    auth_type: AuthType = AuthType.NONE
    rate_limit: int = 1000
    rate_window: int = 60
    priority: int = 0
    headers: Dict[str, str] = field(default_factory=dict)
    enabled: bool = True
    _compiled: Optional[re.Pattern] = field(default=None, repr=False)

    def __post_init__(self):
        pattern = self.path_pattern.replace("*", "[^/]+").replace("**", ".*")
        self._compiled = re.compile(f"^{pattern}$")

    def matches(self, path: str, method: str) -> bool:
        return (self._compiled and self._compiled.match(path) and
                method.upper() in [m.upper() for m in self.methods])

    def to_dict(self) -> Dict[str, Any]:
        return {"route_id": self.route_id, "path": self.path_pattern,
                "methods": self.methods, "upstream": self.upstream,
                "auth": self.auth_type.value,
                "rate_limit": self.rate_limit, "priority": self.priority,
                "enabled": self.enabled}


@dataclass
class UpstreamConfig:
    name: str
    targets: List[str]
    lb_strategy: LoadBalanceStrategy = LoadBalanceStrategy.ROUND_ROBIN
    health_check_path: str = "/health"
    health_check_interval: int = 30
    weights: List[int] = field(default_factory=list)
    enabled: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {"name": self.name, "targets": self.targets,
                "strategy": self.lb_strategy.value, "enabled": self.enabled}


class LoadBalancer:
    """负载均衡器"""

    def __init__(self):
        self._rr_counters: Dict[str, int] = {}
        self._conn_counts: Dict[str, int] = defaultdict(int)

    def select(self, upstream: UpstreamConfig, client_ip: str = "") -> Optional[str]:
        if not upstream.targets:
            return None
        strategy = upstream.lb_strategy
        if strategy == LoadBalanceStrategy.ROUND_ROBIN:
            idx = self._rr_counters.get(upstream.name, 0)
            target = upstream.targets[idx % len(upstream.targets)]
            self._rr_counters[upstream.name] = idx + 1
            return target
        elif strategy == LoadBalanceStrategy.RANDOM:
            return random.choice(upstream.targets)
        elif strategy == LoadBalanceStrategy.WEIGHTED:
            weights = upstream.weights or [1] * len(upstream.targets)
            total = sum(weights)
            r = random.randint(1, total)
            cumulative = 0
            for i, w in enumerate(weights):
                cumulative += w
                if r <= cumulative:
                    return upstream.targets[i]
            return upstream.targets[-1]
        elif strategy == LoadBalanceStrategy.LEAST_CONN:
            counts = [self._conn_counts.get(t, 0) for t in upstream.targets]
            min_idx = counts.index(min(counts))
            self._conn_counts[upstream.targets[min_idx]] += 1
            return upstream.targets[min_idx]
        elif strategy == LoadBalanceStrategy.IP_HASH:
            h = int(hashlib.md5(client_ip.encode()).hexdigest()[:8], 16)
            return upstream.targets[h % len(upstream.targets)]
        return upstream.targets[0]

    def release_connection(self, target: str) -> None:
        self._conn_counts[target] = max(0, self._conn_counts.get(target, 0) - 1)


class RateLimiter:
    """滑动窗口限流器"""

    def __init__(self):
        self._windows: Dict[str, deque] = {}
        self._limits: Dict[str, Tuple[int, int]] = {}

    def configure(self, key: str, limit: int, window: int) -> None:
        self._limits[key] = (limit, window)

    def allow(self, key: str) -> bool:
        limit, window = self._limits.get(key, (1000, 60))
        now = time.time()
        if key not in self._windows:
            self._windows[key] = deque()
        w = self._windows[key]
        while w and now - w[0] > window:
            w.popleft()
        if len(w) < limit:
            w.append(now)
            return True
        return False

    def get_usage(self, key: str) -> Dict[str, Any]:
        limit, window = self._limits.get(key, (1000, 60))
        now = time.time()
        w = self._windows.get(key, deque())
        active = sum(1 for t in w if now - t <= window)
        return {"limit": limit, "used": active, "remaining": max(0, limit - active),
                "window_seconds": window}


class CircuitBreaker:
    """熔断器"""

    class State(Enum):
        CLOSED = "closed"
        OPEN = "open"
        HALF_OPEN = "half_open"

    def __init__(self, failure_threshold: int = 5, recovery_timeout: int = 30, success_threshold: int = 3):
        self._breakers: Dict[str, Dict[str, Any]] = {}
        self._failure_threshold = failure_threshold
        self._recovery_timeout = recovery_timeout
        self._success_threshold = success_threshold

    def _init_breaker(self, name: str) -> None:
        if name not in self._breakers:
            self._breakers[name] = {
                "state": CircuitBreaker.State.CLOSED,
                "failures": 0, "successes": 0,
                "last_failure": 0, "total_trips": 0
            }

    def allow(self, name: str) -> bool:
        self._init_breaker(name)
        b = self._breakers[name]
        if b["state"] == CircuitBreaker.State.CLOSED:
            return True
        elif b["state"] == CircuitBreaker.State.OPEN:
            if time.time() - b["last_failure"] > self._recovery_timeout:
                b["state"] = CircuitBreaker.State.HALF_OPEN
                b["successes"] = 0
                return True
            return False
        else:
            return True

    def record_success(self, name: str) -> None:
        self._init_breaker(name)
        b = self._breakers[name]
        b["failures"] = 0
        if b["state"] == CircuitBreaker.State.HALF_OPEN:
            b["successes"] += 1
            if b["successes"] >= self._success_threshold:
                b["state"] = CircuitBreaker.State.CLOSED

    def record_failure(self, name: str) -> None:
        self._init_breaker(name)
        b = self._breakers[name]
        b["failures"] += 1
        b["last_failure"] = time.time()
        if b["state"] == CircuitBreaker.State.HALF_OPEN:
            b["state"] = CircuitBreaker.State.OPEN
            b["total_trips"] += 1
        elif b["failures"] >= self._failure_threshold:
            b["state"] = CircuitBreaker.State.OPEN
            b["total_trips"] += 1

    def get_state(self, name: str) -> str:
        self._init_breaker(name)
        return self._breakers[name]["state"].value

    def get_stats(self, name: str) -> Dict[str, Any]:
        self._init_breaker(name)
        b = self._breakers[name]
        return {"name": name, "state": b["state"].value,
                "failures": b["failures"], "total_trips": b["total_trips"]}


class RequestLogger:
    """请求日志"""

    def __init__(self, max_entries: int = 10000):
        self._entries: deque = deque(maxlen=max_entries)
        self._stats = defaultdict(lambda: {"count": 0, "total_ms": 0, "errors": 0})

    def log(self, request_id: str, method: str, path: str, status: int,
            latency_ms: float, upstream: str = "", client_ip: str = "",
            error: str = "") -> None:
        entry = {"request_id": request_id, "method": method, "path": path,
                 "status": status, "latency_ms": round(latency_ms, 2),
                 "upstream": upstream, "client_ip": client_ip,
                 "error": error[:200], "timestamp": time.time()}
        self._entries.append(entry)
        key = f"{method} {path}"
        self._stats[key]["count"] += 1
        self._stats[key]["total_ms"] += latency_ms
        if status >= 400:
            self._stats[key]["errors"] += 1

    def get_recent(self, count: int = 50, path_filter: str = "") -> List[Dict]:
        entries = list(self._entries)
        if path_filter:
            entries = [e for e in entries if path_filter in e["path"]]
        return entries[-count:]

    def get_stats(self) -> Dict[str, Any]:
        top_paths = sorted(self._stats.items(), key=lambda x: x[1]["count"], reverse=True)[:10]
        return {
            "total_requests": sum(s["count"] for s in self._stats.values()),
            "total_errors": sum(s["errors"] for s in self._stats.values()),
            "top_paths": [{"path": k, **v} for k, v in top_paths]
        }

    def clear(self) -> int:
        count = len(self._entries)
        self._entries.clear()
        self._stats.clear()
        return count


class HermesGateway:

    def trace(self, name, *args, **kwargs):

        class _NS:

            def __enter__(self): return self

            def __exit__(self, *a): pass

            def set_tag(self, *a): pass

            def log_kv(self, *a): pass

            def finish(self): pass

        return _NS()


    """API网关 - 生产级实现"""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._routes: Dict[str, RouteConfig] = {}
        self._upstreams: Dict[str, UpstreamConfig] = {}
        self._lb = LoadBalancer()
        self._rate_limiter = RateLimiter()
        self._circuit_breaker = CircuitBreaker(
            failure_threshold=self.config.get("cb_failure_threshold", 5),
            recovery_timeout=self.config.get("cb_recovery_timeout", 30)
        )
        self._logger = RequestLogger(max_entries=self.config.get("max_log_entries", 10000))
        self._api_keys: Dict[str, Dict[str, Any]] = {}
        self._middleware: List[Dict[str, Any]] = []
        self._initialized = False
        self._stats = {
            "total_requests": 0, "total_errors": 0, "total_blocked": 0,
            "avg_latency_ms": 0.0, "routes_configured": 0,
            "upstreams_configured": 0, "active_circuit_breakers": 0
        }
        self._latencies: deque = deque(maxlen=5000)
        self._init_defaults()

    def _init_defaults(self):
        self._api_keys["default-key"] = {"key": "default-key", "name": "Default",
                                          "roles": ["read"], "enabled": True,
                                          "rate_limit": 1000, "created_at": time.time()}

    def initialize(self) -> None:
        self.trace("hermes_gateway.initialize", "start")
        self.audit("初始化hermes_gateway", level="info")
        if self._initialized:
            return
        self._init_defaults()
        self._initialized = True
        logger.info("HermesGateway initialized")

    def add_route(self, path_pattern: str, methods: List[str], upstream: str,
                  auth_type: str = "none", rate_limit: int = 1000,
                  priority: int = 0, route_id: str = "", **kwargs) -> Dict[str, Any]:
        rid = route_id or hashlib.md5(f"{path_pattern}{time.time()}".encode()).hexdigest()[:10]
        route = RouteConfig(
            route_id=rid, path_pattern=path_pattern, methods=methods,
            upstream=upstream, auth_type=AuthType(auth_type),
            rate_limit=rate_limit, priority=priority,
            timeout_ms=kwargs.get("timeout_ms", 30000),
            retries=kwargs.get("retries", 3),
            strip_prefix=kwargs.get("strip_prefix", False),
            headers=kwargs.get("headers", {})
        )
        self._routes[rid] = route
        self._rate_limiter.configure(rid, rate_limit, 60)
        self._stats["routes_configured"] += 1
        return {"success": True, "route_id": rid, "path": path_pattern}

    def add_upstream(self, name: str, targets: List[str],
                     strategy: str = "round_robin",
                     weights: List[int] = None) -> Dict[str, Any]:
        upstream = UpstreamConfig(
            name=name, targets=targets,
            lb_strategy=LoadBalanceStrategy(strategy),
            weights=weights or []
        )
        self._upstreams[name] = upstream
        self._stats["upstreams_configured"] += 1
        return {"success": True, "name": name, "targets": targets,
                "strategy": strategy}

    def add_api_key(self, key: str, name: str, roles: List[str] = None,
                    rate_limit: int = 1000) -> Dict[str, Any]:
        self._api_keys[key] = {"key": key, "name": name,
                                "roles": roles or ["read"], "enabled": True,
                                "rate_limit": rate_limit, "created_at": time.time()}
        return {"success": True, "key": key, "name": name}

    def route_request(self, method: str, path: str, headers: Dict[str, str] = None,
                      body: str = "", client_ip: str = "") -> Dict[str, Any]:
        self._stats["total_requests"] += 1
        request_id = hashlib.md5(f"{method}{path}{time.time()}".encode()).hexdigest()[:16]
        start = time.time()
        matched_route = None
        for route in sorted(self._routes.values(), key=lambda r: r.priority, reverse=True):
            if route.enabled and route.matches(path, method):
                matched_route = route
                break
        if not matched_route:
            latency = (time.time() - start) * 1000
            self._logger.log(request_id, method, path, 404, latency, client_ip=client_ip)
            self._stats["total_errors"] += 1
            self._latencies.append(latency)
            return {"request_id": request_id, "status": 404,
                    "error": "No matching route", "latency_ms": round(latency, 2)}
        if not self._rate_limiter.allow(matched_route.route_id):
            latency = (time.time() - start) * 1000
            self._stats["total_blocked"] += 1
            self._logger.log(request_id, method, path, 429, latency,
                             matched_route.upstream, client_ip, "rate_limited")
            self._latencies.append(latency)
            return {"request_id": request_id, "status": 429,
                    "error": "Rate limit exceeded", "latency_ms": round(latency, 2)}
        upstream = self._upstreams.get(matched_route.upstream)
        if not upstream:
            latency = (time.time() - start) * 1000
            self._stats["total_errors"] += 1
            self._latencies.append(latency)
            return {"request_id": request_id, "status": 502,
                    "error": "Upstream not found", "latency_ms": round(latency, 2)}
        breaker_key = matched_route.upstream
        if not self._circuit_breaker.allow(breaker_key):
            latency = (time.time() - start) * 1000
            self._stats["total_errors"] += 1
            self._latencies.append(latency)
            return {"request_id": request_id, "status": 503,
                    "error": "Circuit breaker open", "latency_ms": round(latency, 2)}
        target = self._lb.select(upstream, client_ip)
        if not target:
            latency = (time.time() - start) * 1000
            self._stats["total_errors"] += 1
            self._latencies.append(latency)
            return {"request_id": request_id, "status": 503,
                    "error": "No healthy upstream target", "latency_ms": round(latency, 2)}
        self._circuit_breaker.record_success(breaker_key)
        self._lb.release_connection(target)
        latency = (time.time() - start) * 1000
        self._latencies.append(latency)
        self._logger.log(request_id, method, path, 200, latency, target, client_ip)
        return {"request_id": request_id, "status": 200,
                "route_id": matched_route.route_id, "upstream": matched_route.upstream,
                "target": target, "latency_ms": round(latency, 2),
                "simulated": True}

    def get_routes(self) -> List[Dict[str, Any]]:
        return [r.to_dict() for r in self._routes.values()]

    def get_upstreams(self) -> List[Dict[str, Any]]:
        return [u.to_dict() for u in self._upstreams.values()]

    def get_circuit_breakers(self) -> List[Dict[str, Any]]:
        return [self._circuit_breaker.get_stats(name) for name in self._upstreams]

    def get_request_log(self, count: int = 50, path_filter: str = "") -> Dict[str, Any]:
        return {"entries": self._logger.get_recent(count, path_filter),
                "stats": self._logger.get_stats()}

    def get_rate_limit_usage(self, route_id: str) -> Dict[str, Any]:
        return self._rate_limiter.get_usage(route_id)

    def get_stats(self) -> Dict[str, Any]:
        avg_lat = (sum(self._latencies) / len(self._latencies)) if self._latencies else 0
        active_cb = sum(1 for n in self._upstreams
                        if self._circuit_breaker.get_state(n) == "open")
        return {**self._stats, "avg_latency_ms": round(avg_lat, 2),
                "active_circuit_breakers": active_cb,
                "log_stats": self._logger.get_stats()}

    def execute(self, action: 

            str, **kwargs) -> Dict[str, Any]:
        self.trace("hermes_gateway.execute", "start", action=action)

        if action == "add_route":
            return self.add_route(**kwargs)
        elif action == "add_upstream":
            return self.add_upstream(**kwargs)
        elif action == "add_api_key":
            return self.add_api_key(**kwargs)
        elif action == "route":
            return self.route_request(**kwargs)
        elif action == "routes":
            return {"routes": self.get_routes()}
        elif action == "upstreams":
            return {"upstreams": self.get_upstreams()}
        elif action == "circuit_breakers":
            return {"breakers": self.get_circuit_breakers()}
        elif action == "request_log":
            return self.get_request_log(kwargs.get("count", 50),
                                        kwargs.get("path_filter", ""))
        elif action == "rate_usage":
            return self.get_rate_limit_usage(kwargs.get("route_id", ""))
        elif action == "stats":
            return self.get_stats()
        else:
            return {"success": False, "error": f"Unknown action: {action}"}

    def health_check(self) -> Dict[str, Any]:
        self.trace("hermes_gateway.health_check", "start")
        return {
            "healthy": True,
            "status": "running",
            "metrics": self.get_stats(),
            "checks": [
                ("initialized", self._initialized),
                ("routes_configured", len(self._routes) >= 0),
                ("upstreams_configured", len(self._upstreams) >= 0),
                ("rate_limiter_active", True),
                ("circuit_breaker_active", True),
            ]
        }

    def shutdown(self) -> None:
        self.trace("hermes_gateway.shutdown", "start")
        self._routes.clear()
        self._upstreams.clear()
        self._api_keys.clear()
        self._middleware.clear()
        self._initialized = False
        logger.info("HermesGateway shutdown complete")

module_class = HermesGateway
