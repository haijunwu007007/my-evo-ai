"""
Evo Plugin Market - Plugin Ecosystem Management
Plugin marketplace with publishing, versioning, dependency resolution,
security scanning, and usage analytics.
"""

import re
import json
import time
import uuid
import hashlib
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Tuple
from collections import defaultdict
from enum import Enum, auto

from modules._base.enterprise_module import EnterpriseModule


class PluginStatus(Enum):
    DRAFT = "draft"
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    DEPRECATED = "deprecated"
    SUSPENDED = "suspended"


class PluginCategory(Enum):
    AI_ML = "ai_ml"
    INTEGRATION = "integration"
    SECURITY = "security"
    MONITORING = "monitoring"
    DATA = "data"
    UI = "ui"
    UTILITY = "utility"
    WORKFLOW = "workflow"


class SecurityScanResult:
    def __init__(self, scan_id: str, plugin_id: str):
        self.scan_id = scan_id
        self.plugin_id = plugin_id
        self.status = "pending"
        self.risk_level = "none"
        self.vulnerabilities: List[Dict] = []
        self.dependencies_safe = True
        self.score = 100
        self.scanned_at = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> Dict:
        return {"scan_id": self.scan_id, "plugin_id": self.plugin_id,
                "status": self.status, "risk_level": self.risk_level,
                "vulnerabilities": self.vulnerabilities, "dependencies_safe": self.dependencies_safe,
                "score": self.score, "scanned_at": self.scanned_at}


class DependencyResolver:
    """Resolve plugin dependencies, detect conflicts, compute install order."""

    def __init__(self):
        self.resolution_cache: Dict[str, List[str]] = {}

    def resolve(self, plugin_id: str, catalog: Dict[str, Dict], installed: set) -> Dict:
        result = {"install_order": [], "conflicts": [], "missing": [], "already_installed": []}
        visited = set()

        def _visit(pid):
            if pid in visited:
                return
            visited.add(pid)
            plugin = catalog.get(pid)
            if not plugin:
                result["missing"].append(pid)
                return
            if pid in installed:
                result["already_installed"].append(pid)
                return
            for dep_id, ver in plugin.get("dependencies", {}).items():
                if dep_id not in catalog:
                    result["missing"].append(dep_id)
                else:
                    _visit(dep_id)
            result["install_order"].append(pid)

        _visit(plugin_id)
        return result

    def check_conflicts(self, plugin_id: str, catalog: Dict[str, Dict], installed: Dict[str, str]) -> List[Dict]:
        plugin = catalog.get(plugin_id, {})
        conflicts = []
        for dep_id, req_ver in plugin.get("dependencies", {}).items():
            if dep_id in installed:
                inst_ver = installed[dep_id]
                if self._version_satisfies(inst_ver, req_ver):
                    continue
                conflicts.append({"dependency": dep_id, "required": req_ver,
                                  "installed": inst_ver, "conflict": "version_mismatch"})
        return conflicts

    @staticmethod
    def _version_satisfies(installed: str, required: str) -> bool:
        if not required or required == "*":
            return True
        req_parts = required.split(".")
        inst_parts = installed.split(".")
        for i in range(min(len(req_parts), len(inst_parts))):
            ri, ii = int(req_parts[i]) if req_parts[i].isdigit() else 0
            ini = int(inst_parts[i]) if inst_parts[i].isdigit() else 0
            if ini < ri:
                return False
            if ini > ri:
                return True
        return True


class Plugin:
    def __init__(self, plugin_id: str, name: str, version: str, author: str):
        self.plugin_id = plugin_id
        self.name = name
        self.version = version
        self.author = author
        self.description = ""
        self.category = "utility"
        self.status = "draft"
        self.dependencies: Dict[str, str] = {}
        self.tags: List[str] = []
        self.download_url = ""
        self.readme = ""
        self.license = "MIT"
        self.min_platform_version = "1.0.0"
        self.file_size = 0
        self.downloads = 0
        self.rating = 0.0
        self.rating_count = 0
        self.stars = 0
        self.created_at = datetime.now(timezone.utc).isoformat()
        self.updated_at = datetime.now(timezone.utc).isoformat()
        self.versions: List[Dict] = []
        self.security_scans: List[SecurityScanResult] = []
        self.reviews: List[Dict] = []

    def to_dict(self) -> Dict:
        return {"plugin_id": self.plugin_id, "name": self.name, "version": self.version,
                "author": self.author, "description": self.description,
                "category": self.category, "status": self.status,
                "dependencies": self.dependencies, "tags": self.tags,
                "license": self.license, "downloads": self.downloads,
                "rating": self.rating, "rating_count": self.rating_count,
                "stars": self.stars, "created_at": self.created_at,
                "updated_at": self.updated_at, "version_count": len(self.versions)}


class EvoPluginMarket(EnterpriseModule):
    MODULE_ID = "evo_plugin_market"
    MODULE_NAME = "EvoPluginMarket"
    VERSION = "2.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._plugins: Dict[str, Plugin] = {}
        self._dep_resolver = DependencyResolver()
        self._installed: Dict[str, str] = {}
        self._install_log: List[Dict] = []
        self._categories = {c.value: c.name for c in PluginCategory}
        self._operation_count = 0
        self._error_count = 0

    def execute(self, action: 

str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                handler = getattr(self, f"_action_{action}", None)
                if handler:
                    result = handler(params)
                else:
                    return {"success": False, "error": f"Unknown action: {action}"}
                self._operation_count += 1
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                self._error_count += 1
                return {"success": False, "error": str(e), "action": action}

    def _action_publish(self, p: Dict) -> Dict:
        pid = p.get("plugin_id", f"plugin_{uuid.uuid4().hex[:8]}")
        plugin = Plugin(pid, p["name"], p.get("version", "1.0.0"), p["author"])
        plugin.description = p.get("description", "")
        plugin.category = p.get("category", "utility")
        plugin.dependencies = p.get("dependencies", {})
        plugin.tags = p.get("tags", [])
        plugin.license = p.get("license", "MIT")
        plugin.min_platform_version = p.get("min_platform_version", "1.0.0")
        plugin.readme = p.get("readme", "")
        plugin.versions.append({"version": plugin.version, "published_at": datetime.now(timezone.utc).isoformat()})
        self._plugins[pid] = plugin
        return {"plugin_id": pid, "name": plugin.name, "status": plugin.status}

    def _action_get_plugin(self, p: Dict) -> Dict:
        pid = p.get("plugin_id", "")
        if pid not in self._plugins:
            return {"error": "Plugin not found"}
        return self._plugins[pid].to_dict()

    def _action_update_plugin(self, p: Dict) -> Dict:
        pid = p.get("plugin_id", "")
        if pid not in self._plugins:
            return {"error": "Plugin not found"}
        plugin = self._plugins[pid]
        for key in ("name", "description", "category", "readme", "license", "min_platform_version", "download_url"):
            if key in p:
                setattr(plugin, key, p[key])
        if "tags" in p:
            plugin.tags = p["tags"]
        if "dependencies" in p:
            plugin.dependencies = p["dependencies"]
        new_ver = p.get("new_version")
        if new_ver:
            plugin.versions.append({"version": new_ver, "published_at": datetime.now(timezone.utc).isoformat()})
            plugin.version = new_ver
        plugin.updated_at = datetime.now(timezone.utc).isoformat()
        return {"plugin_id": pid, "version": plugin.version}

    def _action_delete_plugin(self, p: Dict) -> Dict:
        pid = p.get("plugin_id", "")
        if pid not in self._plugins:
            return {"error": "Plugin not found"}
        del self._plugins[pid]
        return {"plugin_id": pid, "deleted": True}

    def _action_search_plugins(self, p: Dict) -> Dict:
        query = p.get("query", "").lower()
        category = p.get("category")
        author = p.get("author")
        status = p.get("status", "approved")
        results = []
        for plugin in self._plugins.values():
            if status and plugin.status != status:
                continue
            if category and plugin.category != category:
                continue
            if author and plugin.author != author:
                continue
            if query:
                text = f"{plugin.name} {plugin.description} {' '.join(plugin.tags)}".lower()
                if query not in text:
                    continue
            results.append(plugin.to_dict())
        results.sort(key=lambda x: x["downloads"], reverse=True)
        limit = p.get("limit", 50)
        return {"results": results[:limit], "total": len(results)}

    def _action_list_plugins(self, p: Dict) -> Dict:
        plugins = list(self._plugins.values())
        cat = p.get("category")
        status = p.get("status")
        if cat:
            plugins = [pl for pl in plugins if pl.category == cat]
        if status:
            plugins = [pl for pl in plugins if pl.status == status]
        return {"plugins": [pl.to_dict() for pl in plugins], "count": len(plugins)}

    def _action_install(self, p: Dict) -> Dict:
        pid = p.get("plugin_id", "")
        if pid not in self._plugins:
            return {"error": "Plugin not found"}
        catalog = {pid: pl.to_dict() for pid, pl in self._plugins.items()}
        resolution = self._dep_resolver.resolve(pid, catalog, set(self._installed.keys()))
        if resolution["missing"]:
            return {"error": "Missing dependencies", "missing": resolution["missing"]}
        conflicts = self._dep_resolver.check_conflicts(pid, catalog, self._installed)
        if conflicts:
            return {"error": "Dependency conflicts", "conflicts": conflicts}
        for inst_pid in resolution["install_order"]:
            if inst_pid not in self._installed:
                self._installed[inst_pid] = self._plugins[inst_pid].version
                self._plugins[inst_pid].downloads += 1
                self._install_log.append({"plugin_id": inst_pid, "action": "install",
                                          "timestamp": datetime.now(timezone.utc).isoformat()})
        return {"installed": resolution["install_order"], "conflicts": [], "missing": []}

    def _action_uninstall(self, p: Dict) -> Dict:
        pid = p.get("plugin_id", "")
        if pid not in self._installed:
            return {"error": "Plugin not installed"}
        dependents = []
        for inst_pid, ver in self._installed.items():
            if inst_pid == pid:
                continue
            plugin = self._plugins.get(inst_pid)
            if plugin and pid in plugin.dependencies:
                dependents.append(inst_pid)
        if dependents and not p.get("force"):
            return {"error": "Has dependents", "dependents": dependents}
        del self._installed[pid]
        self._install_log.append({"plugin_id": pid, "action": "uninstall",
                                  "timestamp": datetime.now(timezone.utc).isoformat()})
        return {"plugin_id": pid, "uninstalled": True}

    def _action_installed_plugins(self, p: Dict) -> Dict:
        result = []
        for pid, ver in self._installed.items():
            plugin = self._plugins.get(pid)
            result.append({"plugin_id": pid, "version": ver,
                           "name": plugin.name if plugin else pid})
        return {"installed": result, "count": len(result)}

    def _action_scan_security(self, p: Dict) -> Dict:
        pid = p.get("plugin_id", "")
        if pid not in self._plugins:
            return {"error": "Plugin not found"}
        plugin = self._plugins[pid]
        scan = SecurityScanResult(f"scan_{uuid.uuid4().hex[:8]}", pid)
        plugin_code = p.get("code", "")
        deps = plugin.dependencies
        vulns = []
        score = 100
        if "eval" in plugin_code or "exec" in plugin_code or "__import__" in plugin_code:
            vulns.append({"type": "dangerous_function", "severity": "high",
                          "description": "Uses eval/exec/dynamic import"})
            score -= 30
        if re.search(r'password\s*=\s*["\']', plugin_code, re.IGNORECASE):
            vulns.append({"type": "hardcoded_secret", "severity": "high",
                          "description": "Potential hardcoded secret"})
            score -= 25
        if "requests.get" in plugin_code and "verify=False" in plugin_code:
            vulns.append({"type": "ssl_disabled", "severity": "medium",
                          "description": "SSL verification disabled"})
            score -= 15
        if "sql" in plugin_code.lower() and "%" in plugin_code:
            vulns.append({"type": "sql_injection_risk", "severity": "high",
                          "description": "Potential SQL injection via string formatting"})
            score -= 30
        scan.vulnerabilities = vulns
        scan.score = max(0, score)
        scan.risk_level = "critical" if score < 40 else "high" if score < 70 else "medium" if score < 90 else "low"
        scan.status = "completed"
        plugin.security_scans.append(scan)
        return {"scan_id": scan.scan_id, "score": scan.score, "risk_level": scan.risk_level,
                "vulnerabilities": vulns}

    def _action_rate_plugin(self, p: Dict) -> Dict:
        pid = p.get("plugin_id", "")
        if pid not in self._plugins:
            return {"error": "Plugin not found"}
        plugin = self._plugins[pid]
        rating = max(1, min(5, int(p.get("rating", 5))))
        review = {"user": p.get("user", "anonymous"), "rating": rating,
                  "comment": p.get("comment", ""),
                  "timestamp": datetime.now(timezone.utc).isoformat()}
        plugin.reviews.append(review)
        total = sum(r["rating"] for r in plugin.reviews)
        plugin.rating = round(total / len(plugin.reviews), 1)
        plugin.rating_count = len(plugin.reviews)
        return {"plugin_id": pid, "rating": plugin.rating, "total_reviews": plugin.rating_count}

    def _action_resolve_dependencies(self, p: Dict) -> Dict:
        pid = p.get("plugin_id", "")
        catalog = {pid: pl.to_dict() for pid, pl in self._plugins.items()}
        return self._dep_resolver.resolve(pid, catalog, set(self._installed.keys()))

    def _action_update_version(self, p: Dict) -> Dict:
        pid = p.get("plugin_id", "")
        if pid not in self._plugins:
            return {"error": "Plugin not found"}
        plugin = self._plugins[pid]
        new_ver = p.get("version", "1.0.1")
        changelog = p.get("changelog", "")
        plugin.versions.append({"version": new_ver, "changelog": changelog,
                                "published_at": datetime.now(timezone.utc).isoformat()})
        plugin.version = new_ver
        plugin.updated_at = datetime.now(timezone.utc).isoformat()
        return {"plugin_id": pid, "version": new_ver, "total_versions": len(plugin.versions)}

    def _action_approve_plugin(self, p: Dict) -> Dict:
        pid = p.get("plugin_id", "")
        if pid not in self._plugins:
            return {"error": "Plugin not found"}
        self._plugins[pid].status = "approved"
        return {"plugin_id": pid, "status": "approved"}

    def _action_reject_plugin(self, p: Dict) -> Dict:
        pid = p.get("plugin_id", "")
        if pid not in self._plugins:
            return {"error": "Plugin not found"}
        self._plugins[pid].status = "rejected"
        self._plugins[pid].metadata = p.get("reason", "")
        return {"plugin_id": pid, "status": "rejected"}

    def _action_stats(self, p: Dict) -> Dict:
        by_cat = defaultdict(int)
        by_status = defaultdict(int)
        for pl in self._plugins.values():
            by_cat[pl.category] += 1
            by_status[pl.status] += 1
        return {"total_plugins": len(self._plugins), "installed_count": len(self._installed),
                "total_downloads": sum(pl.downloads for pl in self._plugins.values()),
                "avg_rating": round(sum(pl.rating for pl in self._plugins.values()) / max(1, len(self._plugins)), 1),
                "by_category": dict(by_cat), "by_status": dict(by_status)}

    def _action_categories(self, p: Dict) -> Dict:
        return {"categories": self._categories, "count": len(self._categories)}

    def _action_featured(self, p: Dict) -> Dict:
        featured = sorted(self._plugins.values(), key=lambda x: (x.downloads, x.rating), reverse=True)
        return {"featured": [pl.to_dict() for pl in featured[:p.get("limit", 10)]]}

    def _action_status(self, p: Dict) -> Dict:
        return {"module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
                "version": self.VERSION, "plugins_count": len(self._plugins),
                "installed_count": len(self._installed), "status": "running"}

    def _action_health(self, p: Dict) -> Dict:
        return {"healthy": True, "status": "ok", "plugins": len(self._plugins)}

    def _action_configure(self, p: Dict) -> Dict:
        return {"configured": list(p.keys()), "status": "ok"}

    def _action_reset(self, p: Dict) -> Dict:
        self._plugins.clear()
        self._installed.clear()
        self._install_log.clear()
        return {"status": "reset_ok"}


module_class = EvoPluginMarket
