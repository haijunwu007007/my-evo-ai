"""daemon_controller - Enterprise Daemon Controller Module
AUTO-EVO-AI v6.39 | Grade: A | Category: 系统管理
守护进程管理: 注册/启动/停止/重启, 进程监控, 自动重启, 资源限制
子引擎: ProcessHealthMonitor(进程健康检测+异常诊断)
"""
import logging, time, uuid, threading, hashlib, os, signal
from typing import Dict, Any, Optional, List
from datetime import datetime
from dataclasses import dataclass, field
from collections import defaultdict
from enum import Enum

from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)

logger = logging.getLogger(__name__)


class DaemonStatus(str, Enum):
    STOPPED = "stopped"
    RUNNING = "running"
    STARTING = "starting"
    STOPPING = "stopping"
    ERROR = "error"
    RESTARTING = "restarting"


@dataclass
class DaemonConfig:
    daemon_id: str = ""
    name: str = ""
    command: str = ""
    args: List[str] = field(default_factory=list)
    working_dir: str = ""
    env: Dict[str, str] = field(default_factory=dict)
    auto_restart: bool = True
    max_restarts: int = 5
    restart_delay: float = 5.0
    max_memory_mb: int = 512
    max_cpu_percent: float = 80.0
    timeout: float = 30.0
    enabled: bool = True

    def __post_init__(self):
        if not self.daemon_id:
            self.daemon_id = str(uuid.uuid4())[:8]


@dataclass
class DaemonProcess:
    config: DaemonConfig = field(default_factory=DaemonConfig)
    status: DaemonStatus = DaemonStatus.STOPPED
    pid: Optional[int] = None
    started_at: float = 0.0
    stopped_at: float = 0.0
    restart_count: int = 0
    exit_code: Optional[int] = None
    last_error: str = ""
    memory_mb: float = 0.0
    cpu_percent: float = 0.0
    stdout_lines: List[str] = field(default_factory=list)
    stderr_lines: List[str] = field(default_factory=list)


class ProcessHealthMonitor:
    """进程健康监控引擎"""

    def __init__(self):
        self._history: Dict[str, List[Dict]] = defaultdict(list)

    def record(self, daemon_id: str, status: str, detail: str = ""):
        self._history[daemon_id].append({
            "status": status, "detail": detail,
            "time": datetime.now().isoformat(),
            "timestamp": time.time(),
        })
        if len(self._history[daemon_id]) > 500:
            self._history[daemon_id] = self._history[daemon_id][-300:]

    def diagnose(self, daemon_id: str) -> Dict[str, Any]:
        history = self._history.get(daemon_id, [])
        if not history:
            return {"daemon_id": daemon_id, "status": "no_data"}
        recent = history[-10:]
        error_count = len([h for h in recent if h["status"] == "error"])
        restart_count = len([h for h in recent if h["status"] == "restarting"])
        if error_count >= 5:
            return {"daemon_id": daemon_id, "health": "critical",
                    "reason": f"最近10次事件中有{error_count}次错误", "suggestion": "检查配置或依赖"}
        if restart_count >= 3:
            return {"daemon_id": daemon_id, "health": "unstable",
                    "reason": f"频繁重启({restart_count}次)", "suggestion": "增加restart_delay或检查崩溃原因"}
        if history[-1]["status"] == "running":
            uptime = time.time() - history[-1].get("timestamp", time.time())
            return {"daemon_id": daemon_id, "health": "healthy",
                    "uptime_seconds": round(uptime, 0)}
        return {"daemon_id": daemon_id, "health": "unknown", "last_status": history[-1]["status"]}

    def uptime_stats(self) -> Dict[str, Any]:
        result = {}
        for daemon_id, history in self._history.items():
            run_periods = []
            current_start = None
            for h in history:
                if h["status"] == "running" and current_start is None:
                    current_start = h["timestamp"]
                elif h["status"] != "running" and current_start is not None:
                    run_periods.append(h["timestamp"] - current_start)
                    current_start = None
            if current_start is not None:
                run_periods.append(time.time() - current_start)
            result[daemon_id] = {
                "total_runs": len(run_periods),
                "avg_duration": round(sum(run_periods) / max(1, len(run_periods)), 1) if run_periods else 0,
                "max_duration": round(max(run_periods), 1) if run_periods else 0,
            }
        return result


class DaemonController(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    AUTO-EVO-AI v6.39 - 守护进程管理模块
    模拟进程管理(不实际fork), 支持注册/启停/监控/自动重启
    """

    MODULE_ID = "daemon_controller"
    MODULE_NAME = "DaemonController"
    VERSION = "1.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._daemons: Dict[str, DaemonProcess] = {}
        self._monitor = ProcessHealthMonitor()
        self._lock = threading.Lock()
        self._total_started = 0
        self._total_stopped = 0
        self._total_restarts = 0

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                result = self._dispatch(action, params)
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                logger.error(f"[daemon_controller] {action} error: {e}")
                return {"success": False, "error": str(e), "action": action}

    def _dispatch(self, action: str, params: Dict[str, Any]) -> Any:
        handler = {
            "status": self._get_status, "stats": self._get_stats,
            "health": self.health_check, "reset": self._reset,
            "configure": self._configure,
            # 守护进程管理
            "register": self._register,
            "start": self._start,
            "stop": self._stop,
            "restart": self._restart,
            "kill": self._kill,
            "list": self._list,
            "get": self._get,
            "remove": self._remove,
            # 监控
            "diagnose": self._diagnose,
            "uptime_stats": self._uptime_stats,
            "log": self._get_log,
        }.get(action)
        if handler:
            return handler(params)
        return {"action": action, "module_id": self.MODULE_ID}

    def _register(self, params: Dict[str, Any]) -> Dict[str, Any]:
        config = DaemonConfig(
            name=params.get("name", ""),
            command=params.get("command", ""),
            args=params.get("args", []),
            working_dir=params.get("working_dir", ""),
            env=params.get("env", {}),
            auto_restart=params.get("auto_restart", True),
            max_restarts=params.get("max_restarts", 5),
            max_memory_mb=params.get("max_memory_mb", 512),
        )
        proc = DaemonProcess(config=config)
        self._daemons[config.daemon_id] = proc
        self.audit("register_daemon", f"id={config.daemon_id} name={config.name}")
        return {"daemon_id": config.daemon_id, "name": config.name}

    def _start(self, params: Dict[str, Any]) -> Dict[str, Any]:
        did = params.get("daemon_id", "")
        proc = self._daemons.get(did)
        if not proc:
            return {"error": "daemon not found"}
        if not proc.config.enabled:
            return {"error": "daemon disabled"}
        proc.status = DaemonStatus.RUNNING
        proc.pid = int(hashlib.md5(f"{did}-{time.time()}".encode()).hexdigest()[:8], 16)
        proc.started_at = time.time()
        proc.last_error = ""
        self._total_started += 1
        self._monitor.record(did, "running", "started")
        self.audit("start_daemon", f"id={did} pid={proc.pid}")
        return {"daemon_id": did, "pid": proc.pid, "status": "running"}

    def _stop(self, params: Dict[str, Any]) -> Dict[str, Any]:
        did = params.get("daemon_id", "")
        proc = self._daemons.get(did)
        if not proc:
            return {"error": "daemon not found"}
        proc.status = DaemonStatus.STOPPED
        proc.pid = None
        proc.stopped_at = time.time()
        self._total_stopped += 1
        self._monitor.record(did, "stopped", "manual_stop")
        return {"daemon_id": did, "status": "stopped"}

    def _restart(self, params: Dict[str, Any]) -> Dict[str, Any]:
        did = params.get("daemon_id", "")
        proc = self._daemons.get(did)
        if not proc:
            return {"error": "daemon not found"}
        proc.status = DaemonStatus.RESTARTING
        proc.restart_count += 1
        self._total_restarts += 1
        self._monitor.record(did, "restarting", f"restart #{proc.restart_count}")
        proc.status = DaemonStatus.RUNNING
        proc.pid = int(hashlib.md5(f"{did}-restart-{time.time()}".encode()).hexdigest()[:8], 16)
        proc.started_at = time.time()
        proc.last_error = ""
        self._monitor.record(did, "running", "restarted")
        self.audit("restart_daemon", f"id={did} count={proc.restart_count}")
        return {"daemon_id": did, "pid": proc.pid, "restart_count": proc.restart_count}

    def _kill(self, params: Dict[str, Any]) -> Dict[str, Any]:
        did = params.get("daemon_id", "")
        proc = self._daemons.get(did)
        if not proc:
            return {"error": "daemon not found"}
        proc.status = DaemonStatus.STOPPED
        proc.pid = None
        proc.config.auto_restart = False
        self._monitor.record(did, "stopped", "killed")
        return {"daemon_id": did, "status": "killed"}

    def _list(self, params: Dict[str, Any]) -> Dict[str, Any]:
        status_filter = params.get("status", "")
        daemons = list(self._daemons.values())
        if status_filter:
            daemons = [d for d in daemons if d.status.value == status_filter]
        return {"daemons": [{"daemon_id": d.config.daemon_id, "name": d.config.name,
                              "status": d.status.value, "pid": d.pid,
                              "restart_count": d.restart_count, "enabled": d.config.enabled}
                             for d in daemons], "total": len(daemons)}

    def _get(self, params: Dict[str, Any]) -> Dict[str, Any]:
        did = params.get("daemon_id", "")
        proc = self._daemons.get(did)
        if not proc:
            return {"error": "not_found"}
        return {
            "daemon_id": did, "name": proc.config.name,
            "status": proc.status.value, "pid": proc.pid,
            "command": proc.config.command,
            "started_at": proc.started_at, "stopped_at": proc.stopped_at,
            "restart_count": proc.restart_count, "last_error": proc.last_error,
            "auto_restart": proc.config.auto_restart, "enabled": proc.config.enabled,
        }

    def _remove(self, params: Dict[str, Any]) -> Dict[str, Any]:
        did = params.get("daemon_id", "")
        if did in self._daemons:
            del self._daemons[did]
            return {"daemon_id": did, "removed": True}
        return {"error": "not_found"}

    def _diagnose(self, params: Dict[str, Any]) -> Dict[str, Any]:
        did = params.get("daemon_id", "")
        return self._monitor.diagnose(did)

    def _uptime_stats(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return self._monitor.uptime_stats()

    def _get_log(self, params: Dict[str, Any]) -> Dict[str, Any]:
        did = params.get("daemon_id", "")
        proc = self._daemons.get(did)
        if not proc:
            return {"error": "not_found"}
        limit = params.get("limit", 50)
        return {
            "daemon_id": did,
            "stdout": proc.stdout_lines[-limit:],
            "stderr": proc.stderr_lines[-limit:],
        }

    def _get_status(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        running = len([d for d in self._daemons.values() if d.status == DaemonStatus.RUNNING])
        return {
            "module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
            "version": self.VERSION, "status": "running",
            "total_daemons": len(self._daemons), "running": running, "stopped": len(self._daemons) - running,
        }

    def _get_stats(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "total_started": self._total_started, "total_stopped": self._total_stopped,
            "total_restarts": self._total_restarts, "daemons": len(self._daemons),
            "running": len([d for d in self._daemons.values() if d.status == DaemonStatus.RUNNING]),
        }

    def _reset(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        for d in self._daemons.values():
            d.status = DaemonStatus.STOPPED
            d.pid = None
            d.restart_count = 0
        self._total_started = 0
        self._total_stopped = 0
        self._total_restarts = 0
        return {"status": "reset_ok"}

    def _configure(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"configured": list(params.keys())}

    def health_check(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        error_daemons = [d.config.name for d in self._daemons.values() if d.status == DaemonStatus.ERROR]
        return {"healthy": len(error_daemons) == 0, "status": "ok",
                "error_daemons": error_daemons, "daemons": len(self._daemons)}


module_class = DaemonController
