"""
        AUTO-EVO-AI v7.0 — MongoDB文档数据库模块
Grade: A (生产级) | Category: 数据存储
职责：MongoDB集合管理、CRUD操作、聚合管道、索引管理、副本集监控
"""

import os
import asyncio
import time
import logging
import threading
import hashlib
import re
import uuid
from typing import Any, Dict, List, Optional
from datetime import datetime
from enum import Enum
from dataclasses import dataclass, field
from collections import OrderedDict

try:
    from modules._base.enterprise_module import (
    EnterpriseModule,
    ModuleStatus, CircuitBreakerMixin, RateLimiterMixin
)
    from modules._base.tracing import trace_operation
    from modules._base.metrics import metrics_collector, prometheus_timer
    from modules._base.audit import AuditLogger
except ImportError:
    class EnterpriseModule:
        def __init__(self, config=None): pass
        pass
    class ModuleStatus: ACTIVE='active'; STOPPED='stopped'
    trace_operation = prometheus_timer = metrics_collector = AuditLogger = lambda **kw: (lambda f: f)

    logger = logging.getLogger(__name__)


@dataclass
class MongoCollection:
    """MongoDB集合"""
    name: str
    database: str = 'evo_db'
    documents: List[dict] = field(default_factory=list)
    indexes: List[dict] = field(default_factory=list)
    schema_rules: Dict[str, str] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    _auto_id_counter: int = 0

    def insert(self, doc: dict) -> dict:
        self._auto_id_counter += 1
        doc['_id'] = doc.get('_id', str(uuid.uuid4())[:8])
        doc['created_at'] = datetime.now().isoformat()
        self.documents.append(doc)
        return doc

    def find(self, query: dict = None, projection: dict = None,
             sort: list = None, skip: int = 0, limit: int = 100) -> List[dict]:
        results = list(self.documents)
        if query:
            results = self._match(results, query)
        if sort:
            key, order = sort[0], -1 if sort[1] == -1 else 1
            results.sort(key=lambda x: x.get(key, ''), reverse=order < 0)
        results = results[skip:skip + limit]
        if projection:
            results = [{k: v for k, v in r.items() if k in projection} for r in results]
        return results

    def _match(self, docs: List[dict], query: dict) -> List[dict]:
        results = []
        for doc in docs:
            match = True
            for key, val in query.items():
                if key == '$and':
                    if not all(self._match_single(doc, q) for q in val):
                        match = False; break
                elif key == '$or':
                    if not any(self._match_single(doc, q) for q in val):
                        match = False; break
                elif key == '$text':
                    search = val.get('$search', '')
                    if not any(search.lower() in str(v).lower() for v in doc.values()):
                        match = False; break
                else:
                    if not self._match_single(doc, {key: val}):
                        match = False; break
            if match:
                results.append(doc)
        return results

    def _match_single(self, doc: dict, query: dict) -> bool:
        for key, val in query.items():
            doc_val = doc.get(key)
            if isinstance(val, dict):
                for op, target in val.items():
                    if op == '$gt' and not (doc_val and doc_val > target):
                        return False
                    if op == '$gte' and not (doc_val and doc_val >= target):
                        return False
                    if op == '$lt' and not (doc_val and doc_val < target):
                        return False
                    if op == '$lte' and not (doc_val and doc_val <= target):
                        return False
                    if op == '$ne' and doc_val == target:
                        return False
                    if op == '$in' and doc_val not in target:
                        return False
                    if op == '$regex' and not re.search(target, str(doc_val)):
                        return False
            elif doc_val != val:
                return False
        return True

    def update_one(self, query: dict, update: dict) -> dict:
        for doc in self.documents:
            if self._match_single(doc, query):
                if '$set' in update:
                    doc.update(update['$set'])
                if '$inc' in update:
                    for k, v in update['$inc'].items():
                        doc[k] = doc.get(k, 0) + v
                if '$push' in update:
                    for k, v in update['$push'].items():
                        doc.setdefault(k, []).append(v)
                if '$pull' in update:
                    for k, v in update['$pull'].items():
                        if k in doc:
                            doc[k] = [x for x in doc[k] if x != v]
                doc['updated_at'] = datetime.now().isoformat()
                return {'matched': 1, 'modified': 1}
        return {'matched': 0, 'modified': 0}

    def delete_one(self, query: dict) -> dict:
        for i, doc in enumerate(self.documents):
            if self._match_single(doc, query):
                self.documents.pop(i)
                return {'deleted': 1}
        return {'deleted': 0}

    def count(self, query: dict = None) -> int:
        if not query:
            return len(self.documents)
        return len(self._match(self.documents, query))

    def aggregate(self, pipeline: List[dict]) -> List[dict]:
        results = list(self.documents)
        for stage in pipeline:
            if '$match' in stage:
                results = self._match(results, stage['$match'])
            elif '$group' in stage:
                g = stage['$group']
                _id = g.get('_id', None)
                groups: Dict[Any, dict] = OrderedDict()
                for doc in results:
                    key = doc.get(_id, 'null') if _id and _id != 'null' else 'null'
                    if key not in groups:
                        groups[key] = {'_id': key}
                    for k, v in g.items():
                        if k == '_id':
                            continue
                        if v == '$sum' and v == {'$sum': 1}:
                            groups[key][k] = groups[key].get(k, 0) + 1
                        elif isinstance(v, dict) and '$sum' in v:
                            field_name = v['$sum'].lstrip('$')
                            groups[key][k] = groups[key].get(k, 0) + doc.get(field_name, 0)
                        elif isinstance(v, dict) and '$avg' in v:
                            field_name = v['$avg'].lstrip('$')
                            groups[key].setdefault(f'_{k}_sum', 0)
                            groups[key].setdefault(f'_{k}_count', 0)
                            groups[key][f'_{k}_sum'] += doc.get(field_name, 0)
                            groups[key][f'_{k}_count'] += 1
                # Post-process averages
                for gdata in groups.values():
                    for k in list(gdata.keys()):
                        if k.startswith('_') and k.endswith('_sum'):
                            base = k[1:-4]
                            cnt = gdata.get(f'_{base}_count', 0)
                            if cnt > 0:
                                gdata[base] = round(gdata[k] / cnt, 2)
                            del gdata[k]
                            if f'_{base}_count' in gdata:
                                del gdata[f'_{base}_count']
                results = list(groups.values())
            elif '$sort' in stage:
                key = list(stage['$sort'].keys())[0]
                order = list(stage['$sort'].values())[0]
                results.sort(key=lambda x: x.get(key, 0), reverse=order < 0)
            elif '$limit' in stage:
                results = results[:stage['$limit']]
            elif '$skip' in stage:
                results = results[stage['$skip']:]
            elif '$project' in stage:
                results = [{k: v for k, v in r.items() if k in stage['$project']}
                           for r in results]
            elif '$unwind' in stage:
                field = stage['$unwind']
                new_results = []
                for doc in results:
                    vals = doc.get(field, [])
                    if isinstance(vals, list):
                        for v in vals:
                            nd = dict(doc)
                            nd[field] = v
                            new_results.append(nd)
                    else:
                        new_results.append(doc)
                results = new_results
            elif '$count' in stage:
                results = [{'count': len(results)}]
        return results

    def stats(self) -> dict:
        return {'name': self.name, 'documents': len(self.documents),
                'indexes': len(self.indexes), 'size_bytes': len(str(self.documents))}



class MongoQueryAnalyzer(object):
    """mongodb_nosql 运营分析引擎
    
    - 分析慢查询模式
    - 检测索引缺失
    - 统计分片均衡
    """
    
    def __init__(self):
        self._stats = {}
    
    def record(self, metric: str, value: float = 1.0):
        self._stats.setdefault(metric, []).append(value)
        if len(self._stats[metric]) > 1000:
            self._stats[metric] = self._stats[metric][-500:]
    
    def analyze(self) -> dict:
        summary = {}
        for k, v in self._stats.items():
            if v:
                summary[k] = {"count": len(v), "avg": sum(v)/len(v), "last": v[-1]}
        return {"analyzer": "MongoQueryAnalyzer", "module": "mongodb_nosql", "summary": summary}

class MongoDBModule(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """MongoDB生产级文档数据库"""

    def __init__(self, config=None):

        super().__init__(config)
        self._collections: Dict[str, MongoCollection] = {}
        self._lock = threading.Lock()
        self._read_preference = 'primary'
        self._write_concern = {'w': 'majority', 'j': True}

    def _cfg(self, key, default):
        if self.config and isinstance(self.config, dict):
            return self.config.get(key, default)
        return default

    def initialize(self) -> dict:
        self.trace("mongodb_nosql.initialize", "start")
        self.trace("mongodb_nosql.initialize", "end")
        self.audit('initialize', 'MongoDB模块初始化')
        # Seed sample data
        users = MongoCollection('users')
        for i in range(1, 51):
            users.insert({
                'username': f'user_{i}', 'email': f'u{i}@evo.ai',
                'age': 20 + (i % 30), 'role': ['admin', 'editor', 'user'][i % 3],
                'score': 50 + i * 3, 'tags': ['active', 'verified'] if i % 2 == 0 else ['active']
            })
        orders = MongoCollection('orders')
        for i in range(1, 31):
            orders.insert({
                'user_id': f'user_{(i % 50) + 1}', 'amount': 10.0 + i * 5.5,
                'status': ['pending', 'shipped', 'delivered', 'cancelled'][i % 4],
                'items': [{'name': f'item_{j}', 'qty': j + 1} for j in range(i % 4 + 1)]
            })
        logs = MongoCollection('logs')
        for i in range(1, 101):
            logs.insert({
                'level': ['INFO', 'WARN', 'ERROR', 'DEBUG'][i % 4],
                'message': f'Log entry {i}', 'service': ['api', 'worker', 'scheduler'][i % 3],
                'timestamp': datetime.now().isoformat()
            })
        with self._lock:
            self._collections['users'] = users
            self._collections['orders'] = orders
            self._collections['logs'] = logs
        return {'success': True, 'collections': 3, 'total_documents': 181,
                'read_preference': self._read_preference}

    def health_check(self) -> dict:
        return {'healthy': True, 'collections': list(self._collections.keys()),
                'total_documents': sum(c.count() for c in self._collections.values())}

    async def execute(self, action: str, params: dict = None) -> dict:
        params = params or {}
        actions = {
            'insert': self._insert, 'find': self._find, 'get': self._get,
            'update': self._update, 'delete': self._delete,
            'list_collections': self._list_collections,
            'create_collection': self._create_collection,
            'drop_collection': self._drop_collection, 'count': self._count,
            'aggregate': self._aggregate, 'index': self._create_index
        }
        handler = actions.get(action)
        if handler:
            return handler(params)
        return {'success': False, 'error': f'Unsupported: {action}'}
