"""
Data Masking Module - 数据脱敏引擎
企业级敏感数据动态脱敏与静态脱敏服务

生产级实现: 支持多种脱敏策略、正则匹配、字段级脱敏、审计日志
"""

import re
import hashlib
import hmac
import base64
import time
import logging
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
from dataclasses import dataclass, field
from enum import Enum
import json
import random
from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector


logger = logging.getLogger(__name__)


class DataMaskingAnalyzer(object):
    """data_masking 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "data_masking"
        self.version = "1.0.0"
        self._analyzer = DataMaskingAnalyzer()
        self._history = []
        self._max_history = 10000
    
    def analyze(self, context: dict = None) -> dict:
        context = context or {}
        result = {"analyzer": "DataMaskingAnalyzer", "timestamp": time.time(), "records": len(self._history), "summary": self._summary()}
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-5000:]
        return result
    
    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "data_masking"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== data_masking ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}

class MaskingStrategy(Enum):
    """脱敏策略枚举"""
    FULL_REPLACE = "full_replace"        # 全部替换为*
    PARTIAL_REPLACE = "partial_replace"  # 部分替换(保留首尾)
    HASH_REPLACE = "hash_replace"        # 哈希替换(不可逆)
    TOKENIZE = "tokenize"               # 令牌化替换(可逆)
    RANDOMIZE = "randomize"             # 随机替换(保持格式)
    NULLIFY = "nullify"                # 置空
    ENCRYPT = "encrypt"                # 加密存储


@dataclass
class MaskingRule:
    """脱敏规则定义"""
    rule_id: str
    rule_name: str
    field_pattern: str          # 字段名匹配模式
    data_type: str              # 数据类型: email, phone, id_card, name, bank_card, address, custom
    strategy: MaskingStrategy
    pattern: Optional[str] = None  # 自定义正则
    preserve_prefix: int = 1
    preserve_suffix: int = 1
    replacement_char: str = "*"
    enabled: bool = True
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class MaskingAuditRecord:
    """脱敏审计记录"""
    timestamp: str
    rule_id: str
    field_name: str
    strategy: str
    original_length: int
    masked_length: int
    operator: str = "system"
    source_table: str = ""
    source_db: str = ""


class DataMaskingEngine(object):
    """数据脱敏核心引擎"""

    # 内置数据类型正则模式库
    PATTERNS = {
        "email": r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}',
        "phone_cn": r'1[3-9]\d{9}',
        "id_card_cn": r'[1-9]\d{5}(?:19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])\d{3}[\dXx]',
        "bank_card_cn": r'[3-6]\d{14,18}',
        "name_cn": r'[\u4e00-\u9fa5]{2,4}',
        "ipv4": r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}',
        "credit_card": r'(?:\d{4}[\s\-]?){3}\d{4}',
        "ssn_us": r'\d{3}[\-]?\d{2}[\-]?\d{4}',
    }

    # 字段名自动识别映射
    FIELD_TYPE_MAP = {
        "email": ["email", "e_mail", "mailbox", "mail"],
        "phone_cn": ["phone", "mobile", "tel", "telephone", "cellphone", "手机", "电话"],
        "id_card_cn": ["id_card", "idcard", "identity", "身份证", "certificate"],
        "bank_card_cn": ["bank_card", "bankcard", "card_no", "银行卡"],
        "name_cn": ["name", "real_name", "user_name", "customer_name", "姓名", "用户名"],
        "address": ["address", "addr", "location", "地址"],
        "ip": ["ip", "ip_address", "remote_addr", "client_ip"],
    }

    def __init__(self):
        self.rules: Dict[str, MaskingRule] = {}
        self.audit_log: List[MaskingAuditRecord] = []
        self.token_store: Dict[str, str] = {}  # 令牌化双向映射
        self._init_builtin_rules()

    def _init_builtin_rules(self):
        """初始化内置脱敏规则"""
        builtin = [
            MaskingRule("rule_email", "邮箱脱敏", "email", "email",
                       MaskingStrategy.PARTIAL_REPLACE, preserve_prefix=3, preserve_suffix=5),
            MaskingRule("rule_phone", "手机号脱敏", "phone", "phone_cn",
                       MaskingStrategy.PARTIAL_REPLACE, preserve_prefix=3, preserve_suffix=4),
            MaskingRule("rule_id_card", "身份证脱敏", "id_card", "id_card_cn",
                       MaskingStrategy.PARTIAL_REPLACE, preserve_prefix=3, preserve_suffix=4),
            MaskingRule("rule_bank_card", "银行卡脱敏", "bank_card", "bank_card_cn",
                       MaskingStrategy.PARTIAL_REPLACE, preserve_prefix=4, preserve_suffix=4),
            MaskingRule("rule_name", "姓名脱敏", "name", "name_cn",
                       MaskingStrategy.PARTIAL_REPLACE, preserve_prefix=1, preserve_suffix=0),
            MaskingRule("rule_ip", "IP地址脱敏", "ip", "ipv4",
                       MaskingStrategy.PARTIAL_REPLACE, preserve_prefix=4, preserve_suffix=3),
            MaskingRule("rule_address", "地址脱敏", "address", "address",
                       MaskingStrategy.PARTIAL_REPLACE, preserve_prefix=6, preserve_suffix=0),
        ]
        for rule in builtin:
            self.rules[rule.rule_id] = rule

    def detect_data_type(self, field_name: str, value: str) -> Optional[str]:
        """自动检测数据类型"""
        field_lower = field_name.lower().strip()
        for dtype, keywords in self.FIELD_TYPE_MAP.items():
            for kw in keywords:
                if kw in field_lower:
                    return dtype
        # 正则匹配
        for dtype, pattern in self.PATTERNS.items():
            if re.fullmatch(pattern, value.strip()):
                return dtype
        return None

    def _mask_partial(self, value: str, rule: MaskingRule) -> str:
        """部分替换脱敏"""
        length = len(value)
        prefix_len = min(rule.preserve_prefix, length)
        suffix_len = min(rule.preserve_suffix, length - prefix_len)
        mask_len = length - prefix_len - suffix_len
        if mask_len <= 0:
            return value
        return value[:prefix_len] + rule.replacement_char * mask_len + value[length - suffix_len:]

    def _mask_hash(self, value: str) -> str:
        """哈希脱敏(不可逆)"""
        return hashlib.sha256(value.encode('utf-8')).hexdigest()[:16]

    def _mask_tokenize(self, value: str) -> str:
        """令牌化脱敏(可逆)"""
        if value in self.token_store:
            return self.token_store[value]
        token = "TK_" + hashlib.md5((value + str(time.time())).encode()).hexdigest()[:12].upper()
        self.token_store[value] = token
        self.token_store[token] = value
        return token

    def _mask_randomize(self, value: str, data_type: str) -> str:
        """随机替换(保持格式)"""
        if data_type == "phone_cn" and len(value) == 11:
            return "1" + random.choice("3456789") + ''.join(random.choices(string.digits, k=9))
        if data_type == "id_card_cn" and len(value) == 18:
            area = random.choice(["110101", "310101", "440301", "510101", "330102"])
            return area + "19900101" + ''.join(random.choices(string.digits, k=3)) + random.choice("0123456789X")
        if data_type == "email" and "@" in value:
            local, domain = value.split("@", 1)
            new_local = ''.join(random.choices(string.ascii_lowercase + string.digits, k=len(local)))
            return new_local + "@" + domain
        return ''.join(random.choices(string.ascii_letters + string.digits, k=len(value)))

    def _mask_nullify(self, value: str) -> str:
        """置空"""
        return "[已脱敏]"

    def mask_field(self, field_name: str, value: str, strategy: Optional[MaskingStrategy] = None) -> Tuple[str, Optional[str]]:
        """
        对单个字段值执行脱敏
        返回: (masked_value, rule_id)
        """
        if not value or not isinstance(value, str):
            return value, None

        # 查找匹配规则
        matched_rule = None
        for rule in self.rules.values():
            if not rule.enabled:
                continue
            if re.search(rule.field_pattern, field_name, re.IGNORECASE):
                matched_rule = rule
                break

        if not matched_rule:
            dtype = self.detect_data_type(field_name, value)
            if dtype:
                for rule in self.rules.values():
                    if rule.data_type == dtype and rule.enabled:
                        matched_rule = rule
                        break

        if not matched_rule:
            return value, None

        active_strategy = strategy or matched_rule.strategy
        original_len = len(value)

        if active_strategy == MaskingStrategy.FULL_REPLACE:
            masked = matched_rule.replacement_char * len(value)
        elif active_strategy == MaskingStrategy.PARTIAL_REPLACE:
            masked = self._mask_partial(value, matched_rule)
        elif active_strategy == MaskingStrategy.HASH_REPLACE:
            masked = self._mask_hash(value)
        elif active_strategy == MaskingStrategy.TOKENIZE:
            masked = self._mask_tokenize(value)
        elif active_strategy == MaskingStrategy.RANDOMIZE:
            masked = self._mask_randomize(value, matched_rule.data_type)
        elif active_strategy == MaskingStrategy.NULLIFY:
            masked = self._mask_nullify(value)
        else:
            masked = value

        # 审计记录
        self.audit_log.append(MaskingAuditRecord(
            timestamp=datetime.now().isoformat(),
            rule_id=matched_rule.rule_id,
            field_name=field_name,
            strategy=active_strategy.value,
            original_length=original_len,
            masked_length=len(masked),
        ))

        return masked, matched_rule.rule_id

    def mask_record(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """对整条记录脱敏"""
        masked = {}
        applied_rules = set()
        for key, value in record.items():
            if isinstance(value, str):
                new_val, rule_id = self.mask_field(key, value)
                masked[key] = new_val
                if rule_id:
                    applied_rules.add(rule_id)
            elif isinstance(value, (list, tuple)):
                masked[key] = [self.mask_field(key, str(v))[0] if isinstance(v, str) else v for v in value]
            elif isinstance(value, dict):
                masked[key] = self.mask_record(value)
            else:
                masked[key] = value
        return masked

    def mask_batch(self, records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """批量脱敏"""
        return [self.mask_record(r) for r in records]

    def add_rule(self, rule: MaskingRule) -> bool:
        """添加自定义脱敏规则"""
        if rule.rule_id in self.rules:
            logger.warning(f"Rule {rule.rule_id} already exists, updating")
        self.rules[rule.rule_id] = rule
        logger.info(f"Added masking rule: {rule.rule_name} ({rule.rule_id})")
        return True

    def remove_rule(self, rule_id: str) -> bool:
        """移除脱敏规则"""
        if rule_id in self.rules:
            del self.rules[rule_id]
            return True
        return False

    def get_audit_summary(self) -> Dict[str, Any]:
        """获取脱敏审计摘要"""
        total = len(self.audit_log)
        by_strategy = {}
        by_field = {}
        for record in self.audit_log[-1000:]:
            by_strategy[record.strategy] = by_strategy.get(record.strategy, 0) + 1
            by_field[record.field_name] = by_field.get(record.field_name, 0) + 1

        return {
            "total_operations": total,
            "active_rules": len([r for r in self.rules.values() if r.enabled]),
            "total_rules": len(self.rules),
            "token_store_size": len(self.token_store) // 2,
            "by_strategy": by_strategy,
            "by_field": dict(sorted(by_field.items(), key=lambda x: -x[1])[:20]),
            "recent_records": [
                {
                    "timestamp": r.timestamp,
                    "rule_id": r.rule_id,
                    "field": r.field_name,
                    "strategy": r.strategy,
                }
                for r in self.audit_log[-10:]
            ],
        }

    def verify_masking(self, original: str, masked: str, strategy: MaskingStrategy) -> Dict[str, Any]:
        """验证脱敏结果是否符合策略"""
        checks = {
            "is_masked": original != masked,
            "length_preserved": len(original) == len(masked),
            "no_original_leaked": original not in masked,
            "is_empty": not masked,
            "strategy_match": True,
        }
        if strategy == MaskingStrategy.HASH_REPLACE:
            checks["is_hash_format"] = bool(re.match(r'^[a-f0-9]+$', masked))
        elif strategy == MaskingStrategy.TOKENIZE:
            checks["is_token_format"] = masked.startswith("TK_")
        elif strategy == MaskingStrategy.NULLIFY:
            checks["is_nullified"] = masked == "[已脱敏]"
        checks["pass"] = checks["is_masked"] and not checks["is_empty"]
        return checks


class DataMaskingModule:
    """数据脱敏模块 - 企业级敏感数据保护"""

    module_id = "data_masking"
    module_name = "Data Masking Engine"
    module_version = "1.0.0"
    module_category = "data_security"

    def __init__(self):
        self.engine = DataMaskingEngine()
        self._initialized = False
        self._stats = {
            "total_masked": 0,
            "total_records": 0,
            "total_batches": 0,
            "errors": 0,
        }

    def initialize(self) -> Dict[str, Any]:
        """初始化模块"""
        try:
            self.engine._init_builtin_rules()
            self._initialized = True
            return {
                "status": "success",
                "rules_loaded": len(self.engine.rules),
                "builtin_patterns": len(self.engine.PATTERNS),
                "field_mappings": len(self.engine.FIELD_TYPE_MAP),
            }
        except Exception as e:
            logger.error(f"Init failed: {e}")
            return {"status": "error", "message": str(e)}

    def execute(self, action: 

str = "mask_record", **kwargs) -> Dict[str, Any]:
        """执行脱敏操作"""
        if not self._initialized:
            self.initialize()

        try:
            if action == "mask_record":
                data = kwargs.get("data", {})
                if not data:
                    return {"status": "error", "message": "No data provided"}
                result = self.engine.mask_record(data)
                self._stats["total_records"] += 1
                self._stats["total_masked"] += len(data)
                return {"status": "success", "masked_data": result, "fields_processed": len(data)}

            elif action == "mask_batch":
                records = kwargs.get("records", [])
                if not records:
                    return {"status": "error", "message": "No records provided"}
                result = self.engine.mask_batch(records)
                self._stats["total_batches"] += 1
                self._stats["total_records"] += len(records)
                self._stats["total_masked"] += sum(len(r) for r in records)
                return {"status": "success", "masked_count": len(result), "records_processed": len(records)}

            elif action == "mask_field":
                field_name = kwargs.get("field_name", "")
                value = kwargs.get("value", "")
                if not field_name or not value:
                    return {"status": "error", "message": "field_name and value required"}
                masked, rule_id = self.engine.mask_field(field_name, str(value))
                self._stats["total_masked"] += 1
                return {
                    "status": "success",
                    "original": value,
                    "masked": masked,
                    "rule_applied": rule_id,
                    "was_masked": value != masked,
                }

            elif action == "add_rule":
                rule_data = kwargs.get("rule", {})
                rule = MaskingRule(
                    rule_id=rule_data.get("rule_id", f"custom_{int(time.time())}"),
                    rule_name=rule_data.get("rule_name", "Custom Rule"),
                    field_pattern=rule_data.get("field_pattern", ""),
                    data_type=rule_data.get("data_type", "custom"),
                    strategy=MaskingStrategy(rule_data.get("strategy", "full_replace")),
                    pattern=rule_data.get("pattern"),
                    preserve_prefix=rule_data.get("preserve_prefix", 1),
                    preserve_suffix=rule_data.get("preserve_suffix", 1),
                    replacement_char=rule_data.get("replacement_char", "*"),
                )
                success = self.engine.add_rule(rule)
                return {"status": "success" if success else "error", "rule_id": rule.rule_id}

            elif action == "verify":
                original = kwargs.get("original", "")
                masked = kwargs.get("masked", "")
                strategy = MaskingStrategy(kwargs.get("strategy", "partial_replace"))
                result = self.engine.verify_masking(str(original), str(masked), strategy)
                return {"status": "success", "verification": result}

            elif action == "audit_summary":
                return {"status": "success", "audit": self.engine.get_audit_summary()}

            elif action == "detect_type":
                field_name = kwargs.get("field_name", "")
                value = kwargs.get("value", "")
                dtype = self.engine.detect_data_type(field_name, str(value))
                return {
                    "status": "success",
                    "field": field_name,
                    "detected_type": dtype,
                    "pattern": self.engine.PATTERNS.get(dtype, "") if dtype else None,
                }

            else:
                return {"status": "error", "message": f"Unknown action: {action}"}

        except Exception as e:
            self._stats["errors"] += 1
            logger.error(f"Execute error: {e}")
            return {"status": "error", "message": str(e)}

    def health_check(self) -> Dict[str, Any]:
        """健康检查"""
        try:
            # 功能性测试
            test_cases = [
                ("email", "testuser@example.com"),
                ("phone", "13812345678"),
                ("id_card", "110101199001011234"),
                ("name", "张三"),
                ("bank_card", "6222021234567890123"),
            ]
            passed = 0
            results = []
            for field, value in test_cases:
                masked, rule_id = self.engine.mask_field(field, value)
                is_masked = value != masked
                passed += int(is_masked)
                results.append({"field": field, "masked": is_masked, "rule": rule_id})

            return {
                "status": "healthy",
                "module_id": self.module_id,
                "initialized": self._initialized,
                "rules": len(self.engine.rules),
                "patterns": len(self.engine.PATTERNS),
                "functional_test": f"{passed}/{len(test_cases)}",
                "stats": self._stats,
                "test_details": results,
            }
        except Exception as e:
            return {"status": "unhealthy", "error": str(e)}

    def get_stats(self) -> Dict[str, Any]:
        return {"status": "success", "stats": self._stats}

    def get_config(self) -> Dict[str, Any]:
        return {
            "status": "success",
            "config": {
                "module_id": self.module_id,
                "version": self.module_version,
                "rules": len(self.engine.rules),
                "strategies": [s.value for s in MaskingStrategy],
            },
        }

    def cleanup(self) -> Dict[str, Any]:
        self.engine.audit_log.clear()
        self.engine.token_store.clear()
        return {"status": "success", "message": "Audit log and token store cleared"}


module = DataMaskingModule()

module_class = DataMaskingModule

