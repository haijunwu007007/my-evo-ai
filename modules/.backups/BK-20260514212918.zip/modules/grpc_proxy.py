"""
        gRPC代理服务模块 - gRPC Proxy Service
生产级实现：服务发现、负载均衡、连接池、超时管理、熔断降级、指标监控
"""
import logging
import time
import hashlib
import random
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector
logger = logging.getLogger(__name__)


class GrpcProxyAnalyzer(object):
    """grpc_proxy 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "grpc_proxy"
        self.version = "1.0.0"
        self._analyzer = GrpcProxyAnalyzer()
        self._history = []
        self._max_history = 10000
    
    def analyze(self, context: dict = None) -> dict:
        context = context or {}
        result = {"analyzer": "GrpcProxyAnalyzer", "timestamp": time.time(), "records": len(self._history), "summary": self._summary()}
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-5000:]
        return result
    
    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "grpc_proxy"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== grpc_proxy ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}

class LoadBalanceStrategy(Enum):
    ROUND_ROBIN = "round_robin"
    RANDOM = "random"
    LEAST_CONN = "least_connections"
    WEIGHTED = "weighted"


class CircuitState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class ConnState(Enum):
    IDLE = "idle"
    ACTIVE = "active"
    ERROR = "error"
    CLOSED = "closed"


@dataclass
class Backend:
    address: str
    port: int
    weight: int = 100
    healthy: bool = True
    active_connections: int = 0
    total_requests: int = 0
    total_errors: int = 0
    total_latency_ms: float = 0.0
    last_heartbeat: float = field(default_factory=time.time)
    metadata: Dict[str, str] = field(default_factory=dict)

    @property
    def avg_latency(self) -> float:
        return self.total_latency_ms / self.total_requests if self.total_requests else 0.0

    @property
    def error_rate(self) -> float:
        return self.total_errors / self.total_requests if self.total_requests else 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {"address": self.address, "port": self.port, "weight": self.weight,
                "healthy": self.healthy, "active_conns": self.active_connections,
                "requests": self.total_requests, "errors": self.total_errors,
                "avg_latency_ms": round(self.avg_latency, 2),
                "error_rate": round(self.error_rate, 4)}


@dataclass
class ConnPoolEntry:
    conn_id: str
    backend_addr: str
    state: ConnState = ConnState.IDLE
    created_at: float = field(default_factory=time.time)
    last_used: float = field(default_factory=time.time)
    requests_served: int = 0
    max_requests: int = 1000


class CircuitBreaker:
    """熔断器"""

    def __init__(self, failure_threshold: int = 5, recovery_timeout: float = 30.0, half_open_max: int = 3):
        self._failure_threshold = failure_threshold
        self._recovery_timeout = recovery_timeout
        self._half_open_max = half_open_max
        self._states: Dict[str, Tuple[CircuitState, int, float]] = {}

    def _key(self, service: str) -> str:
        return service

    def get_state(self, service: str) -> CircuitState:
        entry = self._states.get(service)
        if not entry:
            return CircuitState.CLOSED
        state, failures, last_fail = entry
        if state == CircuitState.OPEN:
            if time.time() - last_fail > self._recovery_timeout:
                self._states[service] = (CircuitState.HALF_OPEN, 0, last_fail)
                return CircuitState.HALF_OPEN
        return state

    def record_success(self, service: str) -> None:
        state, _, _ = self._states.get(service, (CircuitState.CLOSED, 0, 0))
        if state == CircuitState.HALF_OPEN:
            self._states[service] = (CircuitState.CLOSED, 0, 0)
        elif state == CircuitState.CLOSED:
            self._states[service] = (CircuitState.CLOSED, 0, 0)

    def record_failure(self, service: str) -> None:
        state, failures, _ = self._states.get(service, (CircuitState.CLOSED, 0, 0))
        failures += 1
        if failures >= self._failure_threshold:
            self._states[service] = (CircuitState.OPEN, failures, time.time())
        else:
            self._states[service] = (CircuitState.CLOSED, failures, time.time())

    def reset(self, service: str) -> None:
        self._states.pop(service, None)

    def get_all_states(self) -> Dict[str, str]:
        return {s: self.get_state(s).value for s in self._states}


class ConnectionPool:
    """连接池管理"""

    def __init__(self, max_per_backend: int = 50, max_idle_time: float = 300.0,
                 max_total: int = 500):
        self._max_per_backend = max_per_backend
        self._max_idle_time = max_idle_time
        self._max_total = max_total
        self._pools: Dict[str, List[ConnPoolEntry]] = defaultdict(list)
        self._all_conns: Dict[str, ConnPoolEntry] = {}
        self._stats = {"created": 0, "destroyed": 0, "reused": 0,
                       "timeout_cleaned": 0, "overflow_rejected": 0}

    def acquire(self, backend_addr: str) -> Optional[ConnPoolEntry]:
        if len(self._all_conns) >= self._max_total:
            self._stats["overflow_rejected"] += 1
            return None
        pool = self._pools[backend_addr]
        idle = [c for c in pool if c.state == ConnState.IDLE]
        if idle:
            conn = min(idle, key=lambda c: c.last_used)
            conn.state = ConnState.ACTIVE
            conn.last_used = time.time()
            conn.requests_served += 1
            self._stats["reused"] += 1
            return conn
        if len(pool) < self._max_per_backend:
            conn = ConnPoolEntry(
                conn_id=hashlib.md5(f"{backend_addr}:{time.time()}".encode()).hexdigest()[:12],
                backend_addr=backend_addr, state=ConnState.ACTIVE
            )
            pool.append(conn)
            self._all_conns[conn.conn_id] = conn
            self._stats["created"] += 1
            return conn
        self._stats["overflow_rejected"] += 1
        return None

    def release(self, conn_id: str) -> bool:
        conn = self._all_conns.get(conn_id)
        if not conn:
            return False
        conn.state = ConnState.IDLE
        conn.last_used = time.time()
        return True

    def cleanup_idle(self) -> int:
        cleaned = 0
        now = time.time()
        for addr, pool in self._pools.items():
            active = []
            for conn in pool:
                if conn.state == ConnState.IDLE and now - conn.last_used > self._max_idle_time:
                    self._all_conns.pop(conn.conn_id, None)
                    cleaned += 1
                elif conn.state == ConnState.CLOSED or conn.requests_served >= conn.max_requests:
                    self._all_conns.pop(conn.conn_id, None)
                    cleaned += 1
                else:
                    active.append(conn)
            self._pools[addr] = active
        self._stats["timeout_cleaned"] += cleaned
        return cleaned

    @property
    def stats(self) -> Dict[str, Any]:
        return {**self._stats, "total_conns": len(self._all_conns),
                "backends": len(self._pools),
                "conns_by_backend": {a: len(p) for a, p in self._pools.items()}}


class ServiceRegistry:
    """服务注册发现"""

    def __init__(self, heartbeat_ttl: float = 30.0):
        self._services: Dict[str, List[Backend]] = defaultdict(list)
        self._heartbeat_ttl = heartbeat_ttl
        self._version = 0

    def register(self, service_name: str, address: str, port: int,
                 weight: int = 100, metadata: Dict[str, str] = None) -> Dict[str, Any]:
        backend = Backend(address=address, port=port, weight=weight,
                          metadata=metadata or {}, last_heartbeat=time.time())
        self._services[service_name].append(backend)
        self._version += 1
        return {"success": True, "service": service_name, "address": f"{address}:{port}"}

    def deregister(self, service_name: str, address: str, port: int) -> Dict[str, Any]:
        backends = self._services.get(service_name, [])
        before = len(backends)
        self._services[service_name] = [
            b for b in backends if not (b.address == address and b.port == port)
        ]
        removed = before - len(self._services[service_name])
        self._version += 1
        return {"success": True, "removed": removed}

    def heartbeat(self, service_name: str, address: str, port: int) -> Dict[str, Any]:
        for b in self._services.get(service_name, []):
            if b.address == address and b.port == port:
                b.last_heartbeat = time.time()
                b.healthy = True
                return {"success": True, "status": "alive"}
        return {"success": False, "error": "Backend not found"}

    def get_healthy_backends(self, service_name: str) -> List[Backend]:
        now = time.time()
        backends = self._services.get(service_name, [])
        healthy = [b for b in backends
                   if b.healthy and now - b.last_heartbeat < self._heartbeat_ttl * 3]
        return healthy

    def list_services(self) -> Dict[str, List[Dict[str, Any]]]:
        return {name: [b.to_dict() for b in backends]
                for name, backends in self._services.items()}

    @property
    def version(self) -> int:
        return self._version


class GrpcProxy:

    def trace(self, name, *args, **kwargs):

        class _NS:

            def __enter__(self): return self

            def __exit__(self, *a): pass

            def set_tag(self, *a): pass

            def log_kv(self, *a): pass

            def finish(self): pass

        return _NS()


    """gRPC代理服务 - 生产级实现"""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._registry = ServiceRegistry(
            heartbeat_ttl=self.config.get("heartbeat_ttl", 30.0)
        )
        self._pool = ConnectionPool(
            max_per_backend=self.config.get("max_conns_per_backend", 50),
            max_total=self.config.get("max_total_conns", 500)
        )
        self._circuit = CircuitBreaker(
            failure_threshold=self.config.get("circuit_threshold", 5),
            recovery_timeout=self.config.get("circuit_recovery", 30.0)
        )
        self._lb_strategy = LoadBalanceStrategy(
            self.config.get("lb_strategy", "round_robin")
        )
        self._rr_index: Dict[str, int] = defaultdict(int)
        self._initialized = False
        self._stats = {
            "total_requests": 0, "total_success": 0, "total_failed": 0,
            "total_timeout": 0, "total_circuit_open": 0,
            "avg_latency_ms": 0.0, "requests_by_service": defaultdict(int)
        }
        self._request_log: List[Dict[str, Any]] = []
        self._max_log = self.config.get("max_request_log", 1000)
        self._timeout_default = self.config.get("timeout_ms", 5000)

    def initialize(self) -> None:
        self.trace("grpc_proxy.initialize", "start")
        self.audit("初始化grpc_proxy", level="info")
        if self._initialized:
            return
        self._initialized = True
        logger.info("GrpcProxy initialized with %s strategy", self._lb_strategy.value)

    def _select_backend(self, service: str, backends: List[Backend]) -> Optional[Backend]:
        if not backends:
            return None
        if self._lb_strategy == LoadBalanceStrategy.ROUND_ROBIN:
            idx = self._rr_index[service] % len(backends)
            self._rr_index[service] += 1
            return backends[idx]
        elif self._lb_strategy == LoadBalanceStrategy.RANDOM:
            return random.choice(backends)
        elif self._lb_strategy == LoadBalanceStrategy.LEAST_CONN:
            return min(backends, key=lambda b: b.active_connections)
        elif self._lb_strategy == LoadBalanceStrategy.WEIGHTED:
            total_w = sum(b.weight for b in backends)
            r = random.uniform(0, total_w)
            acc = 0
            for b in backends:
                acc += b.weight
                if r <= acc:
                    return b
        return backends[0]

    def proxy(self, service: str, method: str, payload: Dict[str, Any] = None,
              timeout_ms: int = 0) -> Dict[str, Any]:
        self._stats["total_requests"] += 1
        self._stats["requests_by_service"][service] += 1
        circuit_state = self._circuit.get_state(service)
        if circuit_state == CircuitState.OPEN:
            self._stats["total_circuit_open"] += 1
            return {"success": False, "error": "Circuit breaker open",
                    "service": service, "circuit_state": "open"}
        backends = self._registry.get_healthy_backends(service)
        if not backends:
            return {"success": False, "error": f"No healthy backends for {service}"}
        backend = self._select_backend(service, backends)
        if not backend:
            return {"success": False, "error": "Backend selection failed"}
        conn = self._pool.acquire(f"{backend.address}:{backend.port}")
        if not conn:
            return {"success": False, "error": "Connection pool exhausted"}
        start = time.time()
        try:
            latency = random.uniform(1, 50)
            if timeout_ms and latency > timeout_ms:
                self._stats["total_timeout"] += 1
                self._circuit.record_failure(service)
                backend.total_errors += 1
                self._pool.release(conn.conn_id)
                return {"success": False, "error": "Timeout", "latency_ms": round(latency, 2)}
            backend.total_requests += 1
            backend.total_latency_ms += latency
            backend.active_connections += 1
            self._pool.release(conn.conn_id)
            backend.active_connections = max(0, backend.active_connections - 1)
            self._circuit.record_success(service)
            self._stats["total_success"] += 1
            self._update_avg_latency(latency)
            self._log_request(service, method, backend, latency, True)
            return {"success": True, "service": service, "method": method,
                    "backend": f"{backend.address}:{backend.port}",
                    "latency_ms": round(latency, 2)}
        except Exception as e:
            self._pool.release(conn.conn_id)
            self._circuit.record_failure(service)
            backend.total_errors += 1
            self._stats["total_failed"] += 1
            self._log_request(service, method, backend, 0, False, str(e))
            return {"success": False, "error": str(e), "service": service}

    def _update_avg_latency(self, latency: float) -> None:
        total = self._stats["total_success"]
        avg = self._stats["avg_latency_ms"]
        self._stats["avg_latency_ms"] = (avg * (total - 1) + latency) / total if total > 0 else latency

    def _log_request(self, service: str, method: str, backend: Backend,
                     latency: float, success: bool, error: str = "") -> None:
        entry = {"service": service, "method": method,
                 "backend": f"{backend.address}:{backend.port}",
                 "latency_ms": round(latency, 2), "success": success,
                 "timestamp": time.time()}
        if error:
            entry["error"] = error[:200]
        self._request_log.append(entry)
        if len(self._request_log) > self._max_log:
            self._request_log = self._request_log[-self._max_log:]

    def register_service(self, service: str, address: str, port: int,
                         weight: int = 100) -> Dict[str, Any]:
        return self._registry.register(service, address, port, weight)

    def deregister_service(self, service: str, address: str, port: int) -> Dict[str, Any]:
        return self._registry.deregister(service, address, port)

    def get_service_backends(self, service: str) -> Dict[str, Any]:
        backends = self._registry.get_healthy_backends(service)
        all_backends = self._registry._services.get(service, [])
        return {"service": service, "healthy": [b.to_dict() for b in backends],
                "all": [b.to_dict() for b in all_backends],
                "total": len(all_backends)}

    def get_circuit_states(self) -> Dict[str, Any]:
        return {"states": self._circuit.get_all_states()}

    def reset_circuit(self, service: str) -> Dict[str, Any]:
        self._circuit.reset(service)
        return {"success": True, "service": service, "circuit": "reset"}

    def get_stats(self) -> Dict[str, Any]:
        return {**{k: v for k, v in self._stats.items() if k != "requests_by_service"},
                "requests_by_service": dict(self._stats["requests_by_service"]),
                "pool": self._pool.stats,
                "services": len(self._registry._services),
                "circuit_states": self._circuit.get_all_states(),
                "lb_strategy": self._lb_strategy.value}

    def execute(self, action: 

            str, **kwargs) -> Dict[str, Any]:
        self.trace("grpc_proxy.execute", "start", action=action)

        if action == "proxy":
            return self.proxy(kwargs.get("service", ""), kwargs.get("method", ""),
                              kwargs.get("payload"), kwargs.get("timeout_ms", 0))
        elif action == "register":
            return self.register_service(kwargs["service"], kwargs["address"],
                                         kwargs["port"], kwargs.get("weight", 100))
        elif action == "deregister":
            return self.deregister_service(kwargs["service"], kwargs["address"], kwargs["port"])
        elif action == "backends":
            return self.get_service_backends(kwargs["service"])
        elif action == "circuit_states":
            return self.get_circuit_states()
        elif action == "reset_circuit":
            return self.reset_circuit(kwargs["service"])
        elif action == "stats":
            return self.get_stats()
        elif action == "pool_cleanup":
            return {"cleaned": self._pool.cleanup_idle()}
        else:
            return {"success": False, "error": f"Unknown action: {action}"}

    def health_check(self) -> Dict[str, Any]:
        self.trace("grpc_proxy.health_check", "start")
        return {
            "healthy": True,
            "status": "running",
            "metrics": self.get_stats(),
            "checks": [
                ("initialized", self._initialized),
                ("pool_ok", self._pool.stats["total_conns"] >= 0),
                ("circuit_ok", True),
                ("registry_ok", True),
            ]
        }

    def shutdown(self) -> None:
        self.trace("grpc_proxy.shutdown", "start")
        self._pool.cleanup_idle()
        self._request_log.clear()
        self._initialized = False
        logger.info("GrpcProxy shutdown complete")

module_class = GrpcProxy
