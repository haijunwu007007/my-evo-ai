"""
M49 Push Notification Engine - Enterprise-grade push notification management
"""

import time
import json
import logging
import hashlib
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from enum import Enum
from modules._base.enterprise_module import EnterpriseModule

logger = logging.getLogger(__name__)


class NotificationPriority(int, Enum):
    LOW = 0
    NORMAL = 1
    HIGH = 2
    URGENT = 3


class NotificationStatus(str, Enum):
    PENDING = "pending"
    QUEUED = "queued"
    SENT = "sent"
    DELIVERED = "delivered"
    FAILED = "failed"
    EXPIRED = "expired"


class PushChannel(str, Enum):
    EMAIL = "email"
    SMS = "sms"
    WEBHOOK = "webhook"
    IN_APP = "in_app"
    WECHAT = "wechat"
    DINGTALK = "dingtalk"


class Notification:
    """Single notification record"""

    def __init__(self, notification_id: str, title: str, body: str,
                 channel: PushChannel, priority: NotificationPriority = NotificationPriority.NORMAL,
                 recipient: str = "", extra: Optional[Dict] = None):
        self.id = notification_id
        self.title = title
        self.body = body
        self.channel = channel
        self.priority = priority
        self.recipient = recipient
        self.extra = extra or {}
        self.status = NotificationStatus.PENDING
        self.created_at = datetime.now()
        self.sent_at = None
        self.delivered_at = None
        self.retry_count = 0
        self.error_message = ""
        self.fingerprint = hashlib.md5(
            f"{title}:{body}:{recipient}:{channel.value}".encode()
        ).hexdigest()

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "title": self.title,
            "body": self.body,
            "channel": self.channel.value,
            "priority": self.priority.value,
            "recipient": self.recipient,
            "status": self.status.value,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "sent_at": self.sent_at.isoformat() if self.sent_at else None,
            "delivered_at": self.delivered_at.isoformat() if self.delivered_at else None,
            "retry_count": self.retry_count,
            "error_message": self.error_message,
            "fingerprint": self.fingerprint,
        }


class NotificationTemplate:
    """Template for reusable notifications"""

    def __init__(self, template_id: str, name: str, title_template: str,
                 body_template: str, channel: PushChannel, variables: List[str]):
        self.id = template_id
        self.name = name
        self.title_template = title_template
        self.body_template = body_template
        self.channel = channel
        self.variables = variables
        self.usage_count = 0
        self.created_at = datetime.now()

    def render(self, context: Dict[str, str]) -> Dict[str, str]:
        title = self.title_template
        body = self.body_template
        for var in self.variables:
            title = title.replace(f"{{{{{var}}}}}", context.get(var, ""))
            body = body.replace(f"{{{{{var}}}}}", context.get(var, ""))
        self.usage_count += 1
        return {"title": title, "body": body}


class PushDeliveryEngine:
    """Core delivery engine with retry logic and rate limiting"""

    def __init__(self):
        self._queue: List[Notification] = []
        self._history: Dict[str, Notification] = {}
        self._templates: Dict[str, NotificationTemplate] = {}
        self._dedup_cache: Dict[str, float] = {}
        self._rate_limits: Dict[str, Dict] = {}
        self._channel_configs: Dict[str, Dict] = {
            c.value: {"max_rate": 100, "batch_size": 50, "timeout": 30}
            for c in PushChannel
        }
        self._stats = {
            "total_sent": 0,
            "total_delivered": 0,
            "total_failed": 0,
            "total_deduplicated": 0,
            "total_expired": 0,
            "queue_size": 0,
            "template_count": 0,
        }
        self._max_retries = 3
        self._dedup_window = 300  # 5 minutes
        self._queue_capacity = 10000

    def send(self, title: str, body: str, channel: PushChannel,
             recipient: str = "", priority: NotificationPriority = NotificationPriority.NORMAL,
             dedup: bool = True, extra: Optional[Dict] = None) -> Dict:
        """Send a push notification"""
        notif_id = hashlib.sha256(f"{title}:{body}:{recipient}:{time.time()}".encode()).hexdigest()[:16]
        notif = Notification(notif_id, title, body, channel, priority, recipient, extra)

        # Deduplication
        if dedup and notif.fingerprint in self._dedup_cache:
            elapsed = time.time() - self._dedup_cache[notif.fingerprint]
            if elapsed < self._dedup_window:
                self._stats["total_deduplicated"] += 1
                return {"success": True, "id": notif_id, "status": "deduplicated", "reason": "duplicate_within_window"}

        # Rate limiting
        ch_key = channel.value
        ch_cfg = self._channel_configs.get(ch_key, {})
        rl = self._rate_limits.setdefault(ch_key, {"count": 0, "window_start": time.time()})
        now = time.time()
        if now - rl["window_start"] > 60:
            rl["count"] = 0
            rl["window_start"] = now
        if rl["count"] >= ch_cfg.get("max_rate", 100):
            notif.status = NotificationStatus.QUEUED
            if len(self._queue) < self._queue_capacity:
                self._queue.append(notif)
            self._stats["queue_size"] = len(self._queue)
            return {"success": True, "id": notif_id, "status": "queued", "reason": "rate_limited"}

        # Deliver
        rl["count"] += 1
        self._dedup_cache[notif.fingerprint] = now
        notif.status = NotificationStatus.SENT
        notif.sent_at = datetime.now()
        self._stats["total_sent"] += 1

        # Simulate delivery
        success = self._simulate_delivery(notif)
        if success:
            notif.status = NotificationStatus.DELIVERED
            notif.delivered_at = datetime.now()
            self._stats["total_delivered"] += 1
        else:
            notif.status = NotificationStatus.FAILED
            notif.error_message = "delivery_timeout"
            self._stats["total_failed"] += 1
            self._retry_notification(notif)

        self._history[notif_id] = notif
        return {"success": True, "id": notif_id, "status": notif.status.value, "channel": ch_key}

    def _simulate_delivery(self, notif: Notification) -> bool:
        """Simulate channel delivery with random success rate"""
        import random
        return random.random() > 0.05  # 95% success rate

    def _retry_notification(self, notif: Notification):
        """Retry failed notification"""
        if notif.retry_count < self._max_retries:
            notif.retry_count += 1
            notif.status = NotificationStatus.PENDING

    def register_template(self, template_id: str, name: str, title_template: str,
                          body_template: str, channel: PushChannel, variables: List[str]) -> Dict:
        template = NotificationTemplate(template_id, name, title_template, body_template, channel, variables)
        self._templates[template_id] = template
        self._stats["template_count"] = len(self._templates)
        return {"success": True, "template_id": template_id}

    def send_from_template(self, template_id: str, context: Dict[str, str],
                           recipient: str = "", priority: NotificationPriority = NotificationPriority.NORMAL) -> Dict:
        template = self._templates.get(template_id)
        if not template:
            return {"success": False, "error": "template_not_found"}
        rendered = template.render(context)
        return self.send(rendered["title"], rendered["body"], template.channel,
                         recipient, priority, extra={"template_id": template_id})

    def process_queue(self, batch_size: int = 50) -> Dict:
        """Process queued notifications"""
        processed = 0
        remaining = []
        for notif in self._queue:
            if processed >= batch_size:
                remaining.append(notif)
                continue
            ch_key = notif.channel.value
            rl = self._rate_limits.setdefault(ch_key, {"count": 0, "window_start": time.time()})
            now = time.time()
            if now - rl["window_start"] > 60:
                rl["count"] = 0
                rl["window_start"] = now
            if rl["count"] < self._channel_configs.get(ch_key, {}).get("max_rate", 100):
                rl["count"] += 1
                notif.status = NotificationStatus.SENT
                notif.sent_at = datetime.now()
                self._stats["total_sent"] += 1
                if self._simulate_delivery(notif):
                    notif.status = NotificationStatus.DELIVERED
                    notif.delivered_at = datetime.now()
                    self._stats["total_delivered"] += 1
                else:
                    self._retry_notification(notif)
                    if notif.status == NotificationStatus.FAILED:
                        self._stats["total_failed"] += 1
                self._history[notif.id] = notif
                processed += 1
            else:
                remaining.append(notif)
        self._queue = remaining
        self._stats["queue_size"] = len(self._queue)
        return {"success": True, "processed": processed, "remaining": len(self._queue)}

    def get_history(self, status: Optional[str] = None, limit: int = 50) -> List[Dict]:
        results = list(self._history.values())
        if status:
            results = [n for n in results if n.status.value == status]
        results.sort(key=lambda n: n.created_at, reverse=True)
        return [n.to_dict() for n in results[:limit]]

    def get_stats(self) -> Dict:
        s = dict(self._stats)
        s["queue_size"] = len(self._queue)
        s["template_count"] = len(self._templates)
        s["history_size"] = len(self._history)
        s["channels"] = {c.value: self._rate_limits.get(c.value, {"count": 0}) for c in PushChannel}
        return s

    def cleanup(self, max_age_hours: int = 168) -> Dict:
        """Clean up old notifications"""
        cutoff = datetime.now() - timedelta(hours=max_age_hours)
        removed = 0
        for nid, notif in list(self._history.items()):
            if notif.created_at and notif.created_at < cutoff:
                del self._history[nid]
                removed += 1
        return {"success": True, "removed": removed, "remaining": len(self._history)}


class M49PushNotify(EnterpriseModule):
    """M49 Push Notification Engine"""

    module_class = "M49PushNotify"  # type: ignore

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._engine = PushDeliveryEngine()
        self._operation_count = 0
        self._error_count = 0

    def _dispatch(self, action: str, params: Optional[Dict] = None) -> Dict:
        params = params or {}
        if action == "send":
            return self._action_send(params)
        elif action == "send_template":
            return self._action_send_template(params)
        elif action == "process_queue":
            return self._action_process_queue(params)
        elif action == "register_template":
            return self._action_register_template(params)
        elif action == "history":
            return self._action_history(params)
        elif action == "stats":
            return self._action_stats(params)
        elif action == "cleanup":
            return self._action_cleanup(params)
        elif action == "list_channels":
            return self._action_list_channels(params)
        else:
            return {"success": True, "data": {"action": action, "module": "m49_push_notify"}}

    def _action_send(self, params: Dict) -> Dict:
        title = params.get("title", "")
        body = params.get("body", "")
        channel_str = params.get("channel", "in_app")
        try:
            channel = PushChannel(channel_str)
        except ValueError:
            channel = PushChannel.IN_APP
        recipient = params.get("recipient", "")
        priority = NotificationPriority(params.get("priority", 1))
        dedup = params.get("dedup", True)
        return self._engine.send(title, body, channel, recipient, priority, dedup)

    def _action_send_template(self, params: Dict) -> Dict:
        template_id = params.get("template_id", "")
        context = params.get("context", {})
        recipient = params.get("recipient", "")
        priority = NotificationPriority(params.get("priority", 1))
        return self._engine.send_from_template(template_id, context, recipient, priority)

    def _action_process_queue(self, params: Dict) -> Dict:
        batch_size = params.get("batch_size", 50)
        return self._engine.process_queue(batch_size)

    def _action_register_template(self, params: Dict) -> Dict:
        return self._engine.register_template(
            params.get("template_id", ""),
            params.get("name", ""),
            params.get("title_template", ""),
            params.get("body_template", ""),
            PushChannel(params.get("channel", "in_app")),
            params.get("variables", []),
        )

    def _action_history(self, params: Dict) -> Dict:
        status = params.get("status")
        limit = params.get("limit", 50)
        return {"success": True, "data": self._engine.get_history(status, limit)}

    def _action_stats(self, params: Dict) -> Dict:
        return {"success": True, "data": self._engine.get_stats()}

    def _action_cleanup(self, params: Dict) -> Dict:
        max_age = params.get("max_age_hours", 168)
        return self._engine.cleanup(max_age)

    def _action_list_channels(self, params: Dict) -> Dict:
        return {"success": True, "data": [c.value for c in PushChannel]}

    def execute(self, params: Optional[Dict] = None, **kwargs) -> Dict:
        params = params or kwargs or {}
        action = params.get("action", "status")
        try:
            result = self._dispatch(action, params)
            self._operation_count += 1
            return result
        except Exception as e:
            self._error_count += 1
            return {"success": False, "error": str(e)}
