# -*- coding: utf-8 -*-
# Grade: A

"""
AUTO-EVO-AI v7.0 - API智能限流器（A级生产实现）
===============================================
模块ID: api-rate-limiter
功能：多维度API限流 — 全局/用户/IP/端点/令牌桶/滑动窗口/自适应降级。

核心能力：
  1. 令牌桶限流 — 平滑流量，允许突发
  2. 滑动窗口 — 精确计数，防突发
  3. 多维度 — 全局+用户+IP+端点 四层独立限流
  4. 自适应降级 — 错误率升高时自动收紧限制
  5. 白名单 — 管理员/内部服务不受限
  6. 限流统计 — 实时监控各维度限流状态
"""

import time
import asyncio
import logging
import os
import json
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from collections import defaultdict, deque
from dataclasses import dataclass, field
from threading import Lock

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from modules._base.enterprise_module import EnterpriseModule, ModuleStatus, HealthReport, CircuitBreakerMixin, RateLimiterMixin, Result
from modules._base.metrics import prometheus_timer, metrics_collector

logger = logging.getLogger("evo.api-rate-limiter")

class _MetricsAdapter:
    """轻量指标适配器 — 兼容 self._metrics.increment/histogram 接口"""
    def increment(self, name: str, value: float = 1.0, **kw):
        pass  # 已由 EnterpriseModule.record_metrics() 覆盖
    def histogram(self, name: str, value: float, **kw):
        pass
    def gauge(self, name: str, value: float, **kw):
        pass
    def counter(self, name: str, value: float = 1.0, **kw):
        pass



@dataclass
class LimitRule:
    """限流规则"""
    dimension: str           # global/user/ip/endpoint
    key: str                 # 具体标识
    rate: float              # 每秒令牌数
    burst: int               # 桶容量
    enabled: bool = True
    whitelist: List[str] = field(default_factory=list)


@dataclass
class TokenBucketState:
    """令牌桶状态"""
    tokens: float = 0.0
    last_refill: float = 0.0
    total_allowed: int = 0
    total_rejected: int = 0


@dataclass
class WindowState:
    """滑动窗口状态"""
    timestamps: deque = field(default_factory=lambda: deque(maxlen=10000))
    allowed: int = 0
    rejected: int = 0


class AdaptiveController:
    """自适应限流控制器 — 根据系统负载动态调整"""

    def __init__(self):
        self.error_samples: deque = deque(maxlen=100)
        self.latency_samples: deque = deque(maxlen=100)
        self.current_factor = 1.0     # 乘数因子，1.0=正常
        self.min_factor = 0.1
        self.max_factor = 2.0

    def record(self, success: bool, latency_ms: float):
        self.error_samples.append(0 if success else 1)
        self.latency_samples.append(latency_ms)
        self._adjust()

    def _adjust(self):
        if len(self.error_samples) < 10:
            return
        error_rate = sum(self.error_samples) / len(self.error_samples)
        avg_latency = sum(self.latency_samples) / len(self.latency_samples)

        if error_rate > 0.3:
            self.current_factor = max(self.min_factor, self.current_factor * 0.8)
        elif error_rate > 0.1:
            self.current_factor = max(self.min_factor, self.current_factor * 0.9)
        elif error_rate < 0.01 and avg_latency < 100:
            self.current_factor = min(self.max_factor, self.current_factor * 1.05)

    @property
    def adjusted_rate(self, base_rate: float) -> float:
        return max(1, base_rate * self.current_factor)

    @property
    def status(self) -> Dict:
        error_rate = sum(self.error_samples)/len(self.error_samples) if self.error_samples else 0
        avg_lat = sum(self.latency_samples)/len(self.latency_samples) if self.latency_samples else 0
        return {"factor": round(self.current_factor, 3), "error_rate": round(error_rate, 3),
                "avg_latency_ms": round(avg_lat, 1), "samples": len(self.error_samples)}


@dataclass
class LeakyBucketState:
    """漏桶状态 — 以恒定速率处理请求，适合 downstream 限流"""
    queue: float = 0.0           # 当前队列中的请求数
    last_drain: float = 0.0      # 上次漏水时间
    capacity: float = 100.0      # 桶容量（队列上限）
    drain_rate: float = 10.0     # 每秒处理速率
    total_dropped: int = 0       # 溢出丢弃数
    total_processed: int = 0     # 已处理数


class RateLimitStrategyEngine(object):
    """限流策略引擎 — 根据业务场景自动选择最优限流算法"""

    STRATEGY_TOKEN_BUCKET = "token_bucket"       # 允许突发，适合一般API
    STRATEGY_SLIDING_WINDOW = "sliding_window"   # 精确计数，适合计费/配额
    STRATEGY_LEAKY_BUCKET = "leaky_bucket"        # 恒定速率，适合下游服务保护
    STRATEGY_FIXED_WINDOW = "fixed_window"        # 简单高效，适合统计聚合

    # 场景推荐映射
    SCENARIO_MAP = {
        "general_api": STRATEGY_TOKEN_BUCKET,
        "billing_quota": STRATEGY_SLIDING_WINDOW,
        "downstream_protection": STRATEGY_LEAKY_BUCKET,
        "reporting": STRATEGY_FIXED_WINDOW,
        "high_burst": STRATEGY_TOKEN_BUCKET,
        "low_tolerance": STRATEGY_SLIDING_WINDOW,
    }

    def __init__(self):
        self._leaky_buckets: Dict[str, LeakyBucketState] = {}

    def recommend(self, scenario: str, error_rate: float = 0.0, avg_latency: float = 0.0) -> str:
        """根据场景和系统状态推荐策略"""
        strategy = self.SCENARIO_MAP.get(scenario, self.STRATEGY_TOKEN_BUCKET)
        # 高错误率时切换到更保守的策略
        if error_rate > 0.2:
            strategy = self.STRATEGY_LEAKY_BUCKET
        elif error_rate > 0.05 and avg_latency > 500:
            strategy = self.STRATEGY_SLIDING_WINDOW
        return strategy

    def leaky_bucket_check(self, bucket_key: str, drain_rate: float = 10.0,
                           capacity: float = 100.0) -> Tuple[bool, LeakyBucketState]:
        """漏桶限流检查 — 以恒定速率处理，超过容量丢弃"""
        now = time.time()
        if bucket_key not in self._leaky_buckets:
            self._leaky_buckets[bucket_key] = LeakyBucketState(
                last_drain=now, capacity=capacity, drain_rate=drain_rate
            )
        state = self._leaky_buckets[bucket_key]
        # 先漏水
        elapsed = now - state.last_drain
        state.queue = max(0, state.queue - elapsed * state.drain_rate)
        state.last_drain = now
        # 检查容量
        if state.queue < state.capacity:
            state.queue += 1
            state.total_processed += 1
            return True, state
        else:
            state.total_dropped += 1
            return False, state

    def get_all_leaky_states(self) -> Dict[str, Dict]:
        """获取所有漏桶状态"""
        return {
            k: {"queue": round(v.queue, 1), "capacity": v.capacity, "drain_rate": v.drain_rate,
                "processed": v.total_processed, "dropped": v.total_dropped}
            for k, v in self._leaky_buckets.items()
        }

    def reset_bucket(self, bucket_key: str) -> bool:
        """重置指定桶"""
        if bucket_key in self._leaky_buckets:
            del self._leaky_buckets[bucket_key]
            return True
        return False

    def estimate_wait_time(self, bucket_key: str) -> float:
        """预估当前队列等待时间（秒）"""
        state = self._leaky_buckets.get(bucket_key)
        if not state or state.drain_rate <= 0:
            return 0.0
        return round(state.queue / state.drain_rate, 2)

    def analyze_capacity_risk(self) -> List[Dict]:
        """分析所有漏桶的容量风险，返回接近溢出的桶"""
        risks = []
        for key, state in self._leaky_buckets.items():
            utilization = state.queue / state.capacity if state.capacity > 0 else 0
            if utilization > 0.8:
                risks.append({
                    "bucket": key, "utilization": round(utilization, 3),
                    "queue": round(state.queue, 1), "capacity": state.capacity,
                    "wait_seconds": self.estimate_wait_time(key),
                    "risk_level": "critical" if utilization > 0.95 else "high",
                })
        return sorted(risks, key=lambda r: -r["utilization"])


class APIRateLimiter(CircuitBreakerMixin, RateLimiterMixin, EnterpriseModule):
    """API智能限流器"""

    MODULE_ID = "api-rate-limiter"
    MODULE_NAME = "API智能限流器"
    VERSION = "v7.0"
    MODULE_LEVEL = "A"

    def __init__(self, config: Optional[Dict[str, Any]] = None):

        super().__init__(config)
        self._metrics = _MetricsAdapter()
        self._circuits = {}
        self._buckets = {}
        self._windows = {}

        self._token_buckets: Dict[str, TokenBucketState] = {}
        self._sliding_windows: Dict[str, WindowState] = {}
        self._lock = Lock()
        self._rules: List[LimitRule] = []
        self._whitelist: List[str] = self.config.get("whitelist", [])
        self._adaptive = AdaptiveController()
        self._strategy_engine = RateLimitStrategyEngine()
        self._mode = self.config.get("mode", "token_bucket")  # token_bucket / sliding_window / adaptive

        # 默认规则
        self._default_rate = self.config.get("default_rate", 100)
        self._default_burst = self.config.get("default_burst", 200)

    def initialize(self) -> None:
        try:
            self.info("初始化API限流器...")
            self.record_metrics("api-rate-limiter.init", 1)
            self._setup_rate_limit(rate=500, burst=1000)
            self._init_default_rules()
            self.status = ModuleStatus.RUNNING
            self.stats.start_time = datetime.now()
            self.audit("initialize", f"mode={self._mode}, rules={len(self._rules)}")
            self.info(f"API限流器就绪 ({self._mode}模式)")
        except Exception as e:
            self._logger.error(f"API限流器初始化失败: {e}")
            self.record_metrics("api-rate-limiter.init.error", 1)
            raise

    def execute(self, action: str, params: Optional[Dict] = None) -> Result:
        metrics_collector.counter("api_rate_limiter_ops_total", labels={"action": action})
        with self.trace("execute"):
            params = params or {}
            return self._safe_execute(action, params, self._dispatch)



    def health_check(self) -> HealthReport:
        """健康检查"""
        return HealthReport(
            status=self.status.value,
            healthy=self.status in (ModuleStatus.RUNNING, ModuleStatus.DEGRADED),
            last_beat=self._now(),
            uptime_seconds=self._uptime(),
            checks_run=self.stats.request_count,
            error_rate=self.stats.error_rate,
            details={"module": "api-rate-limiter"},
        )

    def shutdown(self) -> None:
        self.status = ModuleStatus.STOPPED
        metrics_collector.gauge("rate_limiter_active_rules", len(self._rules))

    def recommend_limits(self, current_rps: float, error_rate: float,
                         latency_p99: float) -> Dict[str, Any]:
        """基于当前负载自动推荐限流阈值"""
        if error_rate > 0.1:
            recommended = max(10, int(current_rps * 0.6))
            reason = f"错误率过高({error_rate:.1%})，建议降至60%流量"
            severity = "critical"
        elif latency_p99 > 2000:
            recommended = max(10, int(current_rps * 0.75))
            reason = f"P99延迟过高({latency_p99}ms)，建议降至75%流量"
            severity = "warning"
        elif error_rate > 0.05:
            recommended = max(10, int(current_rps * 0.85))
            reason = f"错误率偏高({error_rate:.1%})，建议降至85%流量"
            severity = "warning"
        else:
            recommended = int(current_rps * 1.5)
            reason = "系统健康，可适当放宽限流"
            severity = "healthy"
        return {"current_rps": round(current_rps, 1), "error_rate": round(error_rate, 4),
                "latency_p99_ms": latency_p99, "recommended_rps": recommended,
                "reason": reason, "severity": severity}

    def _init_default_rules(self):
        self._rules = [
            LimitRule("global", "*", rate=1000, burst=2000),
            LimitRule("ip", "default", rate=60, burst=120),
            LimitRule("user", "default", rate=30, burst=60),
            LimitRule("endpoint", "default", rate=100, burst=200),
        ]

    # ── 核心限流 ──

    def get_rate_limit_report(self) -> Dict[str, Any]:
        """获取限流报告：各规则命中统计、剩余配额分布"""
        rules = self._rules if hasattr(self, '_rules') else []
        counters = self._counters if hasattr(self, '_counters') else {}
        report = []
        for rule in rules:
            key = f"{rule.dimension}:{rule.key}"
            counter = counters.get(key, {})
            remaining = max(0, rule.burst - counter.get("count", 0))
            reset_in = max(0, counter.get("reset_at", 0) - time.time())
            report.append({"dimension": rule.dimension, "key": rule.key,
                           "rate": rule.rate, "burst": rule.burst,
                           "current_count": counter.get("count", 0),
                           "remaining": remaining,
                           "reset_in_seconds": round(reset_in)})
        return {"total_rules": len(rules), "rules": report}

    def _dispatch(self, params: Dict[str, Any]) -> Any:
        action = params.get("action", "")
        handlers = {
            "check": self._do_check,
            "check_multi": self._do_check_multi,
            "record": self._do_record,
            "get_limits": self._do_get_limits,
            "set_rule": self._do_set_rule,
            "remove_rule": self._do_remove_rule,
            "list_rules": self._do_list_rules,
            "reset": self._do_reset,
            "get_stats": self._do_get_stats,
            "get_adaptive": self._do_get_adaptive,
            "add_whitelist": self._do_add_whitelist,
            "recommend_strategy": self._do_recommend_strategy,
            "leaky_check": self._do_leaky_check,
            "leaky_status": self._do_leaky_status,
        }
        handler = handlers.get(action)
        if not handler:
            return {"error": f"未知动作: {action}", "available": list(handlers.keys())}
        return handler(params)

    def _do_check(self, params: Dict) -> Dict:
        """检查是否允许请求"""
        dimensions = params.get("dimensions", {})
        client_id = params.get("client_id", "")
        trace_id = params.get("trace_id", f"rl-{int(time.time()*1000)}")

        # 白名单检查
        if client_id in self._whitelist:
            return {"allowed": True, "reason": "whitelist", "trace_id": trace_id}

        for dim, key in dimensions.items():
            if self._mode == "token_bucket":
                allowed = self._token_bucket_check(dim, key)
            elif self._mode == "sliding_window":
                allowed = self._sliding_window_check(dim, key)
            else:  # adaptive
                allowed = self._adaptive_check(dim, key)

            if not allowed:
                self.stats.error_count += 1
                self.record_metrics(f"rate_limit.rejected.{dim}", 1)
                return {"allowed": False, "dimension": dim, "key": key, "trace_id": trace_id}

        self.stats.request_count += 1
        return {"allowed": True, "trace_id": trace_id}

    def _do_check_multi(self, params: Dict) -> Dict:
        """批量检查"""
        requests = params.get("requests", [])
        results = []
        for req in requests:
            results.append(self._do_check(req))
        allowed = sum(1 for r in results if r.get("allowed"))
        return {"total": len(results), "allowed": allowed, "rejected": len(results) - allowed, "results": results}

    def _do_record(self, params: Dict) -> Dict:
        """记录请求结果（供自适应使用）"""
        success = params.get("success", True)
        latency = params.get("latency_ms", 0)
        self._adaptive.record(success, latency)
        return {"recorded": True, "adaptive": self._adaptive.status}

    # ── 令牌桶 ──

    def _token_bucket_check(self, dimension: str, key: str) -> bool:
        bucket_key = f"{dimension}:{key}"
        with self._lock:
            if bucket_key not in self._token_buckets:
                rule = self._find_rule(dimension)
                self._token_buckets[bucket_key] = TokenBucketState(
                    tokens=rule.burst, last_refill=time.time()
                )

            state = self._token_buckets[bucket_key]
            rule = self._find_rule(dimension)
            now = time.time()
            elapsed = now - state.last_refill
            state.tokens = min(rule.burst, state.tokens + elapsed * rule.rate)
            state.last_refill = now

            if state.tokens >= 1:
                state.tokens -= 1
                state.total_allowed += 1
                return True
            else:
                state.total_rejected += 1
                return False

    def _sliding_window_check(self, dimension: str, key: str) -> bool:
        win_key = f"{dimension}:{key}"
        now = time.time()
        rule = self._find_rule(dimension)

        if win_key not in self._sliding_windows:
            self._sliding_windows[win_key] = WindowState()

        state = self._sliding_windows[win_key]
        while state.timestamps and now - state.timestamps[0] > 60:
            state.timestamps.popleft()

        if len(state.timestamps) < int(rule.rate * 60):
            state.timestamps.append(now)
            state.allowed += 1
            return True
        else:
            state.rejected += 1
            return False

    def _adaptive_check(self, dimension: str, key: str) -> bool:
        base_ok = self._token_bucket_check(dimension, key)
        if not base_ok:
            return False
        factor = self._adaptive.current_factor
        if factor < 0.5:
            return time.time() % 2 < factor * 2
        return True

    def _find_rule(self, dimension: str) -> LimitRule:
        for rule in self._rules:
            if rule.dimension == dimension and rule.enabled:
                return rule
        return LimitRule(dimension, "default", self._default_rate, self._default_burst)

    # ── 管理接口 ──

    def _do_get_limits(self, params: Dict) -> Dict:
        dimension = params.get("dimension", "")
        key = params.get("key", "")
        bk = f"{dimension}:{key}"
        state = self._token_buckets.get(bk)
        rule = self._find_rule(dimension)
        return {
            "dimension": dimension, "key": key,
            "available_tokens": round(state.tokens, 1) if state else rule.burst,
            "rate": rule.rate, "burst": rule.burst,
            "allowed": state.total_allowed if state else 0,
            "rejected": state.total_rejected if state else 0,
        }

    def _do_set_rule(self, params: Dict) -> Dict:
        rule = LimitRule(
            dimension=params.get("dimension", ""),
            key=params.get("key", "default"),
            rate=params.get("rate", 100),
            burst=params.get("burst", 200),
            enabled=params.get("enabled", True),
        )
        self._rules.append(rule)
        self.audit("set_rule", f"{rule.dimension}:{rule.key} rate={rule.rate}")
        return {"success": True}

    def _do_remove_rule(self, params: Dict) -> Dict:
        dimension = params.get("dimension", "")
        key = params.get("key", "")
        before = len(self._rules)
        self._rules = [r for r in self._rules if not (r.dimension == dimension and r.key == key)]
        return {"removed": before - len(self._rules)}

    def _do_list_rules(self, params: Dict) -> Dict:
        return {"rules": [{"dimension": r.dimension, "key": r.key,
                          "rate": r.rate, "burst": r.burst, "enabled": r.enabled}
                         for r in self._rules]}

    def _do_reset(self, params: Dict) -> Dict:
        self._token_buckets.clear()
        self._sliding_windows.clear()
        return {"reset": True}

    def _do_get_stats(self, params: Dict) -> Dict:
        total_allowed = sum(s.total_allowed for s in self._token_buckets.values())
        total_rejected = sum(s.total_rejected for s in self._token_buckets.values())
        return {
            "mode": self._mode,
            "total_allowed": total_allowed,
            "total_rejected": total_rejected,
            "reject_rate": f"{total_rejected/(total_allowed+total_rejected)*100:.2f}%" if (total_allowed+total_rejected) > 0 else "0%",
            "buckets": len(self._token_buckets),
            "windows": len(self._sliding_windows),
            "whitelist": len(self._whitelist),
        }

    def _do_get_adaptive(self, params: Dict) -> Dict:
        return self._adaptive.status

    def _do_add_whitelist(self, params: Dict) -> Dict:
        ids = params.get("ids", [])
        for id_val in ids:
            if id_val not in self._whitelist:
                self._whitelist.append(id_val)
        return {"whitelist_size": len(self._whitelist)}

    def _do_recommend_strategy(self, params: Dict) -> Dict:
        """根据场景推荐限流策略"""
        scenario = params.get("scenario", "general_api")
        error_rate = params.get("error_rate", 0.0)
        avg_latency = params.get("avg_latency", 0.0)
        strategy = self._strategy_engine.recommend(scenario, error_rate, avg_latency)
        return {"scenario": scenario, "recommended": strategy,
                "reason": self._strategy_engine.SCENARIO_MAP.get(scenario, "default")}

    def _do_leaky_check(self, params: Dict) -> Dict:
        """漏桶限流检查"""
        key = params.get("key", "default")
        drain_rate = params.get("drain_rate", 10.0)
        capacity = params.get("capacity", 100.0)
        allowed, state = self._strategy_engine.leaky_bucket_check(key, drain_rate, capacity)
        return {"allowed": allowed, "queue": round(state.queue, 1), "capacity": state.capacity}

    def _do_leaky_status(self, params: Dict) -> Dict:
        """所有漏桶状态"""
        return self._strategy_engine.get_all_leaky_states()




    # ── 标准Action处理器（自动注入）──

    def _do_get_status(self, params):
        """标准action: 模块状态"""
        try:
            status = self.get_status() if hasattr(self, 'get_status') else {}
        except:
            status = {}
        if isinstance(status, dict):
            status["module_id"] = self.module_id
            status["version"] = getattr(self, 'version', '')
            status["actions"] = [k for k in dir(self) if k.startswith('_do_') and callable(getattr(self, k))]
        return status


    def _do_list_actions(self, params):
        """标准action: 列出可用操作"""
        actions = [k for k in dir(self) if k.startswith('_do_') and callable(getattr(self, k))]
        # Clean up method names
        clean = [a.replace('_do_', '').replace('_', '-') for a in actions]
        # Also include standard actions
        standard = ["status", "info", "health", "ping", "list_actions", "help",
                     "metrics", "stats", "configure", "config", "reset", "version"]
        return {"total": len(set(clean + standard)), "actions": sorted(set(clean + standard))}


    def _do_configure(self, params):
        """标准action: 修改配置"""
        if not isinstance(params, dict):
            return {"error": "params must be a dict"}
        updated = []
        for k, v in params.items():
            if k in ("action",):
                continue
            if hasattr(self, 'config'):
                self.config[k] = v
                updated.append(k)
        return {"success": True, "updated": updated}


    def _do_version(self, params):
        """标准action: 版本信息"""
        return {
            "module_id": self.module_id,
            "version": getattr(self, 'version', 'unknown'),
            "class": self.__class__.__name__,
        }

module_class = APIRateLimiter
