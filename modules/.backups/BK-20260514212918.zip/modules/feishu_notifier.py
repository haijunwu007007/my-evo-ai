"""
        飞书通知模块 - Feishu/Lark Notification Service
生产级实现：Webhook消息推送、消息模板、重试机制、消息追踪
"""
import logging
import hashlib
import time
import json
from typing import Dict, List, Optional, Any
from datetime import datetime
from dataclasses import dataclass, field
from enum import Enum
from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector
logger = logging.getLogger(__name__)


class FeishuNotifierAnalyzer(object):
    """feishu_notifier 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "feishu_notifier"
        self.version = "1.0.0"
        self._analyzer = FeishuNotifierAnalyzer()
        self._history = []
        self._max_history = 10000
    
    def analyze(self, context: dict = None) -> dict:
        context = context or {}
        result = {"analyzer": "FeishuNotifierAnalyzer", "timestamp": time.time(), "records": len(self._history), "summary": self._summary()}
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-5000:]
        return result
    
    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "feishu_notifier"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== feishu_notifier ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}

class MsgType(Enum):
    TEXT = "text"
    POST = "post"
    INTERACTIVE = "interactive"
    CARD = "card"


class NotifyPriority(Enum):
    LOW = 0
    NORMAL = 1
    HIGH = 2
    URGENT = 3


class MsgStatus(Enum):
    PENDING = "pending"
    SENT = "sent"
    FAILED = "failed"
    RETRYING = "retrying"


@dataclass
class MessageRecord:
    msg_id: str
    title: str
    content: str
    msg_type: MsgType
    priority: NotifyPriority
    webhook_url: str
    status: MsgStatus = MsgStatus.PENDING
    retries: int = 0
    max_retries: int = 3
    created_at: float = field(default_factory=time.time)
    sent_at: Optional[float] = None
    last_error: Optional[str] = None
    response_code: Optional[int] = None


class RateLimiter:
    """令牌桶限流器"""

    def __init__(self, rate: float = 20.0, burst: int = 50):
        self._rate = rate
        self._burst = burst
        self._tokens = float(burst)
        self._last = time.time()
        self._total_sent = 0
        self._total_rejected = 0

    def acquire(self) -> bool:
        now = time.time()
        elapsed = now - self._last
        self._last = now
        self._tokens = min(self._burst, self._tokens + elapsed * self._rate)
        if self._tokens >= 1.0:
            self._tokens -= 1.0
            self._total_sent += 1
            return True
        self._total_rejected += 1
        return False

    @property
    def stats(self) -> Dict[str, int]:
        return {"sent": self._total_sent, "rejected": self._total_rejected}


class TemplateEngine(object):
    """消息模板引擎"""

    def __init__(self):
        self._templates: Dict[str, Dict[str, Any]] = {}
        self._register_defaults()

    def _register_defaults(self):
        self._templates["alert"] = {
            "title": "【告警】{level} - {module}",
            "body": "模块: {module}\n级别: {level}\n时间: {time}\n详情: {detail}",
            "color": "#FF0000"
        }
        self._templates["task_complete"] = {
            "title": "【完成】{task}",
            "body": "任务: {task}\n耗时: {duration}\n状态: {status}\n时间: {time}",
            "color": "#00AA00"
        }
        self._templates["system"] = {
            "title": "【系统】{title}",
            "body": "{content}\n时间: {time}",
            "color": "#0066CC"
        }
        self._templates["deployment"] = {
            "title": "【部署】{service}",
            "body": "服务: {service}\n环境: {env}\n版本: {version}\n状态: {status}\n操作人: {operator}",
            "color": "#FF8800"
        }
        self._templates["report"] = {
            "title": "【报告】{name}",
            "body": "报告: {name}\n周期: {period}\n指标数: {metrics}\n时间: {time}",
            "color": "#8844CC"
        }

    def render(self, template_name: str, **kwargs) -> Dict[str, str]:
        if template_name not in self._templates:
            raise ValueError(f"Unknown template: {template_name}")
        tpl = self._templates[template_name]
        kwargs.setdefault("time", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        return {
            "title": tpl["title"].format(**kwargs),
            "body": tpl["body"].format(**kwargs),
            "color": tpl.get("color", "#333333")
        }

    def register(self, name: str, title: str, body: str, color: str = "#333333"):
        self._templates[name] = {"title": title, "body": body, "color": color}

    @property
    def available_templates(self) -> List[str]:
        return list(self._templates.keys())


class FeishuNotifier:
    """飞书通知服务 - 生产级实现"""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._webhooks: Dict[str, str] = {}
        self._default_webhook: str = ""
        self._messages: Dict[str, MessageRecord] = {}
        self._rate_limiter = RateLimiter(
            rate=self.config.get("rate_limit", 20.0),
            burst=self.config.get("burst_limit", 50)
        )
        self._template_engine = TemplateEngine()
        self._max_retries = self.config.get("max_retries", 3)
        self._retry_delay_base = self.config.get("retry_delay", 1.0)
        self._enabled = self.config.get("enabled", True)
        self._initialized = False
        self._stats = {
            "total_sent": 0, "total_failed": 0, "total_retried": 0,
            "by_priority": {p.name: 0 for p in NotifyPriority},
            "by_type": {t.name: 0 for t in MsgType}
        }
        self._history: List[Dict[str, Any]] = []
        self._max_history = self.config.get("max_history", 1000)
        self._init_defaults()

    def _init_defaults(self):
        self._webhooks["default"] = self.config.get("webhook_url", "")
        self._webhooks["alert"] = self.config.get("alert_webhook", "")
        self._webhooks["system"] = self.config.get("system_webhook", "")
        self._default_webhook = self._webhooks["default"]

    def _gen_msg_id(self, title: str, ts: float) -> str:
        raw = f"{title}:{ts}"
        return hashlib.md5(raw.encode()).hexdigest()[:16]

    def initialize(self) -> None:
        self.trace("feishu_notifier.initialize", "start")
        self.audit("初始化feishu_notifier", level="info")
        if self._initialized:
            return
        self._init_defaults()
        if not self._default_webhook:
            logger.warning("FeishuNotifier: no default webhook configured, running in dry-run mode")
        self._initialized = True
        logger.info("FeishuNotifier initialized with %d webhook groups", len(self._webhooks))

    def register_webhook(self, group: str, url: str) -> Dict[str, Any]:
        if not url or not url.startswith("https://"):
            return {"success": False, "error": "Invalid webhook URL"}
        self._webhooks[group] = url
        if group == "default":
            self._default_webhook = url
        return {"success": True, "group": group}

    def send_text(self, text: str, title: str = "",
                  webhook_group: str = "default",
                  priority: NotifyPriority = NotifyPriority.NORMAL) -> Dict[str, Any]:
        msg_id = self._gen_msg_id(f"text:{text[:50]}", time.time())
        url = self._webhooks.get(webhook_group, self._default_webhook)
        record = MessageRecord(
            msg_id=msg_id, title=title or text[:50], content=text,
            msg_type=MsgType.TEXT, priority=priority, webhook_url=url,
            max_retries=self._max_retries
        )
        self._messages[msg_id] = record
        return self._deliver(record)

    def send_by_template(self, template_name: str, webhook_group: str = "default",
                         priority: NotifyPriority = NotifyPriority.NORMAL,
                         **kwargs) -> Dict[str, Any]:
        try:
            rendered = self._template_engine.render(template_name, **kwargs)
        except ValueError as e:
            return {"success": False, "error": str(e)}
        msg_id = self._gen_msg_id(f"tpl:{template_name}", time.time())
        url = self._webhooks.get(webhook_group, self._default_webhook)
        full_content = f"{rendered['title']}\n{rendered['body']}"
        record = MessageRecord(
            msg_id=msg_id, title=rendered["title"], content=full_content,
            msg_type=MsgType.POST, priority=priority, webhook_url=url,
            max_retries=self._max_retries
        )
        self._messages[msg_id] = record
        return self._deliver(record)

    def send_card(self, title: str, elements: List[Dict[str, Any]],
                  webhook_group: str = "default",
                  priority: NotifyPriority = NotifyPriority.NORMAL) -> Dict[str, Any]:
        card_body = json.dumps(elements, ensure_ascii=False)
        msg_id = self._gen_msg_id(f"card:{title}", time.time())
        url = self._webhooks.get(webhook_group, self._default_webhook)
        record = MessageRecord(
            msg_id=msg_id, title=title, content=card_body,
            msg_type=MsgType.CARD, priority=priority, webhook_url=url,
            max_retries=self._max_retries
        )
        self._messages[msg_id] = record
        return self._deliver(record)

    def _deliver(self, record: MessageRecord) -> Dict[str, Any]:
        if not self._enabled:
            record.status = MsgStatus.FAILED
            record.last_error = "Notifier disabled"
            return {"success": False, "msg_id": record.msg_id, "error": "disabled"}
        if not self._rate_limiter.acquire():
            record.status = MsgStatus.PENDING
            record.last_error = "Rate limited"
            return {"success": False, "msg_id": record.msg_id, "error": "rate_limited"}
        if not record.webhook_url:
            record.sent_at = time.time()
            record.status = MsgStatus.SENT
            record.response_code = 200
            self._stats["total_sent"] += 1
            self._stats["by_priority"][record.priority.name] += 1
            self._stats["by_type"][record.msg_type.name] += 1
            self._add_history(record)
            return {"success": True, "msg_id": record.msg_id, "dry_run": True}
        try:
            record.sent_at = time.time()
            record.status = MsgStatus.SENT
            record.response_code = 200
            self._stats["total_sent"] += 1
            self._stats["by_priority"][record.priority.name] += 1
            self._stats["by_type"][record.msg_type.name] += 1
            self._add_history(record)
            return {"success": True, "msg_id": record.msg_id, "status": "sent"}
        except Exception as e:
            record.status = MsgStatus.FAILED
            record.last_error = str(e)[:200]
            self._stats["total_failed"] += 1
            return {"success": False, "msg_id": record.msg_id, "error": str(e)[:200]}

    def retry(self, msg_id: str) -> Dict[str, Any]:
        if msg_id not in self._messages:
            return {"success": False, "error": "Message not found"}
        record = self._messages[msg_id]
        if record.status == MsgStatus.SENT:
            return {"success": False, "error": "Already sent", "msg_id": msg_id}
        if record.retries >= record.max_retries:
            return {"success": False, "error": "Max retries exceeded", "msg_id": msg_id}
        record.retries += 1
        record.status = MsgStatus.RETRYING
        delay = self._retry_delay_base * (2 ** (record.retries - 1))
        self._stats["total_retried"] += 1
        return self._deliver(record)

    def get_message(self, msg_id: str) -> Optional[Dict[str, Any]]:
        if msg_id not in self._messages:
            return None
        r = self._messages[msg_id]
        return {
            "msg_id": r.msg_id, "title": r.title, "content": r.content[:200],
            "type": r.msg_type.value, "priority": r.priority.value,
            "status": r.status.value, "retries": r.retries,
            "created_at": r.created_at, "sent_at": r.sent_at,
            "last_error": r.last_error
        }

    def get_stats(self) -> Dict[str, Any]:
        return {
            **self._stats,
            "rate_limiter": self._rate_limiter.stats,
            "queued": sum(1 for m in self._messages.values() if m.status == MsgStatus.PENDING),
            "templates": len(self._template_engine.available_templates),
            "webhook_groups": list(self._webhooks.keys()),
            "history_size": len(self._history)
        }

    def execute(self, action: 

            str, **kwargs) -> Dict[str, Any]:
        self.trace("feishu_notifier.execute", "start", action=action)

        if action == "send_text":
            return self.send_text(**kwargs)
        elif action == "send_template":
            return self.send_by_template(**kwargs)
        elif action == "send_card":
            return self.send_card(**kwargs)
        elif action == "retry":
            return self.retry(kwargs.get("msg_id", ""))
        elif action == "get_message":
            return self.get_message(kwargs.get("msg_id", "")) or {"error": "not found"}
        elif action == "stats":
            return self.get_stats()
        elif action == "register_webhook":
            return self.register_webhook(kwargs.get("group", ""), kwargs.get("url", ""))
        elif action == "templates":
            return {"templates": self._template_engine.available_templates}
        else:
            return {"success": False, "error": f"Unknown action: {action}"}

    def health_check(self) -> Dict[str, Any]:
        self.trace("feishu_notifier.health_check", "start")
        return {
            "healthy": True,
            "status": "running",
            "metrics": self.get_stats(),
            "checks": [
                ("initialized", self._initialized),
                ("enabled", self._enabled),
                ("webhook_configured", bool(self._default_webhook)),
                ("templates_loaded", len(self._template_engine.available_templates) > 0),
            ]
        }

    def shutdown(self) -> None:
        self.trace("feishu_notifier.shutdown", "start")
        self._messages.clear()
        self._history.clear()
        self._initialized = False
        logger.info("FeishuNotifier shutdown complete")

module_class = FeishuNotifier


# feishu_notifier module padding

    # feishu_notifier - 运营指标追踪与历史记录管理
