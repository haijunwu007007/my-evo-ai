"""
AUTO-EVO-AI v7.0 — 项目管理器
Grade: A (生产级) | Category: 工具链
职责：项目管理、任务跟踪、里程碑、团队协作、进度报告
"""

import asyncio
import time
import uuid
import json
import os
import logging
from typing import Any, Dict, List, Optional
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime, timedelta

try:
    from modules._base.enterprise_module import EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
    from modules._base.tracing import trace_operation
    from modules._base.metrics import MetricsCollector, metrics_collector
    from modules._base.audit import AuditLogger
except ImportError:
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from _base.enterprise_module import EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
    from _base.tracing import trace_operation
    from _base.metrics import metrics_collector
    from _base.audit import AuditLogger
logger = logging.getLogger("project_manager")

class _MetricsAdapter:
    """轻量指标适配器 — 兼容 self._metrics.increment/histogram 接口"""
    def increment(self, name: str, value: float = 1.0, **kw):
        pass  # 已由 EnterpriseModule.record_metrics() 覆盖
    def histogram(self, name: str, value: float, **kw):
        pass
    def gauge(self, name: str, value: float, **kw):
        pass
    def counter(self, name: str, value: float = 1.0, **kw):
        pass



class TaskStatus(Enum):
    BACKLOG = "backlog"
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    IN_REVIEW = "in_review"
    DONE = "done"
    BLOCKED = "blocked"
    CANCELLED = "cancelled"


class Priority(Enum):
    CRITICAL = 0
    HIGH = 1
    MEDIUM = 2
    LOW = 3


class SprintStatus(Enum):
    PLANNING = "planning"
    ACTIVE = "active"
    REVIEW = "review"
    COMPLETED = "completed"


@dataclass
class ProjectMember:
    """项目成员"""
    member_id: str
    name: str
    role: str = "developer"
    email: str = ""
    capacity_hours: int = 40
    skills: List[str] = field(default_factory=list)


@dataclass
class Task:
    """任务"""
    task_id: str
    title: str
    description: str = ""
    status: TaskStatus = TaskStatus.TODO
    priority: Priority = Priority.MEDIUM
    assignee_id: Optional[str] = None
    story_points: int = 1
    tags: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    subtasks: List[Dict[str, Any]] = field(default_factory=list)
    comments: List[Dict[str, Any]] = field(default_factory=list)
    time_logged_hours: float = 0.0
    estimated_hours: float = 0.0
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None
    sprint_id: Optional[str] = None
    milestone_id: Optional[str] = None


@dataclass
class Milestone:
    """里程碑"""
    milestone_id: str
    name: str
    description: str = ""
    target_date: Optional[str] = None
    status: str = "upcoming"
    completion_percentage: float = 0.0
    tasks: List[str] = field(default_factory=list)


@dataclass
class Sprint:
    """迭代"""
    sprint_id: str
    name: str
    goal: str = ""
    status: SprintStatus = SprintStatus.PLANNING
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    task_ids: List[str] = field(default_factory=list)
    velocity: float = 0.0


class ProjectRiskAnalyzer(object):
    """项目风险分析器 — 评估项目延期风险、资源瓶颈、依赖阻塞"""

    def __init__(self):
        self._risk_history: List[Dict[str, Any]] = []

    def assess_delay_risk(self, tasks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """评估项目延期风险"""
        total_tasks = len(tasks)
        completed = sum(1 for t in tasks if t.get("status") == "done")
        overdue = sum(1 for t in tasks if t.get("status") in ("in_progress", "todo")
                      and t.get("due_date") and t.get("due_date") < time.time())
        progress = completed / total_tasks if total_tasks > 0 else 0

        risk_score = 0
        if overdue > 0:
            risk_score += min(overdue / total_tasks * 50, 30)
        if progress < 0.3:
            risk_score += 20
        elif progress < 0.6:
            risk_score += 10
        if total_tasks > 50 and completed < 10:
            risk_score += 15

        risk_level = "high" if risk_score >= 50 else "medium" if risk_score >= 25 else "low"
        return {"total": total_tasks, "completed": completed, "overdue": overdue,
                "progress": round(progress, 3), "risk_score": round(risk_score, 1),
                "risk_level": risk_level}

    def detect_resource_bottleneck(self, members: List[Dict[str, Any]],
                                   tasks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """检测资源瓶颈（某人分配了过多任务）"""
        member_load: Dict[str, int] = {}
        for t in tasks:
            assignee = t.get("assignee", "unassigned")
            if t.get("status") in ("in_progress", "todo"):
                member_load[assignee] = member_load.get(assignee, 0) + 1
        avg_load = sum(member_load.values()) / len(member_load) if member_load else 0
        bottlenecks = []
        for member, load in member_load.items():
            if load > avg_load * 1.5 and load >= 5:
                bottlenecks.append({"member": member, "task_count": load,
                                    "avg_team_load": round(avg_load, 1),
                                    "overload_pct": round((load / avg_load - 1) * 100, 1) if avg_load > 0 else 0})
        bottlenecks.sort(key=lambda x: x["task_count"], reverse=True)
        return bottlenecks

    def analyze_dependencies(self, tasks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """分析任务依赖链，检测阻塞点"""
        task_map = {t.get("id"): t for t in tasks if t.get("id")}
        blocked = 0
        blockers = []
        for task in tasks:
            deps = task.get("depends_on", [])
            for dep_id in deps:
                dep_task = task_map.get(dep_id)
                if dep_task and dep_task.get("status") != "done":
                    blocked += 1
                    blockers.append(dep_id)
        return {"total_tasks": len(tasks), "blocked_tasks": blocked,
                "unique_blockers": list(set(blockers)),
                "blocker_count": len(set(blockers))}

    def generate_health_report(self, project: Dict[str, Any],
                               tasks: List[Dict[str, Any]],
                               members: List[Dict[str, Any]]) -> Dict[str, Any]:
        """生成项目健康报告"""
        delay = self.assess_delay_risk(tasks)
        bottlenecks = self.detect_resource_bottleneck(members, tasks)
        deps = self.analyze_dependencies(tasks)

        health_score = max(0, 100 - delay["risk_score"] - len(bottlenecks) * 5 - deps["blocked_tasks"])
        return {
            "project": project.get("name", "unnamed"),
            "health_score": round(health_score, 1),
            "grade": "A" if health_score >= 80 else "B" if health_score >= 60 else "C" if health_score >= 40 else "D",
            "delay_risk": delay, "resource_bottlenecks": bottlenecks,
            "dependency_analysis": deps,
        }


class ProjectManager(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """项目管理器"""

    def __init__(self):

        super().__init__()
        self._metrics = _MetricsAdapter()
        self._tasks: Dict[str, Task] = {}
        self._sprints: Dict[str, Sprint] = {}
        self._milestones: Dict[str, Milestone] = {}
        self._members: Dict[str, ProjectMember] = {}
        self._projects: Dict[str, Dict] = {}
        self._activity_log: List[Dict] = []

    def initialize(self) -> None:
        logger.info("项目管理器初始化完成")
        self.record_metrics("unknown.init", 1)
        self.audit("initialized", "Unknown初始化完成")

    # === 项目管理 ===
    @trace_operation("create_project")
    def create_project(self, name: str, description: str,
                             config: Optional[Dict] = None) -> Dict[str, Any]:
        project_id = f"proj_{uuid.uuid4().hex[:8]}"
        self._projects[project_id] = {
            "name": name, "description": description,
            "config": config or {}, "created_at": time.time(),
            "status": "active", "sprints": [], "milestones": []
        }
        self.stats["projects_created"] += 1
        self._log_activity("create_project", f"创建项目: {name}")
        return {"project_id": project_id, "name": name}

    # === 任务管理 ===
    @trace_operation("create_task")
    def create_task(self, title: str, description: str = "",
                          priority: Priority = Priority.MEDIUM,
                          assignee_id: Optional[str] = None,
                          story_points: int = 1,
                          tags: Optional[List[str]] = None,
                          sprint_id: Optional[str] = None,
                          milestone_id: Optional[str] = None) -> Dict[str, Any]:
        task_id = f"task_{uuid.uuid4().hex[:8]}"
        task = Task(
            task_id=task_id, title=title, description=description,
            priority=priority, assignee_id=assignee_id,
            story_points=story_points, tags=tags or [],
            sprint_id=sprint_id, milestone_id=milestone_id
        )
        self._tasks[task_id] = task

        if sprint_id and sprint_id in self._sprints:
            self._sprints[sprint_id].task_ids.append(task_id)
        if milestone_id and milestone_id in self._milestones:
            self._milestones[milestone_id].tasks.append(task_id)

        self._log_activity("create_task", f"创建任务: {title}")
        self.stats["tasks_created"] += 1
        return {"task_id": task_id, "title": title, "status": task.status.value}

    @trace_operation("update_task")
    def update_task(self, task_id: str,
                          status: Optional[TaskStatus] = None,
                          assignee_id: Optional[str] = None,
                          title: Optional[str] = None,
                          add_comment: Optional[str] = None) -> Dict[str, Any]:
        if task_id not in self._tasks:
            raise ValueError(f"任务 {task_id} 不存在")

        task = self._tasks[task_id]
        changes = []

        if status is not None and status != task.status:
            old_status = task.status.value
            task.status = status
            changes.append(f"状态: {old_status} -> {status.value}")
            if status == TaskStatus.DONE:
                task.completed_at = time.time()
            self._log_activity("task_status", f"任务 {task.title}: {' -> '.join(changes)}")

        if assignee_id is not None:
            task.assignee_id = assignee_id
        if title is not None:
            task.title = title

        if add_comment:
            task.comments.append({
                "author": "system", "content": add_comment,
                "timestamp": time.time()
            })

        task.updated_at = time.time()
        self.stats["tasks_updated"] += 1
        return {"task_id": task_id, "status": task.status.value, "changes": changes}

    @trace_operation("get_tasks")
    def get_tasks(self, status: Optional[TaskStatus] = None,
                        assignee_id: Optional[str] = None,
                        sprint_id: Optional[str] = None,
                        priority: Optional[Priority] = None,
                        tags: Optional[List[str]] = None,
                        limit: int = 100) -> List[Dict]:
        tasks = list(self._tasks.values())
        if status:
            tasks = [t for t in tasks if t.status == status]
        if assignee_id:
            tasks = [t for t in tasks if t.assignee_id == assignee_id]
        if sprint_id:
            tasks = [t for t in tasks if t.sprint_id == sprint_id]
        if priority:
            tasks = [t for t in tasks if t.priority == priority]
        if tags:
            tasks = [t for t in tasks if any(tag in t.tags for tag in tags)]

        tasks.sort(key=lambda t: (t.priority.value, t.updated_at), reverse=False)
        return [
            {"task_id": t.task_id, "title": t.title, "status": t.status.value,
             "priority": t.priority.name, "assignee": t.assignee_id,
             "points": t.story_points, "tags": t.tags,
             "subtasks_done": sum(1 for s in t.subtasks if s.get("done")),
             "subtasks_total": len(t.subtasks),
             "updated_at": datetime.fromtimestamp(t.updated_at).isoformat()}
            for t in tasks[:limit]
        ]

    def get_task_detail(self, task_id: str) -> Dict[str, Any]:
        if task_id not in self._tasks:
            raise ValueError(f"任务 {task_id} 不存在")
        t = self._tasks[task_id]
        return {
            "task_id": t.task_id, "title": t.title,
            "description": t.description, "status": t.status.value,
            "priority": t.priority.name, "assignee": t.assignee_id,
            "points": t.story_points, "tags": t.tags,
            "dependencies": t.dependencies,
            "subtasks": t.subtasks,
            "comments": t.comments[-10:],
            "time_logged": t.time_logged_hours,
            "estimated": t.estimated_hours,
            "created_at": datetime.fromtimestamp(t.created_at).isoformat(),
            "completed_at": datetime.fromtimestamp(t.completed_at).isoformat() if t.completed_at else None
        }

    # === 迭代管理 ===
    @trace_operation("create_sprint")
    def create_sprint(self, name: str, goal: str = "",
                            start_date: Optional[str] = None,
                            end_date: Optional[str] = None) -> Dict[str, Any]:
        sprint_id = f"sprint_{uuid.uuid4().hex[:8]}"
        sprint = Sprint(sprint_id=sprint_id, name=name, goal=goal,
                        status=SprintStatus.PLANNING,
                        start_date=start_date, end_date=end_date)
        self._sprints[sprint_id] = sprint
        self._log_activity("create_sprint", f"创建迭代: {name}")
        return {"sprint_id": sprint_id, "name": name}

    @trace_operation("start_sprint")
    def start_sprint(self, sprint_id: str,
                           task_ids: Optional[List[str]] = None) -> Dict[str, Any]:
        if sprint_id not in self._sprints:
            raise ValueError(f"迭代 {sprint_id} 不存在")
        sprint = self._sprints[sprint_id]
        sprint.status = SprintStatus.ACTIVE
        sprint.start_date = sprint.start_date or datetime.now().strftime("%Y-%m-%d")

        if task_ids:
            for tid in task_ids:
                if tid in self._tasks:
                    self._tasks[tid].sprint_id = sprint_id
                    if tid not in sprint.task_ids:
                        sprint.task_ids.append(tid)

        self._log_activity("start_sprint", f"开始迭代: {sprint.name}")
        return {"sprint_id": sprint_id, "status": "active", "tasks": len(sprint.task_ids)}

    @trace_operation("complete_sprint")
    def complete_sprint(self, sprint_id: str) -> Dict[str, Any]:
        if sprint_id not in self._sprints:
            raise ValueError(f"迭代 {sprint_id} 不存在")
        sprint = self._sprints[sprint_id]
        sprint.status = SprintStatus.REVIEW

        done_tasks = [tid for tid in sprint.task_ids
        if tid in self._tasks and self._tasks[tid].status == TaskStatus.DONE]
        total_points = sum(self._tasks[tid].story_points
        for tid in sprint.task_ids if tid in self._tasks)
        done_points = sum(self._tasks[tid].story_points
        for tid in done_tasks)
        sprint.velocity = done_points
        completion_rate = round(done_points / max(total_points, 1), 4)

        return {
            "sprint_id": sprint_id,
            "total_tasks": len(sprint.task_ids),
            "completed_tasks": len(done_tasks),
            "total_points": total_points,
            "completed_points": done_points,
            "velocity": done_points,
            "completion_rate": completion_rate
        }

    def get_sprint_status(self, sprint_id: str) -> Dict[str, Any]:
        if sprint_id not in self._sprints:
            raise ValueError(f"迭代 {sprint_id} 不存在")
        sprint = self._sprints[sprint_id]

        task_statuses = defaultdict(int)
        total_points = 0
        done_points = 0
        for tid in sprint.task_ids:
            if tid in self._tasks:
                t = self._tasks[tid]
                task_statuses[t.status.value] += 1
                total_points += t.story_points
                if t.status == TaskStatus.DONE:
                    done_points += t.story_points

        return {
            "sprint_id": sprint_id, "name": sprint.name,
            "status": sprint.status.value, "goal": sprint.goal,
            "start_date": sprint.start_date, "end_date": sprint.end_date,
            "tasks": len(sprint.task_ids),
            "task_status_distribution": dict(task_statuses),
            "total_points": total_points, "done_points": done_points,
            "progress": round(done_points / max(total_points, 1), 4)
        }

    # === 里程碑 ===
    @trace_operation("create_milestone")
    def create_milestone(self, name: str, description: str = "",
                               target_date: Optional[str] = None) -> Dict[str, Any]:
        milestone_id = f"ms_{uuid.uuid4().hex[:8]}"
        milestone = Milestone(milestone_id=milestone_id, name=name,
        description=description, target_date=target_date)
        self._milestones[milestone_id] = milestone
        return {"milestone_id": milestone_id, "name": name}

    def update_milestone_progress(self, milestone_id: str) -> Dict[str, Any]:
        if milestone_id not in self._milestones:
            raise ValueError(f"里程碑 {milestone_id} 不存在")
        ms = self._milestones[milestone_id]
        total = len(ms.tasks)
        done = sum(1 for tid in ms.tasks
        if tid in self._tasks and self._tasks[tid].status == TaskStatus.DONE)
        ms.completion_percentage = round(done / max(total, 1), 4)

        if ms.completion_percentage >= 1.0:
            ms.status = "completed"
        elif ms.completion_percentage > 0:
            ms.status = "in_progress"

        return {"milestone_id": milestone_id, "name": ms.name,
                "progress": ms.completion_percentage,
                "done": done, "total": total}

    # === 团队 ===
    @trace_operation("add_member")
    def add_member(self, name: str, role: str = "developer",
                         email: str = "", skills: Optional[List[str]] = None) -> Dict[str, Any]:
        member_id = f"mem_{uuid.uuid4().hex[:8]}"
        member = ProjectMember(member_id=member_id, name=name,
        role=role, email=email, skills=skills or [])
        self._members[member_id] = member
        return {"member_id": member_id, "name": name, "role": role}

    def get_workload(self) -> List[Dict]:
        """获取团队工作负载"""
        workloads = []
        for mid, member in self._members.items():
            tasks = [t for t in self._tasks.values()
            if t.assignee_id == mid and t.status in (TaskStatus.TODO, TaskStatus.IN_PROGRESS)]
            total_points = sum(t.story_points for t in tasks)
            total_hours = sum(t.estimated_hours for t in tasks)

            workloads.append({
                "member_id": mid, "name": member.name, "role": member.role,
                "active_tasks": len(tasks), "story_points": total_points,
                "estimated_hours": total_hours,
                "capacity_hours": member.capacity_hours,
                "utilization": round(total_hours / max(member.capacity_hours, 1), 4),
                "task_list": [{"id": t.task_id, "title": t.title, "points": t.story_points}
                             for t in sorted(tasks, key=lambda x: x.priority.value)]
            })
        workloads.sort(key=lambda x: x["utilization"], reverse=True)
        return workloads

    # === 进度报告 ===
    @trace_operation("generate_report")
    def generate_progress_report(self) -> Dict[str, Any]:
        """生成进度报告"""
        status_counts = defaultdict(int)
        priority_counts = defaultdict(int)
        total_points = 0
        done_points = 0

        for task in self._tasks.values():
            status_counts[task.status.value] += 1
            priority_counts[task.priority.name] += 1
            total_points += task.story_points
            if task.status == TaskStatus.DONE:
                done_points += task.story_points

        avg_cycle = 0
        completed = [t for t in self._tasks.values() if t.completed_at and t.created_at]
        if completed:
            avg_cycle = sum(t.completed_at - t.created_at for t in completed) / len(completed) / 3600

        sprints_summary = []
        for sid, sprint in self._sprints.items():
            sprints_summary.append({
                "name": sprint.name, "status": sprint.status.value,
                "velocity": sprint.velocity, "tasks": len(sprint.task_ids)
            })

        return {
            "overall": {
                "total_tasks": len(self._tasks),
                "done_tasks": status_counts.get("done", 0),
                "in_progress": status_counts.get("in_progress", 0),
                "blocked": status_counts.get("blocked", 0),
                "total_points": total_points,
                "done_points": done_points,
                "completion_rate": round(done_points / max(total_points, 1), 4),
                "avg_cycle_hours": round(avg_cycle, 1)
            },
            "by_status": dict(status_counts),
            "by_priority": dict(priority_counts),
            "active_sprints": [s for s in sprints_summary if s["status"] == "active"],
            "milestones": [
                {"name": m.name, "progress": m.completion_percentage,
                 "target": m.target_date}
                for m in self._milestones.values()
            ],
            "team_size": len(self._members),
            "recent_activity": self._activity_log[-20:]
        }

    def _log_activity(self, action: str, description: str) -> None:
        self._activity_log.append({
            "action": action, "description": description,
            "timestamp": time.time()
        })


    def execute(self, action: 

str = "list_actions", params: dict = None) -> dict:
        _ = self.trace("execute")
        metrics_collector.counter("project_manager_ops_total", labels={"action": action})
        """统一执行入口 — 根据action路由到对应业务方法"""
        trace_id = f"project-execute-{int(time.time()*1000)}"
        params = params or {}
        actions = {
            "create_project": self.create_project,
            "create_task": self.create_task,
            "update_task": self.update_task,
            "get_tasks": self.get_tasks,
            "get_task_detail": self.get_task_detail,
            "create_sprint": self.create_sprint,
            "start_sprint": self.start_sprint,
            "complete_sprint": self.complete_sprint,
            "get_sprint_status": self.get_sprint_status,
            "create_milestone": self.create_milestone,
            "update_milestone_progress": self.update_milestone_progress,
            "add_member": self.add_member,
            "get_workload": self.get_workload,
            "generate_progress_report": self.generate_progress_report,
            "list_actions": lambda: list(actions.keys()),
            "help": lambda: {"actions": list(actions.keys()), "usage": "execute(action, params)"},
        }

        if action not in actions:
            return {"status": "error", "message": f"Unknown action: {action}", "available": list(actions.keys())}

        handler = actions[action]
        if callable(handler) and not isinstance(handler, list):
            import inspect
            if inspect.iscoroutinefunction(handler):
                try:
                    sig = inspect.signature(handler)
                    if len(sig.parameters) <= 1:
                        result = handler()
                    else:
                        result = handler(**params)
                except Exception as e:
                    return {"status": "error", "message": str(e)}
            else:
                try:
                    sig = inspect.signature(handler)
                    if len(sig.parameters) <= 1:
                        result = handler()
                    else:
                        result = handler(**params)
                except Exception as e:
                    return {"status": "error", "message": str(e)}
            if isinstance(result, dict):
                return {"status": "success", **result}
            return {"status": "success", "data": result}

    def health_check(self) -> Dict[str, Any]:
        base = super().health_check()
        base.update({
            "projects": len(self._projects),
            "tasks": len(self._tasks),
            "sprints": len(self._sprints),
            "milestones": len(self._milestones),
            "team": len(self._members),
            "activity_entries": len(self._activity_log)
        })
        return base

    def shutdown(self) -> None:
        audit_logger.log(
            action="module_shutdown", resource="project_manager",
            details=f"关闭，{len(self._tasks)} 个任务"
        )


module_class = ProjectManager
