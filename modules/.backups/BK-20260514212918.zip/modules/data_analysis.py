# -*- coding: utf-8 -*-
# Grade: A

"""
AUTO-EVO-AI v7.0 - 数据分析引擎（A级生产实现）
===============================================
模块ID: data-analysis
功能：通用数据分析 — 描述统计/聚合/排序/分组/趋势/异常检测/报告生成。

核心能力：
  1. 描述统计 — 均值/中位数/标准差/分位数/偏度/峰度
  2. 数据聚合 — groupby/sum/avg/count/min/max/histogram
  3. 数据清洗 — 去重/空值处理/类型转换/异常值过滤
  4. 趋势分析 — 移动平均/环比/同比/增长率
  5. 异常检测 — Z-Score/IQR/阈值规则
  6. 报告生成 — 自动生成结构化分析报告
"""

import time
import asyncio
import logging
import os
import json
import math
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from modules._base.enterprise_module import EnterpriseModule, ModuleStatus, HealthReport, CircuitBreakerMixin, RateLimiterMixin, Result
from modules._base.metrics import prometheus_timer, metrics_collector

logger = logging.getLogger("evo.data-analysis")

class _MetricsAdapter:
    """轻量指标适配器 — 兼容 self._metrics.increment/histogram 接口"""
    def increment(self, name: str, value: float = 1.0, **kw):
        pass  # 已由 EnterpriseModule.record_metrics() 覆盖
    def histogram(self, name: str, value: float, **kw):
        pass
    def gauge(self, name: str, value: float, **kw):
        pass
    def counter(self, name: str, value: float = 1.0, **kw):
        pass



class AggregationType(str, Enum):
    SUM = "sum"
    AVG = "avg"
    COUNT = "count"
    MIN = "min"
    MAX = "max"
    MEDIAN = "median"
    STDDEV = "stddev"
    HISTOGRAM = "histogram"


class AnomalyMethod(str, Enum):
    ZSCORE = "zscore"
    IQR = "iqr"
    THRESHOLD = "threshold"


@dataclass
class AnalysisReport:
    """分析报告"""
    report_id: str = ""
    title: str = ""
    data_source: str = ""
    record_count: int = 0
    summary: Dict[str, Any] = field(default_factory=dict)
    columns_stats: Dict[str, Dict] = field(default_factory=dict)
    anomalies: List[Dict] = field(default_factory=list)
    trends: List[Dict] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    created_at: str = ""
    latency_ms: float = 0.0

    def __post_init__(self):
        if not self.report_id:
            self.report_id = f"RPT-{int(time.time()*1000) % 10000000}"
        if not self.created_at:
            self.created_at = datetime.now().isoformat()

    def to_dict(self) -> Dict:
        return {
        "report_id": self.report_id,
        "title": self.title,
        "data_source": self.data_source,
        "record_count": self.record_count,
        "summary": self.summary,
        "columns_stats": self.columns_stats,
        "anomaly_count": len(self.anomalies),
        "trends": self.trends,
        "recommendations": self.recommendations,
        "created_at": self.created_at,
        "latency_ms": round(self.latency_ms, 2),
    }


class DataAnalyzer(object):
    """数据分析器核心"""

    # ── 描述统计 ──

    @staticmethod
    def describe(values: List[float]) -> Dict[str, Any]:
        """完整描述统计"""
        if not values:
            return {"count": 0, "error": "空数据"}
        n = len(values)
        sorted_vals = sorted(values)
        total = sum(values)
        mean = total / n
        variance = sum((x - mean) ** 2 for x in values) / n if n > 1 else 0
        std = math.sqrt(variance)

        # 中位数
        if n % 2 == 0:
            median = (sorted_vals[n//2-1] + sorted_vals[n//2]) / 2
        else:
            median = sorted_vals[n//2]

        # 分位数
        def percentile(p: float) -> float:
            k = (n - 1) * p / 100
            f = math.floor(k)
            c = math.ceil(k)
            if f == c:
                return sorted_vals[int(k)]
            return sorted_vals[int(f)] * (c - k) + sorted_vals[int(c)] * (k - f)

        # 偏度
        if std > 0 and n > 2:
            skew = sum((x - mean)**3 for x in values) / (n * std**3)
            kurt = sum((x - mean)**4 for x in values) / (n * std**4) - 3
        else:
            skew = kurt = 0

        return {
            "count": n, "sum": round(total, 4), "mean": round(mean, 4),
            "median": round(median, 4), "std": round(std, 4), "variance": round(variance, 4),
            "min": round(sorted_vals[0], 4), "max": round(sorted_vals[-1], 4),
            "range": round(sorted_vals[-1] - sorted_vals[0], 4),
            "p25": round(percentile(25), 4), "p75": round(percentile(75), 4),
            "p90": round(percentile(90), 4), "p99": round(percentile(99), 4),
            "skewness": round(skew, 4), "kurtosis": round(kurt, 4),
            "missing": 0,
        }

    # ── 聚合 ──

    @staticmethod
    def aggregate(data: List[Dict], group_by: str, agg_field: str,
                  agg_type: str = "sum") -> Dict[str, Any]:
        """分组聚合"""
        groups: Dict[str, List[float]] = defaultdict(list)
        for row in data:
            key = str(row.get(group_by, ""))
            val = row.get(agg_field)
            if val is not None:
                try:
                    groups[key].append(float(val))
                except (ValueError, TypeError):
                    pass

        result = {}
        for key, values in groups.items():
            if agg_type == "sum":
                result[key] = round(sum(values), 4)
            elif agg_type == "avg":
                result[key] = round(sum(values)/len(values), 4) if values else 0
            elif agg_type == "count":
                result[key] = len(values)
            elif agg_type == "min":
                result[key] = round(min(values), 4) if values else 0
            elif agg_type == "max":
                result[key] = round(max(values), 4) if values else 0
            elif agg_type == "median":
                s = sorted(values)
                n = len(s)
                result[key] = round((s[n//2-1]+s[n//2])/2 if n%2==0 else s[n//2], 4)
            elif agg_type == "stddev":
                m = sum(values)/len(values) if values else 0
                result[key] = round(math.sqrt(sum((x-m)**2 for x in values)/(len(values)-1)), 4) if len(values)>1 else 0
            elif agg_type == "histogram":
                counts = defaultdict(int)
                for v in values:
                    counts[round(v, 1)] += 1
                result[key] = dict(sorted(counts.items()))

        return {"group_by": group_by, "agg_field": agg_field, "agg_type": agg_type,
                "groups": len(groups), "result": result}

    # ── 数据清洗 ──

    @staticmethod
    def clean(data: List[Dict], actions: Optional[Dict] = None) -> Dict[str, Any]:
        """数据清洗"""
        actions = actions or {}
        cleaned = []
        stats = {"original": len(data), "removed_duplicates": 0,
        "filled_nulls": 0, "converted_types": 0, "filtered_outliers": 0}

        # 去重
        if actions.get("remove_duplicates"):
            seen = set()
            unique = []
            for row in data:
                key = json.dumps(row, sort_keys=True, default=str)
                if key not in seen:
                    seen.add(key)
                    unique.append(row)
            stats["removed_duplicates"] = len(data) - len(unique)
            data = unique

        # 空值填充
        fill_value = actions.get("fill_nulls")
        if fill_value is not None:
            for row in data:
                for k, v in row.items():
                    if v is None or v == "" or v == "NULL":
                        row[k] = fill_value
                        stats["filled_nulls"] += 1

        # 类型转换
        type_map = actions.get("convert_types", {})
        if type_map:
            for row in data:
                for col, dtype in type_map.items():
                    if col in row and row[col] is not None:
                        try:
                            if dtype == "int":
                                row[col] = int(float(row[col]))
                            elif dtype == "float":
                                row[col] = float(row[col])
                            elif dtype == "str":
                                row[col] = str(row[col])
                            stats["converted_types"] += 1
                        except (ValueError, TypeError):
                            pass

        # 异常值过滤
        if actions.get("filter_outliers"):
            numeric_cols = [k for k in data[0] if isinstance(data[0].get(k), (int, float))] if data else []
            for col in numeric_cols:
                values = [row[col] for row in data if isinstance(row.get(col), (int, float))]
                if len(values) < 4:
                    continue
                mean = sum(values) / len(values)
                std = math.sqrt(sum((x-mean)**2 for x in values) / len(values))
                threshold = mean + 3 * std
                before = len(data)
                data = [row for row in data if not isinstance(row.get(col), (int, float)) or abs(row[col]-mean) <= 3*std]
                stats["filtered_outliers"] += before - len(data)

        return {"cleaned_count": len(data), "stats": stats, "data": data}

    # ── 趋势分析 ──

    @staticmethod
    def trend(values: List[float], window: int = 5) -> Dict[str, Any]:
        """趋势分析"""
        if len(values) < 2:
            return {"error": "数据不足"}

        # 移动平均
        ma = []
        for i in range(len(values)):
            start = max(0, i - window + 1)
            ma.append(round(sum(values[start:i+1]) / (i - start + 1), 4))

        # 增长率
        growth_rates = []
        for i in range(1, len(values)):
            if values[i-1] != 0:
                growth_rates.append(round((values[i] - values[i-1]) / abs(values[i-1]) * 100, 2))
            else:
                growth_rates.append(0)

        # 线性回归趋势
        n = len(values)
        x_mean = (n - 1) / 2
        y_mean = sum(values) / n
        if n > 1:
            numerator = sum((i - x_mean) * (values[i] - y_mean) for i in range(n))
            denominator = sum((i - x_mean) ** 2 for i in range(n))
            slope = numerator / denominator if denominator != 0 else 0
        else:
            slope = 0

        # 整体方向
        if slope > 0.01 * (max(values) - min(values) + 1):
            direction = "upward"
        elif slope < -0.01 * (max(values) - min(values) + 1):
            direction = "downward"
        else:
            direction = "stable"

        return {
            "moving_avg": ma[-10:],
            "avg_growth_rate": round(sum(growth_rates)/len(growth_rates), 2) if growth_rates else 0,
            "slope": round(slope, 6),
            "direction": direction,
            "first": round(values[0], 4),
            "last": round(values[-1], 4),
            "change_pct": round((values[-1]-values[0])/abs(values[0])*100, 2) if values[0]!=0 else 0,
        }

    # ── 异常检测 ──

    @staticmethod
    def detect_anomalies(values: List[float], method: str = "zscore",
                         threshold: float = 3.0) -> Dict[str, Any]:
        """异常值检测"""
        if len(values) < 4:
            return {"anomalies": [], "method": method, "total_anomalies": 0}

        anomalies = []

        if method == "zscore":
            mean = sum(values) / len(values)
            std = math.sqrt(sum((x-mean)**2 for x in values) / len(values))
            if std == 0:
                return {"anomalies": [], "method": method, "total_anomalies": 0}
            for i, v in enumerate(values):
                z = abs(v - mean) / std
                if z > threshold:
                    anomalies.append({"index": i, "value": v, "z_score": round(z, 4),
                                      "type": "high" if v > mean else "low"})

        elif method == "iqr":
            s = sorted(values)
            n = len(s)
            q1 = s[n//4]
            q3 = s[3*n//4]
            iqr = q3 - q1
            lower = q1 - 1.5 * iqr
            upper = q3 + 1.5 * iqr
            for i, v in enumerate(values):
                if v < lower or v > upper:
                    anomalies.append({"index": i, "value": v, "bounds": [round(lower,4), round(upper,4)],
                                      "type": "low" if v < lower else "high"})

        elif method == "threshold":
            t_low = values[0] if isinstance(values[0], (list, tuple)) else threshold * -1
            t_high = threshold
            for i, v in enumerate(values):
                if v < t_low or v > t_high:
                    anomalies.append({"index": i, "value": v, "type": "low" if v < t_low else "high"})

        return {"anomalies": anomalies, "method": method, "threshold": threshold,
                "total_anomalies": len(anomalies), "anomaly_rate": round(len(anomalies)/len(values)*100, 2)}


class DataAnalysis(CircuitBreakerMixin, RateLimiterMixin, EnterpriseModule):
    """数据分析引擎"""

    MODULE_ID = "data-analysis"
    MODULE_NAME = "数据分析引擎"
    VERSION = "v7.0"
    MODULE_LEVEL = "A"

    def __init__(self, config: Optional[Dict[str, Any]] = None):

        super().__init__(config)
        self._metrics = _MetricsAdapter()
        self._circuits = {}
        self._buckets = {}
        self._windows = {}
        self.analyzer = DataAnalyzer()
        self._reports: List[Dict] = []

    def initialize(self) -> None:
        self.info("初始化数据分析引擎...")
        self.record_metrics("data-analysis.init", 1)
        self.audit("initialized", "DataAnalysis初始化完成")
        self._setup_rate_limit(rate=100, burst=200)
        self.status = ModuleStatus.RUNNING
        self.stats.start_time = datetime.now()
        self.info("数据分析引擎就绪")

    async def execute(self, action: str, params: Optional[Dict] = None) -> Result:
        metrics_collector.counter("data_analysis_ops_total", labels={"action": action})
        _ = self.trace("execute")
        params = params or {}
        return self._safe_execute(action, params, self._dispatch)



    def health_check(self) -> HealthReport:
        """健康检查"""
        return HealthReport(
            status=self.status.value,
            healthy=self.status in (ModuleStatus.RUNNING, ModuleStatus.DEGRADED),
            last_beat=self._now(),
            uptime_seconds=self._uptime(),
            checks_run=self.stats.request_count,
            error_rate=self.stats.error_rate,
            details={"module": "data-analysis"},
        )

    async def shutdown(self) -> None:
        self.status = ModuleStatus.STOPPED

    def _dispatch(self, params: Dict[str, Any]) -> Any:
        action = params.get("action", "")
        handlers = {
            "describe": self._do_describe,
            "aggregate": self._do_aggregate,
            "clean": self._do_clean,
            "trend": self._do_trend,
            "detect_anomalies": self._do_anomalies,
            "full_report": self._do_full_report,
            "top_n": self._do_top_n,
            "correlation": self._do_correlation,
            "compare": self._do_compare,
            "get_reports": lambda p: {"reports": self._reports[-20:]},
        }
        handler = handlers.get(action)
        if not handler:
            return {"error": f"未知动作: {action}", "available": list(handlers.keys())}
        return handler(params)

    def _do_describe(self, params: Dict) -> Dict:
        data = params.get("data", [])
        column = params.get("column", "")
        if not data:
            return {"error": "缺少data参数"}
        if column:
            values = [row.get(column) for row in data if row.get(column) is not None]
            values = [float(v) for v in values if isinstance(v, (int, float, str)) and str(v).replace(".","").isdigit()]
            return {"column": column, **self.analyzer.describe(values)}
        # 全列统计
        result = {"record_count": len(data)}
        for col in data[0] if data else []:
            vals = [float(row[col]) for row in data if isinstance(row.get(col), (int, float))]
            if vals:
                result[col] = self.analyzer.describe(vals)
        return result

    def _do_aggregate(self, params: Dict) -> Dict:
        return self.analyzer.aggregate(
            params.get("data", []),
            params.get("group_by", ""),
            params.get("agg_field", ""),
            params.get("agg_type", "sum"),
        )

    def _do_clean(self, params: Dict) -> Dict:
        return self.analyzer.clean(params.get("data", []), params.get("actions", {}))

    def _do_trend(self, params: Dict) -> Dict:
        values = params.get("values", [])
        window = params.get("window", 5)
        if not values:
            return {"error": "缺少values参数"}
        values = [float(v) for v in values if isinstance(v, (int, float))]
        return self.analyzer.trend(values, window)

    def _do_anomalies(self, params: Dict) -> Dict:
        values = params.get("values", [])
        method = params.get("method", "zscore")
        threshold = params.get("threshold", 3.0)
        if not values:
            return {"error": "缺少values参数"}
        values = [float(v) for v in values if isinstance(v, (int, float))]
        return self.analyzer.detect_anomalies(values, method, threshold)

    def _do_full_report(self, params: Dict) -> Dict:
        data = params.get("data", [])
        title = params.get("title", "数据分析报告")
        if not data:
            return {"error": "缺少data参数"}
        start = time.time()
        report = AnalysisReport(title=title, data_source=params.get("source", "upload"),
        record_count=len(data))
        # 列统计
        numeric_cols = [k for k in data[0] if isinstance(data[0].get(k), (int, float))] if data else []
        for col in numeric_cols:
            vals = [row[col] for row in data if isinstance(row.get(col), (int, float))]
            if vals:
                report.columns_stats[col] = self.analyzer.describe(vals)
        # 异常检测
        for col in numeric_cols:
            vals = [row[col] for row in data if isinstance(row.get(col), (int, float))]
            if len(vals) >= 4:
                anom = self.analyzer.detect_anomalies(vals)
                if anom["total_anomalies"] > 0:
                    for a in anom["anomalies"]:
                        a["column"] = col
                    report.anomalies.extend(anom["anomalies"])
        # 趋势（取第一个数值列）
        if numeric_cols:
            vals = [row[numeric_cols[0]] for row in data if isinstance(row.get(numeric_cols[0]), (int, float))]
            if len(vals) >= 2:
                report.trends.append({"column": numeric_cols[0], **self.analyzer.trend(vals)})
        # 建议
        if report.anomalies:
            report.recommendations.append(f"发现 {len(report.anomalies)} 个异常值，建议审查")
        report.summary = {"records": len(data), "columns": len(data[0]) if data else 0,
        "numeric_columns": len(numeric_cols), "anomalies": len(report.anomalies)}
        report.latency_ms = (time.time() - start) * 1000
        result = report.to_dict()
        self._reports.append(result)
        return result

    def _do_top_n(self, params: Dict) -> Dict:
        data = params.get("data", [])
        column = params.get("column", "")
        n = params.get("n", 10)
        ascending = params.get("ascending", False)
        if not data or not column:
            return {"error": "缺少data或column参数"}
        sorted_data = sorted(data, key=lambda x: x.get(column, 0) or 0, reverse=not ascending)
        return {"top_n": sorted_data[:n], "column": column, "n": n}

    def _do_correlation(self, params: Dict) -> Dict:
        """计算两列相关系数"""
        data = params.get("data", [])
        col_a = params.get("col_a", "")
        col_b = params.get("col_b", "")
        if not data or not col_a or not col_b:
            return {"error": "缺少参数"}
        pairs = [(float(row[col_a]), float(row[col_b]))
                 for row in data
                 if isinstance(row.get(col_a), (int, float)) and isinstance(row.get(col_b), (int, float))]
        if len(pairs) < 2:
            return {"error": "有效数据不足"}
        n = len(pairs)
        a = [p[0] for p in pairs]
        b = [p[1] for p in pairs]
        mean_a = sum(a)/n
        mean_b = sum(b)/n
        cov = sum((a[i]-mean_a)*(b[i]-mean_b) for i in range(n)) / n
        std_a = math.sqrt(sum((x-mean_a)**2 for x in a) / n)
        std_b = math.sqrt(sum((x-mean_b)**2 for x in b) / n)
        corr = cov / (std_a * std_b) if std_a * std_b > 0 else 0
        strength = "强正" if corr > 0.7 else "中等正" if corr > 0.3 else "弱" if abs(corr) <= 0.3 else "中等负" if corr > -0.7 else "强负"
        return {"col_a": col_a, "col_b": col_b, "correlation": round(corr, 4),
                "strength": strength, "pairs": n}

    def _do_compare(self, params: Dict) -> Dict:
        """比较两个数据集"""
        data_a = params.get("data_a", [])
        data_b = params.get("data_b", [])
        column = params.get("column", "")
        if not data_a or not data_b or not column:
            return {"error": "缺少参数"}
        vals_a = [float(row[column]) for row in data_a if isinstance(row.get(column), (int, float))]
        vals_b = [float(row[column]) for row in data_b if isinstance(row.get(column), (int, float))]
        if not vals_a or not vals_b:
            return {"error": "无有效数值数据"}
        desc_a = self.analyzer.describe(vals_a)
        desc_b = self.analyzer.describe(vals_b)
        return {
            "column": column,
            "dataset_a": {"count": desc_a["count"], "mean": desc_a["mean"], "std": desc_a["std"]},
            "dataset_b": {"count": desc_b["count"], "mean": desc_b["mean"], "std": desc_b["std"]},
            "mean_diff": round(desc_a["mean"] - desc_b["mean"], 4),
            "mean_diff_pct": round(abs(desc_a["mean"]-desc_b["mean"])/max(abs(desc_b["mean"]),0.001)*100, 2),
        }



    # ── 标准Action处理器（自动注入）──

    def _do_get_status(self, params):
        """标准action: 模块状态"""
        try:
            status = self.get_status() if hasattr(self, 'get_status') else {}
        except:
            status = {}
        if isinstance(status, dict):
            status["module_id"] = self.module_id
            status["version"] = getattr(self, 'version', '')
            status["actions"] = [k for k in dir(self) if k.startswith('_do_') and callable(getattr(self, k))]
        return status


    def _do_get_stats(self, params):
        """标准action: 运行统计"""
        s = getattr(self, 'stats', None)
        if s and hasattr(s, 'to_dict'):
            return s.to_dict()
        return {"message": "no stats available"}


    def _do_list_actions(self, params):
        """标准action: 列出可用操作"""
        actions = [k for k in dir(self) if k.startswith('_do_') and callable(getattr(self, k))]
        # Clean up method names
        clean = [a.replace('_do_', '').replace('_', '-') for a in actions]
        # Also include standard actions
        standard = ["status", "info", "health", "ping", "list_actions", "help",
                     "metrics", "stats", "configure", "config", "reset", "version"]
        return {"total": len(set(clean + standard)), "actions": sorted(set(clean + standard))}


    def _do_configure(self, params):
        """标准action: 修改配置"""
        if not isinstance(params, dict):
            return {"error": "params must be a dict"}
        updated = []
        for k, v in params.items():
            if k in ("action",):
                continue
            if hasattr(self, 'config'):
                self.config[k] = v
                updated.append(k)
        return {"success": True, "updated": updated}


    def _do_version(self, params):
        """标准action: 版本信息"""
        return {
            "module_id": self.module_id,
            "version": getattr(self, 'version', 'unknown'),
            "class": self.__class__.__name__,
        }


    def _do_reset(self, params):
        """标准action: 重置"""
        if hasattr(self, 'stats'):
            self.stats.request_count = 0
            self.stats.error_count = 0
            self.stats.success_count = 0
            self.stats.latencies = []
        return {"success": True, "message": "reset done"}

module_class = DataAnalysis
