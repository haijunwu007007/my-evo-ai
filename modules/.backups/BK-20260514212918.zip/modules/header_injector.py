"""
        HTTP头部注入器模块 - Header Injection Service
生产级实现：请求/响应头管理、安全策略(CSP/HSTS)、CORS配置、头部分析、注入规则引擎
"""
import logging
import time
import re
import hashlib
from typing import Dict, List, Optional, Any, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum
from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector
logger = logging.getLogger(__name__)


class HeaderDirection(Enum):
    REQUEST = "request"
    RESPONSE = "response"
    BOTH = "both"


class SecurityLevel(Enum):
    NONE = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    STRICT = 4


class ActionType(Enum):
    ADD = "add"
    REMOVE = "remove"
    MODIFY = "modify"
    OVERWRITE = "overwrite"


@dataclass
class HeaderRule:
    rule_id: str
    name: str
    header_name: str
    action: ActionType
    value: str = ""
    pattern: str = ""
    direction: HeaderDirection = HeaderDirection.BOTH
    priority: int = 0
    enabled: bool = True
    conditions: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)

    def matches_path(self, path: str) -> bool:
        if not self.conditions.get("path_pattern"):
            return True
        return bool(re.match(self.conditions["path_pattern"], path))

    def matches_domain(self, domain: str) -> bool:
        allowed = self.conditions.get("domains", [])
        if not allowed:
            return True
        return domain in allowed or any(domain.endswith(f".{d}") for d in allowed)

    def to_dict(self) -> Dict[str, Any]:
        return {"rule_id": self.rule_id, "name": self.name,
                "header": self.header_name, "action": self.action.value,
                "value": self.value[:100], "direction": self.direction.value,
                "priority": self.priority, "enabled": self.enabled}


@dataclass
class InjectionResult:
    headers_before: Dict[str, str]
    headers_after: Dict[str, str]
    rules_applied: List[str]
    changes: List[Dict[str, Any]]
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {"changes": len(self.changes), "rules_applied": self.rules_applied,
                "added": [c for c in self.changes if c["action"] == "add"],
                "removed": [c for c in self.changes if c["action"] == "remove"],
                "modified": [c for c in self.changes if c["action"] == "modify"]}


class SecurityHeaderManager(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """安全头部管理"""

    VERSION = "1.0.0"
    MODULE_NAME = "security_header_manager"
    MODULE_ID = "security_header_manager"

    PRESETS = {
        SecurityLevel.NONE: {},
        SecurityLevel.LOW: {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "SAMEORIGIN",
        },
        SecurityLevel.MEDIUM: {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "X-XSS-Protection": "1; mode=block",
            "Referrer-Policy": "strict-origin-when-cross-origin",
        },
        SecurityLevel.HIGH: {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "X-XSS-Protection": "1; mode=block",
            "Referrer-Policy": "strict-origin-when-cross-origin",
            "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'",
            "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
        },
        SecurityLevel.STRICT: {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "X-XSS-Protection": "1; mode=block",
            "Referrer-Policy": "no-referrer",
            "Content-Security-Policy": "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'",
            "Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=()",
            "Strict-Transport-Security": "max-age=31536000; includeSubDomains; preload",
            "Cross-Origin-Opener-Policy": "same-origin",
            "Cross-Origin-Resource-Policy": "same-origin",
        },
    }

    def __init__(self):
        super().__init__()
        CircuitBreakerMixin.__init__(self)
        self._level = SecurityLevel.MEDIUM
        self._overrides: Dict[str, str] = {}
        self._excluded: Set[str] = set()

class CorsConfig:
    """CORS配置管理"""

    def __init__(self):
        self._allowed_origins: Set[str] = set()
        self._allowed_methods: Set[str] = {"GET", "POST", "OPTIONS"}
        self._allowed_headers: Set[str] = {"Content-Type", "Authorization"}
        self._exposed_headers: Set[str] = set()
        self._allow_credentials = False
        self._max_age = 3600
        self._preflight_enabled = True

    def configure(self, allowed_origins: List[str] = None,
                  allowed_methods: List[str] = None,
                  allowed_headers: List[str] = None,
                  allow_credentials: bool = None,
                  max_age: int = None) -> Dict[str, Any]:
        if allowed_origins is not None:
            self._allowed_origins = set(allowed_origins)
        if allowed_methods is not None:
            self._allowed_methods = set(allowed_methods)
        if allowed_headers is not None:
            self._allowed_headers = set(allowed_headers)
        if allow_credentials is not None:
            self._allow_credentials = allow_credentials
        if max_age is not None:
            self._max_age = max_age
        return self.get_config()

    def is_origin_allowed(self, origin: str) -> bool:
        if "*" in self._allowed_origins:
            return True
        return origin in self._allowed_origins

    def get_preflight_headers(self, origin: str) -> Dict[str, str]:
        if not self.is_origin_allowed(origin):
            return {}
        headers = {
            "Access-Control-Allow-Origin": origin if not self._allow_credentials else origin,
            "Access-Control-Allow-Methods": ", ".join(sorted(self._allowed_methods)),
            "Access-Control-Allow-Headers": ", ".join(sorted(self._allowed_headers)),
            "Access-Control-Max-Age": str(self._max_age),
        }
        if self._allow_credentials:
            headers["Access-Control-Allow-Credentials"] = "true"
        return headers

    def get_response_headers(self, origin: str) -> Dict[str, str]:
        if not self.is_origin_allowed(origin):
            return {}
        headers = {"Access-Control-Allow-Origin": origin}
        if self._allow_credentials:
            headers["Access-Control-Allow-Credentials"] = "true"
        if self._exposed_headers:
            headers["Access-Control-Expose-Headers"] = ", ".join(sorted(self._exposed_headers))
        return headers

    def get_config(self) -> Dict[str, Any]:
        return {
            "allowed_origins": sorted(self._allowed_origins),
            "allowed_methods": sorted(self._allowed_methods),
            "allowed_headers": sorted(self._allowed_headers),
            "exposed_headers": sorted(self._exposed_headers),
            "allow_credentials": self._allow_credentials,
            "max_age": self._max_age,
            "preflight_enabled": self._preflight_enabled
        }


class HeaderInjector:
    """HTTP头部注入器 - 生产级实现"""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._rules: Dict[str, HeaderRule] = {}
        self._security = SecurityHeaderManager()
        self._cors = CorsConfig()
        self._initialized = False
        self._stats = {
            "rules_created": 0, "injections_performed": 0,
            "headers_added": 0, "headers_removed": 0, "headers_modified": 0,
            "requests_processed": 0, "security_level": SecurityLevel.MEDIUM.name
        }
        self._injection_log: List[Dict[str, Any]] = []
        self._max_log = self.config.get("max_log", 5000)
        self._init_defaults()

    def _init_defaults(self):
        defaults = [
            {"rid": "remove_x_powered_by", "name": "Remove X-Powered-By", "header": "X-Powered-By",
             "action": ActionType.REMOVE, "direction": HeaderDirection.RESPONSE},
            {"rid": "add_x_request_id", "name": "Add X-Request-ID", "header": "X-Request-ID",
             "action": ActionType.ADD, "direction": HeaderDirection.BOTH},
            {"rid": "add_server", "name": "Set Server Header", "header": "Server",
             "action": ActionType.OVERWRITE, "value": "AutoEvo/1.0",
             "direction": HeaderDirection.RESPONSE},
            {"rid": "remove_server_info", "name": "Remove Server Version", "header": "Server",
             "action": ActionType.MODIFY, "pattern": r"v[\d.]+",
             "direction": HeaderDirection.RESPONSE},
        ]
        for d in defaults:
            self._rules[d["rid"]] = HeaderRule(
                rule_id=d["rid"], name=d["name"], header_name=d["header"],
                action=d["action"], direction=d.get("direction", HeaderDirection.BOTH),
                value=d.get("value", ""),
                pattern=d.get("pattern", ""),
                priority=d.get("priority", 0)
            )

    def initialize(self) -> None:
        self.trace("header_injector.initialize", "start")
        self.audit("初始化header_injector", level="info")
        self.trace("header_injector.initialize", "end")
        if self._initialized:
            return
        self._init_defaults()
        cors_cfg = self.config.get("cors", {})
        if cors_cfg:
            self._cors.configure(
                allowed_origins=cors_cfg.get("allowed_origins"),
                allowed_methods=cors_cfg.get("allowed_methods"),
                allowed_headers=cors_cfg.get("allowed_headers"),
                allow_credentials=cors_cfg.get("allow_credentials"),
                max_age=cors_cfg.get("max_age")
            )
        self._initialized = True
        logger.info("HeaderInjector initialized")

    def add_rule(self, rule_id: str, name: str, header: str, action: str,
                 value: str = "", direction: str = "both",
                 priority: int = 0, conditions: Dict = None) -> Dict[str, Any]:
        rule = HeaderRule(
            rule_id=rule_id, name=name, header_name=header,
            action=ActionType(action), value=value,
            direction=HeaderDirection(direction), priority=priority,
            conditions=conditions or {}
        )
        self._rules[rule_id] = rule
        self._stats["rules_created"] += 1
        return {"success": True, "rule_id": rule_id}

    def remove_rule(self, rule_id: str) -> Dict[str, Any]:
        if rule_id in self._rules:
            del self._rules[rule_id]
            return {"success": True}
        return {"success": False, "error": "Rule not found"}

    def inject(self, headers: Dict[str, str], direction: str = "response",
               path: str = "/", origin: str = "") -> Dict[str, Any]:
        self._stats["requests_processed"] += 1
        result_headers = dict(headers)
        rules_applied = []
        changes = []
        applicable = sorted(
            [r for r in self._rules.values()
             if r.enabled and (r.direction.value == direction or r.direction == HeaderDirection.BOTH)
             and r.matches_path(path) and r.matches_domain(origin)],
            key=lambda r: r.priority, reverse=True
        )
        for rule in applicable:
            if rule.action == ActionType.ADD:
                if rule.header_name not in result_headers:
                    result_headers[rule.header_name] = rule.value
                    changes.append({"header": rule.header_name, "action": "add", "value": rule.value})
                    self._stats["headers_added"] += 1
            elif rule.action == ActionType.REMOVE:
                if rule.header_name in result_headers:
                    del result_headers[rule.header_name]
                    changes.append({"header": rule.header_name, "action": "remove"})
                    self._stats["headers_removed"] += 1
            elif rule.action == ActionType.MODIFY:
                if rule.header_name in result_headers and rule.pattern:
                    result_headers[rule.header_name] = re.sub(
                        rule.pattern, rule.value if rule.value else "", result_headers[rule.header_name])
                    changes.append({"header": rule.header_name, "action": "modify"})
                    self._stats["headers_modified"] += 1
            elif rule.action == ActionType.OVERWRITE:
                result_headers[rule.header_name] = rule.value
                changes.append({"header": rule.header_name, "action": "overwrite",
                                "value": rule.value})
                self._stats["headers_added"] += 1
            rules_applied.append(rule.rule_id)
        if direction == "response":
            sec_headers = self._security.get_headers()
            for k, v in sec_headers.items():
                if k not in result_headers:
                    result_headers[k] = v
                    changes.append({"header": k, "action": "add", "value": v, "source": "security_preset"})
            if origin:
                cors_headers = self._cors.get_response_headers(origin)
                result_headers.update(cors_headers)
        self._stats["injections_performed"] += 1
        self._log_injection(headers, result_headers, rules_applied, changes)
        return {"success": True, **InjectionResult(
            headers_before=headers, headers_after=result_headers,
            rules_applied=rules_applied, changes=changes).to_dict(),
            "final_headers": {k: v for k, v in sorted(result_headers.items())}}

    def _log_injection(self, before: Dict, after: Dict, rules: List[str], changes: List[Dict]):
        entry = {"rules_applied": rules, "changes_count": len(changes),
                 "timestamp": time.time()}
        self._injection_log.append(entry)
        if len(self._injection_log) > self._max_log:
            self._injection_log = self._injection_log[-self._max_log:]

    def set_security_level(self, level: str) -> Dict[str, Any]:
        lvl = SecurityLevel[level.upper()]
        result = self._security.set_level(lvl)
        self._stats["security_level"] = lvl.name
        return result

    def configure_cors(self, **kwargs) -> Dict[str, Any]:
        return self._cors.configure(**kwargs)

    def analyze_security(self, headers: Dict[str, str]) -> Dict[str, Any]:
        findings = []
        score = 100
        if "X-Content-Type-Options" not in headers:
            findings.append({"severity": "medium", "header": "X-Content-Type-Options",
                             "issue": "Missing", "fix": "Add 'nosniff'"})
            score -= 10
        if "X-Frame-Options" not in headers:
            findings.append({"severity": "medium", "header": "X-Frame-Options",
                             "issue": "Missing", "fix": "Add 'DENY' or 'SAMEORIGIN'"})
            score -= 10
        if "Strict-Transport-Security" not in headers:
            findings.append({"severity": "low", "header": "Strict-Transport-Security",
                             "issue": "Missing", "fix": "Add HSTS header"})
            score -= 5
        if "Content-Security-Policy" in headers:
            csp_analysis = self._security.analyze_csp(headers["Content-Security-Policy"])
            for risk in csp_analysis["risky_patterns"]:
                findings.append({"severity": "high", "header": "Content-Security-Policy",
                                 "issue": f"Risky pattern: {risk}", "fix": "Review CSP directives"})
                score -= 15
        if "X-Powered-By" in headers:
            findings.append({"severity": "low", "header": "X-Powered-By",
                             "issue": "Technology disclosure", "fix": "Remove this header"})
            score -= 5
        if "Server" in headers and re.search(r"v[\d.]+", headers["Server"]):
            findings.append({"severity": "low", "header": "Server",
                             "issue": "Version disclosure", "fix": "Remove version from Server header"})
            score -= 5
        return {"score": max(0, score), "findings": findings,
                "total_issues": len(findings),
                "critical": sum(1 for f in findings if f["severity"] == "critical"),
                "high": sum(1 for f in findings if f["severity"] == "high"),
                "medium": sum(1 for f in findings if f["severity"] == "medium"),
                "low": sum(1 for f in findings if f["severity"] == "low")}

    def get_stats(self) -> Dict[str, Any]:
        return {**self._stats, "rules": len(self._rules),
                "security_level": self._stats["security_level"],
                "cors_configured": len(self._cors._allowed_origins) > 0,
                "log_size": len(self._injection_log)}

    def execute(self, action: 

            str, **kwargs) -> Dict[str, Any]:
        if action == "add_rule":

        # Delegate standard actions to base class
            return self.add_rule(kwargs["rule_id"], kwargs["name"], kwargs["header"],
                                  kwargs["action"], kwargs.get("value", ""),
                                  kwargs.get("direction", "both"),
                                  kwargs.get("priority", 0), kwargs.get("conditions"))
        elif action == "remove_rule":
            return self.remove_rule(kwargs["rule_id"])
        elif action == "inject":
            return self.inject(kwargs.get("headers", {}),
                                kwargs.get("direction", "response"),
                                kwargs.get("path", "/"),
                                kwargs.get("origin", ""))
        elif action == "security_level":
            return self.set_security_level(kwargs.get("level", "MEDIUM"))
        elif action == "configure_cors":
            return self.configure_cors(**kwargs)
        elif action == "analyze":
            return self.analyze_security(kwargs.get("headers", {}))
        elif action == "stats":
            return self.get_stats()
        else:
            return {"success": False, "error": f"Unknown action: {action}"}

    def health_check(self) -> Dict[str, Any]:
        return {
            "healthy": True,
            "status": "running",
            "metrics": self.get_stats(),
            "checks": [
                ("initialized", self._initialized),
                ("rules_loaded", len(self._rules) > 0),
                ("security_manager_ok", True),
                ("cors_configured", True),
            ]
        }

    def shutdown(self) -> None:
        self._rules.clear()
        self._injection_log.clear()
        self._initialized = False
        logger.info("HeaderInjector shutdown complete")

module_class = HeaderInjector
