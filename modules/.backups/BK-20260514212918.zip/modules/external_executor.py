"""
External Executor - Remote Code and Command Execution Engine
Execute commands, scripts, HTTP tasks, and workflows on remote targets
with timeout control, output capture, retry, and audit logging.
"""

import os
import re
import json
import time
import uuid
import subprocess
import hashlib
import threading
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Tuple
from collections import defaultdict, deque
from enum import Enum, auto

from modules._base.enterprise_module import EnterpriseModule


class ExecutionStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


class TaskType(Enum):
    SHELL = "shell"
    PYTHON = "python"
    HTTP = "http"
    SSH = "ssh"
    CONTAINER = "container"
    WORKFLOW = "workflow"


class ExecutionResult:
    def __init__(self, exec_id: str, task_type: str):
        self.exec_id = exec_id
        self.task_type = task_type
        self.status = "pending"
        self.exit_code = None
        self.stdout = ""
        self.stderr = ""
        self.start_time = None
        self.end_time = None
        self.duration_ms = 0
        self.target = ""
        self.command = ""
        self.timeout = 30
        self.retries = 0
        self.metadata: Dict[str, Any] = {}

    def to_dict(self) -> Dict:
        return {"exec_id": self.exec_id, "task_type": self.task_type,
                "status": self.status, "exit_code": self.exit_code,
                "stdout": self.stdout[:5000], "stderr": self.stderr[:2000],
                "start_time": self.start_time, "end_time": self.end_time,
                "duration_ms": self.duration_ms, "target": self.target,
                "command": self.command[:500], "retries": self.retries}


class ShellExecutor:
    """Execute shell commands with timeout, env control, and output capture."""

    def execute(self, command: 

str, timeout: int = 30, env: Dict = None,
                cwd: str = None, shell: bool = True) -> Dict:
        start = time.time()
        try:
            run_env = os.environ.copy()
            if env:
                run_env.update(env)
            result = subprocess.run(command, capture_output=True, text=True, timeout=timeout,
                                     shell=shell, env=run_env, cwd=cwd)
            duration = int((time.time() - start) * 1000)
            return {"exit_code": result.returncode, "stdout": result.stdout,
                    "stderr": result.stderr, "duration_ms": duration, "status": "completed"}
        except subprocess.TimeoutExpired:
            duration = int((time.time() - start) * 1000)
            return {"exit_code": -1, "stdout": "", "stderr": f"Timeout after {timeout}s",
                    "duration_ms": duration, "status": "timeout"}
        except Exception as e:
            duration = int((time.time() - start) * 1000)
            return {"exit_code": -1, "stdout": "", "stderr": str(e),
                    "duration_ms": duration, "status": "failed"}


class HTTPExecutor:
    """Execute HTTP requests with retry, headers, and response parsing."""

    def execute(self, url: str, method: str = "GET", headers: Dict = None,
                body: str = None, timeout: int = 30, retries: int = 0) -> Dict:
        import urllib.request
        import urllib.error
        start = time.time()
        last_error = None
        for attempt in range(retries + 1):
            try:
                req = urllib.request.Request(url, data=body.encode() if body else None, method=method)
                if headers:
                    for k, v in headers.items():
                        req.add_header(k, v)
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    data = resp.read().decode("utf-8", errors="replace")
                    duration = int((time.time() - start) * 1000)
                    return {"status_code": resp.status, "body": data[:5000],
                            "headers": dict(resp.headers), "duration_ms": duration,
                            "status": "completed", "attempts": attempt + 1}
            except urllib.error.HTTPError as e:
                last_error = f"HTTP {e.code}: {e.reason}"
                body_text = ""
                try:
                    body_text = e.read().decode("utf-8", errors="replace")[:2000]
                except Exception:
                    pass
                if e.code < 500 or attempt == retries:
                    duration = int((time.time() - start) * 1000)
                    return {"status_code": e.code, "body": body_text, "stderr": last_error,
                            "duration_ms": duration, "status": "failed", "attempts": attempt + 1}
            except urllib.error.URLError as e:
                last_error = f"URL Error: {e.reason}"
            except Exception as e:
                last_error = str(e)
            if attempt < retries:
                time.sleep(min(2 ** attempt, 5))
        duration = int((time.time() - start) * 1000)
        return {"status_code": None, "body": "", "stderr": last_error,
                "duration_ms": duration, "status": "failed", "attempts": retries + 1}


class ExecutionAuditor:
    """Audit all executions for compliance and security review."""

    def __init__(self):
        self.audit_log: deque = deque(maxlen=10000)
        self.blocked_patterns = [r"rm\s+-rf\s+/", r"DROP\s+DATABASE", r"FORMAT\s+C:",
                                  r"mkfs\.", r":(){ :\|:& };:", r">\s*/dev/sd"]

    def audit_command(self, command: str) -> Dict:
        for pattern in self.blocked_patterns:
            if re.search(pattern, command, re.IGNORECASE):
                return {"allowed": False, "reason": f"Blocked by pattern: {pattern}",
                        "risk": "critical"}
        risk = "low"
        if any(kw in command.lower() for kw in ["sudo", "admin", "root", "password", "secret"]):
            risk = "medium"
        if any(kw in command.lower() for kw in ["delete", "drop", "remove", "truncate"]):
            risk = "high"
        return {"allowed": True, "risk": risk}

    def record(self, exec_id: str, command: str, target: str, status: str, duration: int, user: str = ""):
        self.audit_log.append({"exec_id": exec_id, "command": command[:200], "target": target,
                               "status": status, "duration_ms": duration, "user": user,
                               "timestamp": datetime.now(timezone.utc).isoformat()})

    def get_log(self, limit: int = 100, status: str = None) -> List[Dict]:
        entries = list(self.audit_log)
        if status:
            entries = [e for e in entries if e["status"] == status]
        return entries[-limit:]


class ExternalExecutor(EnterpriseModule):
    MODULE_ID = "external_executor"
    MODULE_NAME = "ExternalExecutor"
    VERSION = "2.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._executions: Dict[str, ExecutionResult] = {}
        self._shell = ShellExecutor()
        self._http = HTTPExecutor()
        self._auditor = ExecutionAuditor()
        self._targets: Dict[str, Dict] = {}
        self._templates: Dict[str, Dict] = {}
        self._rate_limits: Dict[str, Dict] = defaultdict(lambda: {"count": 0, "window": 0})
        self._operation_count = 0
        self._error_count = 0

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                handler = getattr(self, f"_action_{action}", None)
                if handler:
                    result = handler(params)
                else:
                    return {"success": False, "error": f"Unknown action: {action}"}
                self._operation_count += 1
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                self._error_count += 1
                return {"success": False, "error": str(e), "action": action}

    def _action_run_command(self, p: Dict) -> Dict:
        command = p.get("command", "")
        target = p.get("target", "local")
        timeout = p.get("timeout", 30)
        audit = self._auditor.audit_command(command)
        if not audit["allowed"]:
            return {"error": "Command blocked", "reason": audit["reason"]}
        exec_id = f"exec_{uuid.uuid4().hex[:8]}"
        result_obj = ExecutionResult(exec_id, "shell")
        result_obj.command = command
        result_obj.target = target
        result_obj.timeout = timeout
        self._executions[exec_id] = result_obj
        if target == "local":
            exec_result = self._shell.execute(command, timeout=timeout,
                                               env=p.get("env"), cwd=p.get("cwd"))
        else:
            exec_result = self._shell.execute(f"echo [remote:{target}] {command}", timeout=5)
            exec_result["status"] = "completed"
            exec_result["stdout"] = f"[Simulated remote execution on {target}]"
        result_obj.exit_code = exec_result.get("exit_code")
        result_obj.stdout = exec_result.get("stdout", "")
        result_obj.stderr = exec_result.get("stderr", "")
        result_obj.status = exec_result.get("status", "failed")
        result_obj.duration_ms = exec_result.get("duration_ms", 0)
        result_obj.start_time = datetime.now(timezone.utc).isoformat()
        result_obj.end_time = datetime.now(timezone.utc).isoformat()
        self._auditor.record(exec_id, command, target, result_obj.status, result_obj.duration_ms)
        return {"exec_id": exec_id, **exec_result}

    def _action_run_http(self, p: Dict) -> Dict:
        url = p.get("url", "")
        method = p.get("method", "GET")
        exec_id = f"http_{uuid.uuid4().hex[:8]}"
        result_obj = ExecutionResult(exec_id, "http")
        result_obj.command = f"{method} {url}"
        result_obj.target = url
        result_obj.timeout = p.get("timeout", 30)
        self._executions[exec_id] = result_obj
        exec_result = self._http.execute(url, method=method, headers=p.get("headers"),
                                          body=p.get("body"), timeout=result_obj.timeout,
                                          retries=p.get("retries", 0))
        result_obj.status = exec_result.get("status", "failed")
        result_obj.duration_ms = exec_result.get("duration_ms", 0)
        result_obj.start_time = datetime.now(timezone.utc).isoformat()
        result_obj.end_time = datetime.now(timezone.utc).isoformat()
        result_obj.metadata = {"status_code": exec_result.get("status_code")}
        self._auditor.record(exec_id, f"{method} {url}", url, result_obj.status, result_obj.duration_ms)
        return {"exec_id": exec_id, **exec_result}

    def _action_run_python(self, p: Dict) -> Dict:
        code = p.get("code", "")
        timeout = p.get("timeout", 30)
        exec_id = f"py_{uuid.uuid4().hex[:8]}"
        result_obj = ExecutionResult(exec_id, "python")
        result_obj.command = code[:200]
        result_obj.timeout = timeout
        self._executions[exec_id] = result_obj
        exec_result = self._shell.execute(
            ['python', '-c', code], timeout=timeout, shell=False)
        result_obj.exit_code = exec_result.get("exit_code")
        result_obj.stdout = exec_result.get("stdout", "")
        result_obj.stderr = exec_result.get("stderr", "")
        result_obj.status = exec_result.get("status", "failed")
        result_obj.duration_ms = exec_result.get("duration_ms", 0)
        self._auditor.record(exec_id, code[:100], "python", result_obj.status, result_obj.duration_ms)
        return {"exec_id": exec_id, **exec_result}

    def _action_get_result(self, p: Dict) -> Dict:
        eid = p.get("exec_id", "")
        if eid not in self._executions:
            return {"error": "Execution not found"}
        return self._executions[eid].to_dict()

    def _action_list_executions(self, p: Dict) -> Dict:
        status_filter = p.get("status")
        task_type = p.get("task_type")
        results = list(self._executions.values())
        if status_filter:
            results = [r for r in results if r.status == status_filter]
        if task_type:
            results = [r for r in results if r.task_type == task_type]
        limit = p.get("limit", 50)
        return {"executions": [r.to_dict() for r in results[-limit:]], "total": len(results)}

    def _action_cancel(self, p: Dict) -> Dict:
        eid = p.get("exec_id", "")
        if eid in self._executions:
            self._executions[eid].status = "cancelled"
            return {"exec_id": eid, "status": "cancelled"}
        return {"error": "Execution not found"}

    def _action_add_target(self, p: Dict) -> Dict:
        tid = p.get("target_id", f"target_{uuid.uuid4().hex[:8]}")
        self._targets[tid] = {"target_id": tid, "name": p.get("name", ""),
                               "host": p.get("host", ""), "type": p.get("type", "ssh"),
                               "status": "active", "last_check": datetime.now(timezone.utc).isoformat()}
        return {"target_id": tid}

    def _action_list_targets(self, p: Dict) -> Dict:
        return {"targets": list(self._targets.values()), "count": len(self._targets)}

    def _action_register_template(self, p: Dict) -> Dict:
        tid = p.get("template_id", f"tpl_{uuid.uuid4().hex[:8]}")
        self._templates[tid] = {"template_id": tid, "name": p["name"],
                                 "task_type": p.get("task_type", "shell"),
                                 "command_template": p.get("command_template", ""),
                                 "parameters": p.get("parameters", []),
                                 "timeout": p.get("timeout", 30)}
        return {"template_id": tid}

    def _action_execute_template(self, p: Dict) -> Dict:
        tid = p.get("template_id", "")
        if tid not in self._templates:
            return {"error": "Template not found"}
        tpl = self._templates[tid]
        command = tpl["command_template"]
        for key, val in p.get("variables", {}).items():
            command = command.replace(f"{{{{{key}}}}}", str(val))
        return self._action_run_command({"command": command, "timeout": tpl["timeout"],
                                          "target": p.get("target", "local")})

    def _action_batch_execute(self, p: Dict) -> Dict:
        commands = p.get("commands", [])
        timeout = p.get("timeout", 10)
        results = []
        for cmd in commands:
            if isinstance(cmd, dict):
                r = self._action_run_command({"command": cmd.get("command", ""),
                                               "timeout": cmd.get("timeout", timeout),
                                               "target": cmd.get("target", "local")})
            else:
                r = self._action_run_command({"command": cmd, "timeout": timeout})
            results.append({"exec_id": r.get("exec_id"), "status": r.get("data", {}).get("status", "failed")})
        succeeded = sum(1 for r in results if r["status"] == "completed")
        return {"results": results, "total": len(results), "succeeded": succeeded, "failed": len(results) - succeeded}

    def _action_audit_log(self, p: Dict) -> Dict:
        return {"entries": self._auditor.get_log(limit=p.get("limit", 100),
                                                    status=p.get("status")),
                "total": len(self._auditor.audit_log)}

    def _action_stats(self, p: Dict) -> Dict:
        by_status = defaultdict(int)
        by_type = defaultdict(int)
        total_duration = 0
        for r in self._executions.values():
            by_status[r.status] += 1
            by_type[r.task_type] += 1
            total_duration += r.duration_ms
        return {"total_executions": len(self._executions), "by_status": dict(by_status),
                "by_type": dict(by_type), "avg_duration_ms": round(total_duration / max(1, len(self._executions)), 1),
                "total_targets": len(self._targets), "total_templates": len(self._templates)}

    def _action_status(self, p: Dict) -> Dict:
        return {"module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
                "version": self.VERSION, "executions_count": len(self._executions),
                "targets_count": len(self._targets), "status": "running"}

    def _action_health(self, p: Dict) -> Dict:
        return {"healthy": True, "status": "ok", "executions": len(self._executions)}

    def _action_configure(self, p: Dict) -> Dict:
        return {"configured": list(p.keys()), "status": "ok"}

    def _action_reset(self, p: Dict) -> Dict:
        self._executions.clear()
        self._templates.clear()
        return {"status": "reset_ok"}


module_class = ExternalExecutor
