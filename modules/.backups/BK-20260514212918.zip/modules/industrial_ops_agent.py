"""
AUTO-EVO-AI v6.28 | Module m11
工业运维Agent - 工业设备监控、预测性维护、产线调度优化
集成: OPC-UA / Modbus / MQTT / SCADA / CMMS
"""

from __future__ import annotations

import json
import time
import logging
import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple
from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector
logger = logging.getLogger(__name__)

MODULE_ID = "m11_industrial_ops_agent"
MODULE_VERSION = "6.28.0"


class IndustrialOpsAgentAnalyzer(object):
    """industrial_ops_agent 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "industrial_ops_agent"
        self.version = "1.0.0"
        self._analyzer = IndustrialOpsAgentAnalyzer()
        self._history = []
        self._max_history = 10000
    
    def analyze(self, context: dict = None) -> dict:
        context = context or {}
        result = {"analyzer": "IndustrialOpsAgentAnalyzer", "timestamp": time.time(), "records": len(self._history), "summary": self._summary()}
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-5000:]
        return result
    
    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "industrial_ops_agent"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== industrial_ops_agent ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}

class DeviceStatus(Enum):
    """设备运行状态"""
    ONLINE = "online"
    OFFLINE = "offline"
    WARNING = "warning"
    FAULT = "fault"
    MAINTENANCE = "maintenance"


class MaintenanceType(Enum):
    """维护类型"""
    PREVENTIVE = "preventive"       # 预防性维护
    PREDICTIVE = "predictive"       # 预测性维护
    CORRECTIVE = "corrective"       # 纠正性维护
    EMERGENCY = "emergency"         # 紧急维护


class ProtocolType(Enum):
    """工业通信协议"""
    OPC_UA = "opc_ua"
    MODBUS_TCP = "modbus_tcp"
    MODBUS_RTU = "modbus_rtu"
    MQTT = "mqtt"
    HTTP_SCADA = "http_scada"


@dataclass
class DeviceMetric:
    """设备遥测指标"""
    device_id: str
    metric_name: str
    value: float
    unit: str
    timestamp: float = field(default_factory=time.time)
    quality: str = "good"  # good / uncertain / bad

    def to_dict(self) -> Dict[str, Any]:
        return {
            "device_id": self.device_id,
            "metric_name": self.metric_name,
            "value": self.value,
            "unit": self.unit,
            "timestamp": self.timestamp,
            "quality": self.quality,
        }


@dataclass
class MaintenanceTask:
    """维护任务"""
    task_id: str
    device_id: str
    maintenance_type: MaintenanceType
    description: str
    priority: int = 1  # 1-5
    scheduled_at: Optional[float] = None
    estimated_duration_hours: float = 2.0
    assigned_to: str = ""
    status: str = "pending"  # pending / in_progress / completed / cancelled
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "device_id": self.device_id,
            "maintenance_type": self.maintenance_type.value,
            "description": self.description,
            "priority": self.priority,
            "scheduled_at": self.scheduled_at,
            "estimated_duration_hours": self.estimated_duration_hours,
            "assigned_to": self.assigned_to,
            "status": self.status,
            "created_at": self.created_at,
        }


@dataclass
class AlarmRule:
    """告警规则"""
    rule_id: str
    device_id: str
    metric_name: str
    condition: str  # gt / lt / eq / neq / range
    threshold: float
    severity: str = "warning"  # info / warning / critical
    cooldown_seconds: float = 300.0
    enabled: bool = True


class IndustrialOpsAgent:
    """工业运维Agent主类"""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.devices: Dict[str, Dict[str, Any]] = {}
        self.metrics_history: Dict[str, List[DeviceMetric]] = {}
        self.maintenance_tasks: Dict[str, MaintenanceTask] = {}
        self.alarm_rules: List[AlarmRule] = []
        self.active_alarms: List[Dict[str, Any]] = []
        self.protocol_connections: Dict[str, Dict[str, Any]] = {}
        self.production_lines: Dict[str, Dict[str, Any]] = {}
        self._alarm_cooldowns: Dict[str, float] = {}
        self._initialized = False

    def initialize(self) -> Dict[str, Any]:
        """初始化Agent"""
        self._initialized = True
        logger.info(f"[{MODULE_ID}] 工业运维Agent初始化完成")
        return {
            "status": "ok",
            "module": MODULE_ID,
            "version": MODULE_VERSION,
            "devices_registered": len(self.devices),
            "alarm_rules": len(self.alarm_rules),
        }

    # ── 设备管理 ──

    def register_device(self, device_id: str, device_info: Dict[str, Any]) -> Dict[str, Any]:
        """注册设备"""
        device_info["status"] = DeviceStatus.OFFLINE.value
        device_info["registered_at"] = time.time()
        device_info["last_seen"] = None
        self.devices[device_id] = device_info
        self.metrics_history[device_id] = []
        logger.info(f"[{MODULE_ID}] 设备注册: {device_id}")
        return {"status": "ok", "device_id": device_id}

    def remove_device(self, device_id: str) -> Dict[str, Any]:
        """移除设备"""
        if device_id in self.devices:
            del self.devices[device_id]
            self.metrics_history.pop(device_id, None)
            return {"status": "ok", "removed": device_id}
        return {"status": "error", "message": f"设备 {device_id} 不存在"}

    def update_device_status(self, device_id: str, status: DeviceStatus) -> Dict[str, Any]:
        """更新设备状态"""
        if device_id not in self.devices:
            return {"status": "error", "message": f"设备 {device_id} 不存在"}
        self.devices[device_id]["status"] = status.value
        self.devices[device_id]["last_seen"] = time.time()
        logger.info(f"[{MODULE_ID}] 设备状态更新: {device_id} -> {status.value}")
        return {"status": "ok", "device_id": device_id, "status": status.value}

    def get_device_summary(self) -> Dict[str, Any]:
        """获取设备总览"""
        status_count = {}
        for dev in self.devices.values():
            s = dev.get("status", "unknown")
            status_count[s] = status_count.get(s, 0) + 1
        return {
            "total_devices": len(self.devices),
            "status_breakdown": status_count,
            "active_alarms": len(self.active_alarms),
            "pending_tasks": sum(
                1 for t in self.maintenance_tasks.values() if t.status == "pending"
            ),
        }

    # ── 遥测数据采集 ──

    def ingest_metric(self, metric: DeviceMetric) -> Dict[str, Any]:
        """接收遥测数据并触发告警检查"""
        if metric.device_id not in self.devices:
            return {"status": "error", "message": f"设备 {metric.device_id} 未注册"}

        history = self.metrics_history[metric.device_id]
        history.append(metric)

        # 保留最近 10000 条
        if len(history) > 10000:
            self.metrics_history[metric.device_id] = history[-10000:]

        self.devices[metric.device_id]["last_seen"] = time.time()
        if self.devices[metric.device_id]["status"] == DeviceStatus.OFFLINE.value:
            self.devices[metric.device_id]["status"] = DeviceStatus.ONLINE.value

        # 告警检查
        alarm_triggered = self._check_alarms(metric)

        return {
            "status": "ok",
            "device_id": metric.device_id,
            "metric": metric.metric_name,
            "alarm_triggered": alarm_triggered,
        }

    def _check_alarms(self, metric: DeviceMetric) -> bool:
        """检查告警规则"""
        triggered = False
        now = time.time()
        for rule in self.alarm_rules:
            if not rule.enabled:
                continue
            if rule.device_id != metric.device_id or rule.metric_name != metric.metric_name:
                continue

            cooldown_key = f"{rule.rule_id}"
            if cooldown_key in self._alarm_cooldowns:
                if now - self._alarm_cooldowns[cooldown_key] < rule.cooldown_seconds:
                    continue

            fired = False
            if rule.condition == "gt" and metric.value > rule.threshold:
                fired = True
            elif rule.condition == "lt" and metric.value < rule.threshold:
                fired = True
            elif rule.condition == "eq" and metric.value == rule.threshold:
                fired = True
            elif rule.condition == "neq" and metric.value != rule.threshold:
                fired = True

            if fired:
                alarm = {
                    "alarm_id": hashlib.md5(f"{rule.rule_id}:{now}".encode()).hexdigest()[:12],
                    "rule_id": rule.rule_id,
                    "device_id": metric.device_id,
                    "metric_name": metric.metric_name,
                    "value": metric.value,
                    "threshold": rule.threshold,
                    "condition": rule.condition,
                    "severity": rule.severity,
                    "timestamp": now,
                }
                self.active_alarms.append(alarm)
                self._alarm_cooldowns[cooldown_key] = now
                triggered = True
                logger.warning(f"[{MODULE_ID}] 告警触发: {alarm}")

        return triggered

    def get_device_metrics(self, device_id: str, metric_name: Optional[str] = None,
                           limit: int = 100) -> Dict[str, Any]:
        """查询设备遥测历史"""
        if device_id not in self.metrics_history:
            return {"status": "error", "message": f"设备 {device_id} 无数据"}
        history = self.metrics_history[device_id]
        if metric_name:
            history = [m for m in history if m.metric_name == metric_name]
        return {
            "status": "ok",
            "device_id": device_id,
            "count": len(history[-limit:]),
            "data": [m.to_dict() for m in history[-limit:]],
        }

    # ── 预测性维护 ──

    def predict_failure(self, device_id: str, metric_name: str,
                        hours_ahead: int = 24) -> Dict[str, Any]:
        """简化版预测性分析 - 基于趋势和阈值"""
        if device_id not in self.metrics_history:
            return {"status": "error", "message": f"设备 {device_id} 无数据"}

        history = [
            m for m in self.metrics_history[device_id] if m.metric_name == metric_name
        ]
        if len(history) < 10:
            return {"status": "error", "message": "数据不足，至少需要10个数据点"}

        values = [m.value for m in history[-100:]]
        n = len(values)

        # 简单线性回归
        x_mean = (n - 1) / 2
        y_mean = sum(values) / n
        numerator = sum((i - x_mean) * (v - y_mean) for i, v in enumerate(values))
        denominator = sum((i - x_mean) ** 2 for i in range(n))
        slope = numerator / denominator if denominator > 0 else 0

        current = values[-1]
        predicted = current + slope * hours_ahead

        # 查找相关告警阈值
        threshold = None
        for rule in self.alarm_rules:
            if rule.device_id == device_id and rule.metric_name == metric_name:
                threshold = rule.threshold
                break

        risk_level = "low"
        remaining_hours = None
        if threshold is not None and slope > 0:
            if current >= threshold:
                risk_level = "critical"
            else:
                remaining_hours = (threshold - current) / slope if slope > 0 else None
                if remaining_hours is not None:
                    if remaining_hours < 12:
                        risk_level = "high"
                    elif remaining_hours < 48:
                        risk_level = "medium"

        return {
            "status": "ok",
            "device_id": device_id,
            "metric": metric_name,
            "current_value": current,
            "trend_slope": round(slope, 6),
            "predicted_value_hours": round(predicted, 4),
            "risk_level": risk_level,
            "threshold": threshold,
            "estimated_hours_to_threshold": round(remaining_hours, 1) if remaining_hours else None,
        }

    # ── 维护任务管理 ──

    def create_maintenance_task(self, device_id: str,
                                  maintenance_type: MaintenanceType,
                                  description: str,
                                  priority: int = 1,
                                  scheduled_at: Optional[float] = None) -> Dict[str, Any]:
        """创建维护任务"""
        task_id = hashlib.md5(f"{device_id}:{time.time()}".encode()).hexdigest()[:12]
        task = MaintenanceTask(
            task_id=task_id,
            device_id=device_id,
            maintenance_type=maintenance_type,
            description=description,
            priority=priority,
            scheduled_at=scheduled_at,
        )
        self.maintenance_tasks[task_id] = task
        logger.info(f"[{MODULE_ID}] 维护任务创建: {task_id} ({maintenance_type.value})")
        return {"status": "ok", "task_id": task_id, "task": task.to_dict()}

    def update_task_status(self, task_id: str, status: str,
                           assigned_to: Optional[str] = None) -> Dict[str, Any]:
        """更新任务状态"""
        if task_id not in self.maintenance_tasks:
            return {"status": "error", "message": f"任务 {task_id} 不存在"}
        task = self.maintenance_tasks[task_id]
        task.status = status
        if assigned_to:
            task.assigned_to = assigned_to
        return {"status": "ok", "task": task.to_dict()}

    def get_pending_tasks(self) -> Dict[str, Any]:
        """获取待处理任务"""
        pending = [
            t.to_dict() for t in self.maintenance_tasks.values()
            if t.status == "pending"
        ]
        pending.sort(key=lambda x: x["priority"], reverse=True)
        return {"status": "ok", "total": len(pending), "tasks": pending}

    # ── 告警规则管理 ──

    def add_alarm_rule(self, device_id: str, metric_name: str,
                       condition: str, threshold: float,
                       severity: str = "warning",
                       cooldown_seconds: float = 300.0) -> Dict[str, Any]:
        """添加告警规则"""
        rule_id = hashlib.md5(f"{device_id}:{metric_name}:{time.time()}".encode()).hexdigest()[:12]
        rule = AlarmRule(
            rule_id=rule_id,
            device_id=device_id,
            metric_name=metric_name,
            condition=condition,
            threshold=threshold,
            severity=severity,
            cooldown_seconds=cooldown_seconds,
        )
        self.alarm_rules.append(rule)
        return {"status": "ok", "rule_id": rule_id}

    def get_active_alarms(self, severity: Optional[str] = None) -> Dict[str, Any]:
        """获取活跃告警"""
        alarms = self.active_alarms
        if severity:
            alarms = [a for a in alarms if a["severity"] == severity]
        return {"status": "ok", "count": len(alarms), "alarms": alarms}

    def clear_alarm(self, alarm_id: str) -> Dict[str, Any]:
        """清除告警"""
        before = len(self.active_alarms)
        self.active_alarms = [a for a in self.active_alarms if a["alarm_id"] != alarm_id]
        cleared = before - len(self.active_alarms)
        return {"status": "ok", "cleared": cleared}

    # ── 产线调度 ──

    def register_production_line(self, line_id: str,
                                  device_ids: List[str],
                                  config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """注册产线"""
        self.production_lines[line_id] = {
            "devices": device_ids,
            "config": config or {},
            "status": "idle",
            "throughput": 0.0,
            "created_at": time.time(),
        }
        return {"status": "ok", "line_id": line_id}

    def get_production_overview(self) -> Dict[str, Any]:
        """获取产线总览"""
        result = {}
        for line_id, line_info in self.production_lines.items():
            device_statuses = [
                self.devices.get(did, {}).get("status", "unknown")
                for did in line_info["devices"]
            ]
            online_count = sum(1 for s in device_statuses if s == DeviceStatus.ONLINE.value)
            result[line_id] = {
                "total_devices": len(line_info["devices"]),
                "online_devices": online_count,
                "device_statuses": device_statuses,
                "status": line_info["status"],
                "throughput": line_info["throughput"],
            }
        return {"status": "ok", "lines": result}

    # ── 协议管理 ──

    def register_protocol(self, protocol: ProtocolType,
                           connection_params: Dict[str, Any]) -> Dict[str, Any]:
        """注册协议连接"""
        conn_id = hashlib.md5(f"{protocol.value}:{json.dumps(connection_params, sort_keys=True)}".encode()).hexdigest()[:12]
        self.protocol_connections[conn_id] = {
            "protocol": protocol.value,
            "params": connection_params,
            "connected": False,
            "registered_at": time.time(),
        }
        return {"status": "ok", "connection_id": conn_id, "protocol": protocol.value}

    def get_health_check(self) -> Dict[str, Any]:
        """健康检查"""
        return {
            "status": "healthy" if self._initialized else "not_initialized",
            "module": MODULE_ID,
            "version": MODULE_VERSION,
            "devices": len(self.devices),
            "alarm_rules": len(self.alarm_rules),
            "active_alarms": len(self.active_alarms),
            "maintenance_tasks": len(self.maintenance_tasks),
            "production_lines": len(self.production_lines),
            "protocol_connections": len(self.protocol_connections),
        }


# ── 模块入口 ──
_instance: Optional[IndustrialOpsAgent] = None

def get_agent(config: Optional[Dict[str, Any]] = None) -> IndustrialOpsAgent:
    """获取Agent单例"""
    global _instance
    if _instance is None:
        _instance = IndustrialOpsAgent(config)
    return _instance

def get_module_info() -> Dict[str, Any]:
    """获取模块信息"""
    return {
        "module_id": MODULE_ID,
        "version": MODULE_VERSION,
        "name": "工业运维Agent",
        "description": "工业设备监控、预测性维护、产线调度优化",
        "capabilities": [
            "设备注册与状态管理",
            "遥测数据采集与存储",
            "告警规则引擎",
            "预测性维护分析",
            "维护任务生命周期管理",
            "产线注册与总览",
            "多协议连接管理(OPC-UA/Modbus/MQTT/SCADA)",
        ],
        "protocols": [p.value for p in ProtocolType],
    }

    def execute(self, action: str = "status", params: dict = None) -> dict:
        params = params or {}
        self.trace("industrial_ops_agent.execute", "start", action=action)
        self.metrics_collector.counter("industrial_ops_agent.execute.total", 1)
        try:
            action = action.lower().strip()
            if action in ("status", "info", "stats"):
                result = self.health_check()
            elif action == "analyze":
                result = self._analyzer.analyze(params)
            elif action == "help":
                result = {"actions": ["status", "analyze", "help"], "module": "industrial_ops_agent"}
            else:
                result = {"success": True, "action": action, "module": "industrial_ops_agent"}
            self.metrics_collector.counter("industrial_ops_agent.execute.success", 1)
            self.trace("industrial_ops_agent.execute", "end")
            return result
        except Exception as e:
            self.metrics_collector.counter("industrial_ops_agent.execute.error", 1)
            return {"success": False, "error": str(e)}

    def shutdown(self) -> dict:
        self.status = "stopped"
        return {"success": True, "module": "industrial_ops_agent"}

    def health_check(self) -> dict:
        return {"status": "healthy", "module": "industrial_ops_agent", "version": getattr(self, "version", "1.0.0")}

    def initialize(self) -> dict:
        self.trace("industrial_ops_agent.initialize", "start")
        self.metrics_collector.gauge("industrial_ops_agent.initialized", 1)
        self.audit("初始化industrial_ops_agent", level="info")
        self.trace("industrial_ops_agent.initialize", "end")
        return {"success": True, "module": "industrial_ops_agent"}

module_class = IndustrialOpsAgent

