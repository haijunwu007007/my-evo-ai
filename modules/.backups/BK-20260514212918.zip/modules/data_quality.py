"""data_quality - Enterprise Data Quality Module
AUTO-EVO-AI v6.39 | Grade: A | Category: 数据管理
数据质量检测: 完整性/一致性/准确性/唯一性/时效性, 规则引擎, 异常报告
子引擎: QualityRuleEngine(规则评估+评分)
"""
import logging, time, uuid, threading, re
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime
from dataclasses import dataclass, field
from collections import defaultdict
from enum import Enum

from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)

logger = logging.getLogger(__name__)


class QualityDimension(str, Enum):
    COMPLETENESS = "completeness"
    CONSISTENCY = "consistency"
    ACCURACY = "accuracy"
    UNIQUENESS = "uniqueness"
    TIMELINESS = "timeliness"
    VALIDITY = "validity"


@dataclass
class QualityRule:
    rule_id: str = ""
    name: str = ""
    dimension: str = "validity"
    field_name: str = ""
    rule_type: str = "not_null"  # not_null, regex, range, unique, custom
    params: Dict[str, Any] = field(default_factory=dict)
    severity: str = "error"  # error/warning/info
    enabled: bool = True

    def __post_init__(self):
        if not self.rule_id:
            self.rule_id = str(uuid.uuid4())[:8]


@dataclass
class QualityIssue:
    issue_id: str = ""
    rule_id: str = ""
    field_name: str = ""
    value: Any = None
    expected: str = ""
    actual: str = ""
    severity: str = "error"
    row_index: int = -1
    timestamp: float = 0.0

    def __post_init__(self):
        if not self.issue_id:
            self.issue_id = str(uuid.uuid4())[:8]
        if not self.timestamp:
            self.timestamp = time.time()


@dataclass
class QualityReport:
    dataset: str = ""
    total_rows: int = 0
    checked_rows: int = 0
    dimensions: Dict[str, float] = field(default_factory=dict)
    overall_score: float = 0.0
    issues: List[Dict] = field(default_factory=list)
    timestamp: float = 0.0

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = time.time()


class QualityRuleEngine:
    """质量规则引擎"""

    def evaluate(self, data: List[Dict], rules: List[QualityRule]) -> QualityReport:
        total = len(data)
        if total == 0:
            return QualityReport(total_rows=0, overall_score=100.0, dimensions={})
        issues: List[QualityIssue] = []
        dim_scores: Dict[str, List[float]] = defaultdict(list)
        active_rules = [r for r in rules if r.enabled]
        for row_idx, row in enumerate(data):
            for rule in active_rules:
                result = self._check_rule(row, rule, row_idx)
                if result["pass"]:
                    dim_scores[rule.dimension].append(100.0)
                else:
                    dim_scores[rule.dimension].append(0.0)
                    if result.get("issue"):
                        issues.append(result["issue"])
        dimensions = {}
        for dim, scores in dim_scores.items():
            dimensions[dim] = round(sum(scores) / len(scores), 2) if scores else 100.0
        overall = round(sum(dimensions.values()) / max(1, len(dimensions)), 2) if dimensions else 100.0
        return QualityReport(
            total_rows=total, checked_rows=total,
            dimensions=dimensions, overall_score=overall,
            issues=[{"issue_id": i.issue_id, "rule": i.rule_id, "field": i.field_name,
                     "severity": i.severity, "row": i.row_index, "expected": i.expected,
                     "actual": str(i.actual)[:100]} for i in issues],
        )

    def _check_rule(self, row: Dict, rule: QualityRule, row_idx: int) -> Dict[str, Any]:
        val = row.get(rule.field_name)
        if rule.rule_type == "not_null":
            ok = val is not None and val != ""
            if not ok:
                return {"pass": False, "issue": QualityIssue(
                    rule_id=rule.rule_id, field_name=rule.field_name,
                    value=val, expected="non-null", actual=str(val),
                    severity=rule.severity, row_index=row_idx)}
        elif rule.rule_type == "regex":
            pattern = rule.params.get("pattern", "")
            if pattern and val:
                ok = bool(re.match(pattern, str(val)))
            else:
                ok = False
            if not ok:
                return {"pass": False, "issue": QualityIssue(
                    rule_id=rule.rule_id, field_name=rule.field_name,
                    value=val, expected=f"regex:{pattern}", actual=str(val),
                    severity=rule.severity, row_index=row_idx)}
        elif rule.rule_type == "range":
            min_v = rule.params.get("min")
            max_v = rule.params.get("max")
            try:
                num = float(val)
                ok = (min_v is None or num >= min_v) and (max_v is None or num <= max_v)
            except (ValueError, TypeError):
                ok = False
            if not ok:
                return {"pass": False, "issue": QualityIssue(
                    rule_id=rule.rule_id, field_name=rule.field_name,
                    value=val, expected=f"range[{min_v},{max_v}]", actual=str(val),
                    severity=rule.severity, row_index=row_idx)}
        elif rule.rule_type == "unique":
            ok = True  # uniqueness checked at dataset level
            return {"pass": ok}
        elif rule.rule_type == "type":
            expected_type = rule.params.get("type", "str")
            ok = True
            if expected_type == "int":
                ok = isinstance(val, int)
            elif expected_type == "float":
                ok = isinstance(val, (int, float))
            elif expected_type == "str":
                ok = isinstance(val, str)
            if not ok:
                return {"pass": False, "issue": QualityIssue(
                    rule_id=rule.rule_id, field_name=rule.field_name,
                    value=val, expected=f"type:{expected_type}", actual=type(val).__name__,
                    severity=rule.severity, row_index=row_idx)}
        return {"pass": True}

    def check_uniqueness(self, data: List[Dict], field_name: str) -> Tuple[float, List[Dict]]:
        values = [row.get(field_name) for row in data]
        unique_count = len(set(str(v) for v in values if v is not None))
        total = len([v for v in values if v is not None])
        score = round(unique_count / max(1, total) * 100, 2)
        seen: Dict[str, int] = {}
        duplicates = []
        for i, v in enumerate(values):
            if v is None:
                continue
            key = str(v)
            if key in seen:
                duplicates.append({"row": i, "field": field_name, "value": str(v), "first_seen": seen[key]})
            else:
                seen[key] = i
        return score, duplicates[:50]


class DataQuality(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    AUTO-EVO-AI v6.39 - 数据质量检测模块
    """

    MODULE_ID = "data_quality"
    MODULE_NAME = "DataQuality"
    VERSION = "1.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._rules: Dict[str, QualityRule] = {}
        self._reports: List[QualityReport] = []
        self._engine = QualityRuleEngine()
        self._lock = threading.Lock()
        self._total_checks = 0
        self._init_default_rules()

    def _init_default_rules(self):
        for name, dim, ftype in [("not_null_check", "completeness", "not_null"),
                                  ("type_check", "validity", "type")]:
            self._rules[name] = QualityRule(rule_id=name, name=name, dimension=dim, rule_type=ftype)

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                result = self._dispatch(action, params)
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                logger.error(f"[data_quality] {action} error: {e}")
                return {"success": False, "error": str(e), "action": action}

    def _dispatch(self, action: str, params: Dict[str, Any]) -> Any:
        handler = {
            "status": self._get_status, "stats": self._get_stats,
            "health": self.health_check, "reset": self._reset,
            "configure": self._configure,
            # 规则管理
            "add_rule": self._add_rule, "list_rules": self._list_rules,
            "remove_rule": self._remove_rule, "update_rule": self._update_rule,
            # 检测
            "check": self._check_data,
            "check_uniqueness": self._check_uniqueness,
            "check_completeness": self._check_completeness,
            # 报告
            "latest_report": self._latest_report,
            "report_history": self._report_history,
        }.get(action)
        if handler:
            return handler(params)
        return {"action": action, "module_id": self.MODULE_ID}

    def _add_rule(self, params: Dict[str, Any]) -> Dict[str, Any]:
        rule = QualityRule(
            name=params.get("name", ""), dimension=params.get("dimension", "validity"),
            field_name=params.get("field", ""), rule_type=params.get("type", "not_null"),
            params=params.get("params", {}), severity=params.get("severity", "error"),
        )
        self._rules[rule.rule_id] = rule
        return {"rule_id": rule.rule_id, "name": rule.name}

    def _list_rules(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"rules": [{"rule_id": r.rule_id, "name": r.name, "dimension": r.dimension,
                           "field": r.field_name, "type": r.rule_type, "severity": r.severity,
                           "enabled": r.enabled} for r in self._rules.values()],
                "total": len(self._rules)}

    def _remove_rule(self, params: Dict[str, Any]) -> Dict[str, Any]:
        rid = params.get("rule_id", "")
        if rid in self._rules:
            del self._rules[rid]
            return {"rule_id": rid, "removed": True}
        return {"error": "not_found"}

    def _update_rule(self, params: Dict[str, Any]) -> Dict[str, Any]:
        rid = params.get("rule_id", "")
        rule = self._rules.get(rid)
        if not rule:
            return {"error": "not_found"}
        for k in ("name", "dimension", "field_name", "rule_type", "params", "severity", "enabled"):
            if k in params:
                setattr(rule, k, params[k])
        return {"rule_id": rid, "updated": True}

    def _check_data(self, params: Dict[str, Any]) -> Dict[str, Any]:
        data = params.get("data", [])
        dataset = params.get("dataset", "default")
        rules = list(self._rules.values())
        report = self._engine.evaluate(data, rules)
        report.dataset = dataset
        self._reports.append(report)
        if len(self._reports) > 100:
            self._reports = self._reports[-50:]
        self._total_checks += 1
        self.audit("check_data", f"dataset={dataset} rows={len(data)} score={report.overall_score}")
        return {
            "dataset": dataset, "total_rows": report.total_rows,
            "overall_score": report.overall_score, "dimensions": report.dimensions,
            "issue_count": len(report.issues),
            "issues": report.issues[:20],
        }

    def _check_uniqueness(self, params: Dict[str, Any]) -> Dict[str, Any]:
        data = params.get("data", [])
        field_name = params.get("field", "")
        if not field_name:
            return {"error": "field required"}
        score, duplicates = self._engine.check_uniqueness(data, field_name)
        return {"field": field_name, "score": score, "duplicate_count": len(duplicates),
                "duplicates": duplicates[:20]}

    def _check_completeness(self, params: Dict[str, Any]) -> Dict[str, Any]:
        data = params.get("data", [])
        if not data:
            return {"error": "empty data"}
        fields = params.get("fields", list(data[0].keys()))
        result = {}
        for f in fields:
            non_null = len([row for row in data if row.get(f) is not None and row.get(f) != ""])
            result[f] = {"total": len(data), "non_null": non_null,
                         "completeness": round(non_null / len(data) * 100, 2)}
        avg = round(sum(v["completeness"] for v in result.values()) / max(1, len(result)), 2)
        return {"fields": result, "avg_completeness": avg}

    def _latest_report(self, params: Dict[str, Any]) -> Dict[str, Any]:
        if not self._reports:
            return {"error": "no reports"}
        r = self._reports[-1]
        return {"dataset": r.dataset, "total_rows": r.total_rows,
                "overall_score": r.overall_score, "dimensions": r.dimensions,
                "issue_count": len(r.issues), "timestamp": r.timestamp}

    def _report_history(self, params: Dict[str, Any]) -> Dict[str, Any]:
        limit = params.get("limit", 10)
        return {"reports": [{"dataset": r.dataset, "score": r.overall_score,
                              "rows": r.total_rows, "issues": len(r.issues),
                              "timestamp": r.timestamp}
                             for r in self._reports[-limit:]], "total": len(self._reports)}

    def _get_status(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
            "version": self.VERSION, "status": "running",
            "rules": len(self._rules), "reports": len(self._reports),
            "total_checks": self._total_checks,
        }

    def _get_stats(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        avg_score = 0.0
        if self._reports:
            avg_score = round(sum(r.overall_score for r in self._reports) / len(self._reports), 2)
        return {
            "total_checks": self._total_checks,
            "rules": len(self._rules), "reports": len(self._reports),
            "avg_score": avg_score,
        }

    def _reset(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        self._reports.clear()
        self._total_checks = 0
        return {"status": "reset_ok"}

    def _configure(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"configured": list(params.keys())}

    def health_check(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {"healthy": True, "status": "ok", "rules": len(self._rules)}


module_class = DataQuality
