"""
        Finance Legal Agent - Compliance and Legal Automation for Financial Services
Provides contract analysis, regulatory compliance checking, legal document generation,
and regulatory timeline tracking for financial institutions.
"""

import re
import json
import time
import hashlib
import difflib
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Tuple, Set
from collections import defaultdict
from enum import Enum, auto
import uuid

from modules._base.enterprise_module import EnterpriseModule


class ComplianceStatus(Enum):
    COMPLIANT = "COMPLIANT"
    NON_COMPLIANT = "NON_COMPLIANT"
    REQUIRES_REVIEW = "REQUIRES_REVIEW"
    EXEMPT = "EXEMPT"


class DocumentType(Enum):
    CONTRACT = "CONTRACT"
    POLICY = "POLICY"
    DISCLOSURE = "DISCLOSURE"
    AGREEMENT = "AGREEMENT"
    NOTICE = "NOTICE"
    REPORT = "REPORT"


class RiskLevel(Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class FinanceLegalAgent(EnterpriseModule):
    """
    FinanceLegalAgent automates legal and compliance workflows for financial services.

    Sub-engines:
    - ContractEngine      : contract parsing, clause extraction, risk scoring
    - ComplianceEngine    : regulatory rule evaluation, status tracking
    - DocumentEngine      : legal document generation, template management
    - RegulatoryEngine    : regulatory timeline, obligation tracking
    - AuditEngine         : compliance audit, report generation
    """

    def __init__(self):
        super().__init__()
        self._contracts: Dict[str, Dict] = {}
        self._rules: Dict[str, Dict] = {}
        self._documents: Dict[str, Dict] = {}
        self._regulations: Dict[str, Dict] = {}
        self._audits: Dict[str, Dict] = {}
        self._templates: Dict[str, Dict] = {}
        self._jurisdiction_rules: Dict[str, List[str]] = defaultdict(list)
        self._contract_counter = 0
        self._rule_counter = 0
        self._document_counter = 0
        self._reg_counter = 0
        self._audit_counter = 0
        self._dispatch_registered = False
        # built-in regulatory frameworks
        self._init_default_rules()

    def _init_default_rules(self):
        defaults = [
            {"rule_id": "REG-001", "name": "KYC Compliance", "framework": "AML",
             "jurisdiction": "CN", "severity": "HIGH",
             "description": "Customer identity verification required for all transactions > ¥50,000",
             "effective_date": "2020-01-01", "active": True},
            {"rule_id": "REG-002", "name": "Data Localization", "framework": "CSL",
             "jurisdiction": "CN", "severity": "CRITICAL",
             "description": "Personal data must be stored on mainland China servers",
             "effective_date": "2021-11-01", "active": True},
            {"rule_id": "REG-003", "name": "GDPR Consent", "framework": "GDPR",
             "jurisdiction": "EU", "severity": "HIGH",
             "description": "Explicit consent required for personal data processing",
             "effective_date": "2018-05-25", "active": True},
            {"rule_id": "REG-004", "name": "Trading Reporting", "framework": "MiFID_II",
             "jurisdiction": "EU", "severity": "MEDIUM",
             "description": "All trades must be reported within T+1",
             "effective_date": "2018-01-03", "active": True},
            {"rule_id": "REG-005", "name": "Capital Adequacy", "framework": "BASEL_III",
             "jurisdiction": "GLOBAL", "severity": "HIGH",
             "description": "Minimum Tier 1 capital ratio 6%",
             "effective_date": "2015-01-01", "active": True},
        ]
        for r in defaults:
            self._rules[r["rule_id"]] = r
            self._jurisdiction_rules[r["jurisdiction"]].append(r["rule_id"])
            self._rule_counter += 1

    def _register_dispatches(self):
        if self._dispatch_registered:
            return
        self._dispatch_registered = True
        self._dispatches = {
            "analyze_contract": self._analyze_contract,
            "get_contract": self._get_contract,
            "update_contract": self._update_contract,
            "delete_contract": self._delete_contract,
            "list_contracts": self._list_contracts,
            "extract_clauses": self._extract_clauses,
            "compare_contracts": self._compare_contracts,
            "check_compliance": self._check_compliance,
            "add_rule": self._add_rule,
            "update_rule": self._update_rule,
            "delete_rule": self._delete_rule,
            "list_rules": self._list_rules,
            "check_jurisdiction": self._check_jurisdiction,
            "generate_document": self._generate_document,
            "get_document": self._get_document,
            "update_document": self._update_document,
            "delete_document": self._delete_document,
            "list_documents": self._list_documents,
            "add_template": self._add_template,
            "list_templates": self._list_templates,
            "add_regulation": self._add_regulation,
            "get_regulation": self._get_regulation,
            "update_regulation": self._update_regulation,
            "delete_regulation": self._delete_regulation,
            "list_regulations": self._list_regulations,
            "check_obligations": self._check_obligation,
            "create_audit": self._create_audit,
            "get_audit": self._get_audit,
            "update_audit": self._update_audit,
            "delete_audit": self._delete_audit,
            "list_audits": self._list_audits,
            "generate_audit_report": self._generate_audit_report,
            "configure": self._configure,
            "health": self._health,
            "status": self._status,
            "stats": self._stats,
            "reset": self._reset,
        }

    def execute(self, action="status", params=None, **kwargs) -> dict:
        params = params or {}
        self.trace("finance_legal_agent.execute", "start", action=action)
        self.metrics_collector.counter("finance_legal_agent.execute.total", 1)
        try:
            action = action.lower().strip()
            if action in ("status", "info"):
                result = self.health_check()
            elif action == "help":
                result = {"actions": ["status", "info", "help"], "module": "finance_legal_agent"}
            else:
                result = self._dispatch(action, params)
            return {"success": True, "data": result, "action": action}
        except Exception as e:
            return {"success": False, "error": str(e)}
class ContractEngine:
    """Contract parsing, clause extraction, and risk scoring."""

    def __init__(self, contracts_store: Dict):
        self._contracts = contracts_store

    def extract_clauses(self, content: str) -> List[Dict]:
        clauses = []
        # Simple sentence-based clause extraction
        sentences = re.split(r'[。！？\n]+', content)
        for i, sent in enumerate(sentences):
            sent = sent.strip()
            if len(sent) < 10:
                continue
            clause_type = "GENERAL"
            if any(kw in sent for kw in ["应当", "必须", "不得", "shall", "must", "must not"]):
                clause_type = "OBLIGATION"
            elif any(kw in sent for kw in ["有权", "可以", "may", "entitled"]):
                clause_type = "RIGHT"
            elif any(kw in sent for kw in ["违约", "赔偿", "breach", "damages"]):
                clause_type = "LIABILITY"
            elif any(kw in sent for kw in ["终止", "解除", "terminate", "rescind"]):
                clause_type = "TERMINATION"
            clauses.append({"clause_id": f"clause-{i+1}",
                            "text": sent, "type": clause_type})
        return clauses

    def score_risk(self, content: str, jurisdiction: str) -> Dict:
        risk_keywords = ["违约", "赔偿", "责任", "breach", "liability",
                        "indemnif", "penalty", "terminate", "解除"]
        score = 0.0
        details = []
        for kw in risk_keywords:
            count = content.lower().count(kw.lower())
            if count > 0:
                score += count * 0.1
                details.append(f"'{kw}' appears {count} times")
        # Normalize to 0-1
        score = min(score, 1.0)
        level = "LOW"
        if score > 0.7:
            level = "HIGH"
        elif score > 0.4:
            level = "MEDIUM"
        return {"score": round(score, 4), "level": level, "details": details}

    def compare(self, content_a: str, content_b: str) -> Dict:
        lines_a = content_a.splitlines()
        lines_b = content_b.splitlines()
        diff = list(difflib.unified_diff(lines_a, lines_b, lineterm=""))
        # Count differences
        additions = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
        deletions = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))
        return {"additions": additions, "deletions": deletions,
                "similarity": 1.0 - (additions + deletions) / max(len(lines_a), 1)}


class ComplianceEngine:
    """Regulatory rule evaluation and compliance status tracking."""

    def __init__(self, rules_store: Dict):
        self._rules = rules_store

    def check_rule(self, content: str, rule: Dict) -> bool:
        """Returns True if content COMPLIES with rule."""
        framework = rule.get("framework", "")
        # Simplified compliance logic
        if framework == "AML":
            return "identity" in content.lower() or "身份" in content
        elif framework == "CSL":
            return "mainland" in content.lower() or "境内" in content
        elif framework == "GDPR":
            return "consent" in content.lower() or "同意" in content
        elif framework == "MiFID_II":
            return "report" in content.lower() or "报告" in content
        elif framework == "BASEL_III":
            return "capital" in content.lower() or "资本" in content
        return True  # default: compliant


class DocumentEngine:
    """Legal document generation and template management."""

    def __init__(self, documents_store: Dict, templates_store: Dict):
        self._documents = documents_store
        self._templates = templates_store

    def render_template(self, template_content: str, variables: Dict) -> str:
        content = template_content
        for key, value in variables.items():
            placeholder = "{{" + key + "}}"
            content = content.replace(placeholder, str(value))
        return content


class RegulatoryEngine:
    """Regulatory timeline and obligation tracking."""

    def __init__(self, regulations_store: Dict):
        self._regulations = regulations_store

    def get_upcoming_deadlines(self, days: int = 30) -> List[Dict]:
        from datetime import datetime, timedelta
        now = datetime.now()
        cutoff = now + timedelta(days=days)
        upcoming = []
        for r in self._regulations.values():
            for dl in r.get("deadlines", []):
                try:
                    dl_date = datetime.strptime(dl["date"], "%Y-%m-%d")
                    if now <= dl_date <= cutoff:
                        upcoming.append({"reg_id": r["reg_id"], "name": r["name"],
                                         "deadline": dl})
                except Exception:
                    pass
        return upcoming


class AuditEngine:
    """Compliance audit execution and report generation."""

    def __init__(self, audits_store: Dict):
        self._audits = audits_store

    def generate_report(self, audit: Dict) -> Dict:
        findings = audit.get("findings", [])
        compliant = sum(1 for f in findings if f.get("status") == "COMPLIANT")
        non_compliant = len(findings) - compliant
        return {
            "audit_id": audit["audit_id"],
            "name": audit["name"],
            "total_findings": len(findings),
            "compliant": compliant,
            "non_compliant": non_compliant,
            "compliance_rate": compliant / len(findings) if findings else 1.0,
            "generated_at": time.time(),
        }


def module_class():
    return FinanceLegalAgent

module_class = FinanceLegalAgent
