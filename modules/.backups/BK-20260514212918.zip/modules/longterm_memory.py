"""
Longterm Memory - 企业级长期记忆管理模块
生产级功能：记忆存储/语义搜索/时间衰减/重要性评分/记忆合并/分类标签/导入导出/统计
"""

import time
import uuid
import math
import threading
import hashlib
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple
from enum import Enum
from collections import defaultdict

from modules._base.enterprise_module import EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin

module_class = "LongtermMemory"


class MemoryType(Enum):
    FACT = "fact"
    EVENT = "event"
    PREFERENCE = "preference"
    SKILL = "skill"
    CONTEXT = "context"
    EPISODIC = "episodic"


class MemoryImportance(Enum):
    CRITICAL = 5
    HIGH = 4
    MEDIUM = 3
    LOW = 2
    TRIVIAL = 1


# ─── 时间衰减引擎 ──────────────────────────────────────────────

class TimeDecayEngine:
    """记忆时间衰减计算"""

    # 半衰期（天）：重要性越高，衰减越慢
    HALF_LIVES = {
        MemoryImportance.CRITICAL.value: 365,
        MemoryImportance.HIGH.value: 90,
        MemoryImportance.MEDIUM.value: 30,
        MemoryImportance.LOW.value: 7,
        MemoryImportance.TRIVIAL.value: 1,
    }

    def calculate_decay(self, importance: int, days_since_creation: float) -> float:
        """计算记忆衰减后的可用性分数（0-1）"""
        half_life = self.HALF_LIVES.get(importance, 30)
        decay = math.exp(-0.693 * days_since_creation / half_life)
        return max(0.0, min(1.0, decay))

    def should_forget(self, importance: int, days_since_creation: float,
                     threshold: float = 0.01) -> bool:
        return self.calculate_decay(importance, days_since_creation) < threshold


# ─── 语义搜索引擎 ──────────────────────────────────────────────

class SemanticSearchEngine:
    """基于关键词和标签的语义搜索"""

    def __init__(self):
        self._index: Dict[str, List[str]] = defaultdict(list)  # keyword -> [memory_id]

    def index_memory(self, memory_id: str, content: str, tags: List[str]):
        # 分词索引
        words = content.lower().split()
        for w in words:
            if len(w) > 2:
                self._index[w].append(memory_id)
        for tag in tags:
            self._index[tag.lower()].append(memory_id)

    def search(self, query: str, all_ids: List[str], tags: List[str] = None,
               limit: int = 20) -> List[str]:
        """搜索匹配的记忆ID，按相关性排序"""
        query_words = query.lower().split()
        scores: Dict[str, float] = defaultdict(float)
        for w in query_words:
            if len(w) > 2:
                for mid in self._index.get(w, []):
                    if mid in all_ids:
                        scores[mid] += 1.0
        if tags:
            for tag in tags:
                for mid in self._index.get(tag.lower(), []):
                    if mid in all_ids:
                        scores[mid] += 2.0  # 标签匹配权重更高
        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [mid for mid, score in ranked[:limit]]

    def remove_memory(self, memory_id: str):
        for key in list(self._index.keys()):
            if memory_id in self._index[key]:
                self._index[key].remove(memory_id)


# ─── 记忆存储引擎 ──────────────────────────────────────────────

class MemoryStore:
    """记忆存储与生命周期管理"""

    def __init__(self):
        self._memories: Dict[str, Dict] = {}
        self._search = SemanticSearchEngine()
        self._decay = TimeDecayEngine()
        self._lock = threading.Lock()

    def store(self, content: str, memory_type: str = MemoryType.FACT.value,
              importance: int = 3, tags: List[str] = None,
              source: str = "", metadata: Dict = None) -> Dict:
        memory_id = f"mem_{uuid.uuid4().hex[:12]}"
        memory = {
            "memory_id": memory_id,
            "content": content,
            "type": memory_type,
            "importance": importance,
            "tags": tags or [],
            "source": source,
            "metadata": metadata or {},
            "created_at": datetime.utcnow().isoformat(),
            "accessed_at": datetime.utcnow().isoformat(),
            "access_count": 0,
            "enabled": True,
        }
        with self._lock:
            self._memories[memory_id] = memory
        self._search.index_memory(memory_id, content, memory["tags"])
        return memory

    def get(self, memory_id: str) -> Optional[Dict]:
        memory = self._memories.get(memory_id)
        if memory:
            memory["accessed_at"] = datetime.utcnow().isoformat()
            memory["access_count"] += 1
        return memory

    def search(self, query: str, memory_type: str = None, tags: List[str] = None,
               min_importance: int = 0, limit: int = 20) -> List[Dict]:
        with self._lock:
            all_ids = list(self._memories.keys())
            matched_ids = self._search.search(query, all_ids, tags, limit * 3)
        # 过滤和衰减
        now = datetime.utcnow()
        results = []
        for mid in matched_ids:
            m = self._memories.get(mid)
            if not m or not m["enabled"]:
                continue
            if memory_type and m["type"] != memory_type:
                continue
            if m["importance"] < min_importance:
                continue
            # 计算衰减分数
            created = datetime.fromisoformat(m["created_at"])
            days = (now - created).total_seconds() / 86400
            decay_score = self._decay.calculate_decay(m["importance"], days)
            combined_score = (m["importance"] / 5.0) * 0.6 + decay_score * 0.3 + (m["access_count"] / 100.0) * 0.1
            results.append({**m, "relevance_score": round(combined_score, 3), "decay": round(decay_score, 3)})
        results.sort(key=lambda x: x["relevance_score"], reverse=True)
        return results[:limit]

    def update(self, memory_id: str, content: str = None, importance: int = None,
               tags: List[str] = None) -> Optional[Dict]:
        memory = self._memories.get(memory_id)
        if not memory:
            return None
        if content is not None:
            self._search.remove_memory(memory_id)
            memory["content"] = content
            self._search.index_memory(memory_id, content, memory["tags"])
        if importance is not None:
            memory["importance"] = importance
        if tags is not None:
            self._search.remove_memory(memory_id)
            memory["tags"] = tags
            self._search.index_memory(memory_id, memory["content"], tags)
        memory["updated_at"] = datetime.utcnow().isoformat()
        return memory

    def delete(self, memory_id: str) -> bool:
        with self._lock:
            existed = memory_id in self._memories
            if existed:
                self._search.remove_memory(memory_id)
                del self._memories[memory_id]
        return existed

    def decay_cleanup(self, threshold: float = 0.01) -> List[str]:
        """清理衰减过低的记忆"""
        now = datetime.utcnow()
        removed = []
        with self._lock:
            for mid, m in list(self._memories.items()):
                created = datetime.fromisoformat(m["created_at"])
                days = (now - created).total_seconds() / 86400
                if self._decay.should_forget(m["importance"], days, threshold):
                    self._search.remove_memory(mid)
                    del self._memories[mid]
                    removed.append(mid)
        return removed

    def merge_similar(self, similarity_threshold: float = 0.8) -> List[Dict]:
        """合并相似记忆（简化实现）"""
        merged = []
        # 按类型分组
        by_type: Dict[str, List[Dict]] = defaultdict(list)
        for m in self._memories.values():
            by_type[m["type"]].append(m)
        for mtype, memories in by_type.items():
            for i, m1 in enumerate(memories):
                for m2 in memories[i + 1:]:
                    # 简单共享词比例
                    w1 = set(m1["content"].lower().split())
                    w2 = set(m2["content"].lower().split())
                    if not w1 or not w2:
                        continue
                    overlap = len(w1 & w2) / min(len(w1), len(w2))
                    if overlap >= similarity_threshold:
                        # 保留更重要的
                        keeper = m1 if m1["importance"] >= m2["importance"] else m2
                        removed = m2 if keeper["id"] == m1["memory_id"] else m1
                        self.delete(removed["memory_id"])
                        merged.append({"kept": keeper["memory_id"], "removed": removed["memory_id"],
                                        "overlap": round(overlap, 2)})
                        break
        return merged

    def list_all(self, memory_type: str = None, limit: int = 100) -> List[Dict]:
        memories = list(self._memories.values())
        if memory_type:
            memories = [m for m in memories if m["type"] == memory_type]
        memories.sort(key=lambda m: m["created_at"], reverse=True)
        return memories[:limit]

    def stats(self) -> Dict:
        by_type: Dict[str, int] = defaultdict(int)
        by_importance: Dict[int, int] = defaultdict(int)
        for m in self._memories.values():
            by_type[m["type"]] += 1
            by_importance[m["importance"]] += 1
        return {
            "total": len(self._memories),
            "by_type": dict(by_type),
            "by_importance": dict(by_importance),
        }


# ─── 主模块 ──────────────────────────────────────────────────

class LongtermMemory(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    AUTO-EVO-AI v6.39 — Longterm Memory (Production Grade)
    企业级长期记忆：存储/语义搜索/时间衰减/重要性评分/合并/清理/导入导出
    """

    MODULE_ID = "longterm_memory"
    MODULE_NAME = "LongtermMemory"
    VERSION = "2.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._store = MemoryStore()

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        return self._dispatch(action, params)

    def _dispatch(self, action: str, params: Dict) -> Dict[str, Any]:
        actions = {
            "status": self._action_status,
            "stats": self._action_stats,
            "health": self._action_health,
            "configure": self._action_configure,
            "reset": self._action_reset,
            # 记忆CRUD
            "store": self._action_store,
            "get": self._action_get,
            "update": self._action_update,
            "delete": self._action_delete,
            "list": self._action_list,
            # 搜索
            "search": self._action_search,
            "recall": self._action_recall,
            # 管理
            "decay_cleanup": self._action_decay_cleanup,
            "merge_similar": self._action_merge_similar,
            "boost_importance": self._action_boost_importance,
            # 批量
            "store_batch": self._action_store_batch,
            "export": self._action_export,
            "import_memories": self._action_import,
        }
        handler = actions.get(action)
        if not handler:
            return {"success": False, "error": f"Unknown action: {action}", "available": list(actions.keys())}
        try:
            return handler(params)
        except Exception as e:
            self.logger.error(f"LongtermMemory.{action} error: {e}")
            return {"success": False, "error": str(e), "action": action}

    def _action_status(self, params: Dict) -> Dict:
        st = self._store.stats()
        return {"success": True, "data": {
            "module": "LongtermMemory", "version": self.VERSION, "state": "active",
            **st,
        }}

    def _action_stats(self, params: Dict) -> Dict:
        return {"success": True, "data": self._store.stats()}

    def _action_health(self, params: Dict) -> Dict:
        return {"success": True, "data": {"healthy": True, "memory_ok": True}}

    def _action_configure(self, params: Dict) -> Dict:
        return {"success": True, "data": {"configured": True}}

    def _action_reset(self, params: Dict) -> Dict:
        self._store = MemoryStore()
        return {"success": True, "data": {"reset": True}}

    # CRUD
    def _action_store(self, params: Dict) -> Dict:
        memory = self._store.store(
            params.get("content", ""), params.get("type", MemoryType.FACT.value),
            int(params.get("importance", 3)), params.get("tags", []),
            params.get("source", ""), params.get("metadata")
        )
        self.audit("store", f"memory_id={memory['memory_id']}")
        return {"success": True, "data": memory}

    def _action_get(self, params: Dict) -> Dict:
        memory = self._store.get(params.get("memory_id", ""))
        if not memory:
            return {"success": False, "error": "Memory not found"}
        return {"success": True, "data": memory}

    def _action_update(self, params: Dict) -> Dict:
        memory = self._store.update(
            params.get("memory_id", ""), params.get("content"),
            int(params["importance"]) if "importance" in params else None,
            params.get("tags")
        )
        if not memory:
            return {"success": False, "error": "Memory not found"}
        return {"success": True, "data": memory}

    def _action_delete(self, params: Dict) -> Dict:
        ok = self._store.delete(params.get("memory_id", ""))
        return {"success": True, "data": {"deleted": ok}}

    def _action_list(self, params: Dict) -> Dict:
        memories = self._store.list_all(params.get("type"), int(params.get("limit", 100)))
        return {"success": True, "data": {"memories": memories, "total": len(memories)}}

    # 搜索
    def _action_search(self, params: Dict) -> Dict:
        results = self._store.search(
            params.get("query", ""), params.get("type"),
            params.get("tags"), int(params.get("min_importance", 0)),
            int(params.get("limit", 20))
        )
        return {"success": True, "data": {"results": results, "total": len(results)}}

    def _action_recall(self, params: Dict) -> Dict:
        """召回最相关的记忆（top-k）"""
        results = self._store.search(
            params.get("query", ""), limit=int(params.get("top_k", 5))
        )
        return {"success": True, "data": {"recalled": results}}

    # 管理
    def _action_decay_cleanup(self, params: Dict) -> Dict:
        removed = self._store.decay_cleanup(float(params.get("threshold", 0.01)))
        self.audit("decay_cleanup", f"removed={len(removed)}")
        return {"success": True, "data": {"removed_count": len(removed), "removed_ids": removed}}

    def _action_merge_similar(self, params: Dict) -> Dict:
        merged = self._store.merge_similar(float(params.get("threshold", 0.8)))
        return {"success": True, "data": {"merged_count": len(merged), "details": merged}}

    def _action_boost_importance(self, params: Dict) -> Dict:
        memory_id = params.get("memory_id", "")
        boost = int(params.get("boost", 1))
        memory = self._store.get(memory_id)
        if not memory:
            return {"success": False, "error": "Memory not found"}
        new_imp = min(5, memory["importance"] + boost)
        self._store.update(memory_id, importance=new_imp)
        return {"success": True, "data": {"memory_id": memory_id, "old": memory["importance"], "new": new_imp}}

    # 批量
    def _action_store_batch(self, params: Dict) -> Dict:
        items = params.get("items", [])
        stored = []
        for item in items:
            m = self._store.store(
                item.get("content", ""), item.get("type", MemoryType.FACT.value),
                int(item.get("importance", 3)), item.get("tags", []),
                item.get("source", ""), item.get("metadata")
            )
            stored.append(m["memory_id"])
        return {"success": True, "data": {"stored_count": len(stored), "memory_ids": stored}}

    def _action_export(self, params: Dict) -> Dict:
        memories = self._store.list_all(limit=int(params.get("limit", 10000)))
        export_data = [{"content": m["content"], "type": m["type"], "importance": m["importance"],
                        "tags": m["tags"], "source": m["source"], "created_at": m["created_at"]}
                       for m in memories]
        return {"success": True, "data": {"format": "json", "count": len(export_data),
                                           "memories": export_data}}

    def _action_import(self, params: Dict) -> Dict:
        items = params.get("items", [])
        stored = []
        for item in items:
            m = self._store.store(
                item.get("content", ""), item.get("type", MemoryType.FACT.value),
                int(item.get("importance", 3)), item.get("tags", []),
                item.get("source", "")
            )
            stored.append(m["memory_id"])
        return {"success": True, "data": {"imported_count": len(stored)}}

    def get_status(self) -> Dict[str, Any]:
        return {"module": "LongtermMemory", "state": "active",
                "memories": self._store.stats()["total"]}

module_class = LongtermMemory
