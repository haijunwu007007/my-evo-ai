"""schema_evolution - Enterprise Schema Evolution Module
AUTO-EVO-AI v6.39 | Grade: A | Category: 数据库
Schema迁移/Diff/回滚/历史追踪/兼容性检查
子引擎: MigrationPlanner(迁移计划生成+风险评估)
"""
import logging, hashlib, json, time, uuid, copy, threading
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum

from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)

logger = logging.getLogger(__name__)


class MigrationStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"


@dataclass
class SchemaField:
    name: str
    field_type: str
    nullable: bool = True
    default: Any = None
    comment: str = ""


@dataclass
class SchemaVersion:
    version: str
    schema: Dict[str, List[SchemaField]]
    checksum: str = ""
    created_at: str = ""
    author: str = ""

    def __post_init__(self):
        if not self.checksum:
            raw = json.dumps({k: [{"name": f.name, "type": f.field_type} for f in v]
                             for k, v in self.schema.items()}, sort_keys=True)
            self.checksum = hashlib.sha256(raw.encode()).hexdigest()[:16]
        if not self.created_at:
            self.created_at = datetime.now().isoformat()


@dataclass
class Migration:
    migration_id: str = ""
    from_version: str = ""
    to_version: str = ""
    status: MigrationStatus = MigrationStatus.PENDING
    changes: List[Dict[str, Any]] = field(default_factory=list)
    rollback_changes: List[Dict[str, Any]] = field(default_factory=list)
    created_at: str = ""
    executed_at: str = ""
    error: str = ""

    def __post_init__(self):
        if not self.migration_id:
            self.migration_id = str(uuid.uuid4())[:8]
        if not self.created_at:
            self.created_at = datetime.now().isoformat()


class MigrationPlanner:
    """迁移计划引擎 — Diff计算、计划生成、风险评估"""

    def diff_schemas(self, old: SchemaVersion, new: SchemaVersion) -> Dict[str, Any]:
        """比较两个schema版本的差异"""
        changes = []
        all_tables = set(old.schema.keys()) | set(new.schema.keys())
        for table in sorted(all_tables):
            old_fields = {f.name: f for f in old.schema.get(table, [])}
            new_fields = {f.name: f for f in new.schema.get(table, [])}
            for fname in sorted(set(old_fields.keys()) | set(new_fields.keys())):
                if fname not in old_fields:
                    changes.append({"table": table, "field": fname,
                                   "type": "ADD_COLUMN", "detail": new_fields[fname].field_type})
                elif fname not in new_fields:
                    changes.append({"table": table, "field": fname,
                                   "type": "DROP_COLUMN", "detail": old_fields[fname].field_type})
                elif old_fields[fname].field_type != new_fields[fname].field_type:
                    changes.append({"table": table, "field": fname, "type": "MODIFY_COLUMN",
                                   "detail": f"{old_fields[fname].field_type}->{new_fields[fname].field_type}"})
                elif old_fields[fname].nullable != new_fields[fname].nullable:
                    changes.append({"table": table, "field": fname, "type": "MODIFY_NULLABLE",
                                   "detail": f"nullable:{old_fields[fname].nullable}->{new_fields[fname].nullable}"})
            if table not in new.schema:
                changes.append({"table": table, "field": "", "type": "DROP_TABLE", "detail": table})
            elif table not in old.schema:
                changes.append({"table": table, "field": "", "type": "ADD_TABLE", "detail": table})
        return {
            "from_version": old.version, "to_version": new.version,
            "old_checksum": old.checksum, "new_checksum": new.checksum,
            "changes": changes, "total_changes": len(changes),
            "breaking": len([c for c in changes if c["type"] in ("DROP_TABLE", "DROP_COLUMN", "MODIFY_COLUMN")]),
        }

    def generate_plan(self, diff: Dict[str, Any]) -> Dict[str, Any]:
        """生成迁移计划(按依赖排序)"""
        changes = diff["changes"]
        # 先ADD_TABLE, 再ADD/MODIFY_COLUMN, 最后DROP
        add_tables = [c for c in changes if c["type"] == "ADD_TABLE"]
        add_cols = [c for c in changes if c["type"] == "ADD_COLUMN"]
        modify_cols = [c for c in changes if c["type"] in ("MODIFY_COLUMN", "MODIFY_NULLABLE")]
        drop_cols = [c for c in changes if c["type"] == "DROP_COLUMN"]
        drop_tables = [c for c in changes if c["type"] == "DROP_TABLE"]
        plan_steps = add_tables + add_cols + modify_cols + drop_cols + drop_tables
        risk_score = len([c for c in changes if c["type"] in ("DROP_TABLE", "DROP_COLUMN")]) * 30
        risk_score += len([c for c in changes if c["type"] == "MODIFY_COLUMN"]) * 10
        risk_score = min(100, risk_score)
        return {
            "steps": plan_steps, "total_steps": len(plan_steps),
            "risk_score": risk_score,
            "risk_level": "high" if risk_score >= 60 else "medium" if risk_score >= 30 else "low",
            "estimated_duration": f"{len(plan_steps) * 2}s",
            "rollback_available": True,
        }


class SchemaEvolution(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    AUTO-EVO-AI v6.39 - Schema演进模块
    管理数据库schema版本, diff, 迁移计划, 执行, 回滚, 历史追踪
    """

    MODULE_ID = "schema_evolution"
    MODULE_NAME = "SchemaEvolution"
    VERSION = "1.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._versions: Dict[str, SchemaVersion] = {}
        self._migrations: List[Migration] = []
        self._current_version: str = ""
        self._planner = MigrationPlanner()
        self._lock = threading.Lock()
        self._total_migrations = 0
        self._total_rollbacks = 0
        self._init_default()

    def _init_default(self):
        v0 = SchemaVersion(version="0.1.0", schema={}, author="system")
        self._versions["0.1.0"] = v0
        self._current_version = "0.1.0"

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                result = self._dispatch(action, params)
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                logger.error(f"[schema_evolution] {action} error: {e}")
                return {"success": False, "error": str(e), "action": action}

    def _dispatch(self, action: str, params: Dict[str, Any]) -> Any:
        handler = {
            "status": self._get_status, "stats": self._get_stats,
            "health": self.health_check, "reset": self._reset,
            "configure": self._configure,
            # 版本管理
            "register_version": self._register_version,
            "current_version": self._get_current_version,
            "list_versions": self._list_versions,
            "get_version": self._get_version,
            # Diff与计划
            "diff": self._diff,
            "plan": self._plan,
            # 迁移
            "migrate": self._migrate,
            "rollback": self._rollback,
            "list_migrations": self._list_migrations,
            # 兼容性
            "compatibility_check": self._compat_check,
            "breaking_changes": self._breaking_changes,
        }.get(action)
        if handler:
            return handler(params)
        return {"action": action, "module_id": self.MODULE_ID}

    def _register_version(self, params: Dict[str, Any]) -> Dict[str, Any]:
        version = params.get("version", "")
        schema_raw = params.get("schema", {})
        author = params.get("author", "system")
        if not version:
            return {"error": "version required"}
        if version in self._versions:
            return {"error": f"version {version} already exists"}
        schema = {}
        for table, fields in schema_raw.items():
            schema[table] = [SchemaField(**f) if isinstance(f, dict) else f for f in fields]
        sv = SchemaVersion(version=version, schema=schema, author=author)
        self._versions[version] = sv
        self.audit("register_version", f"version={version} checksum={sv.checksum}")
        return {"version": version, "checksum": sv.checksum, "tables": len(schema)}

    def _get_current_version(self, params: Dict[str, Any]) -> Dict[str, Any]:
        sv = self._versions.get(self._current_version)
        return {
            "current_version": self._current_version,
            "checksum": sv.checksum if sv else "",
            "tables": len(sv.schema) if sv else 0,
        }

    def _list_versions(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "versions": [{"version": v.version, "checksum": v.checksum,
                          "tables": len(v.schema), "author": v.author, "created_at": v.created_at}
                         for v in sorted(self._versions.values(), key=lambda x: x.version)],
            "current": self._current_version,
            "total": len(self._versions),
        }

    def _get_version(self, params: Dict[str, Any]) -> Dict[str, Any]:
        version = params.get("version", self._current_version)
        sv = self._versions.get(version)
        if not sv:
            return {"error": f"version {version} not found"}
        return {
            "version": sv.version, "checksum": sv.checksum,
            "schema": {t: [{"name": f.name, "type": f.field_type, "nullable": f.nullable} for f in fields]
                       for t, fields in sv.schema.items()},
            "author": sv.author, "created_at": sv.created_at,
        }

    def _diff(self, params: Dict[str, Any]) -> Dict[str, Any]:
        from_v = params.get("from", self._current_version)
        to_v = params.get("to", "")
        if not to_v:
            return {"error": "to_version required"}
        old = self._versions.get(from_v)
        new = self._versions.get(to_v)
        if not old or not new:
            return {"error": "version not found"}
        return self._planner.diff_schemas(old, new)

    def _plan(self, params: Dict[str, Any]) -> Dict[str, Any]:
        from_v = params.get("from", self._current_version)
        to_v = params.get("to", "")
        if not to_v:
            return {"error": "to_version required"}
        old = self._versions.get(from_v)
        new = self._versions.get(to_v)
        if not old or not new:
            return {"error": "version not found"}
        diff = self._planner.diff_schemas(old, new)
        plan = self._planner.generate_plan(diff)
        return {**diff, "plan": plan}

    def _migrate(self, params: Dict[str, Any]) -> Dict[str, Any]:
        to_v = params.get("to", "")
        if not to_v:
            return {"error": "to_version required"}
        if to_v not in self._versions:
            return {"error": f"version {to_v} not found"}
        old = self._versions.get(self._current_version)
        new = self._versions[to_v]
        if not old:
            return {"error": "current version not found"}
        diff = self._planner.diff_schemas(old, new)
        plan = self._planner.generate_plan(diff)
        mig = Migration(from_version=self._current_version, to_version=to_v,
                        changes=plan["steps"])
        mig.status = MigrationStatus.RUNNING
        self._migrations.append(mig)
        # 模拟执行
        try:
            mig.status = MigrationStatus.COMPLETED
            mig.executed_at = datetime.now().isoformat()
            prev = self._current_version
            self._current_version = to_v
            self._total_migrations += 1
            self.audit("migrate", f"from={prev} to={to_v} steps={len(plan['steps'])}")
            return {"migration_id": mig.migration_id, "from": prev, "to": to_v,
                    "steps_executed": len(plan["steps"]), "status": "completed"}
        except Exception as e:
            mig.status = MigrationStatus.FAILED
            mig.error = str(e)
            return {"migration_id": mig.migration_id, "status": "failed", "error": str(e)}

    def _rollback(self, params: Dict[str, Any]) -> Dict[str, Any]:
        migration_id = params.get("migration_id", "")
        if not migration_id:
            # 回滚最近一次
            completed = [m for m in self._migrations if m.status == MigrationStatus.COMPLETED]
            if not completed:
                return {"error": "no completed migration to rollback"}
            mig = completed[-1]
        else:
            mig = next((m for m in self._migrations if m.migration_id == migration_id), None)
            if not mig:
                return {"error": "migration not found"}
        target_v = mig.from_version
        if target_v not in self._versions:
            return {"error": f"rollback target {target_v} not found"}
        mig.status = MigrationStatus.ROLLED_BACK
        self._current_version = target_v
        self._total_rollbacks += 1
        self.audit("rollback", f"to={target_v} migration={mig.migration_id}")
        return {"rolled_back_to": target_v, "migration_id": mig.migration_id}

    def _list_migrations(self, params: Dict[str, Any]) -> Dict[str, Any]:
        limit = params.get("limit", 50)
        return {
            "migrations": [{"id": m.migration_id, "from": m.from_version,
                           "to": m.to_version, "status": m.status.value,
                           "steps": len(m.changes), "created_at": m.created_at,
                           "executed_at": m.executed_at, "error": m.error}
                          for m in self._migrations[-limit:]],
            "total": len(self._migrations),
        }

    def _compat_check(self, params: Dict[str, Any]) -> Dict[str, Any]:
        from_v = params.get("from", self._current_version)
        to_v = params.get("to", "")
        if not to_v or to_v not in self._versions:
            return {"error": "valid to_version required"}
        old = self._versions.get(from_v)
        new = self._versions.get(to_v)
        if not old:
            return {"compatible": True, "reason": "no baseline to compare"}
        breaking = 0
        for table, fields in old.schema.items():
            if table not in new.schema:
                breaking += 1
        return {
            "from": from_v, "to": to_v,
            "compatible": breaking == 0,
            "breaking_changes": breaking,
            "risk_level": "safe" if breaking == 0 else "breaking",
        }

    def _breaking_changes(self, params: Dict[str, Any]) -> Dict[str, Any]:
        result = self._diff(params)
        if "error" in result:
            return result
        breaking = [c for c in result["changes"] if c["type"] in ("DROP_TABLE", "DROP_COLUMN", "MODIFY_COLUMN")]
        return {"breaking_changes": breaking, "count": len(breaking)}

    def _get_status(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
            "version": self.VERSION, "status": "running",
            "current_version": self._current_version,
            "versions_count": len(self._versions),
            "migrations_count": len(self._migrations),
            "total_migrations": self._total_migrations,
            "total_rollbacks": self._total_rollbacks,
        }

    def _get_stats(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        by_status = defaultdict(int)
        for m in self._migrations:
            by_status[m.status.value] += 1
        return {
            "current_version": self._current_version,
            "versions": len(self._versions),
            "migrations": len(self._migrations),
            "total_migrations": self._total_migrations,
            "total_rollbacks": self._total_rollbacks,
            "by_status": dict(by_status),
        }

    def _reset(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        self._versions.clear()
        self._migrations.clear()
        self._init_default()
        return {"status": "reset_ok", "current_version": self._current_version}

    def _configure(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"configured": list(params.keys())}

    def health_check(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        failed = len([m for m in self._migrations if m.status == MigrationStatus.FAILED])
        return {
            "healthy": failed == 0,
            "status": "ok" if failed == 0 else "degraded",
            "failed_migrations": failed,
        }


module_class = SchemaEvolution
