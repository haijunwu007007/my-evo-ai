"""rate_limiter - Enterprise Rate Limiting Module
AUTO-EVO-AI v6.39 | Grade: A | Category: 安全监控
多算法限流: 滑动窗口/令牌桶/漏桶/固定窗口 + 白名单/黑名单/优先级
子引擎: RateLimitStrategyEngine(策略评估与推荐)
"""
import logging, hashlib, threading, time, math, re
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime, timedelta
from collections import defaultdict, OrderedDict
from dataclasses import dataclass, field

from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)

logger = logging.getLogger(__name__)


@dataclass
class RateLimitRule:
    """限流规则定义"""
    rule_id: str
    name: str
    algorithm: str = "sliding_window"  # sliding_window/token_bucket/leaky_bucket/fixed_window
    limit: int = 100
    window_seconds: int = 60
    burst: int = 0
    priority: int = 0  # 0=最高
    enabled: bool = True
    conditions: Dict[str, Any] = field(default_factory=dict)
    created_at: str = ""
    updated_at: str = ""

    def __post_init__(self):
        now = datetime.now().isoformat()
        if not self.created_at:
            self.created_at = now
        if not self.updated_at:
            self.updated_at = now


@dataclass
class TokenBucket:
    """令牌桶"""
    tokens: float = 0.0
    max_tokens: float = 100.0
    refill_rate: float = 1.0  # tokens per second
    last_refill: float = 0.0

    def consume(self, count: int = 1) -> bool:
        now = time.time()
        elapsed = now - self.last_refill
        self.tokens = min(self.max_tokens, self.tokens + elapsed * self.refill_rate)
        self.last_refill = now
        if self.tokens >= count:
            self.tokens -= count
            return True
        return False


@dataclass
class LeakyBucket:
    """漏桶"""
    water: float = 0.0
    capacity: float = 100.0
    leak_rate: float = 1.0  # requests per second
    last_leak: float = 0.0

    def consume(self, count: int = 1) -> bool:
        now = time.time()
        elapsed = now - self.last_leak
        self.water = max(0.0, self.water - elapsed * self.leak_rate)
        self.last_leak = now
        if self.water + count <= self.capacity:
            self.water += count
            return True
        return False


class RateLimitStrategyEngine:
    """
    限流策略引擎 — 策略评估、算法推荐、容量风险分析
    """

    def __init__(self, logger_ref=None):
        self._logger = logger_ref or logger
        self._metrics: Dict[str, List[float]] = defaultdict(list)
        self._violations: List[Dict] = []

    def record_request(self, key: str, allowed: bool, latency_ms: float = 0):
        """记录请求结果用于策略分析"""
        self._metrics[f"{key}:total"].append(time.time())
        if allowed:
            self._metrics[f"{key}:allowed"].append(time.time())
        else:
            self._metrics[f"{key}:rejected"].append(time.time())
            self._violations.append({
                "key": key, "time": datetime.now().isoformat(),
                "latency_ms": latency_ms
            })
        # 只保留最近1000条
        for mk in list(self._metrics.keys()):
            if len(self._metrics[mk]) > 1000:
                self._metrics[mk] = self._metrics[mk][-500:]
        if len(self._violations) > 500:
            self._violations = self._violations[-250:]

    def evaluate_strategy(self, key: str, window_sec: int = 60) -> Dict[str, Any]:
        """评估当前key的限流策略效果"""
        now = time.time()
        cutoff = now - window_sec
        total = [t for t in self._metrics.get(f"{key}:total", []) if t > cutoff]
        allowed = [t for t in self._metrics.get(f"{key}:allowed", []) if t > cutoff]
        rejected = [t for t in self._metrics.get(f"{key}:rejected", []) if t > cutoff]
        total_n = len(total)
        allowed_n = len(allowed)
        rejected_n = len(rejected)
        allow_rate = allowed_n / max(1, total_n) * 100
        # 请求频率
        if total_n >= 2:
            duration = max(1, total[-1] - total[0])
            avg_rps = total_n / duration
        else:
            avg_rps = 0
        # 拒绝趋势(最近10秒vs之前)
        recent_cutoff = now - 10
        recent_rejected = len([t for t in rejected if t > recent_cutoff])
        old_rejected = len([t for t in rejected if t > cutoff and t <= recent_cutoff])
        rejection_trend = "increasing" if recent_rejected > old_rejected * 2 else (
            "decreasing" if recent_rejected < old_rejected / 2 else "stable"
        )
        return {
            "key": key,
            "window_sec": window_sec,
            "total_requests": total_n,
            "allowed": allowed_n,
            "rejected": rejected_n,
            "allow_rate": round(allow_rate, 2),
            "avg_rps": round(avg_rps, 2),
            "rejection_trend": rejection_trend,
            "recommendation": self._recommend(key, avg_rps, allow_rate, rejection_trend)
        }

    def _recommend(self, key: str, avg_rps: float, allow_rate: float, trend: str) -> str:
        """根据流量模式推荐策略调整"""
        if allow_rate > 95 and avg_rps < 10:
            return f"当前限流过于宽松(avg {avg_rps:.1f}rps, 通过率{allow_rate:.1f}%), 建议降低limit或缩短窗口"
        if allow_rate < 50:
            return f"拒绝率过高({100-allow_rate:.1f}%), 建议: (1)提升limit (2)启用burst (3)对高优先级客户端白名单"
        if trend == "increasing":
            return "拒绝趋势上升, 建议提升limit或切换到令牌桶算法以平滑突发流量"
        if avg_rps > 100:
            return f"高流量场景(avg {avg_rps:.1f}rps), 建议使用令牌桶+burst组合"
        return "当前策略运行正常, 无需调整"

    def capacity_risk_report(self) -> Dict[str, Any]:
        """容量风险分析报告"""
        risks = []
        for key_prefix in set(k.split(":")[0] for k in self._metrics.keys()):
            key = key_prefix
            eval_result = self.evaluate_strategy(key, 300)
            if eval_result["allow_rate"] < 70:
                risks.append({
                    "key": key, "severity": "high",
                    "allow_rate": eval_result["allow_rate"],
                    "reason": f"通过率仅{eval_result['allow_rate']:.1f}%"
                })
            elif eval_result["rejection_trend"] == "increasing":
                risks.append({
                    "key": key, "severity": "medium",
                    "allow_rate": eval_result["allow_rate"],
                    "reason": "拒绝率上升趋势"
                })
        risks.sort(key=lambda x: (0 if x["severity"] == "high" else 1))
        return {
            "total_monitored_keys": len(set(k.split(":")[0] for k in self._metrics.keys())),
            "risk_count": len(risks),
            "risks": risks[:20],
            "total_violations_24h": len([v for v in self._violations
                if (time.time() - datetime.fromisoformat(v["time"]).timestamp()) < 86400])
        }


class RateLimiter(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    AUTO-EVO-AI v6.39 - 企业级限流模块
    多算法: sliding_window / token_bucket / leaky_bucket / fixed_window
    支持: 白名单/黑名单/优先级/动态规则/burst/配额
    """

    MODULE_ID = "rate_limiter"
    MODULE_NAME = "RateLimiter"
    VERSION = "1.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._operation_count = 0
        self._error_count = 0
        # 限流规则
        self._rules: Dict[str, RateLimitRule] = {}
        # 滑动窗口计数器 {key: [(timestamp, count), ...]}
        self._sliding_windows: Dict[str, List[float]] = defaultdict(list)
        # 固定窗口计数器 {key: {window_start: count}}
        self._fixed_windows: Dict[str, Dict[int, int]] = defaultdict(dict)
        # 令牌桶 {key: TokenBucket}
        self._token_buckets: Dict[str, TokenBucket] = {}
        # 漏桶 {key: LeakyBucket}
        self._leaky_buckets: Dict[str, LeakyBucket] = {}
        # 白名单/黑名单
        self._whitelist: set = set()
        self._blacklist: set = set()
        # 统计
        self._total_requests = 0
        self._total_allowed = 0
        self._total_rejected = 0
        self._lock = threading.Lock()
        # 策略引擎
        self._strategy_engine = RateLimitStrategyEngine(logger)
        # 默认规则
        self._init_default_rules()

    def _init_default_rules(self):
        """初始化默认限流规则"""
        defaults = [
            RateLimitRule("default_api", "默认API限流", "sliding_window", 100, 60),
            RateLimitRule("default_auth", "认证限流", "sliding_window", 10, 60),
            RateLimitRule("default_search", "搜索限流", "token_bucket", 50, 60, burst=10),
            RateLimitRule("default_upload", "上传限流", "leaky_bucket", 20, 60),
        ]
        for r in defaults:
            self._rules[r.rule_id] = r

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                result = self._dispatch(action, params)
                self._record_op("execute", action, True)
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                self._record_op("execute", action, False)
                logger.error(f"[rate_limiter] {action} error: {e}")
                return {"success": False, "error": str(e), "action": action}

    def _dispatch(self, action: str, params: Dict[str, Any]) -> Any:
        handler = {
            "status": self._get_status,
            "stats": self._get_stats,
            "health": self.health_check,
            "reset": self._reset,
            "configure": self._configure,
            # 限流操作
            "check": self._check_rate,
            "acquire": self._acquire_permit,
            # 规则管理
            "list_rules": self._list_rules,
            "add_rule": self._add_rule,
            "remove_rule": self._remove_rule,
            "update_rule": self._update_rule,
            # 白名单/黑名单
            "add_whitelist": self._add_whitelist,
            "remove_whitelist": self._remove_whitelist,
            "add_blacklist": self._add_blacklist,
            "remove_blacklist": self._remove_blacklist,
            "list_acl": self._list_acl,
            # 策略分析
            "strategy_eval": self._strategy_eval,
            "capacity_risk": self._capacity_risk,
            "violation_log": self._violation_log,
        }.get(action)
        if handler:
            return handler(params)
        return {"action": action, "params": params, "module_id": self.MODULE_ID}

    # ---- 限流核心 ----

    def _check_rate(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """检查限流(不消费配额)"""
        key = params.get("key", "default")
        rule_id = params.get("rule_id", "default_api")
        if key in self._blacklist:
            return {"allowed": False, "reason": "blacklisted", "key": key}
        if key in self._whitelist:
            return {"allowed": True, "reason": "whitelisted", "key": key}
        rule = self._rules.get(rule_id, self._rules.get("default_api"))
        if not rule or not rule.enabled:
            return {"allowed": True, "reason": "no_rule", "key": key}
        remaining = self._get_remaining(key, rule)
        return {
            "allowed": remaining > 0,
            "remaining": remaining,
            "limit": rule.limit,
            "algorithm": rule.algorithm,
            "key": key,
            "rule_id": rule.rule_id,
        }

    def _acquire_permit(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """获取限流许可(消费配额)"""
        key = params.get("key", "default")
        rule_id = params.get("rule_id", "default_api")
        count = params.get("count", 1)
        check = self._check_rate(params)
        with self._lock:
            self._total_requests += 1
            if not check["allowed"]:
                self._total_rejected += count
                self._strategy_engine.record_request(key, False)
                return {**check, "consumed": 0}
            self._total_allowed += count
            self._strategy_engine.record_request(key, True)
            self._consume(key, self._rules.get(rule_id, self._rules.get("default_api")), count)
            return {**check, "consumed": count}

    def _get_remaining(self, key: str, rule: RateLimitRule) -> int:
        """获取剩余配额"""
        now = time.time()
        if rule.algorithm == "sliding_window":
            window = self._sliding_windows[key]
            cutoff = now - rule.window_seconds
            # 清理过期
            while window and window[0] < cutoff:
                window.pop(0)
            return max(0, rule.limit - len(window) - int(rule.burst))
        elif rule.algorithm == "fixed_window":
            window_start = int(now / rule.window_seconds) * rule.window_seconds
            current = self._fixed_windows[key].get(window_start, 0)
            return max(0, rule.limit - current)
        elif rule.algorithm == "token_bucket":
            bucket = self._get_token_bucket(key, rule)
            return int(bucket.tokens)
        elif rule.algorithm == "leaky_bucket":
            bucket = self._get_leaky_bucket(key, rule)
            return int(bucket.capacity - bucket.water)
        return rule.limit

    def _consume(self, key: str, rule: RateLimitRule, count: int = 1):
        """消费配额"""
        now = time.time()
        if rule.algorithm == "sliding_window":
            for _ in range(count):
                self._sliding_windows[key].append(now)
            # 清理过期
            cutoff = now - rule.window_seconds
            while self._sliding_windows[key] and self._sliding_windows[key][0] < cutoff:
                self._sliding_windows[key].pop(0)
        elif rule.algorithm == "fixed_window":
            window_start = int(now / rule.window_seconds) * rule.window_seconds
            self._fixed_windows[key][window_start] = self._fixed_windows[key].get(window_start, 0) + count
        elif rule.algorithm == "token_bucket":
            bucket = self._get_token_bucket(key, rule)
            bucket.consume(count)
        elif rule.algorithm == "leaky_bucket":
            bucket = self._get_leaky_bucket(key, rule)
            bucket.consume(count)

    def _get_token_bucket(self, key: str, rule: RateLimitRule) -> TokenBucket:
        if key not in self._token_buckets:
            self._token_buckets[key] = TokenBucket(
                max_tokens=float(rule.limit + rule.burst),
                refill_rate=float(rule.limit) / rule.window_seconds,
                tokens=float(rule.limit),
                last_refill=time.time()
            )
        return self._token_buckets[key]

    def _get_leaky_bucket(self, key: str, rule: RateLimitRule) -> LeakyBucket:
        if key not in self._leaky_buckets:
            self._leaky_buckets[key] = LeakyBucket(
                capacity=float(rule.limit + rule.burst),
                leak_rate=float(rule.limit) / rule.window_seconds,
                last_leak=time.time()
            )
        return self._leaky_buckets[key]

    # ---- 规则管理 ----

    def _list_rules(self, params: Dict[str, Any]) -> Dict[str, Any]:
        rules = []
        for r in self._rules.values():
            rules.append({
                "rule_id": r.rule_id, "name": r.name, "algorithm": r.algorithm,
                "limit": r.limit, "window_seconds": r.window_seconds,
                "burst": r.burst, "priority": r.priority, "enabled": r.enabled,
                "conditions": r.conditions, "created_at": r.created_at
            })
        rules.sort(key=lambda x: x["priority"])
        return {"rules": rules, "total": len(rules)}

    def _add_rule(self, params: Dict[str, Any]) -> Dict[str, Any]:
        rule_id = params.get("rule_id", f"rule_{int(time.time())}")
        rule = RateLimitRule(
            rule_id=rule_id,
            name=params.get("name", rule_id),
            algorithm=params.get("algorithm", "sliding_window"),
            limit=params.get("limit", 100),
            window_seconds=params.get("window_seconds", 60),
            burst=params.get("burst", 0),
            priority=params.get("priority", 0),
            conditions=params.get("conditions", {}),
        )
        self._rules[rule_id] = rule
        self.audit("add_rule", f"rule={rule_id} algo={rule.algorithm} limit={rule.limit}")
        return {"rule_id": rule_id, "status": "created"}

    def _remove_rule(self, params: Dict[str, Any]) -> Dict[str, Any]:
        rule_id = params.get("rule_id", "")
        if rule_id in self._rules:
            del self._rules[rule_id]
            return {"rule_id": rule_id, "status": "removed"}
        return {"error": f"rule {rule_id} not found"}

    def _update_rule(self, params: Dict[str, Any]) -> Dict[str, Any]:
        rule_id = params.get("rule_id", "")
        rule = self._rules.get(rule_id)
        if not rule:
            return {"error": f"rule {rule_id} not found"}
        for field_name in ("name", "algorithm", "limit", "window_seconds", "burst", "priority", "enabled"):
            if field_name in params:
                setattr(rule, field_name, params[field_name])
        rule.updated_at = datetime.now().isoformat()
        self.audit("update_rule", f"rule={rule_id}")
        return {"rule_id": rule_id, "status": "updated"}

    # ---- ACL管理 ----

    def _add_whitelist(self, params: Dict[str, Any]) -> Dict[str, Any]:
        keys = params.get("keys", [])
        added = []
        for k in keys:
            if k not in self._whitelist:
                self._whitelist.add(k)
                added.append(k)
        return {"added": added, "total_whitelist": len(self._whitelist)}

    def _remove_whitelist(self, params: Dict[str, Any]) -> Dict[str, Any]:
        keys = params.get("keys", [])
        removed = []
        for k in keys:
            if k in self._whitelist:
                self._whitelist.discard(k)
                removed.append(k)
        return {"removed": removed, "total_whitelist": len(self._whitelist)}

    def _add_blacklist(self, params: Dict[str, Any]) -> Dict[str, Any]:
        keys = params.get("keys", [])
        added = []
        for k in keys:
            if k not in self._blacklist:
                self._blacklist.add(k)
                added.append(k)
        return {"added": added, "total_blacklist": len(self._blacklist)}

    def _remove_blacklist(self, params: Dict[str, Any]) -> Dict[str, Any]:
        keys = params.get("keys", [])
        removed = []
        for k in keys:
            if k in self._blacklist:
                self._blacklist.discard(k)
                removed.append(k)
        return {"removed": removed, "total_blacklist": len(self._blacklist)}

    def _list_acl(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "whitelist": sorted(self._whitelist),
            "blacklist": sorted(self._blacklist),
            "whitelist_count": len(self._whitelist),
            "blacklist_count": len(self._blacklist),
        }

    # ---- 策略分析 ----

    def _strategy_eval(self, params: Dict[str, Any]) -> Dict[str, Any]:
        key = params.get("key", "default")
        window = params.get("window", 60)
        return self._strategy_engine.evaluate_strategy(key, window)

    def _capacity_risk(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return self._strategy_engine.capacity_risk_report()

    def _violation_log(self, params: Dict[str, Any]) -> Dict[str, Any]:
        limit = params.get("limit", 50)
        key_filter = params.get("key", "")
        violations = self._strategy_engine._violations
        if key_filter:
            violations = [v for v in violations if v["key"] == key_filter]
        return {"violations": violations[-limit:], "total": len(violations)}

    # ---- 标准接口 ----

    def _get_status(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
            "version": self.VERSION, "status": "running",
            "rules_count": len(self._rules),
            "whitelist_count": len(self._whitelist),
            "blacklist_count": len(self._blacklist),
            "sliding_window_keys": len(self._sliding_windows),
            "token_bucket_keys": len(self._token_buckets),
            "leaky_bucket_keys": len(self._leaky_buckets),
            "fixed_window_keys": len(self._fixed_windows),
            "total_requests": self._total_requests,
            "total_allowed": self._total_allowed,
            "total_rejected": self._total_rejected,
        }

    def _get_stats(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "total_requests": self._total_requests,
            "total_allowed": self._total_allowed,
            "total_rejected": self._total_rejected,
            "allow_rate": round(self._total_allowed / max(1, self._total_requests) * 100, 2),
            "rules_count": len(self._rules),
            "active_keys": len(self._sliding_windows) + len(self._token_buckets) + len(self._leaky_buckets),
        }

    def _reset(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        with self._lock:
            self._sliding_windows.clear()
            self._fixed_windows.clear()
            self._token_buckets.clear()
            self._leaky_buckets.clear()
            self._total_requests = 0
            self._total_allowed = 0
            self._total_rejected = 0
        return {"status": "reset_ok"}

    def _configure(self, params: Dict[str, Any]) -> Dict[str, Any]:
        if "default_limit" in params:
            for r in self._rules.values():
                if "default" in r.rule_id:
                    r.limit = params["default_limit"]
        if "whitelist" in params:
            self._whitelist = set(params["whitelist"])
        if "blacklist" in params:
            self._blacklist = set(params["blacklist"])
        return {"configured": list(params.keys())}

    def health_check(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "healthy": self._total_requests == 0 or self._total_rejected / max(1, self._total_requests) < 0.5,
            "status": "ok",
            "rules_loaded": len(self._rules),
        }

    def _record_op(self, category: str, action: str, success: bool):
        self._operation_count += 1
        if not success:
            self._error_count += 1


module_class = RateLimiter
