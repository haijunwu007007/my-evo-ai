"""jwt_token - Enterprise JWT Token Management Module
AUTO-EVO-AI v6.39 | Grade: A | Category: 安全认证
JWT令牌签发/验证/刷新/吊销, 多租户, RBAC角色, 黑名单, 密钥轮转
子引擎: TokenAuditEngine(审计分析)
"""
import logging, hashlib, hmac, json, time, base64, threading, uuid
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime, timedelta
from collections import defaultdict
from dataclasses import dataclass, field

from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)

logger = logging.getLogger(__name__)


@dataclass
class TokenRecord:
    """令牌记录"""
    jti: str
    subject: str
    issuer: str
    claims: Dict[str, Any]
    issued_at: float
    expires_at: float
    revoked: bool = False
    revoke_reason: str = ""
    refresh_count: int = 0


class TokenAuditEngine:
    """令牌审计引擎 — 签发/撤销/异常检测"""

    def __init__(self):
        self._events: List[Dict] = []
        self._max_events = 2000

    def record(self, event_type: str, jti: str, subject: str, detail: str = ""):
        self._events.append({
            "type": event_type, "jti": jti, "subject": subject,
            "detail": detail, "time": datetime.now().isoformat()
        })
        if len(self._events) > self._max_events:
            self._events = self._events[-self._max_events:]

    def analyze(self, window_sec: int = 3600) -> Dict[str, Any]:
        cutoff = time.time() - window_sec
        events = [e for e in self._events
                  if (time.time() - datetime.fromisoformat(e["time"]).timestamp()) < window_sec]
        issued = [e for e in events if e["type"] == "issue"]
        revoked = [e for e in events if e["type"] == "revoke"]
        refresh = [e for e in events if e["type"] == "refresh"]
        failed = [e for e in events if e["type"] == "verify_failed"]
        # 异常检测: 同一subject短时间大量签发
        subject_counts: Dict[str, int] = defaultdict(int)
        for e in issued:
            subject_counts[e["subject"]] += 1
        suspicious = {s: c for s, c in subject_counts.items() if c > 10}
        return {
            "window_sec": window_sec,
            "total_events": len(events),
            "issued": len(issued),
            "revoked": len(revoked),
            "refreshed": len(refresh),
            "verify_failed": len(failed),
            "suspicious_subjects": suspicious,
            "active_tokens": len(set(e["jti"] for e in issued) - set(e["jti"] for e in revoked)),
        }

    def get_events(self, subject: str = "", limit: int = 50) -> List[Dict]:
        events = self._events
        if subject:
            events = [e for e in events if e["subject"] == subject]
        return events[-limit:]


class JwtToken(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    AUTO-EVO-AI v6.39 - JWT令牌管理模块
    纯Python HMAC-SHA256实现, 无外部依赖
    """

    MODULE_ID = "jwt_token"
    MODULE_NAME = "JwtToken"
    VERSION = "1.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._secret_keys: Dict[str, bytes] = {}
        self._active_key_id: str = "default"
        self._tokens: Dict[str, TokenRecord] = {}
        self._blacklist: set = set()
        self._refresh_tokens: Dict[str, str] = {}  # refresh_jti -> access_jti
        self._lock = threading.Lock()
        self._token_audit = TokenAuditEngine()
        self._total_issued = 0
        self._total_verified = 0
        self._total_revoked = 0
        self._total_failed = 0
        self._init_default_key()

    def _init_default_key(self):
        key_id = "default"
        secret = hashlib.sha256(f"auto-evo-jwt-{uuid.uuid4()}".encode()).digest()
        self._secret_keys[key_id] = secret
        self._active_key_id = key_id

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                result = self._dispatch(action, params)
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                self._total_failed += 1
                logger.error(f"[jwt_token] {action} error: {e}")
                return {"success": False, "error": str(e), "action": action}

    def _dispatch(self, action: str, params: Dict[str, Any]) -> Any:
        handler = {
            "status": self._get_status, "stats": self._get_stats,
            "health": self.health_check, "reset": self._reset,
            "configure": self._configure,
            # 令牌操作
            "issue": self._issue, "verify": self._verify,
            "refresh": self._refresh, "revoke": self._revoke,
            "decode": self._decode,
            # 密钥管理
            "rotate_key": self._rotate_key, "list_keys": self._list_keys,
            # 黑名单
            "blacklist_add": self._blacklist_add,
            "blacklist_remove": self._blacklist_remove,
            "blacklist_check": self._blacklist_check,
            "blacklist_list": self._blacklist_list,
            # 审计
            "audit_report": self._audit_report,
            "audit_events": self._audit_events,
            # 查询
            "token_info": self._token_info,
            "list_tokens": self._list_tokens,
        }.get(action)
        if handler:
            return handler(params)
        return {"action": action, "module_id": self.MODULE_ID}

    # ---- JWT核心(纯Python HMAC-SHA256) ----

    def _base64url_encode(self, data: bytes) -> str:
        return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

    def _base64url_decode(self, s: str) -> bytes:
        padding = 4 - len(s) % 4
        if padding != 4:
            s += "=" * padding
        return base64.urlsafe_b64decode(s)

    def _sign(self, header_b64: str, payload_b64: str, key: bytes) -> str:
        msg = f"{header_b64}.{payload_b64}".encode()
        sig = hmac.new(key, msg, hashlib.sha256).digest()
        return self._base64url_encode(sig)

    def _issue(self, params: Dict[str, Any]) -> Dict[str, Any]:
        subject = params.get("subject", "anonymous")
        claims = params.get("claims", {})
        ttl = params.get("ttl", 3600)
        issuer = params.get("issuer", "auto-evo")
        now = time.time()
        jti = str(uuid.uuid4())
        payload = {
            "sub": subject, "iss": issuer, "jti": jti,
            "iat": int(now), "exp": int(now + ttl),
            **claims
        }
        header = {"alg": "HS256", "typ": "JWT", "kid": self._active_key_id}
        h_b64 = self._base64url_encode(json.dumps(header).encode())
        p_b64 = self._base64url_encode(json.dumps(payload).encode())
        sig = self._sign(h_b64, p_b64, self._secret_keys[self._active_key_id])
        token = f"{h_b64}.{p_b64}.{sig}"
        record = TokenRecord(jti=jti, subject=subject, issuer=issuer,
                             claims=claims, issued_at=now, expires_at=now + ttl)
        with self._lock:
            self._tokens[jti] = record
            self._total_issued += 1
        self._token_audit.record("issue", jti, subject, f"ttl={ttl}")
        # audit via base class
        try:
            self.audit("issue_token", f"jti={jti} subject={subject} ttl={ttl}")
        except Exception:
            pass
        return {"token": token, "jti": jti, "expires_at": datetime.fromtimestamp(now + ttl).isoformat()}

    def _verify(self, params: Dict[str, Any]) -> Dict[str, Any]:
        token = params.get("token", "")
        parts = token.split(".")
        if len(parts) != 3:
            self._total_failed += 1
            self._token_audit.record("verify_failed", "", "", "malformed_token")
            return {"valid": False, "error": "malformed_token"}
        h_b64, p_b64, sig = parts
        try:
            header = json.loads(self._base64url_decode(h_b64))
        except Exception:
            return {"valid": False, "error": "invalid_header"}
        kid = header.get("kid", self._active_key_id)
        key = self._secret_keys.get(kid)
        if not key:
            return {"valid": False, "error": "unknown_key_id"}
        expected_sig = self._sign(h_b64, p_b64, key)
        if sig != expected_sig:
            self._total_failed += 1
            self._token_audit.record("verify_failed", "", "", "invalid_signature")
            return {"valid": False, "error": "invalid_signature"}
        payload = json.loads(self._base64url_decode(p_b64))
        jti = payload.get("jti", "")
        if jti in self._blacklist:
            return {"valid": False, "error": "token_revoked"}
        if time.time() > payload.get("exp", 0):
            return {"valid": False, "error": "token_expired"}
        with self._lock:
            self._total_verified += 1
        return {"valid": True, "payload": payload}

    def _decode(self, params: Dict[str, Any]) -> Dict[str, Any]:
        token = params.get("token", "")
        parts = token.split(".")
        if len(parts) != 3:
            return {"error": "malformed_token"}
        try:
            payload = json.loads(self._base64url_decode(parts[1]))
            return {"payload": payload}
        except Exception as e:
            return {"error": str(e)}

    def _refresh(self, params: Dict[str, Any]) -> Dict[str, Any]:
        old_token = params.get("token", "")
        old_verify = self._verify({"token": old_token})
        if not old_verify["valid"]:
            return {"error": old_verify.get("error", "invalid_token")}
        payload = old_verify["payload"]
        old_jti = payload.get("jti", "")
        with self._lock:
            if old_jti in self._tokens:
                self._tokens[old_jti].refresh_count += 1
        self._token_audit.record("refresh", old_jti, payload.get("sub", ""), "")
        new_result = self._issue({
            "subject": payload.get("sub", "anonymous"),
            "claims": payload.get("claims", {}),
            "ttl": params.get("ttl", 3600),
            "issuer": payload.get("iss", "auto-evo"),
        })
        return {"new_token": new_result["token"], "jti": new_result["jti"], "old_jti": old_jti}

    def _revoke(self, params: Dict[str, Any]) -> Dict[str, Any]:
        jti = params.get("jti", "")
        reason = params.get("reason", "manual")
        with self._lock:
            self._blacklist.add(jti)
            self._total_revoked += 1
            if jti in self._tokens:
                self._tokens[jti].revoked = True
                self._tokens[jti].revoke_reason = reason
        self._token_audit.record("revoke", jti, "", reason)
        self.audit("revoke_token", f"jti={jti} reason={reason}")
        return {"jti": jti, "revoked": True}

    # ---- 密钥管理 ----

    def _rotate_key(self, params: Dict[str, Any]) -> Dict[str, Any]:
        key_id = params.get("key_id", f"key_{int(time.time())}")
        secret = hashlib.sha256(f"auto-evo-jwt-rotated-{uuid.uuid4()}".encode()).digest()
        old_key_id = self._active_key_id
        self._secret_keys[key_id] = secret
        self._active_key_id = key_id
        self.audit("rotate_key", f"old={old_key_id} new={key_id}")
        return {"old_key_id": old_key_id, "new_key_id": key_id, "active": key_id}

    def _list_keys(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "keys": list(self._secret_keys.keys()),
            "active_key_id": self._active_key_id,
            "count": len(self._secret_keys),
        }

    # ---- 黑名单 ----

    def _blacklist_add(self, params: Dict[str, Any]) -> Dict[str, Any]:
        jtis = params.get("jtis", [])
        for j in jtis:
            self._blacklist.add(j)
        return {"added": len(jtis), "total_blacklisted": len(self._blacklist)}

    def _blacklist_remove(self, params: Dict[str, Any]) -> Dict[str, Any]:
        jtis = params.get("jtis", [])
        for j in jtis:
            self._blacklist.discard(j)
        return {"removed": len(jtis), "total_blacklisted": len(self._blacklist)}

    def _blacklist_check(self, params: Dict[str, Any]) -> Dict[str, Any]:
        jti = params.get("jti", "")
        return {"jti": jti, "blacklisted": jti in self._blacklist}

    def _blacklist_list(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"blacklisted_jtis": list(self._blacklist), "count": len(self._blacklist)}

    # ---- 审计 ----

    def _audit_report(self, params: Dict[str, Any]) -> Dict[str, Any]:
        window = params.get("window", 3600)
        return self._token_audit.analyze(window)

    def _audit_events(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"events": self._token_audit.get_events(params.get("subject", ""), params.get("limit", 50))}

    # ---- 查询 ----

    def _token_info(self, params: Dict[str, Any]) -> Dict[str, Any]:
        jti = params.get("jti", "")
        rec = self._tokens.get(jti)
        if not rec:
            return {"error": "token_not_found"}
        return {
            "jti": rec.jti, "subject": rec.subject, "issuer": rec.issuer,
            "claims": rec.claims, "issued_at": rec.issued_at,
            "expires_at": rec.expires_at, "revoked": rec.revoked,
            "refresh_count": rec.refresh_count,
        }

    def _list_tokens(self, params: Dict[str, Any]) -> Dict[str, Any]:
        subject = params.get("subject", "")
        limit = params.get("limit", 50)
        tokens = list(self._tokens.values())
        if subject:
            tokens = [t for t in tokens if t.subject == subject]
        tokens = tokens[-limit:]
        return {
            "tokens": [{"jti": t.jti, "subject": t.subject, "revoked": t.revoked,
                        "expires_at": t.expires_at} for t in tokens],
            "total": len(tokens),
        }

    # ---- 标准接口 ----

    def _get_status(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
            "version": self.VERSION, "status": "running",
            "active_key_id": self._active_key_id,
            "keys_count": len(self._secret_keys),
            "blacklisted": len(self._blacklist),
            "total_tokens": len(self._tokens),
            "total_issued": self._total_issued,
            "total_verified": self._total_verified,
            "total_revoked": self._total_revoked,
        }

    def _get_stats(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "total_issued": self._total_issued,
            "total_verified": self._total_verified,
            "total_revoked": self._total_revoked,
            "total_failed": self._total_failed,
            "active_tokens": len(self._tokens) - len(self._blacklist),
            "blacklisted": len(self._blacklist),
            "keys_count": len(self._secret_keys),
        }

    def _reset(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        with self._lock:
            self._tokens.clear()
            self._blacklist.clear()
            self._refresh_tokens.clear()
            self._total_issued = 0
            self._total_verified = 0
            self._total_revoked = 0
            self._total_failed = 0
        return {"status": "reset_ok"}

    def _configure(self, params: Dict[str, Any]) -> Dict[str, Any]:
        if "default_ttl" in params:
            self._data_cache["default_ttl"] = params["default_ttl"]
        return {"configured": list(params.keys())}

    def health_check(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {"healthy": True, "status": "ok", "keys_loaded": len(self._secret_keys)}


module_class = JwtToken
