"""
Read Write Split - Database Read/Write Traffic Routing
Routes queries to master/slave nodes with weight-based load balancing,
lag-aware routing, failover, and connection pooling.
"""

import time
import uuid
import random
import hashlib
import threading
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Tuple
from collections import defaultdict, deque
from enum import Enum, auto

from modules._base.enterprise_module import EnterpriseModule


class NodeType(Enum):
    MASTER = "master"
    SLAVE = "slave"


class NodeStatus(Enum):
    ONLINE = "online"
    OFFLINE = "offline"
    RECOVERY = "recovery"
    DRAINING = "draining"


class DBNode:
    def __init__(self, node_id: str, host: str, port: int, node_type: str, weight: int = 1):
        self.node_id = node_id
        self.host = host
        self.port = port
        self.node_type = node_type
        self.weight = weight
        self.status = "online"
        self.active_connections = 0
        self.max_connections = 100
        self.total_queries = 0
        self.total_errors = 0
        self.avg_latency_ms = 0.0
        self.replication_lag_ms = 0
        self.last_heartbeat = datetime.now(timezone.utc).isoformat()
        self.created_at = datetime.now(timezone.utc).isoformat()
        self.tags: List[str] = []

    def to_dict(self) -> Dict:
        return {"node_id": self.node_id, "host": self.host, "port": self.port,
                "node_type": self.node_type, "weight": self.weight,
                "status": self.status, "active_connections": self.active_connections,
                "max_connections": self.max_connections,
                "total_queries": self.total_queries, "total_errors": self.total_errors,
                "avg_latency_ms": self.avg_latency_ms,
                "replication_lag_ms": self.replication_lag_ms,
                "last_heartbeat": self.last_heartbeat}


class QueryRouter:
    """Route SQL queries to appropriate nodes based on type and policy."""

    def __init__(self):
        self.policy = "round_robin"
        self._rr_index = 0
        self._sticky_map: Dict[str, str] = {}

    def route(self, sql: str, nodes: List[DBNode], master: DBNode,
              max_lag_ms: int = 1000) -> Dict:
        is_write = self._is_write_query(sql)
        if is_write:
            return {"target_node": master.node_id, "target_host": master.host,
                    "target_port": master.port, "query_type": "write", "reason": "write_query"}
        candidates = [n for n in nodes if n.node_type == "slave" and n.status == "online"
                      and n.replication_lag_ms <= max_lag_ms
                      and n.active_connections < n.max_connections]
        if not candidates:
            candidates = [n for n in nodes if n.node_type == "slave" and n.status == "online"
                          and n.active_connections < n.max_connections]
        if not candidates:
            return {"target_node": master.node_id, "target_host": master.host,
                    "target_port": master.port, "query_type": "read",
                    "reason": "fallback_to_master"}
        if self.policy == "round_robin":
            node = candidates[self._rr_index % len(candidates)]
            self._rr_index += 1
        elif self.policy == "weighted":
            total_weight = sum(n.weight for n in candidates)
            r = random.randint(1, total_weight)
            cumulative = 0
            node = candidates[0]
            for n in candidates:
                cumulative += n.weight
                if r <= cumulative:
                    node = n
                    break
        elif self.policy == "least_connections":
            node = min(candidates, key=lambda x: x.active_connections)
        elif self.policy == "lowest_latency":
            node = min(candidates, key=lambda x: x.avg_latency_ms)
        else:
            node = candidates[0]
        return {"target_node": node.node_id, "target_host": node.host,
                "target_port": node.port, "query_type": "read", "reason": self.policy}

    @staticmethod
    def _is_write_query(sql: str) -> bool:
        keywords = ("INSERT", "UPDATE", "DELETE", "CREATE", "ALTER", "DROP", "TRUNCATE",
                     "REPLACE", "RENAME", "GRANT", "REVOKE")
        stripped = sql.strip().upper()
        return any(stripped.startswith(kw) for kw in keywords)


class ConnectionPool:
    """Lightweight connection pool simulation."""

    def __init__(self, pool_size: int = 20):
        self.pool_size = pool_size
        self._connections: Dict[str, int] = defaultdict(int)

    def acquire(self, node_id: str) -> bool:
        if self._connections[node_id] < self.pool_size:
            self._connections[node_id] += 1
            return True
        return False

    def release(self, node_id: str):
        if self._connections[node_id] > 0:
            self._connections[node_id] -= 1

    def stats(self) -> Dict:
        return {"pool_size": self.pool_size, "active": dict(self._connections),
                "total_active": sum(self._connections.values())}


class ReadWriteSplit(EnterpriseModule):
    MODULE_ID = "read_write_split"
    MODULE_NAME = "ReadWriteSplit"
    VERSION = "2.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._nodes: Dict[str, DBNode] = {}
        self._master_id: Optional[str] = None
        self._router = QueryRouter()
        self._pool = ConnectionPool()
        self._query_log: deque = deque(maxlen=5000)
        self._failover_history: List[Dict] = []
        self._operation_count = 0
        self._error_count = 0

    def execute(self, action: 

str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                handler = getattr(self, f"_action_{action}", None)
                if handler:
                    result = handler(params)
                else:
                    return {"success": False, "error": f"Unknown action: {action}"}
                self._operation_count += 1
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                self._error_count += 1
                return {"success": False, "error": str(e), "action": action}

    def _action_add_node(self, p: Dict) -> Dict:
        nid = p.get("node_id", f"node_{uuid.uuid4().hex[:8]}")
        node = DBNode(nid, p["host"], p.get("port", 5432), p.get("node_type", "slave"),
                      p.get("weight", 1))
        if p.get("max_connections"):
            node.max_connections = p["max_connections"]
        self._nodes[nid] = node
        if node.node_type == "master":
            self._master_id = nid
        return {"node_id": nid, "node_type": node.node_type}

    def _action_remove_node(self, p: Dict) -> Dict:
        nid = p.get("node_id", "")
        if nid not in self._nodes:
            return {"error": "Node not found"}
        if nid == self._master_id:
            self._master_id = None
        del self._nodes[nid]
        return {"node_id": nid, "removed": True}

    def _action_set_master(self, p: Dict) -> Dict:
        nid = p.get("node_id", "")
        if nid not in self._nodes:
            return {"error": "Node not found"}
        old_master = self._master_id
        if old_master and old_master in self._nodes:
            self._nodes[old_master].node_type = "slave"
        self._nodes[nid].node_type = "master"
        self._master_id = nid
        self._failover_history.append({"from": old_master, "to": nid,
                                        "timestamp": datetime.now(timezone.utc).isoformat()})
        return {"master_id": nid, "previous_master": old_master}

    def _action_route_query(self, p: Dict) -> Dict:
        sql = p.get("query", "")
        if not self._master_id:
            return {"error": "No master node configured"}
        master = self._nodes[self._master_id]
        all_slaves = [n for n in self._nodes.values() if n.node_type == "slave"]
        result = self._router.route(sql, all_slaves, master, p.get("max_lag_ms", 1000))
        node = self._nodes.get(result["target_node"])
        if node:
            node.total_queries += 1
            node.active_connections += 1
            self._pool.acquire(result["target_node"])
        self._query_log.append({"sql": sql[:200], "target": result["target_node"],
                                "type": result["query_type"],
                                "timestamp": datetime.now(timezone.utc).isoformat()})
        return result

    def _action_release_connection(self, p: Dict) -> Dict:
        nid = p.get("node_id", "")
        if nid in self._nodes:
            self._nodes[nid].active_connections = max(0, self._nodes[nid].active_connections - 1)
            self._pool.release(nid)
        return {"node_id": nid}

    def _action_update_lag(self, p: Dict) -> Dict:
        for nid, lag in p.get("lags", {}).items():
            if nid in self._nodes:
                self._nodes[nid].replication_lag_ms = lag
        return {"updated": list(p.get("lags", {}).keys())}

    def _action_set_policy(self, p: Dict) -> Dict:
        self._router.policy = p.get("policy", "round_robin")
        return {"policy": self._router.policy}

    def _action_get_policy(self, p: Dict) -> Dict:
        return {"policy": self._router.policy, "available": ["round_robin", "weighted", "least_connections", "lowest_latency"]}

    def _action_list_nodes(self, p: Dict) -> Dict:
        return {"nodes": [n.to_dict() for n in self._nodes.values()],
                "master_id": self._master_id, "count": len(self._nodes)}

    def _action_get_node(self, p: Dict) -> Dict:
        nid = p.get("node_id", "")
        if nid not in self._nodes:
            return {"error": "Node not found"}
        return self._nodes[nid].to_dict()

    def _action_failover(self, p: Dict) -> Dict:
        if not self._master_id:
            return {"error": "No master to failover from"}
        slaves = [n for n in self._nodes.values() if n.node_type == "slave" and n.status == "online"]
        if not slaves:
            return {"error": "No healthy slave for failover"}
        best = min(slaves, key=lambda x: x.replication_lag_ms)
        old_master = self._master_id
        if old_master in self._nodes:
            self._nodes[old_master].status = "offline"
        best.node_type = "master"
        self._master_id = best.node_id
        self._failover_history.append({"from": old_master, "to": best.node_id,
                                        "reason": p.get("reason", "manual"),
                                        "timestamp": datetime.now(timezone.utc).isoformat()})
        return {"old_master": old_master, "new_master": best.node_id, "status": "completed"}

    def _action_pool_stats(self, p: Dict) -> Dict:
        return self._pool.stats()

    def _action_query_history(self, p: Dict) -> Dict:
        limit = p.get("limit", 50)
        return {"history": list(self._query_log)[-limit:], "total": len(self._query_log)}

    def _action_stats(self, p: Dict) -> Dict:
        total_q = sum(n.total_queries for n in self._nodes.values())
        total_e = sum(n.total_errors for n in self._nodes.values())
        by_type = defaultdict(int)
        for n in self._nodes.values():
            by_type[n.node_type] += 1
        return {"total_nodes": len(self._nodes), "total_queries": total_q,
                "total_errors": total_e, "master_id": self._master_id,
                "policy": self._router.policy, "by_type": dict(by_type),
                "failover_count": len(self._failover_history),
                "pool": self._pool.stats()}

    def _action_status(self, p: Dict) -> Dict:
        return {"module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
                "version": self.VERSION, "nodes": len(self._nodes),
                "master_id": self._master_id, "policy": self._router.policy, "status": "running"}

    def _action_health(self, p: Dict) -> Dict:
        healthy = all(n.status == "online" for n in self._nodes.values()) if self._nodes else True
        return {"healthy": healthy, "master_available": self._master_id is not None,
                "slave_count": sum(1 for n in self._nodes.values() if n.node_type == "slave" and n.status == "online")}

    def _action_configure(self, p: Dict) -> Dict:
        return {"configured": list(p.keys()), "status": "ok"}

    def _action_reset(self, p: Dict) -> Dict:
        self._nodes.clear()
        self._master_id = None
        self._query_log.clear()
        self._failover_history.clear()
        return {"status": "reset_ok"}


module_class = ReadWriteSplit
