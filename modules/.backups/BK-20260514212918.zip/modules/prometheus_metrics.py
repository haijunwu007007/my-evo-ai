"""
Prometheus Metrics - 企业级Prometheus指标采集与聚合模块
生产级功能：多维度标签/Counter/Gauge/Histogram/Summary/指标注册/数据导出/告警规则
"""

import time
import math
import threading
import hashlib
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple
from collections import defaultdict
from enum import Enum

from modules._base.enterprise_module import EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin

module_class = "PrometheusMetrics"


class MetricType(Enum):
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"
    SUMMARY = "summary"


class AlertSeverity(Enum):
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


# ─── 核心数据结构 ──────────────────────────────────────────────

class MetricSample:
    """单个指标样本"""
    def __init__(self, name: str, labels: Dict[str, str], value: float):
        self.name = name
        self.labels = labels
        self.value = value
        self.timestamp = time.time()

    def label_key(self) -> str:
        return ",".join(f'{k}="{v}"' for k, v in sorted(self.labels.items()))

    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "labels": self.labels,
            "value": self.value,
            "timestamp": self.timestamp,
        }


class HistogramBucket:
    """Histogram桶"""
    def __init__(self, upper_bound: float):
        self.upper_bound = upper_bound
        self.count = 0

    def observe(self, value: float):
        if value <= self.upper_bound:
            self.count += 1


class PrometheusHistogram:
    """Histogram实现：分位数近似计算"""
    DEFAULT_BUCKETS = [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0]

    def __init__(self, name: str, help_text: str, labels: List[str], buckets: List[float] = None):
        self.name = name
        self.help_text = help_text
        self.label_names = labels
        self.buckets_def = sorted(buckets or self.DEFAULT_BUCKETS)
        # label_key -> {buckets, sum, count, observations}
        self._data: Dict[str, Dict] = {}

    def _get_or_create(self, label_vals: Dict[str, str]) -> Dict:
        key = ",".join(f'{k}="{label_vals.get(k,"")}"' for k in self.label_names)
        if key not in self._data:
            self._data[key] = {
                "labels": label_vals,
                "buckets": {b: 0 for b in self.buckets_def},
                "sum": 0.0,
                "count": 0,
                "observations": [],
            }
        return self._data[key]

    def observe(self, value: float, label_vals: Dict[str, str] = None):
        d = self._get_or_create(label_vals or {})
        d["sum"] += value
        d["count"] += 1
        d["observations"].append(value)
        if len(d["observations"]) > 10000:
            d["observations"] = d["observations"][-5000:]
        for b in self.buckets_def:
            if value <= b:
                d["buckets"][b] += 1

    def quantile(self, q: float, label_vals: Dict[str, str] = None) -> float:
        d = self._get_or_create(label_vals or {})
        obs = sorted(d["observations"])
        if not obs:
            return 0.0
        idx = int(q * len(obs))
        return obs[min(idx, len(obs) - 1)]

    def snapshot(self) -> List[Dict]:
        result = []
        for key, d in self._data.items():
            result.append({
                "labels": d["labels"],
                "buckets": d["buckets"],
                "sum": d["sum"],
                "count": d["count"],
                "p50": self.quantile(0.5, d["labels"]),
                "p90": self.quantile(0.9, d["labels"]),
                "p99": self.quantile(0.99, d["labels"]),
            })
        return result


# ─── 指标注册表 ──────────────────────────────────────────────

class MetricRegistry:
    """指标注册与存储"""

    def __init__(self):
        self._lock = threading.Lock()
        # name -> {type, help, label_names, samples: {label_key -> MetricSample}}
        self._metrics: Dict[str, Dict] = {}
        self._histograms: Dict[str, PrometheusHistogram] = {}

    def register(self, name: str, metric_type: str, help_text: str, label_names: List[str] = None) -> bool:
        with self._lock:
            if name in self._metrics:
                return False
            self._metrics[name] = {
                "type": metric_type,
                "help": help_text,
                "label_names": label_names or [],
                "samples": {},
                "created_at": datetime.utcnow().isoformat(),
            }
            if metric_type == MetricType.HISTOGRAM.value:
                self._histograms[name] = PrometheusHistogram(name, help_text, label_names or [])
            return True

    def inc(self, name: str, value: float = 1.0, labels: Dict[str, str] = None):
        labels = labels or {}
        with self._lock:
            if name not in self._metrics:
                return
            key = self._label_key(labels)
            existing = self._metrics[name]["samples"].get(key)
            if existing:
                existing.value += value
            else:
                self._metrics[name]["samples"][key] = MetricSample(name, labels, value)

    def set(self, name: str, value: float, labels: Dict[str, str] = None):
        labels = labels or {}
        with self._lock:
            if name not in self._metrics:
                return
            key = self._label_key(labels)
            self._metrics[name]["samples"][key] = MetricSample(name, labels, value)

    def observe(self, name: str, value: float, labels: Dict[str, str] = None):
        labels = labels or {}
        if name in self._histograms:
            self._histograms[name].observe(value, labels)
        self.inc(f"{name}_sum", value, labels)
        self.inc(f"{name}_count", 1, labels)

    def get(self, name: str) -> Optional[Dict]:
        with self._lock:
            return self._metrics.get(name)

    def list_names(self) -> List[str]:
        with self._lock:
            return list(self._metrics.keys())

    def _label_key(self, labels: Dict[str, str]) -> str:
        return ",".join(f'{k}="{v}"' for k, v in sorted(labels.items()))

    def export_text(self) -> str:
        """导出Prometheus文本格式"""
        lines = []
        with self._lock:
            for name, meta in self._metrics.items():
                lines.append(f"# HELP {name} {meta['help']}")
                lines.append(f"# TYPE {name} {meta['type']}")
                for key, sample in meta["samples"].items():
                    label_str = "{" + sample.label_key() + "}" if sample.labels else ""
                    lines.append(f"{name}{label_str} {sample.value} {int(sample.timestamp * 1000)}")
        return "\n".join(lines)

    def snapshot(self) -> Dict[str, Any]:
        result = {}
        with self._lock:
            for name, meta in self._metrics.items():
                result[name] = {
                    "type": meta["type"],
                    "help": meta["help"],
                    "samples": [s.to_dict() for s in meta["samples"].values()],
                }
        return result


# ─── 告警引擎 ──────────────────────────────────────────────────

class AlertRuleEngine:
    """Prometheus告警规则引擎"""

    def __init__(self):
        self._rules: Dict[str, Dict] = {}
        self._alert_history: List[Dict] = []
        self._lock = threading.Lock()

    def add_rule(self, rule_id: str, metric: str, condition: str,
                 threshold: float, severity: str, duration_s: int = 60) -> Dict:
        """
        添加告警规则
        condition: gt | lt | gte | lte | eq
        """
        with self._lock:
            self._rules[rule_id] = {
                "rule_id": rule_id,
                "metric": metric,
                "condition": condition,
                "threshold": threshold,
                "severity": severity,
                "duration_s": duration_s,
                "created_at": datetime.utcnow().isoformat(),
                "enabled": True,
                "fire_count": 0,
            }
        return {"rule_id": rule_id, "status": "added"}

    def evaluate(self, registry: MetricRegistry) -> List[Dict]:
        """评估所有规则，返回触发的告警"""
        alerts = []
        ops = {"gt": lambda a, b: a > b, "lt": lambda a, b: a < b,
               "gte": lambda a, b: a >= b, "lte": lambda a, b: a <= b,
               "eq": lambda a, b: a == b}
        with self._lock:
            for rule_id, rule in self._rules.items():
                if not rule["enabled"]:
                    continue
                meta = registry.get(rule["metric"])
                if not meta:
                    continue
                for sample in meta["samples"].values():
                    op = ops.get(rule["condition"], lambda a, b: False)
                    if op(sample.value, rule["threshold"]):
                        rule["fire_count"] += 1
                        alert = {
                            "rule_id": rule_id,
                            "metric": rule["metric"],
                            "labels": sample.labels,
                            "value": sample.value,
                            "threshold": rule["threshold"],
                            "condition": rule["condition"],
                            "severity": rule["severity"],
                            "fired_at": datetime.utcnow().isoformat(),
                        }
                        alerts.append(alert)
                        self._alert_history.append(alert)
                        if len(self._alert_history) > 2000:
                            self._alert_history = self._alert_history[-1000:]
        return alerts

    def list_rules(self) -> List[Dict]:
        with self._lock:
            return list(self._rules.values())

    def alert_history(self, limit: int = 100) -> List[Dict]:
        with self._lock:
            return self._alert_history[-limit:]

    def silence_rule(self, rule_id: str) -> bool:
        with self._lock:
            if rule_id in self._rules:
                self._rules[rule_id]["enabled"] = False
                return True
            return False


# ─── 主模块 ──────────────────────────────────────────────────

class PrometheusMetrics(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    AUTO-EVO-AI v6.39 — Prometheus Metrics Module (Production Grade)
    企业级指标采集、聚合、多维标签、文本导出、告警规则引擎
    """

    MODULE_ID = "prometheus_metrics"
    MODULE_NAME = "PrometheusMetrics"
    VERSION = "2.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._registry = MetricRegistry()
        self._alert_engine = AlertRuleEngine()
        self._lock = threading.Lock()
        self._scrape_history: List[Dict] = []
        self._scrape_count = 0
        self._register_system_metrics()

    def _register_system_metrics(self):
        """注册系统内置指标"""
        builtins = [
            ("process_cpu_seconds_total", MetricType.COUNTER.value, "CPU time consumed"),
            ("process_resident_memory_bytes", MetricType.GAUGE.value, "Resident memory size"),
            ("http_requests_total", MetricType.COUNTER.value, "Total HTTP requests", ["method", "status", "path"]),
            ("http_request_duration_seconds", MetricType.HISTOGRAM.value, "HTTP request latency", ["method", "path"]),
            ("go_goroutines", MetricType.GAUGE.value, "Number of goroutines"),
        ]
        for item in builtins:
            name, mtype, help_text = item[0], item[1], item[2]
            labels = item[3] if len(item) > 3 else []
            self._registry.register(name, mtype, help_text, labels)

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        return self._dispatch(action, params)

    def _dispatch(self, action: str, params: Dict) -> Dict[str, Any]:
        actions = {
            "status": self._action_status,
            "stats": self._action_stats,
            "health": self._action_health,
            "configure": self._action_configure,
            "reset": self._action_reset,
            # 指标管理
            "register_metric": self._action_register_metric,
            "list_metrics": self._action_list_metrics,
            "inc": self._action_inc,
            "set_gauge": self._action_set_gauge,
            "observe": self._action_observe,
            "get_metric": self._action_get_metric,
            "delete_metric": self._action_delete_metric,
            # 导出
            "export": self._action_export,
            "snapshot": self._action_snapshot,
            "scrape": self._action_scrape,
            "scrape_history": self._action_scrape_history,
            # 告警
            "add_alert_rule": self._action_add_alert_rule,
            "list_alert_rules": self._action_list_alert_rules,
            "evaluate_alerts": self._action_evaluate_alerts,
            "alert_history": self._action_alert_history,
            "silence_rule": self._action_silence_rule,
            # Histogram
            "histogram_observe": self._action_histogram_observe,
            "histogram_quantile": self._action_histogram_quantile,
        }
        handler = actions.get(action)
        if not handler:
            return {"success": False, "error": f"Unknown action: {action}", "available": list(actions.keys())}
        try:
            return handler(params)
        except Exception as e:
            self.logger.error(f"PrometheusMetrics.{action} error: {e}")
            return {"success": False, "error": str(e), "action": action}

    # ─── Status / Stats / Health ─────────────────────────────

    def _action_status(self, params: Dict) -> Dict:
        return {
            "success": True,
            "data": {
                "module": "PrometheusMetrics",
                "version": self.VERSION,
                "state": "active",
                "metrics_registered": len(self._registry.list_names()),
                "alert_rules": len(self._alert_engine.list_rules()),
                "scrape_count": self._scrape_count,
            }
        }

    def _action_stats(self, params: Dict) -> Dict:
        names = self._registry.list_names()
        return {
            "success": True,
            "data": {
                "total_metrics": len(names),
                "scrape_count": self._scrape_count,
                "alert_rules": len(self._alert_engine.list_rules()),
                "alert_history_size": len(self._alert_engine.alert_history(9999)),
            }
        }

    def _action_health(self, params: Dict) -> Dict:
        return {"success": True, "data": {"healthy": True, "registry_ok": True}}

    def _action_configure(self, params: Dict) -> Dict:
        return {"success": True, "data": {"configured": True}}

    def _action_reset(self, params: Dict) -> Dict:
        self._registry = MetricRegistry()
        self._alert_engine = AlertRuleEngine()
        self._scrape_count = 0
        self._register_system_metrics()
        return {"success": True, "data": {"reset": True}}

    # ─── 指标管理 ─────────────────────────────────────────────

    def _action_register_metric(self, params: Dict) -> Dict:
        name = params.get("name", "")
        metric_type = params.get("type", MetricType.GAUGE.value)
        help_text = params.get("help", "")
        label_names = params.get("labels", [])
        if not name:
            return {"success": False, "error": "name required"}
        ok = self._registry.register(name, metric_type, help_text, label_names)
        return {"success": True, "data": {"registered": ok, "name": name, "already_existed": not ok}}

    def _action_list_metrics(self, params: Dict) -> Dict:
        names = self._registry.list_names()
        metrics = []
        for n in names:
            m = self._registry.get(n)
            if m:
                metrics.append({"name": n, "type": m["type"], "help": m["help"],
                                 "sample_count": len(m["samples"])})
        return {"success": True, "data": {"metrics": metrics, "total": len(metrics)}}

    def _action_inc(self, params: Dict) -> Dict:
        name = params.get("name", "")
        value = float(params.get("value", 1.0))
        labels = params.get("labels", {})
        if not name:
            return {"success": False, "error": "name required"}
        self._registry.inc(name, value, labels)
        return {"success": True, "data": {"name": name, "incremented": value}}

    def _action_set_gauge(self, params: Dict) -> Dict:
        name = params.get("name", "")
        value = float(params.get("value", 0.0))
        labels = params.get("labels", {})
        if not name:
            return {"success": False, "error": "name required"}
        self._registry.set(name, value, labels)
        return {"success": True, "data": {"name": name, "value": value}}

    def _action_observe(self, params: Dict) -> Dict:
        name = params.get("name", "http_request_duration_seconds")
        value = float(params.get("value", 0.0))
        labels = params.get("labels", {})
        self._registry.observe(name, value, labels)
        return {"success": True, "data": {"name": name, "observed": value}}

    def _action_get_metric(self, params: Dict) -> Dict:
        name = params.get("name", "")
        if not name:
            return {"success": False, "error": "name required"}
        meta = self._registry.get(name)
        if not meta:
            return {"success": False, "error": f"Metric not found: {name}"}
        return {"success": True, "data": {
            "name": name, "type": meta["type"], "help": meta["help"],
            "samples": [s.to_dict() for s in meta["samples"].values()]
        }}

    def _action_delete_metric(self, params: Dict) -> Dict:
        name = params.get("name", "")
        with self._registry._lock:
            existed = name in self._registry._metrics
            self._registry._metrics.pop(name, None)
            self._registry._histograms.pop(name, None)
        return {"success": True, "data": {"deleted": existed, "name": name}}

    # ─── 导出 ─────────────────────────────────────────────────

    def _action_export(self, params: Dict) -> Dict:
        text = self._registry.export_text()
        return {"success": True, "data": {"format": "text/plain; version=0.0.4", "content": text,
                                           "lines": len(text.splitlines())}}

    def _action_snapshot(self, params: Dict) -> Dict:
        snap = self._registry.snapshot()
        return {"success": True, "data": {"snapshot": snap, "metric_count": len(snap)}}

    def _action_scrape(self, params: Dict) -> Dict:
        self._scrape_count += 1
        text = self._registry.export_text()
        record = {
            "scrape_id": self._scrape_count,
            "timestamp": datetime.utcnow().isoformat(),
            "bytes": len(text.encode()),
            "metric_families": len(self._registry.list_names()),
        }
        self._scrape_history.append(record)
        if len(self._scrape_history) > 500:
            self._scrape_history = self._scrape_history[-200:]
        return {"success": True, "data": record}

    def _action_scrape_history(self, params: Dict) -> Dict:
        limit = int(params.get("limit", 50))
        return {"success": True, "data": {"history": self._scrape_history[-limit:],
                                           "total": len(self._scrape_history)}}

    # ─── 告警 ─────────────────────────────────────────────────

    def _action_add_alert_rule(self, params: Dict) -> Dict:
        rule_id = params.get("rule_id", f"rule_{int(time.time())}")
        metric = params.get("metric", "")
        condition = params.get("condition", "gt")
        threshold = float(params.get("threshold", 0))
        severity = params.get("severity", AlertSeverity.WARNING.value)
        duration_s = int(params.get("duration_s", 60))
        if not metric:
            return {"success": False, "error": "metric required"}
        result = self._alert_engine.add_rule(rule_id, metric, condition, threshold, severity, duration_s)
        self.audit("add_alert_rule", f"rule_id={rule_id} metric={metric} threshold={threshold}")
        return {"success": True, "data": result}

    def _action_list_alert_rules(self, params: Dict) -> Dict:
        rules = self._alert_engine.list_rules()
        return {"success": True, "data": {"rules": rules, "total": len(rules)}}

    def _action_evaluate_alerts(self, params: Dict) -> Dict:
        alerts = self._alert_engine.evaluate(self._registry)
        return {"success": True, "data": {"alerts": alerts, "fired_count": len(alerts)}}

    def _action_alert_history(self, params: Dict) -> Dict:
        limit = int(params.get("limit", 100))
        history = self._alert_engine.alert_history(limit)
        return {"success": True, "data": {"history": history, "total": len(history)}}

    def _action_silence_rule(self, params: Dict) -> Dict:
        rule_id = params.get("rule_id", "")
        ok = self._alert_engine.silence_rule(rule_id)
        return {"success": True, "data": {"silenced": ok, "rule_id": rule_id}}

    # ─── Histogram ────────────────────────────────────────────

    def _action_histogram_observe(self, params: Dict) -> Dict:
        name = params.get("name", "http_request_duration_seconds")
        value = float(params.get("value", 0.0))
        labels = params.get("labels", {})
        if name not in self._registry._histograms:
            self._registry.register(name, MetricType.HISTOGRAM.value, f"Histogram: {name}")
        self._registry.observe(name, value, labels)
        return {"success": True, "data": {"name": name, "observed": value}}

    def _action_histogram_quantile(self, params: Dict) -> Dict:
        name = params.get("name", "http_request_duration_seconds")
        q = float(params.get("quantile", 0.99))
        labels = params.get("labels", {})
        hist = self._registry._histograms.get(name)
        if not hist:
            return {"success": False, "error": f"Histogram not found: {name}"}
        value = hist.quantile(q, labels)
        return {"success": True, "data": {"name": name, "quantile": q, "value": value}}

    def get_status(self) -> Dict[str, Any]:
        return {"module": "PrometheusMetrics", "state": "active",
                "metrics": len(self._registry.list_names())}

module_class = PrometheusMetrics
