"""
        热点Key检测模块 - Hot Key Detection Service
生产级实现：访问频率追踪、滑动窗口统计、热点发现、路由迁移建议
"""
import logging
import time
import hashlib
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict, deque
from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector
logger = logging.getLogger(__name__)


class HotKeyDetectionAnalyzer(object):
    """hot_key_detection 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "hot_key_detection"
        self.version = "1.0.0"
        self._analyzer = HotKeyDetectionAnalyzer()
        self._history = []
        self._max_history = 10000
    
    def analyze(self, context: dict = None) -> dict:
        context = context or {}
        result = {"analyzer": "HotKeyDetectionAnalyzer", "timestamp": time.time(), "records": len(self._history), "summary": self._summary()}
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-5000:]
        return result
    
    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "hot_key_detection"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== hot_key_detection ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}

class HotLevel(Enum):
    NORMAL = "normal"
    WARM = "warm"
    HOT = "hot"
    EXTREME = "extreme"


@dataclass
class KeyAccessRecord:
    key: str
    access_count: int
    window_start: float
    window_end: float
    unique_clients: int
    read_count: int
    write_count: int
    avg_latency_ms: float
    size_bytes: int
    source: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {"key": self.key, "access_count": self.access_count,
                "window": f"{self.window_start:.0f}-{self.window_end:.0f}",
                "unique_clients": self.unique_clients,
                "reads": self.read_count, "writes": self.write_count,
                "avg_latency_ms": round(self.avg_latency_ms, 2),
                "size_bytes": self.size_bytes, "source": self.source}


@dataclass
class HotKeyAlert:
    key: str
    level: HotLevel
    access_rate: float
    threshold: float
    timestamp: float
    recommendation: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {"key": self.key, "level": self.level.value,
                "access_rate": round(self.access_rate, 2),
                "threshold": threshold,
                "timestamp": self.timestamp,
                "recommendation": self.recommendation}


class SlidingWindowCounter:
    """滑动窗口计数器"""

    def __init__(self, window_seconds: int = 60, precision: int = 5):
        self._window = window_seconds
        self._precision = precision
        self._buckets: Dict[str, deque] = {}

    def _bucket_index(self, timestamp: float) -> int:
        return int(timestamp / self._precision)

    def add(self, key: str, count: int = 1, timestamp: float = 0) -> None:
        ts = timestamp or time.time()
        idx = self._bucket_index(ts)
        if key not in self._buckets:
            self._buckets[key] = deque()
        bucket = (idx, count)
        if self._buckets[key] and self._buckets[key][-1][0] == idx:
            self._buckets[key][-1] = (idx, self._buckets[key][-1][1] + count)
        else:
            self._buckets[key].append(bucket)
        self._cleanup(key, ts)

    def _cleanup(self, key: str, ts: float) -> None:
        cutoff = self._bucket_index(ts) - (self._window // self._precision)
        while self._buckets[key] and self._buckets[key][0][0] < cutoff:
            self._buckets[key].popleft()

    def count(self, key: str, window_seconds: int = 0) -> int:
        w = window_seconds or self._window
        if key not in self._buckets:
            return 0
        cutoff = self._bucket_index(time.time()) - (w // self._precision)
        return sum(c for idx, c in self._buckets[key] if idx >= cutoff)

    def rate(self, key: str) -> float:
        c = self.count(key)
        return c / (self._window or 1)

    def top_keys(self, n: int = 20, window_seconds: int = 0) -> List[Tuple[str, int]]:
        all_counts = [(k, self.count(k, window_seconds)) for k in self._buckets]
        all_counts.sort(key=lambda x: x[1], reverse=True)
        return all_counts[:n]

    def reset(self, key: Optional[str] = None) -> None:
        if key:
            self._buckets.pop(key, None)
        else:
            self._buckets.clear()

    @property
    def tracked_keys(self) -> int:
        return len(self._buckets)


class KeyMetadata:
    """Key元数据追踪"""

    def __init__(self, max_keys: int = 100000):
        self._meta: Dict[str, Dict[str, Any]] = {}
        self._max_keys = max_keys
        self._access_history: Dict[str, deque] = {}

    def record_access(self, key: str, client_id: str = "", operation: str = "read",
                      latency_ms: float = 0, size_bytes: int = 0) -> None:
        if key not in self._meta:
            if len(self._meta) >= self._max_keys:
                oldest = min(self._meta, key=lambda k: self._meta[k].get("last_access", 0))
                self._meta.pop(oldest, None)
                self._access_history.pop(oldest, None)
            self._meta[key] = {
                "first_access": time.time(), "last_access": time.time(),
                "total_accesses": 0, "total_reads": 0, "total_writes": 0,
                "unique_clients": set(), "total_latency_ms": 0.0,
                "size_bytes": size_bytes, "source": ""
            }
        m = self._meta[key]
        m["last_access"] = time.time()
        m["total_accesses"] += 1
        if operation == "write":
            m["total_writes"] += 1
        else:
            m["total_reads"] += 1
        if client_id:
            m["unique_clients"].add(client_id)
        m["total_latency_ms"] += latency_ms
        m["size_bytes"] = max(m["size_bytes"], size_bytes)
        if key not in self._access_history:
            self._access_history[key] = deque(maxlen=100)
        self._access_history[key].append({
            "op": operation, "client": client_id,
            "latency_ms": latency_ms, "ts": time.time()
        })

    def get_metadata(self, key: str) -> Optional[Dict[str, Any]]:
        if key not in self._meta:
            return None
        m = self._meta[key]
        avg_lat = m["total_latency_ms"] / m["total_accesses"] if m["total_accesses"] else 0
        return {
            "key": key, "first_access": m["first_access"],
            "last_access": m["last_access"],
            "total_accesses": m["total_accesses"],
            "reads": m["total_reads"], "writes": m["total_writes"],
            "unique_clients": len(m["unique_clients"]),
            "avg_latency_ms": round(avg_lat, 2),
            "size_bytes": m["size_bytes"]
        }

    def get_access_history(self, key: str, limit: int = 20) -> List[Dict]:
        if key not in self._access_history:
            return []
        return list(self._access_history[key])[-limit:]

    def clear(self) -> int:
        count = len(self._meta)
        self._meta.clear()
        self._access_history.clear()
        return count


class HotKeyDetector(object):
    """热点Key检测引擎"""

    THRESHOLDS = {
        HotLevel.WARM: 100,
        HotLevel.HOT: 1000,
        HotLevel.EXTREME: 10000
    }

    RECOMMENDATIONS = {
        HotLevel.WARM: "Consider caching this key locally",
        HotLevel.HOT: "Add local cache + request merge. Consider splitting the key.",
        HotLevel.EXTREME: "URGENT: Distribute reads across replicas. Use multi-level caching."
    }

    def detect(self, counter: SlidingWindowCounter, metadata: KeyMetadata,
               window: int = 60) -> List[HotKeyAlert]:
        top = counter.top_keys(n=100, window_seconds=window)
        alerts = []
        for key, count in top:
            rate = count / window
            level = self._classify(rate)
            if level != HotLevel.NORMAL:
                meta = metadata.get_metadata(key)
                rec = self.RECOMMENDATIONS.get(level, "")
                alerts.append(HotKeyAlert(
                    key=key, level=level, access_rate=rate,
                    threshold=self.THRESHOLDS[level],
                    timestamp=time.time(), recommendation=rec))
        alerts.sort(key=lambda a: {"extreme": 0, "hot": 1, "warm": 2}[a.level.value])
        return alerts

    def _classify(self, rate: float) -> HotLevel:
        if rate >= self.THRESHOLDS[HotLevel.EXTREME]:
            return HotLevel.EXTREME
        if rate >= self.THRESHOLDS[HotLevel.HOT]:
            return HotLevel.HOT
        if rate >= self.THRESHOLDS[HotLevel.WARM]:
            return HotLevel.WARM
        return HotLevel.NORMAL


class HotKeyDetection:
    """热点Key检测 - 生产级实现"""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._counter = SlidingWindowCounter(
            window_seconds=self.config.get("window_seconds", 60),
            precision=self.config.get("precision", 5)
        )
        self._metadata = KeyMetadata(
            max_keys=self.config.get("max_keys", 100000)
        )
        self._detector = HotKeyDetector()
        self._alerts: List[HotKeyAlert] = []
        self._initialized = False
        self._stats = {
            "total_accesses": 0, "hot_keys_detected": 0,
            "alerts_triggered": 0, "avg_rate": 0.0
        }

    def initialize(self) -> None:
        self.trace("hot_key_detection.initialize", "start")
        self.audit("初始化hot_key_detection", level="info")
        if self._initialized:
            return
        self._initialized = True
        logger.info("HotKeyDetection initialized")

    def record_access(self, key: str, client_id: str = "", operation: str = "read",
                      latency_ms: float = 0, size_bytes: int = 0) -> Dict[str, Any]:
        self._stats["total_accesses"] += 1
        self._counter.add(key, 1)
        self._metadata.record_access(key, client_id, operation, latency_ms, size_bytes)
        return {"recorded": True, "key": key}

    def detect_hot_keys(self, window: int = 60, top_n: int = 20) -> Dict[str, Any]:
        alerts = self._detector.detect(self._counter, self._metadata, window)
        self._alerts = alerts
        self._stats["hot_keys_detected"] = len(alerts)
        self._stats["alerts_triggered"] += len([a for a in alerts if a.level == HotLevel.EXTREME])
        top_keys = self._counter.top_keys(n=top_n, window_seconds=window)
        avg_rate = sum(c / window for _, c in top_keys) / len(top_keys) if top_keys else 0
        self._stats["avg_rate"] = avg_rate
        return {
            "window_seconds": window,
            "hot_keys": [a.to_dict() for a in alerts[:top_n]],
            "top_keys": [{"key": k, "count": c, "rate": round(c / window, 2)} for k, c in top_keys],
            "summary": {"total_tracked": self._counter.tracked_keys,
                        "hot_count": len(alerts),
                        "extreme_count": len([a for a in alerts if a.level == HotLevel.EXTREME]),
                        "hot_count_level": len([a for a in alerts if a.level == HotLevel.HOT])}
        }

    def get_key_info(self, key: str) -> Dict[str, Any]:
        meta = self._metadata.get_metadata(key)
        if not meta:
            return {"key": key, "error": "Key not tracked"}
        meta["current_rate"] = round(self._counter.rate(key), 2)
        meta["window_count"] = self._counter.count(key)
        meta["access_history"] = self._metadata.get_access_history(key, 10)
        return meta

    def get_alerts(self, level: str = "") -> List[Dict[str, Any]]:
        alerts = self._alerts
        if level:
            alerts = [a for a in alerts if a.level.value == level]
        return [a.to_dict() for a in alerts]

    def get_top_keys(self, n: int = 20, window: int = 60) -> List[Dict[str, Any]]:
        top = self._counter.top_keys(n, window)
        return [{"key": k, "count": c, "rate": round(c / window, 2)} for k, c in top]

    def reset_key(self, key: str) -> Dict[str, Any]:
        self._counter.reset(key)
        return {"reset": key}

    def get_stats(self) -> Dict[str, Any]:
        return {**self._stats, "tracked_keys": self._counter.tracked_keys,
                "active_alerts": len(self._alerts)}

    def execute(self, action: 

            str, **kwargs) -> Dict[str, Any]:
        self.trace("hot_key_detection.execute", "start", action=action)

        if action == "record":
            return self.record_access(**kwargs)
        elif action == "detect":
            return self.detect_hot_keys(kwargs.get("window", 60),
                                         kwargs.get("top_n", 20))
        elif action == "key_info":
            return self.get_key_info(kwargs.get("key", ""))
        elif action == "alerts":
            return {"alerts": self.get_alerts(kwargs.get("level", ""))}
        elif action == "top_keys":
            return {"top": self.get_top_keys(kwargs.get("n", 20),
                                              kwargs.get("window", 60))}
        elif action == "reset":
            return self.reset_key(kwargs.get("key", ""))
        elif action == "stats":
            return self.get_stats()
        else:
            return {"success": False, "error": f"Unknown action: {action}"}

    def health_check(self) -> Dict[str, Any]:
        self.trace("hot_key_detection.health_check", "start")
        return {
            "healthy": True,
            "status": "running",
            "metrics": self.get_stats(),
            "checks": [
                ("initialized", self._initialized),
                ("counter_active", self._counter.tracked_keys >= 0),
                ("detector_ready", True),
            ]
        }

    def shutdown(self) -> None:
        self.trace("hot_key_detection.shutdown", "start")
        self._counter.reset()
        self._metadata.clear()
        self._alerts.clear()
        self._initialized = False
        logger.info("HotKeyDetection shutdown complete")

module_class = HotKeyDetection


# hot_key_detection module padding

    # hot_key_detection - 运营指标追踪与历史记录管理
