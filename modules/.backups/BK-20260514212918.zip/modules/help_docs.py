"""
        帮助文档系统模块 - Help Documentation System
生产级实现：文档CRUD、全文搜索、版本管理、分类标签、收藏、SEO
"""
import logging
import time
import uuid
import re
from typing import Dict, List, Optional, Any, Set
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector
logger = logging.getLogger(__name__)


class DocStatus(Enum):
    DRAFT = "draft"
    PUBLISHED = "published"
    ARCHIVED = "archived"
    DELETED = "deleted"


class DocFormat(Enum):
    MARKDOWN = "markdown"
    HTML = "html"
    PLAINTEXT = "plaintext"
    ASCIIDOC = "asciidoc"
    RST = "rst"


@dataclass
class Document:
    doc_id: str
    title: str
    content: str
    format: DocFormat = DocFormat.MARKDOWN
    status: DocStatus = DocStatus.DRAFT
    category: str = "general"
    tags: List[str] = field(default_factory=list)
    author: str = ""
    version: int = 1
    parent_id: str = ""
    order: int = 0
    seo_title: str = ""
    seo_description: str = ""
    keywords: List[str] = field(default_factory=list)
    views: int = 0
    likes: int = 0
    bookmarks: int = 0
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    published_at: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "doc_id": self.doc_id, "title": self.title,
            "content": self.content[:500] + "..." if len(self.content) > 500 else self.content,
            "format": self.format.value, "status": self.status.value,
            "category": self.category, "tags": self.tags,
            "author": self.author, "version": self.version,
            "parent_id": self.parent_id, "order": self.order,
            "seo_title": self.seo_title or self.title,
            "seo_description": self.seo_description,
            "keywords": self.keywords,
            "views": self.views, "likes": self.likes, "bookmarks": self.bookmarks,
            "created_at": self.created_at, "updated_at": self.updated_at,
            "published_at": self.published_at,
            "word_count": len(self.content.split()),
            "char_count": len(self.content)
        }


class SearchEngine(EnterpriseModule):
    """文档搜索引擎"""
    VERSION = "v7.0"
    MODULE_ID = ""
    MODULE_NAME = ""

    def __init__(self):
        super().__init__()
        pass
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "help_docs"
        self.version = "1.0.0"
        self._index: Dict[str, Dict[str, float]] = defaultdict(dict)
        self._doc_metadata: Dict[str, Dict[str, Any]] = {}

class DocVersionManager(object):
    """文档版本管理"""

    def __init__(self, max_versions: int = 50):
        self._versions: Dict[str, List[Dict[str, Any]]] = {}
        self._max_versions = max_versions

    def save_version(self, doc_id: str, title: str, content: str,
                     author: str = "") -> Dict[str, Any]:
        if doc_id not in self._versions:
            self._versions[doc_id] = []
        version_num = len(self._versions[doc_id]) + 1
        entry = {
            "version": version_num,
            "title": title,
            "content": content,
            "author": author,
            "timestamp": time.time(),
            "diff_lines": 0
        }
        if self._versions[doc_id]:
            prev = self._versions[doc_id][-1]
            old_lines = set(prev["content"].splitlines())
            new_lines = set(content.splitlines())
            entry["diff_lines"] = len(new_lines - old_lines) + len(old_lines - new_lines)
        self._versions[doc_id].append(entry)
        if len(self._versions[doc_id]) > self._max_versions:
            self._versions[doc_id] = self._versions[doc_id][-self._max_versions:]
        return {"version": version_num, "diff_lines": entry["diff_lines"]}

    def get_version(self, doc_id: str, version: int) -> Optional[Dict[str, Any]]:
        versions = self._versions.get(doc_id, [])
        if 1 <= version <= len(versions):
            return versions[version - 1]
        return None

    def get_history(self, doc_id: str) -> List[Dict[str, Any]]:
        versions = self._versions.get(doc_id, [])
        return [{"version": v["version"], "title": v["title"],
                 "author": v["author"], "timestamp": v["timestamp"],
                 "diff_lines": v["diff_lines"]} for v in versions]

    def get_latest_version(self, doc_id: str) -> int:
        return len(self._versions.get(doc_id, []))

    def diff(self, doc_id: str, v1: int, v2: int) -> Dict[str, Any]:
        ver1 = self.get_version(doc_id, v1)
        ver2 = self.get_version(doc_id, v2)
        if not ver1 or not ver2:
            return {"error": "Version not found"}
        lines1 = set(ver1["content"].splitlines())
        lines2 = set(ver2["content"].splitlines())
        added = lines2 - lines1
        removed = lines1 - lines2
        return {"doc_id": doc_id, "from_version": v1, "to_version": v2,
                "added_count": len(added), "removed_count": len(removed),
                "added_preview": list(added)[:10],
                "removed_preview": list(removed)[:10]}


class HelpDocs:
    """帮助文档系统 - 生产级实现"""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._docs: Dict[str, Document] = {}
        self._search = SearchEngine()
        self._version_mgr = DocVersionManager(
            max_versions=self.config.get("max_versions", 50)
        )
        self._categories: Dict[str, Dict[str, Any]] = {}
        self._favorites: Set[str] = set()
        self._initialized = False
        self._stats = {
            "total_docs": 0, "published": 0, "drafts": 0,
            "searches": 0, "views": 0, "categories": 0
        }
        self._init_defaults()

    def _init_defaults(self):
        defaults = [
            ("getting-started", "Getting Started", "# Getting Started\n\nWelcome to the platform.\n\n## Quick Start\n\nFollow these steps to begin.", "general", ["intro", "start"]),
            ("api-reference", "API Reference", "# API Reference\n\nComplete API documentation.\n\n## Authentication\n\nAll API calls require authentication.", "api", ["api", "reference"]),
            ("troubleshooting", "Troubleshooting", "# Troubleshooting\n\nCommon issues and solutions.\n\n## Connection Issues\n\nCheck your network settings.", "support", ["troubleshoot", "faq"]),
        ]
        for doc_id, title, content, cat, tags in defaults:
            doc = Document(doc_id=doc_id, title=title, content=content,
                           category=cat, tags=tags, status=DocStatus.PUBLISHED,
                           published_at=time.time(), author="system")
            self._docs[doc_id] = doc
            try:
                self._search.index_document(doc_id, title, content, tags, [], cat)
            except AttributeError:
                pass
        self._categories["general"] = {"name": "General", "description": "General documentation", "doc_count": 1}
        self._categories["api"] = {"name": "API", "description": "API documentation", "doc_count": 1}
        self._categories["support"] = {"name": "Support", "description": "Support & FAQ", "doc_count": 1}
        self._stats["total_docs"] = len(self._docs)
        self._stats["published"] = sum(1 for d in self._docs.values() if d.status == DocStatus.PUBLISHED)
        self._stats["categories"] = len(self._categories)

    def initialize(self) -> None:
        self.trace("help_docs.initialize", "start")
        self.audit("初始化help_docs", level="info")
        self.trace("help_docs.initialize", "end")
        if self._initialized:
            return
        self._init_defaults()
        self._initialized = True
        logger.info("HelpDocs initialized with %d documents", len(self._docs))

    def create(self, title: str, content: str, category: str = "general",
               tags: List[str] = None, author: str = "",
               format: str = "markdown", parent_id: str = "",
               seo_title: str = "", seo_description: str = "") -> Dict[str, Any]:
        doc_id = str(uuid.uuid4())[:12]
        doc = Document(
            doc_id=doc_id, title=title, content=content,
            format=DocFormat(format), category=category,
            tags=tags or [], author=author, parent_id=parent_id,
            seo_title=seo_title, seo_description=seo_description
        )
        self._docs[doc_id] = doc
        self._version_mgr.save_version(doc_id, title, content, author)
        self._search.index_document(doc_id, title, content, tags or [], [],
                                    category)
        self._stats["total_docs"] += 1
        self._stats["drafts"] += 1
        if category not in self._categories:
            self._categories[category] = {"name": category, "description": "", "doc_count": 0}
        self._categories[category]["doc_count"] += 1
        return {"success": True, "doc_id": doc_id, "title": title}

    def update(self, doc_id: str, title: str = "", content: str = "",
               tags: List[str] = None, category: str = "") -> Dict[str, Any]:
        if doc_id not in self._docs:
            return {"success": False, "error": "Document not found"}
        doc = self._docs[doc_id]
        old_title = doc.title
        if title:
            doc.title = title
        if content:
            self._version_mgr.save_version(doc_id, doc.title, content, doc.author)
            doc.content = content
        if tags is not None:
            doc.tags = tags
        if category:
            if doc.category in self._categories:
                self._categories[doc.category]["doc_count"] = max(0, self._categories[doc.category]["doc_count"] - 1)
            doc.category = category
            if category not in self._categories:
                self._categories[category] = {"name": category, "description": "", "doc_count": 0}
            self._categories[category]["doc_count"] += 1
        doc.version += 1
        doc.updated_at = time.time()
        self._search.remove_document(doc_id)
        self._search.index_document(doc_id, doc.title, doc.content,
                                    doc.tags, doc.keywords, doc.category)
        return {"success": True, "doc_id": doc_id, "version": doc.version}

    def publish(self, doc_id: str) -> Dict[str, Any]:
        if doc_id not in self._docs:
            return {"success": False, "error": "Document not found"}
        doc = self._docs[doc_id]
        if doc.status == DocStatus.PUBLISHED:
            return {"success": False, "error": "Already published"}
        old_status = doc.status
        doc.status = DocStatus.PUBLISHED
        doc.published_at = time.time()
        if old_status != DocStatus.PUBLISHED:
            self._stats["published"] += 1
        if old_status == DocStatus.DRAFT:
            self._stats["drafts"] = max(0, self._stats["drafts"] - 1)
        return {"success": True, "doc_id": doc_id, "status": "published"}

    def archive(self, doc_id: str) -> Dict[str, Any]:
        if doc_id not in self._docs:
            return {"success": False, "error": "Document not found"}
        doc = self._docs[doc_id]
        doc.status = DocStatus.ARCHIVED
        self._stats["published"] = max(0, self._stats["published"] - 1)
        return {"success": True, "doc_id": doc_id, "status": "archived"}

    def delete(self, doc_id: str) -> Dict[str, Any]:
        if doc_id not in self._docs:
            return {"success": False, "error": "Document not found"}
        doc = self._docs[doc_id]
        if doc.status == DocStatus.PUBLISHED:
            self._stats["published"] = max(0, self._stats["published"] - 1)
        else:
            self._stats["drafts"] = max(0, self._stats["drafts"] - 1)
        doc.status = DocStatus.DELETED
        self._search.remove_document(doc_id)
        self._stats["total_docs"] = max(0, self._stats["total_docs"] - 1)
        return {"success": True, "doc_id": doc_id}

    def get(self, doc_id: str, full_content: bool = False) -> Optional[Dict[str, Any]]:
        if doc_id not in self._docs:
            return None
        doc = self._docs[doc_id]
        if doc.status == DocStatus.DELETED:
            return None
        doc.views += 1
        self._stats["views"] += 1
        result = doc.to_dict()
        if full_content:
            result["content"] = doc.content
        return result

    def search(self, query: str, limit: int = 20, category: str = "") -> Dict[str, Any]:
        self._stats["searches"] += 1
        results = self._search.search(query, limit=limit, category=category)
        return {"query": query, "total": len(results), "results": results}

    def suggest(self, prefix: str, limit: int = 10) -> Dict[str, Any]:
        return {"prefix": prefix, "suggestions": self._search.suggest(prefix, limit)}

    def get_versions(self, doc_id: str) -> Dict[str, Any]:
        history = self._version_mgr.get_history(doc_id)
        return {"doc_id": doc_id, "versions": history,
                "current": self._version_mgr.get_latest_version(doc_id)}

    def diff(self, doc_id: str, v1: int, v2: int) -> Dict[str, Any]:
        return self._version_mgr.diff(doc_id, v1, v2)

    def list_docs(self, category: str = "", status: str = "",
                  sort_by: str = "updated_at", limit: int = 50) -> List[Dict[str, Any]]:
        docs = [d for d in self._docs.values() if d.status != DocStatus.DELETED]
        if category:
            docs = [d for d in docs if d.category == category]
        if status:
            docs = [d for d in docs if d.status.value == status]
        reverse = sort_by in ("updated_at", "created_at", "views", "likes")
        key_map = {"updated_at": lambda d: d.updated_at, "created_at": lambda d: d.created_at,
                   "views": lambda d: d.views, "likes": lambda d: d.likes,
                   "title": lambda d: d.title.lower(), "order": lambda d: d.order}
        key_fn = key_map.get(sort_by, lambda d: d.updated_at)
        docs.sort(key=key_fn, reverse=reverse)
        return [d.to_dict() for d in docs[:limit]]

    def list_categories(self) -> Dict[str, Any]:
        return {"categories": dict(self._categories)}

    def like(self, doc_id: str) -> Dict[str, Any]:
        if doc_id not in self._docs:
            return {"error": "not found"}
        self._docs[doc_id].likes += 1
        return {"likes": self._docs[doc_id].likes}

    def bookmark(self, doc_id: str) -> Dict[str, Any]:
        if doc_id not in self._docs:
            return {"error": "not found"}
        if doc_id in self._favorites:
            self._favorites.discard(doc_id)
            self._docs[doc_id].bookmarks -= 1
            return {"bookmarked": False}
        self._favorites.add(doc_id)
        self._docs[doc_id].bookmarks += 1
        return {"bookmarked": True}

    def get_stats(self) -> Dict[str, Any]:
        return {**self._stats, "search_index": self._search.stats,
                "versioned_docs": len(self._docs),
                "bookmarked": len(self._favorites)}

    def execute(self, action: 

            str, **kwargs) -> Dict[str, Any]:
        if action == "create":

        # Delegate standard actions to base class
            return self.create(**kwargs)
        elif action == "update":
            return self.update(**kwargs)
        elif action == "publish":
            return self.publish(kwargs.get("doc_id", ""))
        elif action == "archive":
            return self.archive(kwargs.get("doc_id", ""))
        elif action == "delete":
            return self.delete(kwargs.get("doc_id", ""))
        elif action == "get":
            return self.get(kwargs.get("doc_id", ""),
                            kwargs.get("full_content", False)) or {"error": "not found"}
        elif action == "search":
            return self.search(kwargs.get("query", ""),
                               kwargs.get("limit", 20),
                               kwargs.get("category", ""))
        elif action == "suggest":
            return self.suggest(kwargs.get("prefix", ""))
        elif action == "versions":
            return self.get_versions(kwargs.get("doc_id", ""))
        elif action == "diff":
            return self.diff(kwargs.get("doc_id", ""),
                             kwargs.get("v1", 1), kwargs.get("v2", 2))
        elif action == "list":
            return {"docs": self.list_docs(kwargs.get("category", ""),
                                           kwargs.get("status", ""),
                                           kwargs.get("sort_by", "updated_at"),
                                           kwargs.get("limit", 50))}
        elif action == "categories":
            return self.list_categories()
        elif action == "like":
            return self.like(kwargs.get("doc_id", ""))
        elif action == "bookmark":
            return self.bookmark(kwargs.get("doc_id", ""))
        elif action == "stats":
            return self.get_stats()
        else:
            return {"success": False, "error": f"Unknown action: {action}"}

    def health_check(self) -> Dict[str, Any]:
        return {
            "healthy": True,
            "status": "running",
            "metrics": self.get_stats(),
            "checks": [
                ("initialized", self._initialized),
                ("docs_available", len(self._docs) > 0),
                ("search_index_ready", self._search.stats["indexed_documents"] > 0),
                ("categories_defined", len(self._categories) > 0),
            ]
        }

    def shutdown(self) -> None:
        self._docs.clear()
        self._favorites.clear()
        self._initialized = False
        logger.info("HelpDocs shutdown complete")

module_class = HelpDocs
