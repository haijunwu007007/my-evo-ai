"""
        地理空间索引模块 - Geospatial Index Service
生产级实现：GeoHash编码、空间查询、距离计算、边界搜索、区域管理
"""
import logging
import time
import math
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector
logger = logging.getLogger(__name__)

BASE32 = "0123456789bcdefghjkmnpqrstuvwxyz"
NEIGHBORS = {
    "right": {"even": "bc01fg45238967deuvhjyznpkmstqrwx"},
    "left": {"even": "238967debc01fg45uvhjyznpkmstqrwx"},
    "top": {"even": "p0r21436x8zb9dcf5h7kjnmqesgutwvy"},
    "bottom": {"even": "14365h7k9dcfesgujnmqp0r2twvyx8zb"},
    "right": {"odd": "p0r21436x8zb9dcf5h7kjnmqesgutwvy"},
    "left": {"odd": "14365h7k9dcfesgujnmqp0r2twvyx8zb"},
    "top": {"odd": "bc01fg45238967deuvhjyznpkmstqrwx"},
    "bottom": {"odd": "238967debc01fg45uvhjyznpkmstqrwx"},
}
BORDERS = {
    "right": {"even": "bcfguvyz", "odd": "prxz"},
    "left": {"even": "0145hjnp", "odd": "028b"},
    "top": {"even": "prxz", "odd": "bcfguvyz"},
    "bottom": {"even": "028b", "odd": "0145hjnp"},
}


class GeoIndexAnalyzer(object):
    """geo_index 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "geo_index"
        self.version = "1.0.0"
        self._analyzer = GeoIndexAnalyzer()
        self._history = []
        self._max_history = 10000
    
    def analyze(self, context: dict = None) -> dict:
        context = context or {}
        result = {"analyzer": "GeoIndexAnalyzer", "timestamp": time.time(), "records": len(self._history), "summary": self._summary()}
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-5000:]
        return result
    
    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "geo_index"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== geo_index ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}

class GeoUnit(Enum):
    KILOMETERS = "km"
    MILES = "mi"
    METERS = "m"
    NAUTICAL = "nm"


@dataclass
class GeoPoint:
    lat: float
    lng: float
    properties: Dict[str, Any] = field(default_factory=dict)
    point_id: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.point_id, "lat": round(self.lat, 6),
                "lng": round(self.lng, 6), "properties": self.properties}


@dataclass
class GeoRect:
    min_lat: float
    min_lng: float
    max_lat: float
    max_lng: float

    def contains(self, point: GeoPoint) -> bool:
        return (self.min_lat <= point.lat <= self.max_lat and
                self.min_lng <= point.lng <= self.max_lng)

    def to_dict(self) -> Dict[str, Any]:
        return {"min_lat": self.min_lat, "min_lng": self.min_lng,
                "max_lat": self.max_lat, "max_lng": self.max_lng}


@dataclass
class GeoCircle:
    center_lat: float
    center_lng: float
    radius: float
    unit: GeoUnit = GeoUnit.KILOMETERS


class GeoHash:
    """GeoHash编解码器"""

    @staticmethod
    def encode(lat: float, lng: float, precision: int = 12) -> str:
        lat_range = [-90.0, 90.0]
        lng_range = [-180.0, 180.0]
        geohash = []
        bits = 0
        bit_count = 0
        ch = 0
        is_lng = True
        while len(geohash) < precision:
            if is_lng:
                mid = (lng_range[0] + lng_range[1]) / 2
                if lng > mid:
                    ch = ch * 2 + 1
                    lng_range[0] = mid
                else:
                    ch = ch * 2
                    lng_range[1] = mid
            else:
                mid = (lat_range[0] + lat_range[1]) / 2
                if lat > mid:
                    ch = ch * 2 + 1
                    lat_range[0] = mid
                else:
                    ch = ch * 2
                    lat_range[1] = mid
            is_lng = not is_lng
            bit_count += 1
            if bit_count == 5:
                geohash.append(BASE32[ch])
                bit_count = 0
                ch = 0
        return "".join(geohash)

    @staticmethod
    def decode(geohash: str) -> Tuple[float, float, GeoRect]:
        lat_range = [-90.0, 90.0]
        lng_range = [-180.0, 180.0]
        is_lng = True
        for ch in geohash:
            idx = BASE32.index(ch)
            for bit_pos in range(4, -1, -1):
                bit = (idx >> bit_pos) & 1
                if is_lng:
                    mid = (lng_range[0] + lng_range[1]) / 2
                    if bit:
                        lng_range[0] = mid
                    else:
                        lng_range[1] = mid
                else:
                    mid = (lat_range[0] + lat_range[1]) / 2
                    if bit:
                        lat_range[0] = mid
                    else:
                        lat_range[1] = mid
                is_lng = not is_lng
        center_lat = (lat_range[0] + lat_range[1]) / 2
        center_lng = (lng_range[0] + lng_range[1]) / 2
        return center_lat, center_lng, GeoRect(
            min_lat=lat_range[0], max_lat=lat_range[1],
            min_lng=lng_range[0], max_lng=lng_range[1])

    @staticmethod
    def neighbors(geohash: str) -> Dict[str, str]:
        lat, lng, _ = GeoHash.decode(geohash)
        precision = len(geohash)
        lat_delta = (90.0 / (2 ** (5 * precision // 2))) * 1.5
        lng_delta = (180.0 / (2 ** (5 * (precision + 1) // 2))) * 1.5
        positions = {
            "n": (lat + lat_delta, lng), "s": (lat - lat_delta, lng),
            "e": (lat, lng + lng_delta), "w": (lat, lng - lng_delta),
            "ne": (lat + lat_delta, lng + lng_delta),
            "nw": (lat + lat_delta, lng - lng_delta),
            "se": (lat - lat_delta, lng + lng_delta),
            "sw": (lat - lat_delta, lng - lng_delta),
        }
        return {k: GeoHash.encode(la, ln, precision)
                for k, (la, ln) in positions.items()}


class DistanceCalculator:
    """距离计算器（Haversine公式）"""

    EARTH_RADIUS_KM = 6371.0

    @classmethod
    def haversine(cls, lat1: float, lng1: float, lat2: float, lng2: float,
                  unit: GeoUnit = GeoUnit.KILOMETERS) -> float:
        rlat1, rlat2 = math.radians(lat1), math.radians(lat2)
        dlat = math.radians(lat2 - lat1)
        dlng = math.radians(lng2 - lng1)
        a = math.sin(dlat / 2) ** 2 + math.cos(rlat1) * math.cos(rlat2) * math.sin(dlng / 2) ** 2
        c = 2 * math.asin(math.sqrt(a))
        dist_km = cls.EARTH_RADIUS_KM * c
        multipliers = {
            GeoUnit.KILOMETERS: 1.0, GeoUnit.MILES: 0.621371,
            GeoUnit.METERS: 1000.0, GeoUnit.NAUTICAL: 0.539957
        }
        return dist_km * multipliers.get(unit, 1.0)

    @classmethod
    def bounding_box(cls, lat: float, lng: float, radius: float,
                     unit: GeoUnit = GeoUnit.KILOMETERS) -> GeoRect:
        radius_km = radius
        if unit == GeoUnit.MILES:
            radius_km *= 1.60934
        elif unit == GeoUnit.NAUTICAL:
            radius_km *= 1.852
        elif unit == GeoUnit.METERS:
            radius_km /= 1000.0
        r = cls.EARTH_RADIUS_KM
        dlat = radius_km / r * (180.0 / math.pi)
        dlng = dlat / math.cos(math.radians(lat))
        return GeoRect(
            min_lat=lat - dlat, max_lat=lat + dlat,
            min_lng=lng - dlng, max_lng=lng + dlng)


class SpatialIndex:
    """空间索引（基于GeoHash网格）"""

    def __init__(self, hash_precision: int = 6):
        self._precision = hash_precision
        self._cells: Dict[str, List[GeoPoint]] = defaultdict(list)
        self._all_points: Dict[str, GeoPoint] = {}
        self._total_points = 0

    def insert(self, point: GeoPoint) -> str:
        if not point.point_id:
            point.point_id = str(len(self._all_points))
        gh = GeoHash.encode(point.lat, point.lng, self._precision)
        self._cells[gh].append(point)
        self._all_points[point.point_id] = point
        self._total_points += 1
        return gh

    def remove(self, point_id: str) -> bool:
        if point_id not in self._all_points:
            return False
        point = self._all_points.pop(point_id)
        gh = GeoHash.encode(point.lat, point.lng, self._precision)
        cell = self._cells.get(gh, [])
        self._cells[gh] = [p for p in cell if p.point_id != point_id]
        if not self._cells[gh]:
            del self._cells[gh]
        self._total_points -= 1
        return True

    def radius_search(self, lat: float, lng: float, radius: float,
                      unit: GeoUnit = GeoUnit.KILOMETERS) -> List[GeoPoint]:
        bbox = DistanceCalculator.bounding_box(lat, lng, radius, unit)
        center_gh = GeoHash.encode(lat, lng, self._precision)
        neighbor_ghs = set(GeoHash.neighbors(center_gh).values())
        neighbor_ghs.add(center_gh)
        candidates = []
        for gh in neighbor_ghs:
            for pt in self._cells.get(gh, []):
                if bbox.contains(pt):
                    dist = DistanceCalculator.haversine(lat, lng, pt.lat, pt.lng, unit)
                    if dist <= radius:
                        pt.properties["_distance"] = round(dist, 4)
                        candidates.append(pt)
        candidates.sort(key=lambda p: p.properties.get("_distance", 0))
        return candidates

    def rect_search(self, rect: GeoRect) -> List[GeoPoint]:
        results = []
        for pt in self._all_points.values():
            if rect.contains(pt):
                results.append(pt)
        return results

    def nearest(self, lat: float, lng: float, n: int = 5,
                unit: GeoUnit = GeoUnit.KILOMETERS) -> List[Dict[str, Any]]:
        all_pts = []
        for pt in self._all_points.values():
            dist = DistanceCalculator.haversine(lat, lng, pt.lat, pt.lng, unit)
            all_pts.append({"point": pt, "distance": round(dist, 4)})
        all_pts.sort(key=lambda x: x["distance"])
        return all_pts[:n]

    @property
    def total_points(self) -> int:
        return self._total_points

    @property
    def cell_count(self) -> int:
        return len(self._cells)


class GeoIndex:

    def trace(self, name, *args, **kwargs):

        class _NS:

            def __enter__(self): return self

            def __exit__(self, *a): pass

            def set_tag(self, *a): pass

            def log_kv(self, *a): pass

            def finish(self): pass

        return _NS()


    """地理空间索引服务 - 生产级实现"""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._index = SpatialIndex(
            hash_precision=self.config.get("hash_precision", 6)
        )
        self._regions: Dict[str, GeoRect] = {}
        self._initialized = False
        self._stats = {
            "points_indexed": 0, "radius_searches": 0,
            "rect_searches": 0, "nearest_queries": 0,
            "regions_defined": 0, "geohash_computes": 0,
            "errors": 0
        }

    def initialize(self) -> None:
        self.trace("geo_index.initialize", "start")
        self.audit("初始化geo_index", level="info")
        if self._initialized:
            return
        self._initialized = True
        logger.info("GeoIndex initialized")

    def add_point(self, lat: float, lng: float, point_id: str = "",
                  properties: Dict = None) -> Dict[str, Any]:
        if not (-90 <= lat <= 90) or not (-180 <= lng <= 180):
            return {"success": False, "error": "Invalid coordinates"}
        point = GeoPoint(lat=lat, lng=lng, point_id=point_id,
                         properties=properties or {})
        gh = self._index.insert(point)
        self._stats["points_indexed"] += 1
        return {"success": True, "point_id": point.point_id, "geohash": gh}

    def remove_point(self, point_id: str) -> Dict[str, Any]:
        ok = self._index.remove(point_id)
        if ok:
            return {"success": True, "removed": point_id}
        return {"success": False, "error": "Point not found"}

    def radius_search(self, lat: float, lng: float, radius: float,
                      unit: str = "km", limit: int = 100) -> Dict[str, Any]:
        u = GeoUnit(unit)
        self._stats["radius_searches"] += 1
        results = self._index.radius_search(lat, lng, radius, u)[:limit]
        return {"success": True, "center": {"lat": lat, "lng": lng},
                "radius": radius, "unit": unit, "count": len(results),
                "results": [p.to_dict() for p in results]}

    def rect_search(self, min_lat: float, min_lng: float,
                    max_lat: float, max_lng: float) -> Dict[str, Any]:
        rect = GeoRect(min_lat=min_lat, min_lng=min_lng,
                       max_lat=max_lat, max_lng=max_lng)
        self._stats["rect_searches"] += 1
        results = self._index.rect_search(rect)
        return {"success": True, "bounds": rect.to_dict(),
                "count": len(results),
                "results": [p.to_dict() for p in results]}

    def nearest(self, lat: float, lng: float, n: int = 5,
                unit: str = "km") -> Dict[str, Any]:
        self._stats["nearest_queries"] += 1
        results = self._index.nearest(lat, lng, n, GeoUnit(unit))
        return {"success": True, "count": len(results),
                "results": [{"point": r["point"].to_dict(), "distance": r["distance"]}
                            for r in results]}

    def geohash_encode(self, lat: float, lng: float,
                       precision: int = 12) -> Dict[str, Any]:
        self._stats["geohash_computes"] += 1
        gh = GeoHash.encode(lat, lng, precision)
        center_lat, center_lng, rect = GeoHash.decode(gh)
        return {"success": True, "geohash": gh, "center": [center_lat, center_lng],
                "bounds": rect.to_dict(), "precision": precision}

    def geohash_decode(self, geohash: str) -> Dict[str, Any]:
        lat, lng, rect = GeoHash.decode(geohash)
        return {"success": True, "center": [round(lat, 6), round(lng, 6)],
                "bounds": rect.to_dict(), "geohash": geohash}

    def distance(self, lat1: float, lng1: float, lat2: float, lng2: float,
                 unit: str = "km") -> Dict[str, Any]:
        dist = DistanceCalculator.haversine(lat1, lng1, lat2, lng2, GeoUnit(unit))
        return {"success": True, "distance": round(dist, 4), "unit": unit,
                "from": {"lat": lat1, "lng": lng1}, "to": {"lat": lat2, "lng": lng2}}

    def define_region(self, name: str, min_lat: float, min_lng: float,
                      max_lat: float, max_lng: float) -> Dict[str, Any]:
        rect = GeoRect(min_lat=min_lat, min_lng=min_lng,
                       max_lat=max_lat, max_lng=max_lng)
        self._regions[name] = rect
        self._stats["regions_defined"] += 1
        return {"success": True, "region": name, "bounds": rect.to_dict()}

    def get_stats(self) -> Dict[str, Any]:
        return {
            **self._stats,
            "index_points": self._index.total_points,
            "index_cells": self._index.cell_count,
            "regions": len(self._regions)
        }

    def execute(self, action: 

            str, **kwargs) -> Dict[str, Any]:
        self.trace("geo_index.execute", "start", action=action)

        if action == "add_point":
            return self.add_point(kwargs.get("lat", 0), kwargs.get("lng", 0),
                                  kwargs.get("id", ""), kwargs.get("properties"))
        elif action == "remove_point":
            return self.remove_point(kwargs.get("id", ""))
        elif action == "radius":
            return self.radius_search(kwargs.get("lat", 0), kwargs.get("lng", 0),
                                      kwargs.get("radius", 0), kwargs.get("unit", "km"),
                                      kwargs.get("limit", 100))
        elif action == "rect":
            return self.rect_search(kwargs.get("min_lat", -90), kwargs.get("min_lng", -180),
                                   kwargs.get("max_lat", 90), kwargs.get("max_lng", 180))
        elif action == "nearest":
            return self.nearest(kwargs.get("lat", 0), kwargs.get("lng", 0),
                                kwargs.get("n", 5), kwargs.get("unit", "km"))
        elif action == "encode":
            return self.geohash_encode(kwargs.get("lat", 0), kwargs.get("lng", 0),
                                       kwargs.get("precision", 12))
        elif action == "decode":
            return self.geohash_decode(kwargs.get("geohash", ""))
        elif action == "distance":
            return self.distance(kwargs.get("lat1", 0), kwargs.get("lng1", 0),
                                 kwargs.get("lat2", 0), kwargs.get("lng2", 0),
                                 kwargs.get("unit", "km"))
        elif action == "stats":
            return self.get_stats()
        else:
            return {"success": False, "error": f"Unknown action: {action}"}

    def health_check(self) -> Dict[str, Any]:
        self.trace("geo_index.health_check", "start")
        return {
            "healthy": True,
            "status": "running",
            "metrics": self.get_stats(),
            "checks": [
                ("initialized", self._initialized),
                ("spatial_index_active", self._index.total_points >= 0),
                ("geohash_precision", self._index._precision > 0),
                ("calculator_ready", True),
            ]
        }

    def shutdown(self) -> None:
        self.trace("geo_index.shutdown", "start")
        self._regions.clear()
        self._initialized = False
        logger.info("GeoIndex shutdown complete")

module_class = GeoIndex


# geo_index module padding

