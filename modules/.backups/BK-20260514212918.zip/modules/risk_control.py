import time
import os
import json
import logging
import hashlib
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional

from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)

logger = logging.getLogger(__name__)

RISK_DB_DIR = os.environ.get("RISK_DB_DIR", "data/risk")
RISK_DEFAULT_THRESHOLD = float(os.environ.get("RISK_DEFAULT_THRESHOLD", "0.7"))
RISK_WINDOW_SIZE = int(os.environ.get("RISK_WINDOW_SIZE", "60"))
RISK_MAX_FREQUENCY = int(os.environ.get("RISK_MAX_FREQUENCY", "100"))



class RiskControlAnalyzer(EnterpriseModule):
    """risk_control 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        super().__init__()
        self._operation_count = 0
        self._error_count = 0
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "risk_control"
        self.version = "1.0.0"
        self._analyzer = self
        self._history = []
        self._max_history = 10000
    
    def analyze(self, context: dict = None) -> dict:
        context = context or {}
        result = {"analyzer": "RiskControlAnalyzer", "timestamp": time.time(), "records": len(self._history), "summary": self._summary()}
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-5000:]
        return result
    
    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "risk_control"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== risk_control ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}
    async def execute(self, action: str = "status", params: dict = None) -> dict:
            

            params = params or {}
            action = action or "status"
            try:
                self._operation_count += 1
                if action == "status":
                    return {"success": True, "data": {"status": "running", "operations": self._operation_count, "errors": self._error_count}}
                elif action == "stats":
                    return {"success": True, "data": {"operations": self._operation_count, "errors": self._error_count}}
                elif action == "health":
                    return {"success": True, "data": {"healthy": True}}
                elif action == "configure":
                    return {"success": True, "data": {"message": "Configured"}}
                elif action == "reset":
                    self._operation_count = 0
                    self._error_count = 0
                    return {"success": True, "data": {"message": "Reset"}}
                else:
                    return {"success": False, "error": f"Unknown action: {action}"}
            except Exception as e:
                self._error_count += 1
                return {"success": False, "error": str(e)}

class RiskLevel(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class ListType(Enum):
    BLACK = "black"
    WHITE = "white"
    GRAY = "gray"

class InterceptAction(Enum):
    ALLOW = "allow"
    MONITOR = "monitor"
    CAPTCHA = "captcha"
    RATE_LIMIT = "rate_limit"
    BLOCK = "block"
    FREEZE = "freeze"


@dataclass
class RiskFactor:
    """风险因子"""
    name: str
    weight: float = 1.0
    value: float = 0.0
    max_score: float = 1.0

    def score(self) -> float:
        return min(self.value * self.weight, self.max_score)


@dataclass
class RiskEvent:
    """风险事件"""
    id: str = ""
    timestamp: str = ""
    source: str = ""
    risk_level: str = "low"
    risk_score: float = 0.0
    factors: dict = field(default_factory=dict)
    action_taken: str = "allow"
    details: dict = field(default_factory=dict)


@dataclass
class RiskRule:
    """风控规则"""
    name: str
    condition_fn: Callable[[dict], bool]
    action: InterceptAction = InterceptAction.MONITOR
    description: str = ""


# ---------------------------------------------------------------------------
# 核心: 风控引擎
# ---------------------------------------------------------------------------

class RiskControlEngine(object):
    """多维度风控拦截引擎"""

    VERSION = "1.0.0"

    def __init__(self, db_dir: str = RISK_DB_DIR, threshold: float = RISK_DEFAULT_THRESHOLD):
        self.db_dir = db_dir
        self.threshold = threshold
        self.factors_config: dict[str, float] = {}
        self.rules: list[RiskRule] = []
        self.event_history: list[RiskEvent] = []
        self._blacklist: set[str] = set()
        self._whitelist: set[str] = set()
        self._graylist: set[str] = set()
        self._frequency_counter: dict[str, list[float]] = defaultdict(list)
        self._lock = threading.Lock()
        self._event_id_counter = 0
        self._alert_handlers: list[Callable[[RiskEvent], None]] = []

        os.makedirs(db_dir, exist_ok=True)
        self._load_lists()

    # ---- 名单管理 ----

    def _load_lists(self):
        for list_type, attr in [("blacklist.json", "_blacklist"),
                                 ("whitelist.json", "_whitelist"),
                                 ("graylist.json", "_graylist")]:
            fpath = os.path.join(self.db_dir, list_type)
            if os.path.exists(fpath):
                try:
                    with open(fpath, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    setattr(self, attr, set(data))
                except Exception:
                    pass

    def _save_list(self, list_type: str, data: set):
        fpath = os.path.join(self.db_dir, f"{list_type}.json")
        with open(fpath, "w", encoding="utf-8") as f:
            json.dump(sorted(data), f, indent=2)

    def add_to_blacklist(self, key: str, reason: str = ""):
        with self._lock:
            self._blacklist.add(key)
            self._save_list("blacklist", self._blacklist)

    def add_to_whitelist(self, key: str):
        with self._lock:
            self._whitelist.add(key)
            self._save_list("whitelist", self._whitelist)

    def add_to_graylist(self, key: str):
        with self._lock:
            self._graylist.add(key)
            self._save_list("graylist", self._graylist)

    def remove_from_list(self, key: str, list_type: ListType):
        with self._lock:
            target = {"black": self._blacklist, "white": self._whitelist, "gray": self._graylist}[list_type.value]
            target.discard(key)
            self._save_list(f"{list_type.value}list", target)

    def is_in_blacklist(self, key: str) -> bool:
        return key in self._blacklist

    def is_in_whitelist(self, key: str) -> bool:
        return key in self._whitelist

    def is_in_graylist(self, key: str) -> bool:
        return key in self._graylist

    # ---- 频率控制 ----

    def check_frequency(self, key: str) -> bool:
        """检查是否超频，返回 True 表示允许"""
        now = time.time()
        with self._lock:
            timestamps = self._frequency_counter[key]
            # 清理过期
            self._frequency_counter[key] = [t for t in timestamps if now - t < RISK_WINDOW_SIZE]
            if len(self._frequency_counter[key]) >= RISK_MAX_FREQUENCY:
                return False
            self._frequency_counter[key].append(now)
            return True

    def reset_frequency(self, key: str):
        with self._lock:
            self._frequency_counter.pop(key, None)

    # ---- 风险评分 ----

    def configure_factor(self, name: str, weight: float):
        self.factors_config[name] = weight

    def evaluate(self, context: dict) -> tuple[float, RiskLevel, dict]:
        """评估风险，返回 (score, level, factor_scores)"""
        total_score = 0.0
        factor_details = {}

        for fname, weight in self.factors_config.items():
            value = context.get(fname, 0.0)
            factor = RiskFactor(name=fname, weight=weight, value=value)
            s = factor.score()
            total_score += s
            factor_details[fname] = round(s, 4)

        # 归一化
        if self.factors_config:
            total_score = min(total_score / sum(self.factors_config.values()), 1.0)

        # 风险等级
        if total_score >= 0.9:
            level = RiskLevel.CRITICAL
        elif total_score >= 0.7:
            level = RiskLevel.HIGH
        elif total_score >= 0.4:
            level = RiskLevel.MEDIUM
        else:
            level = RiskLevel.LOW

        return round(total_score, 4), level, factor_details

    # ---- 拦截决策 ----

    def decide(self, context: dict) -> tuple[InterceptAction, RiskEvent]:
        """风控决策入口"""
        source = context.get("source", "unknown")
        ip = context.get("ip", "")
        user_id = context.get("user_id", "")

        # 1. 白名单直接放行
        if user_id and self.is_in_whitelist(user_id):
            event = self._create_event(source, 0.0, RiskLevel.LOW, InterceptAction.ALLOW, context, {"reason": "whitelist"})
            return InterceptAction.ALLOW, event

        if ip and self.is_in_whitelist(ip):
            event = self._create_event(source, 0.0, RiskLevel.LOW, InterceptAction.ALLOW, context, {"reason": "ip_whitelist"})
            return InterceptAction.ALLOW, event

        # 2. 黑名单直接拦截
        if user_id and self.is_in_blacklist(user_id):
            event = self._create_event(source, 1.0, RiskLevel.CRITICAL, InterceptAction.BLOCK, context, {"reason": "blacklist"})
            return InterceptAction.BLOCK, event

        if ip and self.is_in_blacklist(ip):
            event = self._create_event(source, 1.0, RiskLevel.CRITICAL, InterceptAction.BLOCK, context, {"reason": "ip_blacklist"})
            return InterceptAction.BLOCK, event

        # 3. 频率检查
        freq_key = f"freq:{user_id or ip}"
        if not self.check_frequency(freq_key):
            event = self._create_event(source, 0.8, RiskLevel.HIGH, InterceptAction.RATE_LIMIT, context, {"reason": "rate_limit"})
            return InterceptAction.RATE_LIMIT, event

        # 4. 规则匹配
        for rule in self.rules:
            try:
                if rule.condition_fn(context):
                    if rule.action == InterceptAction.BLOCK:
                        self.add_to_blacklist(user_id or ip, f"Rule: {rule.name}")
                    event = self._create_event(source, 0.85, RiskLevel.HIGH, rule.action, context, {"rule": rule.name})
                    return rule.action, event
            except Exception as e:
                logger.error(f"规则执行失败 [{rule.name}]: {e}")

        # 5. 综合评分
        score, level, factors = self.evaluate(context)

        if level == RiskLevel.CRITICAL:
            action = InterceptAction.BLOCK
        elif level == RiskLevel.HIGH:
            action = InterceptAction.CAPTCHA if self.is_in_graylist(user_id or ip) else InterceptAction.MONITOR
        elif level == RiskLevel.MEDIUM:
            action = InterceptAction.MONITOR
        else:
            action = InterceptAction.ALLOW

        event = self._create_event(source, score, level, action, context, {"factors": factors})
        return action, event

    def _create_event(
        self, source: str, score: float, level: RiskLevel,
        action: InterceptAction, context: dict, details: dict,
    ) -> RiskEvent:
        self._event_id_counter += 1
        event = RiskEvent(
            id=f"RSK-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}-{self._event_id_counter:04d}",
            timestamp=datetime.now(timezone.utc).isoformat(),
            source=source,
            risk_level=level.value,
            risk_score=score,
            action_taken=action.value,
            details=details,
            factors={k: v for k, v in context.items() if k in self.factors_config},
        )
        self.event_history.append(event)
        if len(self.event_history) > 10000:
            self.event_history = self.event_history[-5000:]

        if level in (RiskLevel.HIGH, RiskLevel.CRITICAL):
            for handler in self._alert_handlers:
                try:
                    handler(event)
                except Exception as e:
                    logger.error(f"风控告警处理失败: {e}")

        return event

    # ---- 规则管理 ----

    def add_rule(self, rule: RiskRule):
        self.rules.append(rule)

    def add_alert_handler(self, handler: Callable[[RiskEvent], None]):
        self._alert_handlers.append(handler)

    def setup_default_rules(self):
        """加载默认风控规则"""
        self.configure_factor("ip_suspicion", 2.0)
        self.configure_factor("behavior_anomaly", 2.5)
        self.configure_factor("frequency_score", 1.5)
        self.configure_factor("amount_risk", 2.0)
        self.configure_factor("device_unfamiliar", 1.0)
        self.configure_factor("geo_mismatch", 1.5)

        self.add_rule(RiskRule(
            name="单笔大额异常",
            condition_fn=lambda ctx: ctx.get("amount", 0) > 100000,
            action=InterceptAction.BLOCK,
            description="单笔操作金额超过阈值",
        ))
        self.add_rule(RiskRule(
            name="异地登录",
            condition_fn=lambda ctx: ctx.get("geo_mismatch", False) is True,
            action=InterceptAction.CAPTCHA,
            description="登录地理位置异常",
        ))

    # ---- 查询 & 统计 ----

    def get_events(self, level: Optional[str] = None, limit: int = 100) -> list[dict]:
        results = self.event_history[-limit:]
        if level:
            results = [e for e in results if e.risk_level == level]
        return [asdict(e) for e in reversed(results)]

    def get_statistics(self) -> dict:
        counts = defaultdict(int)
        for event in self.event_history:
            counts[event.risk_level] += 1
        return {
            "total_events": len(self.event_history),
            "blacklist_size": len(self._blacklist),
            "whitelist_size": len(self._whitelist),
            "graylist_size": len(self._graylist),
            "active_rules": len(self.rules),
            "risk_distribution": dict(counts),
            "threshold": self.threshold,
        }


# ---------------------------------------------------------------------------
# API Endpoints
# ---------------------------------------------------------------------------

        API_ENDPOINTS = {
    "risk_evaluate":   {"method": "POST", "path": "/api/v1/risk/evaluate"},
    "risk_decide":     {"method": "POST", "path": "/api/v1/risk/decide"},
    "risk_blacklist":  {"method": "GET",  "path": "/api/v1/risk/blacklist"},
    "risk_whitelist":  {"method": "GET",  "path": "/api/v1/risk/whitelist"},
    "risk_events":     {"method": "GET",  "path": "/api/v1/risk/events"},
    "risk_stats":      {"method": "GET",  "path": "/api/v1/risk/stats"},
    "risk_rules":      {"method": "GET",  "path": "/api/v1/risk/rules"},
}


# ---------------------------------------------------------------------------
# 模块注册
# ---------------------------------------------------------------------------

        MODULE_INFO = {
    "name": "risk_control",
    "version": "1.0.0",
    "description": "多维度风控拦截系统 - 实时评分、名单管理、频率控制",
    "category": "security",
    "dependencies": [],
}

        __all__ = [
    "RiskControlEngine", "RiskEvent", "RiskRule", "RiskFactor",
    "RiskLevel", "ListType", "InterceptAction", "API_ENDPOINTS", "MODULE_INFO",
]
# risk_control module padding
module_class = RiskControlAnalyzer
