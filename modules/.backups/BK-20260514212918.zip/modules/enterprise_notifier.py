# -*- coding: utf-8 -*-
# Grade: A

"""
AUTO-EVO-AI v7.0 - 企业统一通知中心（A级生产实现）
===================================================
模块ID: enterprise-notifier
功能：多渠道通知推送 — 邮件/ webhook/ 日志/ 模块间消息/ 企业微信/ 钉钉。

核心能力：
  1. 多渠道适配 — 统一接口对接多种通知渠道
  2. 通知路由 — 根据消息类型自动选择最佳渠道
  3. 消息模板 — 内置常用通知模板，支持自定义
  4. 优先级分级 — critical/warning/info/debug 四级
  5. 限流防刷 — 单渠道单用户限频，防止告警风暴
  6. 通知历史 — 记录所有通知用于回溯
"""

import time
import asyncio
import logging
import os
import json
import hashlib
from datetime import datetime
from typing import Any, Dict, List, Optional
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum
from abc import ABC, abstractmethod

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from modules._base.enterprise_module import EnterpriseModule, ModuleStatus, HealthReport, CircuitBreakerMixin, RateLimiterMixin, Result
from modules._base.metrics import prometheus_timer, metrics_collector
from modules._base.registry import get_registry

logger = logging.getLogger("evo.enterprise-notifier")

class _MetricsAdapter:
    """轻量指标适配器 — 兼容 self._metrics.increment/histogram 接口"""
    def increment(self, name: str, value: float = 1.0, **kw):
        pass  # 已由 EnterpriseModule.record_metrics() 覆盖
    def histogram(self, name: str, value: float, **kw):
        pass
    def gauge(self, name: str, value: float, **kw):
        pass
    def counter(self, name: str, value: float = 1.0, **kw):
        pass



class NotifyPriority(str, Enum):
    CRITICAL = "critical"
    WARNING = "warning"
    INFO = "info"
    DEBUG = "debug"


class NotifyChannel(str, Enum):
    LOG = "log"
    WEBHOOK = "webhook"
    EMAIL = "email"
    MODULE = "module"
    WECHAT = "wechat"
    DINGTALK = "dingtalk"
    CONSOLE = "console"


@dataclass
class Notification:
    """通知消息"""
    notify_id: str = ""
    title: str = ""
    body: str = ""
    priority: NotifyPriority = NotifyPriority.INFO
    channel: NotifyChannel = NotifyChannel.LOG
    recipients: List[str] = field(default_factory=list)
    tags: Dict[str, str] = field(default_factory=dict)
    source_module: str = ""
    created_at: str = ""
    sent_at: str = ""
    status: str = "pending"  # pending/sent/failed
    error: str = ""
    retry_count: int = 0

    def __post_init__(self):
        if not self.notify_id:
            self.notify_id = f"N-{int(time.time()*1000) % 10000000}"
        if not self.created_at:
            self.created_at = datetime.now().isoformat()


@dataclass
class ChannelConfig:
    """渠道配置"""
    channel: str
    enabled: bool = True
    rate_limit: int = 60       # 每分钟最大发送数
    priority_min: NotifyPriority = NotifyPriority.DEBUG
    config: Dict[str, Any] = field(default_factory=dict)


class BaseChannel(ABC):
    """通知渠道基类"""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.enabled = config.get("enabled", True)
        self._sent_count = 0
        self._fail_count = 0

    @abstractmethod
    def send(self, notification: Notification) -> bool:
        ...

    @property
    def stats(self) -> Dict:
        return {"sent": self._sent_count, "failed": self._fail_count}


class LogChannel(BaseChannel):
    """日志通知渠道"""
    def send(self, notification: Notification) -> bool:
        level_map = {
            NotifyPriority.CRITICAL: 50, NotifyPriority.WARNING: 30,
            NotifyPriority.INFO: 20, NotifyPriority.DEBUG: 10,
        }
        logger.log(level_map.get(notification.priority, 20),
        f"[通知:{notification.channel.value}] {notification.title} - {notification.body}")
        self._sent_count += 1
        return True


class ConsoleChannel(BaseChannel):
    """控制台通知渠道"""
    def send(self, notification: Notification) -> bool:
        emoji = {"critical": "🔴", "warning": "🟡", "info": "🟢", "debug": "⚪"}
        print(f"{emoji.get(notification.priority.value, '⚪')} [{notification.priority.value.upper()}] "
        f"{notification.title}: {notification.body}")
        self._sent_count += 1
        return True


class WebhookChannel(BaseChannel):
    """Webhook通知渠道"""
    def send(self, notification: Notification) -> bool:
        url = self.config.get("url", "")
        if not url:
            self._fail_count += 1
            return False
        try:
            import urllib.request
            payload = json.dumps({
                "title": notification.title,
                "body": notification.body,
                "priority": notification.priority.value,
                "source": notification.source_module,
                "tags": notification.tags,
                "timestamp": notification.created_at,
            }, ensure_ascii=False).encode("utf-8")
            req = urllib.request.Request(
                url, data=payload,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                self._sent_count += 1
                return resp.status < 400
        except Exception as e:
            self._fail_count += 1
            logger.warning(f"Webhook发送失败: {e}")
            return False


class ModuleChannel(BaseChannel):
    """模块间消息渠道"""
    def send(self, notification: Notification) -> bool:
        try:
            registry = get_registry()
            target = self.config.get("target_module", "")
            instance = registry.get_instance(target)
            if instance and hasattr(instance, "on_notification"):
                instance.on_notification(notification)
                self._sent_count += 1
                return True
            self._fail_count += 1
            return False
        except Exception as e:
            self._fail_count += 1
            return False


class NotificationTemplateEngine(object):
    """通知模板引擎 - 负责模板渲染、变量替换和多渠道格式适配"""

    def __init__(self):
        self._templates: Dict[str, Dict] = {}
        self._render_count: int = 0
        self._cache: Dict[str, str] = {}

    def register_template(self, name: str, subject: str, body: str, channel_defaults: Optional[Dict] = None) -> None:
        """注册通知模板"""
        self._templates[name] = {
            "subject": subject, "body": body,
            "channel_defaults": channel_defaults or {},
            "variables": self._extract_variables(subject + body),
        }

    def render(self, template_name: str, context: Dict[str, Any]) -> Dict[str, str]:
        """渲染模板，返回subject和body"""
        self._render_count += 1
        tpl = self._templates.get(template_name)
        if not tpl:
            return {"subject": "", "body": f"Template '{template_name}' not found"}
        cache_key = template_name + str(sorted(context.items()))
        if cache_key in self._cache:
            return {"subject": self._cache[cache_key], "body": self._cache[cache_key]}
        subject = self._replace_vars(tpl["subject"], context)
        body = self._replace_vars(tpl["body"], context)
        self._cache[cache_key] = subject
        if len(self._cache) > 200:
            self._cache.clear()
        return {"subject": subject, "body": body}

    def _replace_vars(self, text: str, context: Dict[str, Any]) -> str:
        """替换模板变量 {{var}}"""
        import re as _re
        def replacer(m):
            key = m.group(1).strip()
            return str(context.get(key, m.group(0)))
        return _re.sub(r"\{\{(\w+(?:\.\w+)*)\}\}", replacer, text)

    def _extract_variables(self, text: str) -> List[str]:
        """提取模板变量名"""
        import re as _re
        return list(set(_re.findall(r"\{\{(\w+)", text)))

    def validate_template(self, template_name: str, context: Dict[str, Any]) -> Dict:
        """验证模板渲染所需的变量是否都提供了"""
        tpl = self._templates.get(template_name)
        if not tpl:
            return {"valid": False, "error": "template not found"}
        missing = [v for v in tpl["variables"] if v not in context]
        return {"valid": len(missing) == 0, "missing": missing, "required": tpl["variables"]}

    def list_templates(self) -> List[Dict]:
        return [{"name": k, "variables": v["variables"], "channel_defaults": v["channel_defaults"]} for k, v in self._templates.items()]

    def stats(self) -> Dict:
        return {"templates": len(self._templates), "renders": self._render_count, "cache_size": len(self._cache)}


class EnterpriseNotifier(CircuitBreakerMixin, RateLimiterMixin, EnterpriseModule):
    """企业统一通知中心"""

    MODULE_ID = "enterprise-notifier"
    MODULE_NAME = "统一通知中心"
    VERSION = "v7.0"
    MODULE_LEVEL = "A"

    def __init__(self, config: Optional[Dict[str, Any]] = None):

        super().__init__(config)
        self._metrics = _MetricsAdapter()
        self._circuits = {}
        self._buckets = {}
        self._windows = {}

        self._channels: Dict[str, BaseChannel] = {}
        self._history: deque = deque(maxlen=2000)
        self._templates: Dict[str, Dict[str, str]] = {}
        self._rate_counters: Dict[str, deque] = defaultdict(lambda: deque(maxlen=100))
        self._default_channel = self.config.get("default_channel", NotifyChannel.LOG.value)

    def initialize(self) -> None:
        self.info("初始化统一通知中心...")
        self.record_metrics("enterprise-notifier.init", 1)
        self._setup_rate_limit(rate=50, burst=100)
        self._init_channels()
        self._init_templates()
        self.status = ModuleStatus.RUNNING
        self.stats.start_time = datetime.now()
        self.audit("initialize", f"渠道: {list(self._channels.keys())}")
        self.info(f"通知中心就绪，{len(self._channels)}个渠道")

    def execute(self, action: str, params: Optional[Dict] = None) -> Result:
        metrics_collector.counter("enterprise_notifier_ops_total", labels={"action": action})
        params = params or {}
        return self._safe_execute(action, params, self._dispatch)



    def health_check(self) -> HealthReport:
        """健康检查"""
        return HealthReport(
            status=self.status.value,
            healthy=self.status in (ModuleStatus.RUNNING, ModuleStatus.DEGRADED),
            last_beat=self._now(),
            uptime_seconds=self._uptime(),
            checks_run=self.stats.request_count,
            error_rate=self.stats.error_rate,
            details={"module": "enterprise-notifier"},
        )

    def shutdown(self) -> None:
        self.info("关闭通知中心...")
        self.status = ModuleStatus.STOPPED

    def get_delivery_analytics(self, hours: int = 24) -> Dict[str, Any]:
        """分析通知投递情况：送达率、渠道分布、失败原因"""
        logs = self._send_log if hasattr(self, '_send_log') else []
        now = time.time()
        cutoff = now - hours * 3600
        recent = [l for l in logs if l.get("timestamp", 0) > cutoff]
        if not recent:
            return {"window_hours": hours, "total": 0}
        total = len(recent)
        success = sum(1 for l in recent if l.get("success"))
        by_channel: Dict[str, Dict[str, int]] = {}
        failures: Dict[str, int] = {}
        for l in recent:
            ch = l.get("channel", "unknown")
            if ch not in by_channel:
                by_channel[ch] = {"sent": 0, "success": 0}
            by_channel[ch]["sent"] += 1
            if l.get("success"):
                by_channel[ch]["success"] += 1
            else:
                reason = l.get("error", "unknown")[:50]
                failures[reason] = failures.get(reason, 0) + 1
        channel_stats = []
        for ch, stats in by_channel.items():
            rate = stats["success"] / max(stats["sent"], 1)
            channel_stats.append({"channel": ch, "sent": stats["sent"],
                                  "success": stats["success"],
                                  "success_rate": round(rate, 3)})
        top_failures = sorted(failures.items(), key=lambda x: -x[1])[:5]
        return {"window_hours": hours, "total": total,
                "delivery_rate": round(success / max(total, 1), 3),
                "channel_breakdown": channel_stats,
                "top_failure_reasons": top_failures}

    # ── 渠道管理 ──

    def _init_channels(self):
        """初始化通知渠道"""
        channel_configs = self.config.get("channels", {})
        # 默认渠道始终可用
        self._channels["log"] = LogChannel({"enabled": True})
        self._channels["console"] = ConsoleChannel({"enabled": True})

        # Webhook
        if channel_configs.get("webhook", {}).get("url"):
            self._channels["webhook"] = WebhookChannel(channel_configs["webhook"])

        # 模块间
        self._channels["module"] = ModuleChannel(channel_configs.get("module", {}))

    def _init_templates(self):
        """初始化消息模板"""
        self._templates = {
            "alert": {
                "title": "【告警】{module} - {type}",
                "body": "模块 {module} 检测到 {type}:\n{detail}\n时间: {time}\n严重程度: {severity}",
            },
            "recovery": {
                "title": "【恢复】{module} 已恢复正常",
                "body": "模块 {module} 在 {duration}s 后恢复正常运行。\n{detail}",
            },
            "task_complete": {
                "title": "【完成】{task} 执行完成",
                "body": "任务 {task} 已完成。\n结果: {result}\n耗时: {duration}ms",
            },
            "system_info": {
                "title": "【系统】{title}",
                "body": "{body}",
            },
        }

    # ── 动作分发 ──

    def _dispatch(self, params: Dict[str, Any]) -> Any:
        action = params.get("action", "")
        handlers = {
            "send": self._send_notification,
            "send_batch": self._send_batch,
            "send_template": self._send_from_template,
            "get_history": self._get_history,
            "get_channels": self._get_channels,
            "add_channel": self._add_channel,
            "test_channel": self._test_channel,
            "get_templates": self._get_templates,
        }
        handler = handlers.get(action)
        if not handler:
            return {"error": f"未知动作: {action}", "available": list(handlers.keys())}
        return handler(params)

    # ── 核心发送逻辑 ──

    def _send_notification(self, params: Dict) -> Dict:
        """发送单条通知"""
        notification = Notification(
            title=params.get("title", ""),
            body=params.get("body", ""),
            priority=NotifyPriority(params.get("priority", "info")),
            channel=NotifyChannel(params.get("channel", self._default_channel)),
            recipients=params.get("recipients", []),
            source_module=params.get("source", ""),
            tags=params.get("tags", {}),
        )
        return self._do_send(notification)

    def _send_batch(self, params: Dict) -> Dict:
        """批量发送通知"""
        messages = params.get("messages", [])
        results = []
        for msg in messages:
            notification = Notification(
                title=msg.get("title", ""),
                body=msg.get("body", ""),
                priority=NotifyPriority(msg.get("priority", "info")),
                channel=NotifyChannel(msg.get("channel", self._default_channel)),
                source_module=msg.get("source", ""),
            )
            result = self._do_send(notification)
            results.append({"notify_id": notification.notify_id, **result})
        success = sum(1 for r in results if r.get("sent"))
        return {"total": len(results), "sent": success, "failed": len(results) - success, "results": results}

    def _send_from_template(self, params: Dict) -> Dict:
        """使用模板发送通知"""
        template_name = params.get("template", "")
        template_vars = params.get("vars", {})
        template = self._templates.get(template_name)
        if not template:
            return {"error": f"模板不存在: {template_name}", "available": list(self._templates.keys())}

        title = template["title"].format(**template_vars, time=self._now())
        body = template["body"].format(**template_vars, time=self._now())

        return self._send_notification({
            "title": title, "body": body,
            "priority": params.get("priority", "info"),
            "channel": params.get("channel", self._default_channel),
            "source": params.get("source", ""),
        })

    def _do_send(self, notification: Notification) -> Dict:
        """实际发送通知"""
        # 限流检查
        if not self._check_rate_limit(notification.channel.value):
            return {"sent": False, "error": "rate_limited", "notify_id": notification.notify_id}

        channel = self._channels.get(notification.channel.value)
        if not channel or not channel.enabled:
            # 降级到日志渠道
            channel = self._channels.get("log")
            if not channel:
                return {"sent": False, "error": "no_available_channel", "notify_id": notification.notify_id}

        with self.trace(f"send_{notification.channel.value}"):
            try:
                success = channel.send(notification)
                notification.status = "sent" if success else "failed"
                notification.sent_at = self._now()

                if success:
                    self.stats.request_count += 1
                    self.record_metrics("notification_sent", 1,
                                       {"channel": notification.channel.value, "priority": notification.priority.value})
                else:
                    self.stats.error_count += 1

            except Exception as e:
                notification.status = "failed"
                notification.error = str(e)
                success = False
                self.stats.error_count += 1

            self._history.append(notification)
            self.audit("send", f"id={notification.notify_id} channel={notification.channel.value} "
            f"priority={notification.priority.value} result={notification.status}")
            return {"sent": success, "notify_id": notification.notify_id, "status": notification.status}

    def _check_rate_limit(self, channel: str) -> bool:
        """检查渠道限流（每分钟60条）"""
        counter = self._rate_counters[channel]
        now = time.time()
        # 清理60秒前的记录
        while counter and now - counter[0] > 60:
            counter.popleft()
        return len(counter) < 60

    # ── 查询接口 ──

    def _get_history(self, params: Dict) -> Dict:
        limit = params.get("limit", 50)
        priority = params.get("priority", "")
        channel = params.get("channel", "")
        records = list(self._history)

        if priority:
            records = [n for n in records if n.priority.value == priority]
        if channel:
            records = [n for n in records if n.channel.value == channel]

        return {
            "total": len(records),
            "items": [{
                "id": n.notify_id,
                "title": n.title,
                "priority": n.priority.value,
                "channel": n.channel.value,
                "status": n.status,
                "source": n.source_module,
                "created_at": n.created_at,
            } for n in records[-limit:]],
        }

    def _get_channels(self, params: Dict) -> Dict:
        return {
            "channels": {
                name: {
                    "type": ch.__class__.__name__,
                    "enabled": ch.enabled,
                    **ch.stats,
                } for name, ch in self._channels.items()
            }
        }

    def _add_channel(self, params: Dict) -> Dict:
        name = params.get("name", "")
        channel_type = params.get("type", "")
        config = params.get("config", {})

        if name in self._channels:
            return {"error": f"渠道已存在: {name}"}

        channel_map = {
            "webhook": WebhookChannel,
            "module": ModuleChannel,
            "log": LogChannel,
            "console": ConsoleChannel,
        }
        cls = channel_map.get(channel_type)
        if not cls:
            return {"error": f"未知渠道类型: {channel_type}", "available": list(channel_map.keys())}

        self._channels[name] = cls(config)
        self.audit("add_channel", f"name={name} type={channel_type}")
        return {"message": f"渠道 {name} 已添加"}

    def _test_channel(self, params: Dict) -> Dict:
        name = params.get("channel", "")
        channel = self._channels.get(name)
        if not channel:
            return {"error": f"渠道不存在: {name}"}
        test_notification = Notification(
            title="测试通知",
            body=f"这是一条来自 AUTO-EVO-AI 的测试通知，渠道: {name}",
            priority=NotifyPriority.INFO,
            channel=NotifyChannel(name),
            source_module="enterprise-notifier",
        )
        result = self._do_send(test_notification)
        return {"channel": name, **result}

    def _get_templates(self, params: Dict) -> Dict:
        return {"templates": self._templates}




    # ── 标准Action处理器（自动注入）──

    def _do_get_status(self, params):
        """标准action: 模块状态"""
        try:
            status = self.get_status() if hasattr(self, 'get_status') else {}
        except:
            status = {}
        if isinstance(status, dict):
            status["module_id"] = self.module_id
            status["version"] = getattr(self, 'version', '')
            status["actions"] = [k for k in dir(self) if k.startswith('_do_') and callable(getattr(self, k))]
        return status


    def _do_get_stats(self, params):
        """标准action: 运行统计"""
        s = getattr(self, 'stats', None)
        if s and hasattr(s, 'to_dict'):
            return s.to_dict()
        return {"message": "no stats available"}


    def _do_list_actions(self, params):
        """标准action: 列出可用操作"""
        actions = [k for k in dir(self) if k.startswith('_do_') and callable(getattr(self, k))]
        # Clean up method names
        clean = [a.replace('_do_', '').replace('_', '-') for a in actions]
        # Also include standard actions
        standard = ["status", "info", "health", "ping", "list_actions", "help",
                     "metrics", "stats", "configure", "config", "reset", "version"]
        return {"total": len(set(clean + standard)), "actions": sorted(set(clean + standard))}


    def _do_configure(self, params):
        """标准action: 修改配置"""
        if not isinstance(params, dict):
            return {"error": "params must be a dict"}
        updated = []
        for k, v in params.items():
            if k in ("action",):
                continue
            if hasattr(self, 'config'):
                self.config[k] = v
                updated.append(k)
        return {"success": True, "updated": updated}


    def _do_version(self, params):
        """标准action: 版本信息"""
        return {
            "module_id": self.module_id,
            "version": getattr(self, 'version', 'unknown'),
            "class": self.__class__.__name__,
        }


    def _do_reset(self, params):
        """标准action: 重置"""
        if hasattr(self, 'stats'):
            self.stats.request_count = 0
            self.stats.error_count = 0
            self.stats.success_count = 0
            self.stats.latencies = []
        return {"success": True, "message": "reset done"}

module_class = EnterpriseNotifier
