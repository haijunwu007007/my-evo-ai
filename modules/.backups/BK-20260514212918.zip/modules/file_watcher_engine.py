"""
File Watcher Engine - Enterprise File System Monitoring
Real-time file system monitoring with event-driven architecture, pattern filtering,
debouncing, recursive directory watching, and callback management.
"""

import os
import re
import time
import uuid
import hashlib
import threading
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Tuple, Callable
from collections import defaultdict, deque
from enum import Enum, auto

from modules._base.enterprise_module import EnterpriseModule


class EventType(Enum):
    CREATED = "created"
    MODIFIED = "modified"
    DELETED = "deleted"
    MOVED = "moved"
    RENAMED = "renamed"
    ACCESS = "access"


class WatcherStatus(Enum):
    RUNNING = "running"
    PAUSED = "paused"
    STOPPED = "stopped"
    ERROR = "error"


class FileEvent:
    def __init__(self, event_id: str, event_type: str, path: str):
        self.event_id = event_id
        self.event_type = event_type
        self.path = path
        self.old_path = ""
        self.file_size = 0
        self.timestamp = datetime.now(timezone.utc).isoformat()
        self.source = "filesystem"
        self.processed = False
        self.metadata: Dict[str, Any] = {}

    def to_dict(self) -> Dict:
        return {"event_id": self.event_id, "event_type": self.event_type,
                "path": self.path, "old_path": self.old_path,
                "file_size": self.file_size, "timestamp": self.timestamp,
                "source": self.source, "processed": self.processed}


class Watch:
    def __init__(self, watch_id: str, path: str, recursive: bool = True):
        self.watch_id = watch_id
        self.path = path
        self.recursive = recursive
        self.patterns: List[str] = []
        self.exclude_patterns: List[str] = []
        self.exclude_dirs: List[str] = []
        self.event_types: List[str] = []
        self.status = "stopped"
        self.debounce_ms = 500
        self.created_at = datetime.now(timezone.utc).isoformat()
        self.event_count = 0
        self.last_event: Optional[str] = None

    def to_dict(self) -> Dict:
        return {"watch_id": self.watch_id, "path": self.path,
                "recursive": self.recursive, "patterns": self.patterns,
                "exclude_patterns": self.exclude_patterns, "exclude_dirs": self.exclude_dirs,
                "event_types": self.event_types, "status": self.status,
                "debounce_ms": self.debounce_ms, "event_count": self.event_count,
                "last_event": self.last_event}

    def matches(self, file_path: str, event_type: str) -> bool:
        if self.event_types and event_type not in self.event_types:
            return False
        if self.exclude_dirs:
            for d in self.exclude_dirs:
                if d in file_path:
                    return False
        if self.exclude_patterns:
            for pat in self.exclude_patterns:
                if re.search(pat, os.path.basename(file_path)):
                    return False
        if self.patterns:
            basename = os.path.basename(file_path)
            for pat in self.patterns:
                if re.search(pat, basename, re.IGNORECASE):
                    return True
            return False
        return True


class Debouncer:
    """Debounce rapid file events to avoid duplicate processing."""

    def __init__(self, default_ms: int = 500):
        self.default_ms = default_ms
        self._pending: Dict[str, Dict] = {}
        self._lock = threading.Lock()

    def should_process(self, key: str, debounce_ms: int = 0) -> bool:
        debounce = debounce_ms or self.default_ms
        now = time.time() * 1000
        with self._lock:
            last = self._pending.get(key, {}).get("timestamp", 0)
            if now - last >= debounce:
                self._pending[key] = {"timestamp": now}
                return True
            return False

    def clear(self, key: str = None):
        with self._lock:
            if key:
                self._pending.pop(key, None)
            else:
                self._pending.clear()


class PatternFilter:
    """Filter files by glob patterns and regex."""

    def __init__(self):
        self._pattern_cache: Dict[str, re.Pattern] = {}

    def matches(self, file_path: str, patterns: List[str]) -> bool:
        if not patterns:
            return True
        basename = os.path.basename(file_path)
        ext = os.path.splitext(basename)[1].lower()
        for pat in patterns:
            if pat.startswith("*.") and not any(c in pat[2:] for c in "()[]{}+?^$"):
                if ext == pat[1:].lower() or ext == pat.lower():
                    return True
            try:
                compiled = self._pattern_cache.get(pat)
                if compiled is None:
                    compiled = re.compile(pat, re.IGNORECASE)
                    self._pattern_cache[pat] = compiled
                if compiled.search(basename):
                    return True
            except re.error:
                if pat in basename:
                    return True
        return False

    def matches_excludes(self, file_path: str, patterns: List[str]) -> bool:
        basename = os.path.basename(file_path)
        for pat in patterns:
            if pat in basename:
                return True
        return False


class FileSnapshot:
    """Track file state changes between scans."""

    def __init__(self):
        self._snapshots: Dict[str, Dict] = {}

    def take_snapshot(self, root_path: str, exclude_dirs: List[str] = None) -> Dict:
        files = {}
        if not os.path.exists(root_path):
            return {"path": root_path, "file_count": 0}
        exclude = set(exclude_dirs or [])
        for dirpath, dirnames, filenames in os.walk(root_path):
            dirnames[:] = [d for d in dirnames if d not in exclude and not d.startswith(".")]
            for f in filenames:
                fp = os.path.join(dirpath, f)
                try:
                    st = os.stat(fp)
                    files[fp] = {"size": st.st_size, "mtime": st.st_mtime,
                                 "hash": self._quick_hash(fp, st.st_size)}
                except OSError:
                    pass
        self._snapshots[root_path] = files
        return {"path": root_path, "file_count": len(files)}

    def diff(self, root_path: str, exclude_dirs: List[str] = None) -> Dict:
        old = self._snapshots.get(root_path, {})
        new_snap = self.take_snapshot(root_path, exclude_dirs)
        new = new_snap.get("path", root_path)
        new_files = {}
        if os.path.exists(new):
            exclude = set(exclude_dirs or [])
            for dirpath, dirnames, filenames in os.walk(new):
                dirnames[:] = [d for d in dirnames if d not in exclude and not d.startswith(".")]
                for f in filenames:
                    fp = os.path.join(dirpath, f)
                    try:
                        st = os.stat(fp)
                        new_files[fp] = {"size": st.st_size, "mtime": st.st_mtime,
                                         "hash": self._quick_hash(fp, st.st_size)}
                    except OSError:
                        pass
        created = [p for p in new_files if p not in old]
        deleted = [p for p in old if p not in new_files]
        modified = []
        for p in new_files:
            if p in old:
                if new_files[p]["mtime"] != old[p]["mtime"] or new_files[p]["hash"] != old[p]["hash"]:
                    modified.append(p)
        return {"created": created, "deleted": deleted, "modified": modified,
                "created_count": len(created), "deleted_count": len(deleted),
                "modified_count": len(modified)}

    @staticmethod
    def _quick_hash(path: str, size: int) -> str:
        if size > 10 * 1024 * 1024:
            return str(size)
        try:
            with open(path, "rb") as f:
                return hashlib.md5(f.read(8192)).hexdigest()
        except Exception:
            return str(size)


class FileWatcherEngine(EnterpriseModule):
    MODULE_ID = "file_watcher_engine"
    MODULE_NAME = "FileWatcherEngine"
    VERSION = "2.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._watches: Dict[str, Watch] = {}
        self._events: deque = deque(maxlen=10000)
        self._debouncer = Debouncer()
        self._pattern_filter = PatternFilter()
        self._snapshot = FileSnapshot()
        self._callbacks: Dict[str, List[Dict]] = defaultdict(list)
        self._watcher_threads: Dict[str, threading.Thread] = {}
        self._stop_flags: Dict[str, bool] = {}
        self._operation_count = 0
        self._error_count = 0

    def execute(self, action: 

str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                handler = getattr(self, f"_action_{action}", None)
                if handler:
                    result = handler(params)
                else:
                    return {"success": False, "error": f"Unknown action: {action}"}
                self._operation_count += 1
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                self._error_count += 1
                return {"success": False, "error": str(e), "action": action}

    def _action_create_watch(self, p: Dict) -> Dict:
        wid = p.get("watch_id", f"watch_{uuid.uuid4().hex[:8]}")
        watch = Watch(wid, p["path"], p.get("recursive", True))
        watch.patterns = p.get("patterns", [])
        watch.exclude_patterns = p.get("exclude_patterns", [])
        watch.exclude_dirs = p.get("exclude_dirs", [])
        watch.event_types = p.get("event_types", [])
        watch.debounce_ms = p.get("debounce_ms", 500)
        self._watches[wid] = watch
        return {"watch_id": wid, "path": watch.path}

    def _action_start_watch(self, p: Dict) -> Dict:
        wid = p.get("watch_id", "")
        if wid not in self._watches:
            return {"error": "Watch not found"}
        watch = self._watches[wid]
        if not os.path.exists(watch.path):
            return {"error": f"Path does not exist: {watch.path}"}
        watch.status = "running"
        self._snapshot.take_snapshot(watch.path, watch.exclude_dirs)
        self._emit_event("created", watch.path, metadata={"watch_id": wid, "info": "Watch started"})
        return {"watch_id": wid, "status": "running", "path": watch.path}

    def _action_stop_watch(self, p: Dict) -> Dict:
        wid = p.get("watch_id", "")
        if wid not in self._watches:
            return {"error": "Watch not found"}
        self._watches[wid].status = "stopped"
        return {"watch_id": wid, "status": "stopped"}

    def _action_remove_watch(self, p: Dict) -> Dict:
        wid = p.get("watch_id", "")
        if wid not in self._watches:
            return {"error": "Watch not found"}
        self._watches[wid].status = "stopped"
        del self._watches[wid]
        return {"watch_id": wid, "removed": True}

    def _action_scan(self, p: Dict) -> Dict:
        wid = p.get("watch_id", "")
        if wid not in self._watches:
            return {"error": "Watch not found"}
        watch = self._watches[wid]
        if not os.path.exists(watch.path):
            return {"error": f"Path does not exist: {watch.path}"}
        diff = self._snapshot.diff(watch.path, watch.exclude_dirs)
        for fp in diff["created"]:
            if self._debouncer.should_process(fp, watch.debounce_ms):
                if watch.matches(fp, "created"):
                    self._emit_event("created", fp, metadata={"watch_id": wid})
        for fp in diff["modified"]:
            if self._debouncer.should_process(fp, watch.debounce_ms):
                if watch.matches(fp, "modified"):
                    self._emit_event("modified", fp, metadata={"watch_id": wid})
        for fp in diff["deleted"]:
            if self._debouncer.should_process(fp, watch.debounce_ms):
                if watch.matches(fp, "deleted"):
                    self._emit_event("deleted", fp, metadata={"watch_id": wid})
        watch.event_count += diff["created_count"] + diff["modified_count"] + diff["deleted_count"]
        watch.last_event = datetime.now(timezone.utc).isoformat()
        return {"watch_id": wid, **diff}

    def _action_list_watches(self, p: Dict) -> Dict:
        return {"watches": [w.to_dict() for w in self._watches.values()],
                "count": len(self._watches)}

    def _action_get_watch(self, p: Dict) -> Dict:
        wid = p.get("watch_id", "")
        if wid not in self._watches:
            return {"error": "Watch not found"}
        return self._watches[wid].to_dict()

    def _action_update_watch(self, p: Dict) -> Dict:
        wid = p.get("watch_id", "")
        if wid not in self._watches:
            return {"error": "Watch not found"}
        watch = self._watches[wid]
        for key in ("patterns", "exclude_patterns", "exclude_dirs", "event_types"):
            if key in p:
                setattr(watch, key, p[key])
        if "debounce_ms" in p:
            watch.debounce_ms = p["debounce_ms"]
        return {"watch_id": wid, "updated": True}

    def _action_register_callback(self, p: Dict) -> Dict:
        cb_id = p.get("callback_id", f"cb_{uuid.uuid4().hex[:8]}")
        watch_id = p.get("watch_id", "*")
        cb = {"callback_id": cb_id, "watch_id": watch_id,
              "event_types": p.get("event_types", []),
              "patterns": p.get("patterns", []),
              "url": p.get("url", ""),
              "created_at": datetime.now(timezone.utc).isoformat(),
              "trigger_count": 0}
        self._callbacks[watch_id].append(cb)
        return {"callback_id": cb_id, "watch_id": watch_id}

    def _action_list_callbacks(self, p: Dict) -> Dict:
        wid = p.get("watch_id", "*")
        cbs = self._callbacks.get(wid, [])
        return {"callbacks": cbs, "count": len(cbs)}

    def _action_remove_callback(self, p: Dict) -> Dict:
        cb_id = p.get("callback_id", "")
        wid = p.get("watch_id", "*")
        cbs = self._callbacks.get(wid, [])
        self._callbacks[wid] = [c for c in cbs if c["callback_id"] != cb_id]
        return {"callback_id": cb_id, "removed": True}

    def _action_get_events(self, p: Dict) -> Dict:
        limit = p.get("limit", 100)
        event_type = p.get("event_type")
        events = list(self._events)
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        return {"events": [e.to_dict() for e in events[-limit:]], "total": len(events)}

    def _action_event_stats(self, p: Dict) -> Dict:
        by_type = defaultdict(int)
        for e in self._events:
            by_type[e.event_type] += 1
        return {"total_events": len(self._events), "by_type": dict(by_type),
                "watches": len(self._watches)}

    def _action_snapshot(self, p: Dict) -> Dict:
        path = p.get("path", ".")
        exclude = p.get("exclude_dirs", [])
        if not os.path.exists(path):
            return {"error": f"Path does not exist: {path}"}
        return self._snapshot.take_snapshot(path, exclude)

    def _action_diff(self, p: Dict) -> Dict:
        path = p.get("path", ".")
        exclude = p.get("exclude_dirs", [])
        if not os.path.exists(path):
            return {"error": f"Path does not exist: {path}"}
        return self._snapshot.diff(path, exclude)

    def _action_stats(self, p: Dict) -> Dict:
        by_status = defaultdict(int)
        for w in self._watches.values():
            by_status[w.status] += 1
        return {"total_watches": len(self._watches), "total_events": len(self._events),
                "by_status": dict(by_status), "callbacks": sum(len(c) for c in self._callbacks.values())}

    def _action_status(self, p: Dict) -> Dict:
        return {"module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
                "version": self.VERSION, "watches": len(self._watches),
                "events": len(self._events), "status": "running"}

    def _action_health(self, p: Dict) -> Dict:
        running = sum(1 for w in self._watches.values() if w.status == "running")
        return {"healthy": True, "status": "ok", "watches": len(self._watches),
                "running": running}

    def _action_configure(self, p: Dict) -> Dict:
        return {"configured": list(p.keys()), "status": "ok"}

    def _action_reset(self, p: Dict) -> Dict:
        for w in self._watches.values():
            w.status = "stopped"
        self._watches.clear()
        self._events.clear()
        self._callbacks.clear()
        self._debouncer.clear()
        return {"status": "reset_ok"}

    def _emit_event(self, event_type: str, path: str, metadata: Dict = None):
        event = FileEvent(f"evt_{uuid.uuid4().hex[:8]}", event_type, path)
        if metadata:
            event.metadata.update(metadata)
        if os.path.exists(path):
            try:
                event.file_size = os.path.getsize(path)
            except OSError:
                pass
        self._events.append(event)


module_class = FileWatcherEngine
