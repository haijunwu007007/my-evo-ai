"""
Replication Monitor - Database Replication Health Monitoring
Tracks replication lag, sync status, node health, and alerting
for master-slave and multi-master replication topologies.
"""

import time
import uuid
import threading
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Tuple
from collections import defaultdict, deque
from enum import Enum, auto

from modules._base.enterprise_module import EnterpriseModule


class ReplicationState(Enum):
    HEALTHY = "healthy"
    LAGGING = "lagging"
    DISCONNECTED = "disconnected"
    ERROR = "error"
    CATCHING_UP = "catching_up"


class ReplicationNode:
    def __init__(self, node_id: str, host: str, port: int, role: str):
        self.node_id = node_id
        self.host = host
        self.port = port
        self.role = role
        self.state = "healthy"
        self.master_id: Optional[str] = None
        self.replication_lag_ms = 0
        self.last_sync_position = 0
        self.current_position = 0
        self.bytes_behind = 0
        self.io_running = True
        self.sql_running = True
        self.last_heartbeat = datetime.now(timezone.utc).isoformat()
        self.uptime_seconds = 0
        self.error_message = ""
        self.gtid_position = ""
        self.relay_log_size = 0

    def to_dict(self) -> Dict:
        return {"node_id": self.node_id, "host": self.host, "port": self.port,
                "role": self.role, "state": self.state, "master_id": self.master_id,
                "replication_lag_ms": self.replication_lag_ms,
                "last_sync_position": self.last_sync_position,
                "current_position": self.current_position,
                "bytes_behind": self.bytes_behind,
                "io_running": self.io_running, "sql_running": self.sql_running,
                "gtid_position": self.gtid_position,
                "error_message": self.error_message,
                "last_heartbeat": self.last_heartbeat}


class LagAnalyzer:
    """Analyze replication lag patterns and detect anomalies."""

    def __init__(self):
        self.lag_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=100))
        self.alerts: List[Dict] = []

    def record(self, node_id: str, lag_ms: int):
        self.lag_history[node_id].append({
            "lag_ms": lag_ms,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        if lag_ms > 5000:
            self.alerts.append({"node_id": node_id, "type": "high_lag",
                                "lag_ms": lag_ms, "severity": "warning",
                                "timestamp": datetime.now(timezone.utc).isoformat()})
        if lag_ms > 30000:
            self.alerts.append({"node_id": node_id, "type": "critical_lag",
                                "lag_ms": lag_ms, "severity": "critical",
                                "timestamp": datetime.now(timezone.utc).isoformat()})

    def analyze_trend(self, node_id: str) -> Dict:
        history = list(self.lag_history.get(node_id, []))
        if len(history) < 3:
            return {"trend": "insufficient_data", "current_lag": history[-1]["lag_ms"] if history else 0}
        recent = [h["lag_ms"] for h in history[-10:]]
        avg = sum(recent) / len(recent)
        older = [h["lag_ms"] for h in history[:-10]] if len(history) > 10 else recent
        older_avg = sum(older) / len(older)
        if avg > older_avg * 1.5:
            trend = "degrading"
        elif avg < older_avg * 0.7:
            trend = "improving"
        else:
            trend = "stable"
        return {"trend": trend, "current_lag": recent[-1],
                "avg_lag": round(avg, 1), "max_lag": max(recent),
                "min_lag": min(recent), "samples": len(recent)}

    def get_alerts(self, severity: str = None, limit: int = 50) -> List[Dict]:
        alerts = self.alerts
        if severity:
            alerts = [a for a in alerts if a["severity"] == severity]
        return alerts[-limit:]


class TopologyMapper:
    """Map and visualize replication topology."""

    def __init__(self):
        self.topology_cache: Dict[str, Any] = {}

    def build_topology(self, nodes: Dict[str, ReplicationNode]) -> Dict:
        masters = [n for n in nodes.values() if n.role == "master"]
        slaves = [n for n in nodes.values() if n.role == "slave"]
        tree = {}
        for m in masters:
            children = [s.node_id for s in slaves if s.master_id == m.node_id]
            tree[m.node_id] = {"role": "master", "host": m.host,
                               "children": children, "child_count": len(children)}
        orphan_slaves = [s.node_id for s in slaves if s.master_id not in [m.node_id for m in masters]]
        if orphan_slaves:
            tree["_orphan"] = {"role": "orphan_slaves", "children": orphan_slaves,
                               "child_count": len(orphan_slaves)}
        self.topology_cache = {"topology": tree, "masters": len(masters),
                               "slaves": len(slaves), "orphan": len(orphan_slaves)}
        return self.topology_cache

    def find_bottleneck(self, nodes: Dict[str, ReplicationNode]) -> Dict:
        worst = None
        max_lag = 0
        for n in nodes.values():
            if n.role == "slave" and n.replication_lag_ms > max_lag:
                max_lag = n.replication_lag_ms
                worst = n
        if worst:
            return {"bottleneck_node": worst.node_id, "lag_ms": worst.replication_lag_ms,
                    "host": worst.host, "state": worst.state}
        return {"bottleneck_node": None, "lag_ms": 0, "state": "healthy"}


class ReplicationMonitor(EnterpriseModule):
    MODULE_ID = "replication_monitor"
    MODULE_NAME = "ReplicationMonitor"
    VERSION = "2.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._nodes: Dict[str, ReplicationNode] = {}
        self._lag_analyzer = LagAnalyzer()
        self._topology_mapper = TopologyMapper()
        self._check_history: deque = deque(maxlen=2000)
        self._operation_count = 0
        self._error_count = 0

    def execute(self, action: 

str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                handler = getattr(self, f"_action_{action}", None)
                if handler:
                    result = handler(params)
                else:
                    return {"success": False, "error": f"Unknown action: {action}"}
                self._operation_count += 1
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                self._error_count += 1
                return {"success": False, "error": str(e), "action": action}

    def _action_add_node(self, p: Dict) -> Dict:
        nid = p.get("node_id", f"node_{uuid.uuid4().hex[:8]}")
        node = ReplicationNode(nid, p.get("host", ""), p.get("port", 3306), p.get("role", "slave"))
        node.master_id = p.get("master_id")
        self._nodes[nid] = node
        return {"node_id": nid, "role": node.role}

    def _action_remove_node(self, p: Dict) -> Dict:
        nid = p.get("node_id", "")
        if nid not in self._nodes:
            return {"error": "Node not found"}
        del self._nodes[nid]
        return {"node_id": nid, "removed": True}

    def _action_report_status(self, p: Dict) -> Dict:
        nid = p.get("node_id", "")
        if nid not in self._nodes:
            return {"error": "Node not found"}
        node = self._nodes[nid]
        node.replication_lag_ms = p.get("replication_lag_ms", 0)
        node.current_position = p.get("current_position", node.current_position)
        node.last_sync_position = p.get("last_sync_position", node.last_sync_position)
        node.bytes_behind = p.get("bytes_behind", 0)
        node.io_running = p.get("io_running", True)
        node.sql_running = p.get("sql_running", True)
        node.error_message = p.get("error_message", "")
        node.last_heartbeat = datetime.now(timezone.utc).isoformat()
        if node.replication_lag_ms > 30000:
            node.state = "error"
        elif node.replication_lag_ms > 5000:
            node.state = "lagging"
        elif node.replication_lag_ms > 1000:
            node.state = "catching_up"
        else:
            node.state = "healthy"
        if not node.io_running or not node.sql_running:
            node.state = "error"
        self._lag_analyzer.record(nid, node.replication_lag_ms)
        self._check_history.append({"node_id": nid, "state": node.state,
                                     "lag_ms": node.replication_lag_ms,
                                     "timestamp": datetime.now(timezone.utc).isoformat()})
        return {"node_id": nid, "state": node.state, "lag_ms": node.replication_lag_ms}

    def _action_list_nodes(self, p: Dict) -> Dict:
        return {"nodes": [n.to_dict() for n in self._nodes.values()],
                "count": len(self._nodes)}

    def _action_get_node(self, p: Dict) -> Dict:
        nid = p.get("node_id", "")
        if nid not in self._nodes:
            return {"error": "Node not found"}
        return self._nodes[nid].to_dict()

    def _action_get_topology(self, p: Dict) -> Dict:
        return self._topology_mapper.build_topology(self._nodes)

    def _action_analyze_lag(self, p: Dict) -> Dict:
        nid = p.get("node_id", "")
        return self._lag_analyzer.analyze_trend(nid)

    def _action_get_alerts(self, p: Dict) -> Dict:
        alerts = self._lag_analyzer.get_alerts(severity=p.get("severity"), limit=p.get("limit", 50))
        return {"alerts": alerts, "count": len(alerts)}

    def _action_find_bottleneck(self, p: Dict) -> Dict:
        return self._topology_mapper.find_bottleneck(self._nodes)

    def _action_cluster_health(self, p: Dict) -> Dict:
        healthy = sum(1 for n in self._nodes.values() if n.state == "healthy")
        total = len(self._nodes)
        masters_ok = all(n.state != "error" for n in self._nodes.values() if n.role == "master")
        max_lag = max((n.replication_lag_ms for n in self._nodes.values()), default=0)
        return {"healthy_nodes": healthy, "total_nodes": total,
                "health_pct": round(healthy / max(1, total) * 100, 1),
                "masters_ok": masters_ok, "max_lag_ms": max_lag,
                "status": "healthy" if healthy == total and masters_ok else "degraded"}

    def _action_compare_positions(self, p: Dict) -> Dict:
        results = []
        masters = [n for n in self._nodes.values() if n.role == "master"]
        slaves = [n for n in self._nodes.values() if n.role == "slave"]
        for m in masters:
            for s in slaves:
                if s.master_id == m.node_id:
                    diff = m.current_position - s.current_position
                    results.append({"master": m.node_id, "slave": s.node_id,
                                    "master_pos": m.current_position,
                                    "slave_pos": s.current_position,
                                    "behind": diff})
        return {"comparisons": results}

    def _action_check_history(self, p: Dict) -> Dict:
        limit = p.get("limit", 100)
        return {"history": list(self._check_history)[-limit:], "total": len(self._check_history)}

    def _action_stats(self, p: Dict) -> Dict:
        by_state = defaultdict(int)
        by_role = defaultdict(int)
        for n in self._nodes.values():
            by_state[n.state] += 1
            by_role[n.role] += 1
        return {"total_nodes": len(self._nodes), "by_state": dict(by_state),
                "by_role": dict(by_role), "alert_count": len(self._lag_analyzer.alerts),
                "max_lag_ms": max((n.replication_lag_ms for n in self._nodes.values()), default=0),
                "check_count": len(self._check_history)}

    def _action_status(self, p: Dict) -> Dict:
        return {"module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
                "version": self.VERSION, "nodes": len(self._nodes), "status": "running"}

    def _action_health(self, p: Dict) -> Dict:
        healthy = all(n.state != "error" for n in self._nodes.values()) if self._nodes else True
        return {"healthy": healthy, "status": "ok", "nodes": len(self._nodes)}

    def _action_configure(self, p: Dict) -> Dict:
        return {"configured": list(p.keys()), "status": "ok"}

    def _action_reset(self, p: Dict) -> Dict:
        self._nodes.clear()
        self._check_history.clear()
        return {"status": "reset_ok"}


module_class = ReplicationMonitor
