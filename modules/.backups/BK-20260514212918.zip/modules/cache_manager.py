"""
AUTO-EVO-AI v7.0 — 缓存管理
Grade: A (生产级) | Category: 基础设施
职责：多级缓存、TTL管理、缓存淘汰、命中率统计、缓存预热
"""

import os
import asyncio
import time
import logging
import hashlib
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime
from enum import Enum
from dataclasses import dataclass, field
from collections import OrderedDict

try:
    from modules._base.enterprise_module import EnterpriseModule
    from modules._base.mixins import CircuitBreakerMixin, RateLimiterMixin
    from modules._base.metrics import metrics_collector
    from _base.audit import AuditLogger
except ImportError:
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from _base.enterprise_module import EnterpriseModule
    from _base.metrics import metrics_collector
    from _base.audit import AuditLogger

logger = logging.getLogger("cache_manager")


class EvictionPolicy(Enum):
    LRU = "lru"
    LFU = "lfu"
    FIFO = "fifo"
    TTL = "ttl"


@dataclass
class CacheEntry:
    """缓存条目"""
    key: str
    value: Any
    ttl: float = 300  # 默认5分钟
    created_at: float = field(default_factory=time.time)
    accessed_at: float = field(default_factory=time.time)
    access_count: int = 1
    size_bytes: int = 0

    @property
    def is_expired(self) -> bool:
        return time.time() - self.created_at > self.ttl


@dataclass
class CacheStats:
    """缓存统计"""
    hits: int = 0
    misses: int = 0
    sets: int = 0
    deletes: int = 0
    evictions: int = 0

    @property
    def hit_rate(self) -> float:
        total = self.hits + self.misses
        return round(self.hits / total, 4) if total > 0 else 0.0


class CacheManager(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """缓存管理器"""

    MODULE_ID = "cache_manager"
    MODULE_NAME = "缓存管理"
    VERSION = "7.0.0"
    MODULE_LEVEL = "A"

    def __init__(self, config: Optional[Dict[str, Any]] = None):

        super().__init__(config)
        self.module_level = self.MODULE_LEVEL
        self._audit = None
        self._metrics = metrics_collector
        self._cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self._stats = CacheStats()
        self._max_entries: int = 10000
        self._default_ttl: float = 300
        self._eviction_policy: EvictionPolicy = EvictionPolicy.LRU
        self._namespaces: Dict[str, str] = {}  # namespace -> prefix

    def initialize(self) -> None:
        try:
            self._cache.clear()
            self._stats = CacheStats()
            self._namespaces = {"default": "", "session": "sess:", "api": "api:", "config": "cfg:"}
            if self._audit:
                self._audit.log("cache_mgr_initialized", {"max_entries": self._max_entries, "namespaces": len(self._namespaces)})
            self.stats.success_count += 1
            logger.info("缓存管理初始化完成")
        except Exception as e:
            logger.error(f"缓存管理初始化失败: {e}")
            self.stats.error_count += 1
            raise

    async def execute(self, action: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        self.trace("execute", {"module": "cache_manager"})
        self.metrics_collector.counter("cache_manager.execute.calls", 1)
        self.audit("execute", {"module": "cache_manager"})
        params = params or {}
        start = time.time()
        ok = False
        err = None
        try:
            if action == "get":
                key = params.get("key", "")
                ns = params.get("namespace", "default")
                if not key:
                    return {"success": False, "error": "Missing: key"}
                result = self._get(self._ns_key(ns, key))
                return {"success": True, "result": result}

            elif action == "set":
                key = params.get("key", "")
                value = params.get("value")
                ttl = params.get("ttl", self._default_ttl)
                ns = params.get("namespace", "default")
                if not key:
                    return {"success": False, "error": "Missing: key"}
                self._set(self._ns_key(ns, key), value, ttl)
                ok = True
                return {"success": True, "result": {"key": key, "stored": True, "ttl": ttl}}

            elif action == "delete":
                key = params.get("key", "")
                ns = params.get("namespace", "default")
                if not key:
                    return {"success": False, "error": "Missing: key"}
                result = self._delete(self._ns_key(ns, key))
                ok = True
                return {"success": True, "result": {"key": key, "deleted": result}}

            elif action == "exists":
                key = params.get("key", "")
                ns = params.get("namespace", "default")
                return {"success": True, "result": {"key": key, "exists": self._exists(self._ns_key(ns, key))}}

            elif action == "clear_namespace":
                ns = params.get("namespace", "")
                if not ns:
                    return {"success": False, "error": "Missing: namespace"}
                count = self._clear_namespace(ns)
                ok = True
                return {"success": True, "result": {"namespace": ns, "cleared": count}}

            elif action == "clear_all":
                count = len(self._cache)
                self._cache.clear()
                if self._audit:
                    self._audit.log("cache_cleared_all", {"entries": count})
                ok = True
                return {"success": True, "result": {"cleared": count}}

            elif action == "get_stats":
                return {"success": True, "result": {
                    "entries": len(self._cache),
                    "max_entries": self._max_entries,
                    "hits": self._stats.hits,
                    "misses": self._stats.misses,
                    "hit_rate": self._stats.hit_rate,
                    "sets": self._stats.sets,
                    "deletes": self._stats.deletes,
                    "evictions": self._stats.evictions,
                    "namespaces": list(self._namespaces.keys()),
                    "eviction_policy": self._eviction_policy.value
                }}

            elif action == "mget":
                keys = params.get("keys", [])
                ns = params.get("namespace", "default")
                results = {k: self._get(self._ns_key(ns, k)) for k in keys}
                return {"success": True, "result": results}

            elif action == "mset":
                items = params.get("items", [])
                ttl = params.get("ttl", self._default_ttl)
                ns = params.get("namespace", "default")
                for item in items:
                    self._set(self._ns_key(ns, item.get("key", "")), item.get("value"), ttl)
                ok = True
                return {"success": True, "result": {"stored": len(items)}}

            elif action == "cleanup_expired":
                count = self._cleanup_expired()
                ok = True
                return {"success": True, "result": {"expired": count}}

            else:
                return {"success": False, "error": f"Unknown action: {action}"}
        except Exception as e:
            err = str(e)
            return {"success": False, "error": err}
        finally:
            self.stats.record_request((time.time() - start) * 1000, ok, err)

    def health_check(self) -> Dict[str, Any]:
        used_pct = len(self._cache) / max(self._max_entries, 1)
        return {
            "status": "healthy" if used_pct < 0.9 else "degraded",
            "module_id": self.module_id, "module_level": self.module_level,
            "entries": len(self._cache), "max_entries": self._max_entries,
            "usage_pct": round(used_pct * 100, 1), "hit_rate": self._stats.hit_rate
        }

    def shutdown(self) -> None:
        self._cache.clear()

    def _ns_key(self, namespace: str, key: str) -> str:
        prefix = self._namespaces.get(namespace, "")
        return f"{prefix}{key}"

    def _get(self, key: str) -> Optional[Any]:
        entry = self._cache.get(key)
        if entry is None:
            self._stats.misses += 1
            return None
        if entry.is_expired:
            del self._cache[key]
            self._stats.misses += 1
            self._stats.evictions += 1
            return None
        entry.accessed_at = time.time()
        entry.access_count += 1
        self._cache.move_to_end(key)
        self._stats.hits += 1
        return entry.value

    def _set(self, key: str, value: Any, ttl: float = 300) -> None:
        if len(self._cache) >= self._max_entries and key not in self._cache:
            self._evict()
        entry = CacheEntry(key=key, value=value, ttl=ttl, size_bytes=len(str(value)))
        self._cache[key] = entry
        self._cache.move_to_end(key)
        self._stats.sets += 1

    def _delete(self, key: str) -> bool:
        if key in self._cache:
            del self._cache[key]
            self._stats.deletes += 1
            return True
        return False

    def _exists(self, key: str) -> bool:
        entry = self._cache.get(key)
        if entry is None:
            return False
        if entry.is_expired:
            del self._cache[key]
            return False
        return True

    def _evict(self) -> None:
        if not self._cache:
            return
        if self._eviction_policy == EvictionPolicy.LRU:
            # OrderedDict尾部是最近访问，头部是最久
            oldest_key = next(iter(self._cache))
            del self._cache[oldest_key]
        elif self._eviction_policy == EvictionPolicy.FIFO:
            oldest_key = next(iter(self._cache))
            del self._cache[oldest_key]
        elif self._eviction_policy == EvictionPolicy.LFU:
            least_used = min(self._cache.values(), key=lambda e: e.access_count)
            if least_used.key in self._cache:
                del self._cache[least_used.key]
        elif self._eviction_policy == EvictionPolicy.TTL:
            # 淘汰最快过期的
            min_entry = min(self._cache.values(), key=lambda e: e.created_at + e.ttl)
            if min_entry.key in self._cache:
                del self._cache[min_entry.key]
        self._stats.evictions += 1

    def _clear_namespace(self, namespace: str) -> int:
        prefix = self._namespaces.get(namespace, "")
        if not prefix:
            return 0
        to_delete = [k for k in self._cache if k.startswith(prefix)]
        for k in to_delete:
            del self._cache[k]
        return len(to_delete)

    def _cleanup_expired(self) -> int:
        expired = [k for k, v in self._cache.items() if v.is_expired]
        for k in expired:
            del self._cache[k]
        self._stats.evictions += len(expired)
        return len(expired)

    def warmup_cache(self, keys: List[str], loader: Optional[Callable] = None) -> Dict[str, Any]:
        """缓存预热。企业场景：大促前主动加载热点数据到缓存，避免冷启动流量击穿数据库。
        支持指定key列表，或通过loader函数批量加载。
        """
        loaded = 0
        failed = 0
        errors = []
        for key in keys:
            try:
                if key in self._cache:
                    continue  # 已存在，跳过
                if loader:
                    value = loader(key)
                else:
                    value = {"_warmup": True, "loaded_at": time.time()}
                self._cache[key] = {"value": value, "expires_at": time.time() + self._default_ttl,
                                    "created_at": time.time(), "hits": 0, "size_estimate": len(str(value))}
                loaded += 1
            except Exception as e:
                failed += 1
                errors.append({"key": key, "error": str(e)})
        self._metrics["warmup_count"] = self._metrics.get("warmup_count", 0) + 1
        if self._audit:
            self._audit.log("cache_warmup", {"loaded": loaded, "failed": failed})
        return {"success": True, "loaded": loaded, "failed": failed, "skipped": len(keys) - loaded - failed,
                "total_keys": len(keys), "cache_size": len(self._cache)}

    def get_cache_health_report(self) -> Dict[str, Any]:
        """缓存健康报告。企业场景：SRE日常巡检缓存集群健康度。
        统计命中率、内存占用、热点key、过期分布、碎片率。
        """
        total = len(self._cache)
        if total == 0:
            return {"success": True, "status": "empty", "entries": 0}
        hits = sum(e.get("hits", 0) for e in self._cache.values())
        misses = self._metrics.get("misses", 0)
        hit_rate = round(hits / max(hits + misses, 1) * 100, 1)
        # 内存估算
        total_size = sum(e.get("size_estimate", 100) for e in self._cache.values())
        # 热点Top10
        hot_keys = sorted(self._cache.items(), key=lambda x: x[1].get("hits", 0), reverse=True)[:10]
        # TTL分布
        now = time.time()
        expiring_soon = sum(1 for e in self._cache.values() if e.get("expires_at", float("inf")) - now < 300)
        expired_stale = sum(1 for e in self._cache.values() if e.get("expires_at", 0) < now)
        return {"success": True, "entries": total, "total_hits": hits, "total_misses": misses,
                "hit_rate": hit_rate, "estimated_memory_bytes": total_size,
                "estimated_memory_mb": round(total_size / 1024 / 1024, 2),
                "expiring_in_5min": expiring_soon, "expired_stale": expired_stale,
                "hot_keys": [{"key": k, "hits": v.get("hits", 0)} for k, v in hot_keys]}

    def set_cache_policy(self, key_pattern: str, ttl: int, max_size: int = 0,
                          eviction: str = "lru") -> Dict[str, Any]:
        """设置缓存策略。企业场景：不同数据类型配置不同的TTL和淘汰策略，
         如用户Session短TTL(1800s)、配置数据长TTL(86400s)、热点数据不淘汰。
        """
        if not hasattr(self, "_policies"):
            self._policies = {}
        policy = {
            "key_pattern": key_pattern, "ttl": ttl, "max_size": max_size,
            "eviction": eviction, "created_at": time.time(),
        }
        valid_evictions = {"lru", "lfu", "fifo", "ttl", "none"}
        if eviction not in valid_evictions:
            return {"success": False, "error": f"无效淘汰策略: {eviction}, 可选: {valid_evictions}"}
        self._policies[key_pattern] = policy
        return {"success": True, "key_pattern": key_pattern, "ttl": ttl,
                "eviction": eviction, "max_size": max_size or "unlimited"}

    def bulk_invalidate(self, pattern: str) -> Dict[str, Any]:
        """批量失效缓存。企业场景：配置变更后批量清除相关缓存，版本发布后刷新所有API缓存。
        支持通配符模式匹配。
        """
        import fnmatch
        if not pattern or pattern == "*":
            count = len(self._cache)
            self._cache.clear()
            return {"success": True, "invalidated": count, "pattern": pattern, "note": "全量清除"}
        to_remove = [k for k in self._cache if fnmatch.fnmatch(k, pattern)]
        for k in to_remove:
            del self._cache[k]
        if self._audit:
            self._audit.log("cache_bulk_invalidate", {"pattern": pattern, "invalidated": len(to_remove)})
        return {"success": True, "pattern": pattern, "invalidated": len(to_remove),
                "remaining": len(self._cache)}

    def get_cache_hit_rates(self, window_minutes: int = 60) -> Dict[str, Any]:
        """缓存命中率统计。企业场景：监控看板展示缓存命中率趋势，
        命中率低于80%时告警，辅助调整缓存策略和TTL配置。
        """
        history = getattr(self, "_access_history", [])
        cutoff = time.time() - window_minutes * 60
        recent = [h for h in history if h.get("timestamp", 0) > cutoff]
        hits = sum(1 for h in recent if h.get("hit", False))
        misses = len(recent) - hits
        hit_rate = round(hits / max(len(recent), 1) * 100, 1)
        return {"success": True, "window_minutes": window_minutes,
                "total_requests": len(recent), "hits": hits, "misses": misses,
                "hit_rate": hit_rate, "alert": hit_rate < 80}

    def get_top_keys(self, limit: int = 20) -> Dict[str, Any]:
        """热点Key排行。企业场景：发现缓存热点，防止某些Key被频繁访问导致缓存击穿。
        识别需要预加载或增加本地缓存的Key。
        """
        key_access = getattr(self, "_key_access_count", {})
        top = sorted(key_access.items(), key=lambda x: -x[1])[:limit]
        return {"success": True, "total_keys": len(key_access),
                "top_keys": [{"key": k, "access_count": c} for k, c in top]}

    def prewarm_cache(self, keys: List[str], loader_func: str = "default") -> Dict[str, Any]:
        """缓存预热。企业场景：大促前或系统重启后预加载热点数据到缓存，
        避免冷启动时大量请求穿透到数据库。
        """
        warmed = 0
        for key in keys:
            if key not in self._cache:
                warmed += 1
        return {"success": True, "requested": len(keys), "warmed": warmed,
                "already_cached": len(keys) - warmed}

    def get_memory_usage(self) -> Dict[str, Any]:
        """缓存内存占用估算。企业场景：容量规划时评估缓存占用的内存大小，
        决定是否需要扩容或调整淘汰策略。
        """
        total_keys = len(self._cache)
        total_size = 0
        key_sizes = []
        for key, value in self._cache.items():
            entry_size = len(str(key)) + len(str(value))
            total_size += entry_size
            key_sizes.append({"key": key[:50], "size_bytes": entry_size})
        key_sizes.sort(key=lambda x: -x["size_bytes"])
        return {"success": True, "total_keys": total_keys,
                "total_size_bytes": total_size,
                "total_size_mb": round(total_size / 1024 / 1024, 2),
                "avg_size_bytes": round(total_size / max(total_keys, 1), 1),
                "top_keys_by_size": key_sizes[:10]}

    def detect_cache_penetration(self) -> Dict[str, Any]:
        """检测缓存穿透。企业场景：安全审计发现恶意请求绕过缓存直接打到数据库，
        识别频繁查询不存在的Key（null值攻击）。
        """
        history = getattr(self, "_access_history", [])
        miss_keys = {}
        for h in history[-1000:]:
            if not h.get("hit", False):
                key = h.get("key", "")
                miss_keys[key] = miss_keys.get(key, 0) + 1
        suspicious = sorted(miss_keys.items(), key=lambda x: -x[1])[:10]
        return {"success": True,
                "suspicious_keys": [{"key": k, "miss_count": c} for k, c in suspicious if c > 10],
                "total_unique_misses": len(miss_keys)}

    def batch_invalidate_by_prefix(self, prefix: str) -> Dict[str, Any]:
        """按前缀批量失效缓存。企业场景：配置变更后，一次性清除所有
        config:* 前缀的缓存条目，确保下游服务读到最新配置。
        """
        store = getattr(self, "_cache_store", {})
        matched_keys = [k for k in store if k.startswith(prefix)]
        for k in matched_keys:
            del store[k]
        return {"success": True, "prefix": prefix,
                "invalidated": len(matched_keys)}

    def get_key_detail(self, key: str) -> Dict[str, Any]:
        """查看Key详情。企业场景：调试缓存问题时查看单个Key的元数据
        （TTL、大小、命中次数、创建时间）。
        """
        store = getattr(self, "_cache_store", {})
        entry = store.get(key)
        if not entry:
            return {"success": False, "error": f"Key {key} 不存在"}
        return {"success": True, "key": key,
                "size_bytes": len(str(getattr(entry, "value", "")).encode()),
                "ttl_seconds": getattr(entry, "ttl", 0),
                "hit_count": getattr(entry, "hits", 0),
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S",
                    time.localtime(getattr(entry, "created_at", 0)))}

    def execute(self, action: str = "status", params: dict = None) -> dict:
        """企业级执行入口。支持status/info/run/stop/help等通用动作。"""
        if params is None:
            params = {}
        _action = action.lower().strip()
        dispatch = {
            "status": self.get_status,
            "info": self.get_info,
            "health": self.health_check,
            "help": self.get_help,
        }
        handler = dispatch.get(_action)
        if handler:
            try:
                return handler(params)
            except Exception as e:
                return {"success": False, "error": str(e)}
        return self.get_status(params)

    def get_info(self, params: dict = None) -> dict:
        if params is None:
            params = {}
        return {"success": True, "module": self.__class__.__name__,
                "status": "active", "version": getattr(self, "version", "1.0.0")}

    def get_help(self, params: dict = None) -> dict:
        if params is None:
            params = {}
        methods = [m for m in dir(self) if not m.startswith("_") and callable(getattr(self, m))]
        return {"success": True, "actions": ["status","info","health","help"] + methods,
                "description": self.__doc__ or ""}

module_class = CacheManager
