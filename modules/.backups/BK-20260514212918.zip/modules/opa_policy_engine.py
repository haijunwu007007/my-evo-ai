"""opa_policy_engine - Enterprise OPA Policy Engine Module
AUTO-EVO-AI v6.39 | Grade: A | Category: 安全认证
OPA策略引擎: 策略注册/评估/决策, RBAC/ABAC混合, 策略测试, 审计
子引擎: PolicyConflictResolver(策略冲突检测+解决)
"""
import logging, time, uuid, threading, re, json
from typing import Dict, Any, Optional, List, Set
from datetime import datetime
from dataclasses import dataclass, field
from collections import defaultdict

from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)

logger = logging.getLogger(__name__)


@dataclass
class Policy:
    policy_id: str = ""
    name: str = ""
    description: str = ""
    resource: str = ""  # * or specific resource
    action: str = ""    # * or specific action
    effect: str = "allow"  # allow/deny
    conditions: Dict[str, Any] = field(default_factory=dict)
    priority: int = 0  # higher = evaluated first
    enabled: bool = True
    created_at: str = ""

    def __post_init__(self):
        if not self.policy_id:
            self.policy_id = str(uuid.uuid4())[:8]
        if not self.created_at:
            self.created_at = datetime.now().isoformat()

    def matches(self, resource: str, action: str) -> bool:
        res_match = self.resource == "*" or self.resource == resource or resource.startswith(self.resource.rstrip("*"))
        act_match = self.action == "*" or self.action == action
        return res_match and act_match


@dataclass
class DecisionLog:
    log_id: str = ""
    policy_id: str = ""
    resource: str = ""
    action: str = ""
    effect: str = ""
    matched: bool = False
    input_data: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = 0.0

    def __post_init__(self):
        if not self.log_id:
            self.log_id = str(uuid.uuid4())[:8]
        if not self.timestamp:
            self.timestamp = time.time()


class PolicyConflictResolver:
    """策略冲突检测与解决"""

    def find_conflicts(self, policies: List[Policy]) -> List[Dict]:
        conflicts = []
        for i, p1 in enumerate(policies):
            for p2 in policies[i+1:]:
                if not p1.enabled or not p2.enabled:
                    continue
                if p1.resource == p2.resource and p1.action == p2.action and p1.effect != p2.effect:
                    conflicts.append({
                        "type": "effect_conflict",
                        "policies": [p1.policy_id, p2.policy_id],
                        "resource": p1.resource, "action": p1.action,
                        "effects": [p1.effect, p2.effect],
                        "resolution": f"priority wins: {p1.policy_id if p1.priority >= p2.priority else p2.policy_id}",
                    })
        return conflicts

    def find_overlaps(self, policies: List[Policy]) -> List[Dict]:
        overlaps = []
        allow_policies = [p for p in policies if p.enabled and p.effect == "allow" and p.resource != "*"]
        for p1 in allow_policies:
            for p2 in allow_policies:
                if p1.policy_id >= p2.policy_id:
                    continue
                if (p1.resource.startswith(p2.resource.rstrip("*")) or
                    p2.resource.startswith(p1.resource.rstrip("*"))):
                    overlaps.append({
                        "policies": [p1.policy_id, p2.policy_id],
                        "resource": p1.resource, "action": p1.action,
                    })
        return overlaps[:20]

    def suggest_priority(self, policies: List[Policy]) -> Dict[str, int]:
        """建议优先级: deny优先, 越具体越高"""
        suggestions = {}
        for p in policies:
            score = 100
            if p.effect == "deny":
                score += 50
            if p.resource != "*":
                score += 20
            if p.action != "*":
                score += 10
            if p.conditions:
                score += 15
            suggestions[p.policy_id] = score
        return suggestions


class OpaPolicyEngine(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    AUTO-EVO-AI v6.39 - OPA策略引擎模块
    """

    MODULE_ID = "opa_policy_engine"
    MODULE_NAME = "OpaPolicyEngine"
    VERSION = "1.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._policies: Dict[str, Policy] = {}
        self._decision_log: List[DecisionLog] = []
        self._conflict_resolver = PolicyConflictResolver()
        self._lock = threading.Lock()
        self._total_evaluations = 0
        self._total_allowed = 0
        self._total_denied = 0
        self._init_default_policies()

    def _init_default_policies(self):
        defaults = [
            Policy(name="deny_all", resource="*", action="*", effect="deny", priority=0),
            Policy(name="allow_read", resource="*", action="read", effect="allow", priority=10),
            Policy(name="allow_admin", resource="*", action="*", effect="allow",
                   conditions={"role": "admin"}, priority=100),
        ]
        for p in defaults:
            self._policies[p.policy_id] = p

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        with self.trace("execute", action):
            try:
                result = self._dispatch(action, params)
                return {"success": True, "data": result, "action": action}
            except Exception as e:
                logger.error(f"[opa] {action} error: {e}")
                return {"success": False, "error": str(e), "action": action}

    def _dispatch(self, action: str, params: Dict[str, Any]) -> Any:
        handler = {
            "status": self._get_status, "stats": self._get_stats,
            "health": self.health_check, "reset": self._reset,
            "configure": self._configure,
            # 策略管理
            "add_policy": self._add_policy, "list_policies": self._list_policies,
            "remove_policy": self._remove_policy, "update_policy": self._update_policy,
            # 评估
            "evaluate": self._evaluate,
            # 分析
            "find_conflicts": self._find_conflicts,
            "find_overlaps": self._find_overlaps,
            "suggest_priority": self._suggest_priority,
            # 日志
            "decision_log": self._decision_log_query,
        }.get(action)
        if handler:
            return handler(params)
        return {"action": action, "module_id": self.MODULE_ID}

    def _add_policy(self, params: Dict[str, Any]) -> Dict[str, Any]:
        p = Policy(name=params.get("name", ""), resource=params.get("resource", "*"),
                   action=params.get("action", "*"), effect=params.get("effect", "allow"),
                   conditions=params.get("conditions", {}), priority=params.get("priority", 10))
        self._policies[p.policy_id] = p
        self.audit("add_policy", f"id={p.policy_id} effect={p.effect} resource={p.resource}")
        return {"policy_id": p.policy_id, "name": p.name}

    def _list_policies(self, params: Dict[str, Any]) -> Dict[str, Any]:
        policies = sorted(self._policies.values(), key=lambda x: -x.priority)
        return {"policies": [{"policy_id": p.policy_id, "name": p.name, "resource": p.resource,
                              "action": p.action, "effect": p.effect, "priority": p.priority,
                              "conditions": p.conditions, "enabled": p.enabled}
                             for p in policies], "total": len(policies)}

    def _remove_policy(self, params: Dict[str, Any]) -> Dict[str, Any]:
        pid = params.get("policy_id", "")
        if pid in self._policies:
            del self._policies[pid]
            return {"policy_id": pid, "removed": True}
        return {"error": "not_found"}

    def _update_policy(self, params: Dict[str, Any]) -> Dict[str, Any]:
        pid = params.get("policy_id", "")
        p = self._policies.get(pid)
        if not p:
            return {"error": "not_found"}
        for k in ("name", "resource", "action", "effect", "conditions", "priority", "enabled"):
            if k in params:
                setattr(p, k, params[k])
        return {"policy_id": pid, "updated": True}

    def _evaluate(self, params: Dict[str, Any]) -> Dict[str, Any]:
        resource = params.get("resource", "")
        action = params.get("action", "")
        input_data = params.get("input", {})
        self._total_evaluations += 1
        sorted_policies = sorted([p for p in self._policies.values() if p.enabled], key=lambda x: -x.priority)
        matched_policy = None
        for p in sorted_policies:
            if not p.matches(resource, action):
                continue
            if p.conditions:
                if not self._check_conditions(p.conditions, input_data):
                    continue
            matched_policy = p
            break
        if not matched_policy:
            effect = "deny"
        else:
            effect = matched_policy.effect
        allowed = effect == "allow"
        if allowed:
            self._total_allowed += 1
        else:
            self._total_denied += 1
        log = DecisionLog(
            policy_id=matched_policy.policy_id if matched_policy else "",
            resource=resource, action=action, effect=effect,
            matched=matched_policy is not None, input_data=input_data,
        )
        self._decision_log.append(log)
        if len(self._decision_log) > 5000:
            self._decision_log = self._decision_log[-3000:]
        return {"allowed": allowed, "effect": effect,
                "matched_policy": matched_policy.policy_id if matched_policy else None,
                "resource": resource, "action": action}

    def _check_conditions(self, conditions: Dict[str, Any], input_data: Dict[str, Any]) -> bool:
        for key, expected in conditions.items():
            actual = input_data.get(key)
            if isinstance(expected, list):
                if actual not in expected:
                    return False
            elif actual != expected:
                return False
        return True

    def _find_conflicts(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"conflicts": self._conflict_resolver.find_conflicts(list(self._policies.values()))}

    def _find_overlaps(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"overlaps": self._conflict_resolver.find_overlaps(list(self._policies.values()))}

    def _suggest_priority(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return self._conflict_resolver.suggest_priority(list(self._policies.values()))

    def _decision_log_query(self, params: Dict[str, Any]) -> Dict[str, Any]:
        limit = params.get("limit", 50)
        return {"decisions": [{"policy_id": d.policy_id, "resource": d.resource,
                                "action": d.action, "effect": d.effect, "matched": d.matched,
                                "timestamp": d.timestamp}
                               for d in self._decision_log[-limit:]],
                "total": len(self._decision_log)}

    def _get_status(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "module_id": self.MODULE_ID, "module_name": self.MODULE_NAME,
            "version": self.VERSION, "status": "running",
            "policies": len(self._policies), "total_evaluations": self._total_evaluations,
        }

    def _get_stats(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {
            "total_evaluations": self._total_evaluations,
            "total_allowed": self._total_allowed,
            "total_denied": self._total_denied,
            "allow_rate": round(self._total_allowed / max(1, self._total_evaluations) * 100, 1),
            "policies": len(self._policies),
        }

    def _reset(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        self._decision_log.clear()
        self._total_evaluations = 0
        self._total_allowed = 0
        self._total_denied = 0
        return {"status": "reset_ok"}

    def _configure(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {"configured": list(params.keys())}

    def health_check(self, params: Dict[str, Any] = None) -> Dict[str, Any]:
        return {"healthy": len(self._policies) > 0, "status": "ok", "policies": len(self._policies)}


module_class = OpaPolicyEngine
