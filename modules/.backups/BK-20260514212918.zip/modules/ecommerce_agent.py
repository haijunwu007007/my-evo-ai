"""
E-Commerce Agent - 企业级电商智能Agent模块
生产级功能：商品管理/订单处理/库存引擎/价格策略/购物车/推荐引擎/促销规则/退款流程
"""

import time
import uuid
import threading
import hashlib
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple
from enum import Enum
from collections import defaultdict

from modules._base.enterprise_module import EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin

module_class = "EcommerceAgent"


class OrderStatus(Enum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    PROCESSING = "processing"
    SHIPPED = "shipped"
    DELIVERED = "delivered"
    CANCELLED = "cancelled"
    REFUNDED = "refunded"
    RETURNED = "returned"


class PaymentStatus(Enum):
    PENDING = "pending"
    PAID = "paid"
    FAILED = "failed"
    REFUNDED = "refunded"


class PromotionType(Enum):
    PERCENT_OFF = "percent_off"
    FIXED_AMOUNT = "fixed_amount"
    BUY_X_GET_Y = "buy_x_get_y"
    FREE_SHIPPING = "free_shipping"
    MEMBER_EXCLUSIVE = "member_exclusive"


# ─── 库存引擎 ──────────────────────────────────────────────────

class InventoryEngine:
    """库存管理与预警"""

    def __init__(self):
        self._stock: Dict[str, int] = {}          # sku -> quantity
        self._reserved: Dict[str, int] = {}       # sku -> reserved
        self._history: List[Dict] = []
        self._lock = threading.Lock()

    def add_product(self, sku: str, quantity: int):
        with self._lock:
            self._stock[sku] = self._stock.get(sku, 0) + quantity

    def get_stock(self, sku: str) -> Dict:
        with self._lock:
            avail = self._stock.get(sku, 0) - self._reserved.get(sku, 0)
            return {"sku": sku, "total": self._stock.get(sku, 0),
                    "reserved": self._reserved.get(sku, 0), "available": max(avail, 0)}

    def reserve(self, sku: str, quantity: int) -> Tuple[bool, str]:
        with self._lock:
            avail = self._stock.get(sku, 0) - self._reserved.get(sku, 0)
            if avail >= quantity:
                self._reserved[sku] = self._reserved.get(sku, 0) + quantity
                self._history.append({"sku": sku, "action": "reserve", "qty": quantity,
                                       "ts": datetime.utcnow().isoformat()})
                return True, "reserved"
            return False, f"insufficient stock: need {quantity}, available {avail}"

    def confirm_deduction(self, sku: str, quantity: int):
        with self._lock:
            self._reserved[sku] = max(0, self._reserved.get(sku, 0) - quantity)
            self._stock[sku] = max(0, self._stock.get(sku, 0) - quantity)
            self._history.append({"sku": sku, "action": "deduct", "qty": quantity,
                                   "ts": datetime.utcnow().isoformat()})

    def release_reservation(self, sku: str, quantity: int):
        with self._lock:
            self._reserved[sku] = max(0, self._reserved.get(sku, 0) - quantity)

    def restock(self, sku: str, quantity: int):
        with self._lock:
            self._stock[sku] = self._stock.get(sku, 0) + quantity
            self._history.append({"sku": sku, "action": "restock", "qty": quantity,
                                   "ts": datetime.utcnow().isoformat()})

    def low_stock_alerts(self, threshold: int = 10) -> List[Dict]:
        with self._lock:
            alerts = []
            for sku, total in self._stock.items():
                avail = total - self._reserved.get(sku, 0)
                if avail <= threshold:
                    alerts.append({"sku": sku, "available": avail, "threshold": threshold})
            return alerts

    def list_all(self) -> List[Dict]:
        with self._lock:
            return [self.get_stock(sku) for sku in self._stock]


# ─── 价格策略引擎 ──────────────────────────────────────────────

class PricingEngine:
    """动态定价与促销策略"""

    def __init__(self):
        self._base_prices: Dict[str, float] = {}     # sku -> base_price
        self._promotions: Dict[str, Dict] = {}
        self._member_prices: Dict[str, Dict] = {}    # member_level -> {sku: price}
        self._lock = threading.Lock()

    def set_price(self, sku: str, price: float):
        with self._lock:
            self._base_prices[sku] = price

    def add_promotion(self, promo_id: str, promo_type: str, sku: str,
                      value: float, min_qty: int = 1,
                      valid_from: str = None, valid_until: str = None,
                      max_uses: int = 0) -> Dict:
        with self._lock:
            promo = {
                "promo_id": promo_id, "type": promo_type, "sku": sku,
                "value": value, "min_qty": min_qty,
                "valid_from": valid_from, "valid_until": valid_until,
                "max_uses": max_uses, "used_count": 0,
                "created_at": datetime.utcnow().isoformat(), "enabled": True,
            }
            self._promotions[promo_id] = promo
            return promo

    def calculate_price(self, sku: str, quantity: int = 1,
                        member_level: str = None, promo_code: str = None) -> Dict:
        with self._lock:
            base = self._base_prices.get(sku, 0.0)
            original_total = base * quantity
            final_price = original_total
            applied_promos = []

            # 会员价
            if member_level and member_level in self._member_prices:
                mp = self._member_prices[member_level].get(sku)
                if mp:
                    final_price = mp * quantity
                    applied_promos.append({"type": "member_price", "sku": sku, "price": mp})

            # 促销码
            if promo_code and promo_code in self._promotions:
                promo = self._promotions[promo_code]
                if promo["enabled"] and promo["sku"] == sku and quantity >= promo["min_qty"]:
                    if promo["type"] == PromotionType.PERCENT_OFF.value:
                        discount = final_price * (promo["value"] / 100.0)
                        final_price -= discount
                    elif promo["type"] == PromotionType.FIXED_AMOUNT.value:
                        final_price -= promo["value"]
                    final_price = max(final_price, 0)
                    applied_promos.append({"type": promo["type"], "promo_id": promo_code,
                                           "value": promo["value"]})
                    promo["used_count"] += 1

            return {
                "sku": sku, "base_price": base, "quantity": quantity,
                "original_total": original_total, "final_price": round(final_price, 2),
                "discount": round(original_total - final_price, 2),
                "applied_promos": applied_promos,
            }

    def set_member_price(self, level: str, sku: str, price: float):
        with self._lock:
            if level not in self._member_prices:
                self._member_prices[level] = {}
            self._member_prices[level][sku] = price

    def list_promotions(self) -> List[Dict]:
        with self._lock:
            return list(self._promotions.values())


# ─── 推荐引擎 ──────────────────────────────────────────────────

class RecommendationEngine:
    """协同过滤推荐"""

    def __init__(self):
        self._user_views: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
        self._user_purchases: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
        self._co_occurrence: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))

    def record_view(self, user_id: str, sku: str):
        self._user_views[user_id][sku] += 1

    def record_purchase(self, user_id: str, items: List[str]):
        for i, sku_a in enumerate(items):
            self._user_purchases[user_id][sku_a] += 1
            for sku_b in items[i + 1:]:
                self._co_occurrence[sku_a][sku_b] += 1
                self._co_occurrence[sku_b][sku_a] += 1

    def recommend(self, sku: str, limit: int = 10) -> List[Tuple[str, int]]:
        """基于协同过滤推荐：购买A的人也买了B"""
        scores = self._co_occurrence.get(sku, {})
        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:limit]
        return ranked

    def recommend_for_user(self, user_id: str, limit: int = 10) -> List[Tuple[str, float]]:
        """基于用户历史行为的推荐"""
        purchased = set(self._user_purchases[user_id].keys())
        viewed = set(self._user_views[user_id].keys())
        score_map: Dict[str, float] = defaultdict(float)
        for sku in purchased:
            for related, count in self._co_occurrence.get(sku, {}).items():
                if related not in purchased:
                    score_map[related] += count
        for sku in viewed:
            for related, count in self._co_occurrence.get(sku, {}).items():
                if related not in purchased:
                    score_map[related] += count * 0.3
        ranked = sorted(score_map.items(), key=lambda x: x[1], reverse=True)[:limit]
        return ranked


# ─── 购物车 ──────────────────────────────────────────────────

class CartManager:
    def __init__(self):
        self._carts: Dict[str, Dict[str, Dict]] = defaultdict(dict)  # user_id -> {sku: {qty, added_at}}

    def add_item(self, user_id: str, sku: str, quantity: int = 1):
        if sku in self._carts[user_id]:
            self._carts[user_id][sku]["quantity"] += quantity
        else:
            self._carts[user_id][sku] = {"sku": sku, "quantity": quantity,
                                          "added_at": datetime.utcnow().isoformat()}

    def remove_item(self, user_id: str, sku: str):
        self._carts[user_id].pop(sku, None)

    def get_cart(self, user_id: str) -> List[Dict]:
        return list(self._carts.get(user_id, {}).values())

    def clear_cart(self, user_id: str):
        self._carts[user_id] = {}

    def get_total_items(self, user_id: str) -> int:
        return sum(item["quantity"] for item in self._carts.get(user_id, {}).values())


# ─── 主模块 ──────────────────────────────────────────────────

class EcommerceAgent(EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin):
    """
    AUTO-EVO-AI v6.39 — E-Commerce Agent (Production Grade)
    企业级电商智能体：商品/订单/库存/定价/购物车/推荐/促销/退款
    """

    MODULE_ID = "ecommerce_agent"
    MODULE_NAME = "EcommerceAgent"
    VERSION = "2.0.0"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._inventory = InventoryEngine()
        self._pricing = PricingEngine()
        self._recommender = RecommendationEngine()
        self._cart = CartManager()
        self._products: Dict[str, Dict] = {}       # sku -> product_info
        self._orders: Dict[str, Dict] = {}
        self._payments: Dict[str, Dict] = {}
        self._refunds: Dict[str, Dict] = {}
        self._lock = threading.Lock()

    def execute(self, action: str = "status", params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        return self._dispatch(action, params)

    def _dispatch(self, action: str, params: Dict) -> Dict[str, Any]:
        actions = {
            "status": self._action_status,
            "stats": self._action_stats,
            "health": self._action_health,
            "configure": self._action_configure,
            "reset": self._action_reset,
            # 商品
            "add_product": self._action_add_product,
            "list_products": self._action_list_products,
            "get_product": self._action_get_product,
            "update_product": self._action_update_product,
            # 库存
            "stock_info": self._action_stock_info,
            "restock": self._action_restock,
            "stock_alerts": self._action_stock_alerts,
            "list_inventory": self._action_list_inventory,
            # 价格
            "set_price": self._action_set_price,
            "calculate_price": self._action_calculate_price,
            "add_promotion": self._action_add_promotion,
            "list_promotions": self._action_list_promotions,
            "set_member_price": self._action_set_member_price,
            # 购物车
            "cart_add": self._action_cart_add,
            "cart_remove": self._action_cart_remove,
            "cart_get": self._action_cart_get,
            "cart_clear": self._action_cart_clear,
            # 订单
            "create_order": self._action_create_order,
            "get_order": self._action_get_order,
            "list_orders": self._action_list_orders,
            "update_order_status": self._action_update_order_status,
            # 支付
            "pay_order": self._action_pay_order,
            "refund_order": self._action_refund_order,
            # 推荐
            "recommend": self._action_recommend,
            "recommend_user": self._action_recommend_user,
            "record_view": self._action_record_view,
        }
        handler = actions.get(action)
        if not handler:
            return {"success": False, "error": f"Unknown action: {action}", "available": list(actions.keys())}
        try:
            return handler(params)
        except Exception as e:
            self.logger.error(f"EcommerceAgent.{action} error: {e}")
            return {"success": False, "error": str(e), "action": action}

    def _action_status(self, params: Dict) -> Dict:
        return {"success": True, "data": {
            "module": "EcommerceAgent", "version": self.VERSION, "state": "active",
            "products": len(self._products), "orders": len(self._orders),
            "promotions": len(self._pricing.list_promotions()),
        }}

    def _action_stats(self, params: Dict) -> Dict:
        total_revenue = sum(o.get("paid_amount", 0) for o in self._orders.values()
                           if o.get("payment_status") == PaymentStatus.PAID.value)
        return {"success": True, "data": {
            "total_products": len(self._products), "total_orders": len(self._orders),
            "total_revenue": round(total_revenue, 2),
            "refunds": len(self._refunds), "promotions": len(self._pricing.list_promotions()),
        }}

    def _action_health(self, params: Dict) -> Dict:
        return {"success": True, "data": {"healthy": True, "inventory_ok": True, "pricing_ok": True}}

    def _action_configure(self, params: Dict) -> Dict:
        return {"success": True, "data": {"configured": True}}

    def _action_reset(self, params: Dict) -> Dict:
        self._inventory = InventoryEngine()
        self._pricing = PricingEngine()
        self._recommender = RecommendationEngine()
        self._cart = CartManager()
        self._products = {}
        self._orders = {}
        self._payments = {}
        self._refunds = {}
        return {"success": True, "data": {"reset": True}}

    # 商品
    def _action_add_product(self, params: Dict) -> Dict:
        sku = params.get("sku", "")
        name = params.get("name", "")
        category = params.get("category", "default")
        price = float(params.get("price", 0))
        stock = int(params.get("stock", 0))
        if not sku:
            return {"success": False, "error": "sku required"}
        product = {
            "sku": sku, "name": name, "category": category,
            "price": price, "stock": stock,
            "created_at": datetime.utcnow().isoformat(),
        }
        self._products[sku] = product
        self._pricing.set_price(sku, price)
        if stock > 0:
            self._inventory.add_product(sku, stock)
        self.audit("add_product", f"sku={sku} name={name}")
        return {"success": True, "data": product}

    def _action_list_products(self, params: Dict) -> Dict:
        category = params.get("category")
        products = list(self._products.values())
        if category:
            products = [p for p in products if p.get("category") == category]
        return {"success": True, "data": {"products": products, "total": len(products)}}

    def _action_get_product(self, params: Dict) -> Dict:
        sku = params.get("sku", "")
        if sku not in self._products:
            return {"success": False, "error": f"Product not found: {sku}"}
        return {"success": True, "data": self._products[sku]}

    def _action_update_product(self, params: Dict) -> Dict:
        sku = params.get("sku", "")
        if sku not in self._products:
            return {"success": False, "error": f"Product not found: {sku}"}
        for k in ("name", "category", "price"):
            if k in params:
                self._products[sku][k] = params[k]
        if "price" in params:
            self._pricing.set_price(sku, float(params["price"]))
        self._products[sku]["updated_at"] = datetime.utcnow().isoformat()
        return {"success": True, "data": self._products[sku]}

    # 库存
    def _action_stock_info(self, params: Dict) -> Dict:
        sku = params.get("sku", "")
        return {"success": True, "data": self._inventory.get_stock(sku)}

    def _action_restock(self, params: Dict) -> Dict:
        sku = params.get("sku", "")
        quantity = int(params.get("quantity", 0))
        if not sku or quantity <= 0:
            return {"success": False, "error": "sku and quantity>0 required"}
        self._inventory.restock(sku, quantity)
        return {"success": True, "data": {"sku": sku, "restocked": quantity}}

    def _action_stock_alerts(self, params: Dict) -> Dict:
        threshold = int(params.get("threshold", 10))
        alerts = self._inventory.low_stock_alerts(threshold)
        return {"success": True, "data": {"alerts": alerts, "count": len(alerts)}}

    def _action_list_inventory(self, params: Dict) -> Dict:
        items = self._inventory.list_all()
        return {"success": True, "data": {"items": items, "total": len(items)}}

    # 价格
    def _action_set_price(self, params: Dict) -> Dict:
        sku = params.get("sku", "")
        price = float(params.get("price", 0))
        self._pricing.set_price(sku, price)
        return {"success": True, "data": {"sku": sku, "price": price}}

    def _action_calculate_price(self, params: Dict) -> Dict:
        sku = params.get("sku", "")
        quantity = int(params.get("quantity", 1))
        member_level = params.get("member_level")
        promo_code = params.get("promo_code")
        return {"success": True, "data": self._pricing.calculate_price(sku, quantity, member_level, promo_code)}

    def _action_add_promotion(self, params: Dict) -> Dict:
        promo_id = params.get("promo_id", f"promo_{int(time.time())}")
        promo = self._pricing.add_promotion(
            promo_id, params.get("type", "percent_off"),
            params.get("sku", ""), float(params.get("value", 0)),
            int(params.get("min_qty", 1)), params.get("valid_from"),
            params.get("valid_until"), int(params.get("max_uses", 0))
        )
        return {"success": True, "data": promo}

    def _action_list_promotions(self, params: Dict) -> Dict:
        promos = self._pricing.list_promotions()
        return {"success": True, "data": {"promotions": promos, "total": len(promos)}}

    def _action_set_member_price(self, params: Dict) -> Dict:
        level = params.get("level", "")
        sku = params.get("sku", "")
        price = float(params.get("price", 0))
        self._pricing.set_member_price(level, sku, price)
        return {"success": True, "data": {"level": level, "sku": sku, "price": price}}

    # 购物车
    def _action_cart_add(self, params: Dict) -> Dict:
        user_id = params.get("user_id", "anonymous")
        sku = params.get("sku", "")
        quantity = int(params.get("quantity", 1))
        self._cart.add_item(user_id, sku, quantity)
        return {"success": True, "data": {"user_id": user_id, "sku": sku, "added": quantity}}

    def _action_cart_remove(self, params: Dict) -> Dict:
        user_id = params.get("user_id", "anonymous")
        sku = params.get("sku", "")
        self._cart.remove_item(user_id, sku)
        return {"success": True, "data": {"user_id": user_id, "sku": sku, "removed": True}}

    def _action_cart_get(self, params: Dict) -> Dict:
        user_id = params.get("user_id", "anonymous")
        items = self._cart.get_cart(user_id)
        return {"success": True, "data": {"user_id": user_id, "items": items, "total_items": self._cart.get_total_items(user_id)}}

    def _action_cart_clear(self, params: Dict) -> Dict:
        user_id = params.get("user_id", "anonymous")
        self._cart.clear_cart(user_id)
        return {"success": True, "data": {"cleared": True}}

    # 订单
    def _action_create_order(self, params: Dict) -> Dict:
        user_id = params.get("user_id", "anonymous")
        items = params.get("items", [])  # [{sku, quantity}]
        if not items:
            return {"success": False, "error": "items required"}
        order_id = f"ORD-{uuid.uuid4().hex[:12].upper()}"
        order_items = []
        total = 0.0
        all_reserved = True
        reserve_errors = []
        for item in items:
            sku = item["sku"]
            qty = item.get("quantity", 1)
            price_info = self._pricing.calculate_price(sku, qty)
            ok, msg = self._inventory.reserve(sku, qty)
            if not ok:
                all_reserved = False
                reserve_errors.append({"sku": sku, "error": msg})
            order_items.append({"sku": sku, "quantity": qty, **price_info})
            total += price_info["final_price"]
        if not all_reserved:
            # 释放已预留的
            for item in items:
                self._inventory.release_reservation(item["sku"], item.get("quantity", 1))
            return {"success": False, "error": "insufficient stock", "details": reserve_errors}
        order = {
            "order_id": order_id, "user_id": user_id,
            "items": order_items, "total": round(total, 2),
            "status": OrderStatus.PENDING.value,
            "payment_status": PaymentStatus.PENDING.value,
            "created_at": datetime.utcnow().isoformat(),
        }
        with self._lock:
            self._orders[order_id] = order
        # 记录购买用于推荐
        skus = [item["sku"] for item in items]
        self._recommender.record_purchase(user_id, skus)
        self.audit("create_order", f"order_id={order_id} total={total}")
        return {"success": True, "data": order}

    def _action_get_order(self, params: Dict) -> Dict:
        order_id = params.get("order_id", "")
        if order_id not in self._orders:
            return {"success": False, "error": f"Order not found: {order_id}"}
        return {"success": True, "data": self._orders[order_id]}

    def _action_list_orders(self, params: Dict) -> Dict:
        user_id = params.get("user_id")
        status = params.get("status")
        orders = list(self._orders.values())
        if user_id:
            orders = [o for o in orders if o.get("user_id") == user_id]
        if status:
            orders = [o for o in orders if o.get("status") == status]
        return {"success": True, "data": {"orders": orders, "total": len(orders)}}

    def _action_update_order_status(self, params: Dict) -> Dict:
        order_id = params.get("order_id", "")
        new_status = params.get("status", "")
        if order_id not in self._orders:
            return {"success": False, "error": f"Order not found: {order_id}"}
        old = self._orders[order_id]["status"]
        self._orders[order_id]["status"] = new_status
        self._orders[order_id]["updated_at"] = datetime.utcnow().isoformat()
        # shipped/delivered时扣减库存
        if new_status == OrderStatus.SHIPPED.value:
            for item in self._orders[order_id]["items"]:
                self._inventory.confirm_deduction(item["sku"], item["quantity"])
        self.audit("update_order_status", f"order_id={order_id} {old}->{new_status}")
        return {"success": True, "data": {"order_id": order_id, "old_status": old, "new_status": new_status}}

    # 支付
    def _action_pay_order(self, params: Dict) -> Dict:
        order_id = params.get("order_id", "")
        method = params.get("method", "alipay")
        if order_id not in self._orders:
            return {"success": False, "error": f"Order not found: {order_id}"}
        order = self._orders[order_id]
        if order["payment_status"] == PaymentStatus.PAID.value:
            return {"success": False, "error": "already paid"}
        payment_id = f"PAY-{uuid.uuid4().hex[:10].upper()}"
        payment = {
            "payment_id": payment_id, "order_id": order_id,
            "amount": order["total"], "method": method,
            "status": PaymentStatus.PAID.value,
            "paid_at": datetime.utcnow().isoformat(),
        }
        self._payments[payment_id] = payment
        order["payment_status"] = PaymentStatus.PAID.value
        order["status"] = OrderStatus.CONFIRMED.value
        order["paid_amount"] = order["total"]
        self.audit("pay_order", f"order_id={order_id} amount={order['total']} method={method}")
        return {"success": True, "data": payment}

    def _action_refund_order(self, params: Dict) -> Dict:
        order_id = params.get("order_id", "")
        reason = params.get("reason", "customer_request")
        if order_id not in self._orders:
            return {"success": False, "error": f"Order not found: {order_id}"}
        order = self._orders[order_id]
        if order["payment_status"] != PaymentStatus.PAID.value:
            return {"success": False, "error": "order not paid, cannot refund"}
        refund_id = f"REF-{uuid.uuid4().hex[:10].upper()}"
        refund = {
            "refund_id": refund_id, "order_id": order_id,
            "amount": order.get("paid_amount", order["total"]),
            "reason": reason,
            "status": PaymentStatus.REFUNDED.value,
            "refunded_at": datetime.utcnow().isoformat(),
        }
        self._refunds[refund_id] = refund
        order["payment_status"] = PaymentStatus.REFUNDED.value
        order["status"] = OrderStatus.REFUNDED.value
        # 恢复库存
        for item in order["items"]:
            self._inventory.restock(item["sku"], item["quantity"])
        self.audit("refund_order", f"order_id={order_id} reason={reason}")
        return {"success": True, "data": refund}

    # 推荐
    def _action_recommend(self, params: Dict) -> Dict:
        sku = params.get("sku", "")
        limit = int(params.get("limit", 10))
        recs = self._recommender.recommend(sku, limit)
        return {"success": True, "data": {"sku": sku, "recommendations": recs}}

    def _action_recommend_user(self, params: Dict) -> Dict:
        user_id = params.get("user_id", "")
        limit = int(params.get("limit", 10))
        recs = self._recommender.recommend_for_user(user_id, limit)
        return {"success": True, "data": {"user_id": user_id, "recommendations": recs}}

    def _action_record_view(self, params: Dict) -> Dict:
        user_id = params.get("user_id", "anonymous")
        sku = params.get("sku", "")
        self._recommender.record_view(user_id, sku)
        return {"success": True, "data": {"user_id": user_id, "sku": sku, "recorded": True}}

    def get_status(self) -> Dict[str, Any]:
        return {"module": "EcommerceAgent", "state": "active",
                "products": len(self._products), "orders": len(self._orders)}

module_class = EcommerceAgent
