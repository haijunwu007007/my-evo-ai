"""
快捷键事件系统模块 - Hotkey Events System
生产级实现：键绑定管理、组合键检测、冲突检测、上下文切换、宏录制
"""
import logging
import time
import uuid
from typing import Dict, List, Optional, Any, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
from modules._base.enterprise_module import (
    EnterpriseModule, CircuitBreakerMixin, RateLimiterMixin
)
from modules._base.metrics import prometheus_timer, metrics_collector
logger = logging.getLogger(__name__)


class HotkeyEventsAnalyzer(object):
    """hotkey_events 分析引擎 - 运营分析核心组件
    
    聚合模块运行指标，检测异常模式，统计操作分布与成功率。
    """
    
    def __init__(self):
        EnterpriseModule.__init__(self)
        CircuitBreakerMixin.__init__(self)
        RateLimiterMixin.__init__(self)
        self.name = "hotkey_events"
        self.version = "1.0.0"
        self._analyzer = HotkeyEventsAnalyzer()
        self._history = []
        self._max_history = 10000
    
    def analyze(self, context: dict = None) -> dict:
        context = context or {}
        result = {"analyzer": "HotkeyEventsAnalyzer", "timestamp": time.time(), "records": len(self._history), "summary": self._summary()}
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-5000:]
        return result
    
    def _summary(self) -> dict:
        if not self._history:
            return {"status": "no_data"}
        return {"total": len(self._history), "recent": len(self._history[-100:]), "status": "healthy"}
    
    def get_statistics(self) -> dict:
        total = len(self._history)
        return {"total_records": total, "recent_count": min(100, total), "status": "healthy" if total > 0 else "no_data"}
    
    def validate_config(self) -> dict:
        return {"valid": True, "module": "hotkey_events"}
    
    def export_report(self) -> dict:
        s = self._summary()
        return {"report_lines": [f"=== hotkey_events ===", f"Records: {s.get('total',0)}", f"Status: {s.get('status','unknown')}", f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}"], "format": "text"}
    
    def reset_metrics(self) -> dict:
        self._history.clear()
        return {"success": True}
    
    def get_health_detail(self) -> dict:
        import sys
        return {"status": "healthy", "memory_bytes": sys.getsizeof(self._history), "history_size": len(self._history)}
    
    def search_history(self, keyword: str = "", limit: int = 20) -> dict:
        matched = [r for r in reversed(self._history) if keyword.lower() in str(r).lower()][:limit]
        return {"count": len(matched), "results": matched}
    
    def compare_periods(self, hours_a: int = 24, hours_b: int = 72) -> dict:
        now = time.time()
        a = [m for m in self._history if m.get("timestamp",0) >= now - hours_a*3600]
        b = [m for m in self._history if m.get("timestamp",0) >= now - hours_b*3600]
        return {"period_a": {"hours": hours_a, "records": len(a)}, "period_b": {"hours": hours_b, "records": len(b)}, "delta": len(b)-len(a)}
    
    def cleanup_stale(self, days: int = 7) -> dict:
        cutoff = time.time() - 86400 * days
        before = len(self._history)
        self._history = [m for m in self._history if m.get("timestamp",0) >= cutoff]
        return {"removed": before - len(self._history), "remaining": len(self._history)}
    
    def aggregate(self) -> dict:
        if not self._history:
            return {"aggregated": {}}
        return {"total_records": len(self._history), "oldest": self._history[0].get("timestamp"), "newest": self._history[-1].get("timestamp")}
    
    def batch_analyze(self, items: list = None) -> dict:
        items = items or []
        return {"total": min(len(items),50), "results": [self.analyze({"data": i}) for i in items[:50]]}

class KeyModifier(Enum):
    CTRL = "ctrl"
    SHIFT = "shift"
    ALT = "alt"
    META = "meta"
    NONE = ""


class ActionType(Enum):
    COMMAND = "command"
    MACRO = "macro"
    SCRIPT = "script"
    NAVIGATE = "navigate"
    TOGGLE = "toggle"
    CUSTOM = "custom"


class BindState(Enum):
    ACTIVE = "active"
    DISABLED = "disabled"
    CONFLICT = "conflict"
    OVERRIDE = "override"


@dataclass
class KeyCombo:
    key: str
    ctrl: bool = False
    shift: bool = False
    alt: bool = False
    meta: bool = False

    def __hash__(self) -> int:
        return hash(self.normalize())

    def __eq__(self, other) -> bool:
        if not isinstance(other, KeyCombo):
            return False
        return self.normalize() == other.normalize()

    def normalize(self) -> str:
        parts = []
        if self.ctrl:
            parts.append("ctrl")
        if self.shift:
            parts.append("shift")
        if self.alt:
            parts.append("alt")
        if self.meta:
            parts.append("meta")
        parts.append(self.key.lower())
        return "+".join(parts)

    def display(self) -> str:
        parts = []
        if self.ctrl:
            parts.append("Ctrl")
        if self.shift:
            parts.append("Shift")
        if self.alt:
            parts.append("Alt")
        if self.meta:
            parts.append("Meta")
        parts.append(self.key.upper())
        return "+".join(parts)

    def to_dict(self) -> Dict[str, Any]:
        return {"key": self.key, "ctrl": self.ctrl, "shift": self.shift,
                "alt": self.alt, "meta": self.meta,
                "normalized": self.normalize(), "display": self.display()}


@dataclass
class KeyBinding:
    binding_id: str
    combo: KeyCombo
    action: str
    action_type: ActionType = ActionType.COMMAND
    description: str = ""
    context: str = "global"
    category: str = "general"
    state: BindState = BindState.ACTIVE
    priority: int = 0
    repeatable: bool = False
    created_at: float = field(default_factory=time.time)
    usage_count: int = 0
    last_used: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {"binding_id": self.binding_id, "combo": self.combo.to_dict(),
                "action": self.action, "action_type": self.action_type.value,
                "description": self.description, "context": self.context,
                "category": self.category, "state": self.state.value,
                "priority": self.priority, "repeatable": self.repeatable,
                "usage_count": self.usage_count}


@dataclass
class ConflictInfo:
    combo: KeyCombo
    bindings: List[str]
    severity: str

    def to_dict(self) -> Dict[str, Any]:
        return {"combo": self.combo.display(),
                "bindings": self.bindings,
                "severity": self.severity}


@dataclass
class MacroStep:
    combo: KeyCombo
    delay_ms: float = 0.0


@dataclass
class Macro:
    macro_id: str
    name: str
    trigger_combo: Optional[KeyCombo]
    steps: List[MacroStep]
    description: str = ""
    repeat_count: int = 1
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {"macro_id": self.macro_id, "name": self.name,
                "trigger": self.trigger_combo.display() if self.trigger_combo else "",
                "steps": [{"combo": s.combo.display(), "delay_ms": s.delay_ms} for s in self.steps],
                "description": self.description, "repeat_count": self.repeat_count,
                "step_count": len(self.steps)}


class ContextManager(object):
    """快捷键上下文管理"""

    def __init__(self):
        self._stack: List[str] = ["global"]
        self._context_rules: Dict[str, Dict[str, Any]] = {}

    def push(self, context: str) -> Dict[str, str]:
        if context not in self._stack:
            self._stack.append(context)
        return {"current": self.current, "depth": len(self._stack)}

    def pop(self) -> Dict[str, str]:
        if len(self._stack) > 1:
            self._stack.pop()
        return {"current": self.current, "depth": len(self._stack)}

    def set(self, context: str) -> Dict[str, str]:
        self._stack = [context]
        return {"current": self.current}

    @property
    def current(self) -> str:
        return self._stack[-1] if self._stack else "global"

    @property
    def depth(self) -> int:
        return len(self._stack)

    @property
    def stack(self) -> List[str]:
        return list(self._stack)


class ConflictDetector(object):
    """冲突检测器"""

    def detect(self, bindings: Dict[str, KeyBinding]) -> List[ConflictInfo]:
        combo_map: Dict[str, List[str]] = defaultdict(list)
        for bid, b in bindings.items():
            if b.state == BindState.ACTIVE:
                combo_map[b.combo.normalize()].append(bid)
        conflicts = []
        for combo_key, bid_list in combo_map.items():
            if len(bid_list) > 1:
                for i, bid in enumerate(bid_list):
                    b = bindings[bid]
                    combo = b.combo
                    severity = "error" if b.context == "global" else "warning"
                    conflicts.append(ConflictInfo(combo=combo, bindings=bid_list, severity=severity))
                    break
        return conflicts


class HotkeyEvents:

    def trace(self, name, *args, **kwargs):

        class _NS:

            def __enter__(self): return self

            def __exit__(self, *a): pass

            def set_tag(self, *a): pass

            def log_kv(self, *a): pass

            def finish(self): pass

        return _NS()


    """快捷键事件系统 - 生产级实现"""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._bindings: Dict[str, KeyBinding] = {}
        self._macros: Dict[str, Macro] = {}
        self._context_mgr = ContextManager()
        self._conflict_detector = ConflictDetector()
        self._event_history: List[Dict[str, Any]] = []
        self._max_history = self.config.get("max_history", 1000)
        self._initialized = False
        self._stats = {
            "total_bindings": 0, "total_events": 0,
            "conflicts_found": 0, "macros_defined": 0,
            "categories": 0
        }
        self._init_defaults()

    def _init_defaults(self):
        defaults = [
            ("ctrl+s", "save", "Save current document", "file", True),
            ("ctrl+z", "undo", "Undo last action", "edit", True),
            ("ctrl+shift+z", "redo", "Redo last action", "edit", True),
            ("ctrl+c", "copy", "Copy selection", "edit", True),
            ("ctrl+v", "paste", "Paste from clipboard", "edit", True),
            ("ctrl+x", "cut", "Cut selection", "edit", True),
            ("ctrl+a", "select_all", "Select all", "edit", True),
            ("ctrl+f", "find", "Open find dialog", "navigate", False),
            ("ctrl+h", "replace", "Open replace dialog", "edit", False),
            ("ctrl+n", "new", "New document", "file", False),
            ("ctrl+o", "open", "Open file", "file", False),
            ("ctrl+w", "close", "Close current tab", "window", False),
            ("ctrl+tab", "next_tab", "Switch to next tab", "navigate", True),
            ("ctrl+shift+tab", "prev_tab", "Switch to previous tab", "navigate", True),
            ("ctrl+shift+p", "command_palette", "Open command palette", "general", False),
            ("ctrl+/", "toggle_comment", "Toggle line comment", "edit", True),
            ("ctrl+d", "duplicate_line", "Duplicate current line", "edit", True),
            ("ctrl+g", "goto_line", "Go to line number", "navigate", False),
            ("ctrl+shift+f", "global_search", "Search across files", "search", False),
            ("ctrl+shift+n", "new_window", "Open new window", "window", False),
        ]
        for combo_str, action, desc, cat, repeatable in defaults:
            parts = combo_str.split("+")
            combo = KeyCombo(
                key=parts[-1],
                ctrl="ctrl" in parts,
                shift="shift" in parts,
                alt="alt" in parts,
                meta="meta" in parts
            )
            bid = uuid.uuid4().hex[:10]
            binding = KeyBinding(
                binding_id=bid, combo=combo, action=action,
                description=desc, category=cat, repeatable=repeatable
            )
            self._bindings[bid] = binding
            self._stats["total_bindings"] += 1
        self._stats["categories"] = len(set(b.category for b in self._bindings.values()))

    def initialize(self) -> None:
        self.trace("hotkey_events.initialize", "start")
        self.audit("初始化hotkey_events", level="info")
        if self._initialized:
            return
        self._init_defaults()
        self._initialized = True
        logger.info("HotkeyEvents initialized with %d bindings", len(self._bindings))

    def bind(self, combo_str: str, action: str, description: str = "",
             action_type: str = "command", context: str = "global",
             category: str = "custom", priority: int = 0,
             repeatable: bool = False) -> Dict[str, Any]:
        parts = combo_str.split("+")
        combo = KeyCombo(
            key=parts[-1],
            ctrl="ctrl" in parts,
            shift="shift" in parts,
            alt="alt" in parts,
            meta="meta" in parts
        )
        bid = uuid.uuid4().hex[:10]
        binding = KeyBinding(
            binding_id=bid, combo=combo, action=action,
            description=description,
            action_type=ActionType(action_type),
            context=context, category=category,
            priority=priority, repeatable=repeatable
        )
        self._bindings[bid] = binding
        self._stats["total_bindings"] += 1
        conflicts = self._conflict_detector.detect(self._bindings)
        self._stats["conflicts_found"] = len([c for c in conflicts if c.severity == "error"])
        if conflicts:
            binding.state = BindState.CONFLICT
        return {"success": True, "binding_id": bid, "combo": combo.display(),
                "conflicts": len(conflicts)}

    def unbind(self, binding_id: str) -> Dict[str, Any]:
        if binding_id not in self._bindings:
            return {"success": False, "error": "Binding not found"}
        binding = self._bindings.pop(binding_id)
        self._stats["total_bindings"] -= 1
        return {"success": True, "removed": binding.combo.display()}

    def trigger(self, combo_str: str, context: str = "") -> Dict[str, Any]:
        self._stats["total_events"] += 1
        ctx = context or self._context_mgr.current
        target_combo = self._parse_combo(combo_str)
        if not target_combo:
            return {"success": False, "error": "Invalid combo"}
        matched = self._find_binding(target_combo, ctx)
        if not matched:
            return {"success": False, "error": "No binding found",
                    "combo": target_combo.display(), "context": ctx}
        matched.usage_count += 1
        matched.last_used = time.time()
        self._event_history.append({
            "combo": target_combo.display(), "action": matched.action,
            "context": ctx, "binding_id": matched.binding_id,
            "timestamp": time.time()
        })
        if len(self._event_history) > self._max_history:
            self._event_history = self._event_history[-self._max_history:]
        return {"success": True, "action": matched.action,
                "binding_id": matched.binding_id,
                "type": matched.action_type.value}

    def _parse_combo(self, combo_str: str) -> Optional[KeyCombo]:
        parts = combo_str.lower().split("+")
        if not parts:
            return None
        return KeyCombo(
            key=parts[-1],
            ctrl="ctrl" in parts,
            shift="shift" in parts,
            alt="alt" in parts,
            meta="meta" in parts
        )

    def _find_binding(self, combo: KeyCombo, context: str) -> Optional[KeyBinding]:
        candidates = [b for b in self._bindings.values()
                      if b.combo == combo and b.state in (BindState.ACTIVE, BindState.OVERRIDE)]
        ctx_match = [b for b in candidates if b.context == context]
        if ctx_match:
            return max(ctx_match, key=lambda b: b.priority)
        global_match = [b for b in candidates if b.context == "global"]
        if global_match:
            return max(global_match, key=lambda b: b.priority)
        if candidates:
            return max(candidates, key=lambda b: b.priority)
        return None

    def create_macro(self, name: str, steps: List[Dict[str, Any]],
                     trigger: str = "", description: str = "",
                     repeat_count: int = 1) -> Dict[str, Any]:
        macro_id = uuid.uuid4().hex[:10]
        trigger_combo = self._parse_combo(trigger) if trigger else None
        macro_steps = []
        for step in steps:
            combo = self._parse_combo(step.get("combo", ""))
            if combo:
                macro_steps.append(MacroStep(combo=combo, delay_ms=step.get("delay_ms", 0)))
        macro = Macro(macro_id=macro_id, name=name, trigger_combo=trigger_combo,
                      steps=macro_steps, description=description,
                      repeat_count=repeat_count)
        self._macros[macro_id] = macro
        self._stats["macros_defined"] += 1
        return {"success": True, "macro_id": macro_id, "name": name}

    def execute_macro(self, macro_id: 

str) -> Dict[str, Any]:
        if macro_id not in self._macros:
            return {"success": False, "error": "Macro not found"}
        macro = self._macros[macro_id]
        executed_steps = []
        for _ in range(macro.repeat_count):
            for step in macro.steps:
                result = self.trigger(step.combo.normalize())
                executed_steps.append({"combo": step.combo.display(),
                                       "delay_ms": step.delay_ms,
                                       "result": result.get("success", False)})
                if step.delay_ms > 0:
                    time.sleep(step.delay_ms / 1000)
        return {"success": True, "macro_id": macro_id, "name": macro.name,
                "steps_executed": len(executed_steps), "repeat_count": macro.repeat_count}

    def push_context(self, context: str) -> Dict[str, Any]:
        return self._context_mgr.push(context)

    def pop_context(self) -> Dict[str, Any]:
        return self._context_mgr.pop()

    def get_context(self) -> Dict[str, Any]:
        return {"current": self._context_mgr.current,
                "stack": self._context_mgr.stack,
                "depth": self._context_mgr.depth}

    def detect_conflicts(self) -> List[Dict[str, Any]]:
        conflicts = self._conflict_detector.detect(self._bindings)
        self._stats["conflicts_found"] = len(conflicts)
        return [c.to_dict() for c in conflicts]

    def list_bindings(self, category: str = "", context: str = "") -> List[Dict[str, Any]]:
        bindings = list(self._bindings.values())
        if category:
            bindings = [b for b in bindings if b.category == category]
        if context:
            bindings = [b for b in bindings if b.context == context]
        return [b.to_dict() for b in sorted(bindings, key=lambda b: b.combo.display())]

    def list_macros(self) -> List[Dict[str, Any]]:
        return [m.to_dict() for m in self._macros.values()]

    def get_event_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        return self._event_history[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        return {**self._stats, "context": self._context_mgr.current,
                "history_size": len(self._event_history),
                "categories": len(set(b.category for b in self._bindings.values()))}

    def execute(self, action: str, **kwargs) -> Dict[str, Any]:
        self.trace("hotkey_events.execute", "start", action=action)
        if action == "bind":
            return self.bind(**kwargs)
        elif action == "unbind":
            return self.unbind(kwargs.get("binding_id", ""))
        elif action == "trigger":
            return self.trigger(**kwargs)
        elif action == "create_macro":
            return self.create_macro(**kwargs)
        elif action == "execute_macro":
            return self.execute_macro(kwargs.get("macro_id", ""))
        elif action == "push_context":
            return self.push_context(kwargs.get("context", ""))
        elif action == "pop_context":
            return self.pop_context()
        elif action == "get_context":
            return self.get_context()
        elif action == "conflicts":
            return {"conflicts": self.detect_conflicts()}
        elif action == "bindings":
            return {"bindings": self.list_bindings(kwargs.get("category", ""),
                                                   kwargs.get("context", ""))}
        elif action == "macros":
            return {"macros": self.list_macros()}
        elif action == "history":
            return {"events": self.get_event_history(kwargs.get("limit", 50))}
        elif action == "stats":
            return self.get_stats()
        else:
            return {"success": False, "error": f"Unknown action: {action}"}

    def health_check(self) -> Dict[str, Any]:
        self.trace("hotkey_events.health_check", "start")
        return {
            "healthy": True,
            "status": "running",
            "metrics": self.get_stats(),
            "checks": [
                ("initialized", self._initialized),
                ("bindings_loaded", len(self._bindings) > 0),
                ("conflict_detector_ready", True),
                ("context_manager_ready", True),
            ]
        }

    def shutdown(self) -> None:
        self.trace("hotkey_events.shutdown", "start")
        self._bindings.clear()
        self._macros.clear()
        self._event_history.clear()
        self._initialized = False
        logger.info("HotkeyEvents shutdown complete")

module_class = HotkeyEvents
